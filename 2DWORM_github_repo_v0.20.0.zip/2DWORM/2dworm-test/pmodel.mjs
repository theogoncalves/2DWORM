/* pMODEL — the link-atom model system, checked without a browser.
   Every decision in the spec has a check here: the ONIOM cap distance on a real C–C bond,
   one cap per bond order with the multi-caps genuinely apart, the linkers frozen and the
   rest of the region free, the map that keeps the original numbering, the warnings that
   name a double bond and a metal without ever refusing the cut, the three refusals that
   are structural impossibilities, a disconnected region, and the round trip putting only
   the free atoms back into an untouched original. */
import { buildModel, applyModel, regionClosure, cutBonds, describe } from '../2dworm/lib/pmodel.js';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol;
const dist = (p, q) => Math.hypot(p.x - q.x, p.y - q.y, p.z - q.z);
const threwSaying = (fn, re) => { try { fn(); return false; } catch (e) { return re.test(e.message); } };

/* ---------------------------------------------------------------- fixtures

   Everything below is built from real bond lengths and real angles: C–C 1.54 Å at 112°,
   C–H 1.09 Å tetrahedral, C=C 1.33 Å, Fe–S 2.30 Å in a tetrahedron, S–H 1.34 Å. Small and
   synthetic, but not invented numbers. */
const D2R = Math.PI / 180, TET = 109.4712206;
const V = (a, b) => [a.x - b.x, a.y - b.y, a.z - b.z];
const unit = (v) => { const n = Math.hypot(...v) || 1; return [v[0] / n, v[1] / n, v[2] / n]; };
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
function frame(u) {
  const ax = Math.abs(u[0]), ay = Math.abs(u[1]), az = Math.abs(u[2]);
  const seed = (ax <= ay && ax <= az) ? [1, 0, 0] : (ay <= az ? [0, 1, 0] : [0, 0, 1]);
  const e1 = unit(cross(u, seed));
  return [e1, unit(cross(u, e1))];
}
/* A point on a cone of half-angle th about axis a, at azimuth ph, distance d from p. */
function cone(p, a, th, ph, d) {
  const [e1, e2] = frame(a);
  const ct = Math.cos(th * D2R), st = Math.sin(th * D2R), cp = Math.cos(ph * D2R), sp = Math.sin(ph * D2R);
  return {
    x: p.x + d * (ct * a[0] + st * (cp * e1[0] + sp * e2[0])),
    y: p.y + d * (ct * a[1] + st * (cp * e1[1] + sp * e2[1])),
    z: p.z + d * (ct * a[2] + st * (cp * e1[2] + sp * e2[2])),
  };
}

/* n-butane, all-trans: four carbons zig-zagging in the xy plane, then the hydrogens —
   three on each terminal carbon, two on each middle carbon. Atom order is C0 C1 C2 C3
   then the hydrogens, grouped by the carbon they hang off. */
function butane() {
  const dx = 1.54 * Math.sin(56 * D2R), dy = 1.54 * Math.cos(56 * D2R);
  const atoms = [
    { elem: 'C', x: 0, y: 0, z: 0 },
    { elem: 'C', x: dx, y: dy, z: 0 },
    { elem: 'C', x: 2 * dx, y: 0, z: 0 },
    { elem: 'C', x: 3 * dx, y: dy, z: 0 },
  ];
  const bonds = [{ a: 0, b: 1, o: 1 }, { a: 1, b: 2, o: 1 }, { a: 2, b: 3, o: 1 }];
  const nb = [[1], [0, 2], [1, 3], [2]];
  const hOf = [[], [], [], []];
  for (let c = 0; c < 4; c++) {
    const p = atoms[c];
    if (nb[c].length === 1) {                       /* terminal: three H on a cone */
      const a = unit(V(p, atoms[nb[c][0]]));        /* points away from the chain */
      for (const ph of [0, 120, 240]) {
        const h = cone(p, a, 180 - TET, ph, 1.09);
        hOf[c].push(atoms.length); bonds.push({ a: c, b: atoms.length, o: 1 });
        atoms.push({ elem: 'H', ...h });
      }
    } else {                                        /* middle: two H on the bisector cone */
      const u1 = unit(V(atoms[nb[c][0]], p)), u2 = unit(V(atoms[nb[c][1]], p));
      const b = unit([-(u1[0] + u2[0]), -(u1[1] + u2[1]), -(u1[2] + u2[2])]);
      const perp = unit(cross(u1, u2));
      for (const s of [1, -1]) {
        const ct = Math.cos(TET / 2 * D2R), st = s * Math.sin(TET / 2 * D2R);
        const h = { x: p.x + 1.09 * (ct * b[0] + st * perp[0]), y: p.y + 1.09 * (ct * b[1] + st * perp[1]), z: p.z + 1.09 * (ct * b[2] + st * perp[2]) };
        hOf[c].push(atoms.length); bonds.push({ a: c, b: atoms.length, o: 1 });
        atoms.push({ elem: 'H', ...h });
      }
    }
  }
  return { struct: { atoms, bonds }, hOf };
}

/* Ethene: C=C at 1.33 Å along x, four hydrogens at 121.3° in the plane, C–H 1.08 Å. */
function ethene() {
  const atoms = [{ elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'C', x: 1.33, y: 0, z: 0 }];
  const bonds = [{ a: 0, b: 1, o: 2 }];
  const ang = 121.3 * D2R, cx = 1.08 * Math.cos(ang), sy = 1.08 * Math.sin(ang);
  for (const [c, sign] of [[0, 1], [0, -1], [1, 1], [1, -1]]) {
    const base = atoms[c].x, dir = c === 0 ? 1 : -1;
    bonds.push({ a: c, b: atoms.length, o: 1 });
    atoms.push({ elem: 'H', x: base + dir * cx, y: sign * sy, z: 0 });
  }
  return { atoms, bonds };
}

/* Fe(SH)4: iron at the origin, four sulfurs on the tetrahedral directions at 2.30 Å, each
   with a hydrogen 1.34 Å further out along the same ray. */
function feSH4() {
  const dirs = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]].map(unit);
  const atoms = [{ elem: 'Fe', x: 0, y: 0, z: 0 }];
  const bonds = [];
  for (const d of dirs) {
    const s = atoms.length;
    atoms.push({ elem: 'S', x: 2.30 * d[0], y: 2.30 * d[1], z: 2.30 * d[2] });
    bonds.push({ a: 0, b: s, o: 1 });
    bonds.push({ a: s, b: atoms.length, o: 1 });
    atoms.push({ elem: 'H', x: 3.64 * d[0], y: 3.64 * d[1], z: 3.64 * d[2] });
  }
  return { atoms, bonds };
}

/* ---------------------------------------------------------------- butane: the central cut */

const { struct: BUT, hOf: HOF } = butane();
const beforeJSON = JSON.stringify(BUT);
const midRegion = [1, 2, ...HOF[1], ...HOF[2]];
const R = buildModel(BUT, midRegion);

check('the region is the two middle carbons and their four hydrogens', R.stats.region === 6);
check('two bonds leave the region: C1–C2 and C3–C4', R.cuts.length === 2
  && R.cuts.every(c => (c.a === 1 && c.b === 0) || (c.a === 2 && c.b === 3)), JSON.stringify(R.cuts));
check('two single-bond cuts make two caps', R.stats.caps === 2 && R.caps.length === 2);
check('the model is six region atoms followed by the caps', R.model.atoms.length === 8
  && R.model.atoms.slice(6).every(a => a.elem === 'H'));

const CAP_D = 1.54 * (0.76 + 0.31) / (0.76 + 0.76);          /* 1.0841 Å */
const capDists = R.caps.map(c => dist(R.model.atoms[c.index], R.model.atoms[c.linker]));
check('each cap sits at the ONIOM scaled distance, 1.54 × 1.07/1.52 = 1.084 Å',
  capDists.every(d => near(d, CAP_D, 1e-9)) && near(CAP_D, 1.0841, 1e-3), capDists.map(d => d.toFixed(4)).join(', '));

/* On a single bond the cap must lie ON the original bond vector, not merely near it. */
const onVector = R.caps.every(c => {
  const L = BUT.atoms[R.map[c.linker]], Rm = BUT.atoms[c.removedOriginal];
  const u = unit(V(Rm, L)), p = R.model.atoms[c.index];
  return near(p.x, L.x + CAP_D * u[0], 1e-9) && near(p.y, L.y + CAP_D * u[1], 1e-9) && near(p.z, L.z + CAP_D * u[2], 1e-9);
});
check('a single-bond cap lies exactly along the original bond vector', onVector);

const linkerModel = [R.map.indexOf(1), R.map.indexOf(2)];
check('the two linkers are held', linkerModel.every(mi => R.frozen.includes(mi) && !R.free.includes(mi)));
check('the caps are held too', R.caps.every(c => R.frozen.includes(c.index)));
check('the four middle hydrogens are free, and nothing else is',
  R.free.length === 4 && R.free.every(mi => BUT.atoms[R.map[mi]].elem === 'H'));
check('free + frozen is the whole model, with no overlap',
  R.free.length + R.frozen.length === R.model.atoms.length
  && R.free.every(i => !R.frozen.includes(i)));
check('the map gives every region atom its original index, in ascending order',
  JSON.stringify(R.map.slice(0, 6)) === JSON.stringify([...midRegion].sort((a, b) => a - b)));
check('a cap has no original index: −1', R.map.slice(6).every(v => v === -1));
check('the C–C bond inside the region survives with its order',
  R.model.bonds.some(b => ((R.map[b.a] === 1 && R.map[b.b] === 2) || (R.map[b.a] === 2 && R.map[b.b] === 1)) && b.o === 1));
check('a linker–cap bond is a single bond',
  R.caps.every(c => R.model.bonds.some(b => ((b.a === c.linker && b.b === c.index) || (b.b === c.linker && b.a === c.index)) && b.o === 1)));
check('a single bond between light atoms raises no warning', R.warnings.length === 0, R.warnings.join(' | '));
check('the notes say the charge may differ and that UFF has no electrostatics',
  R.notes.some(n => /charge/i.test(n)) && R.notes.some(n => /electrostatic/i.test(n)));
check('the notes say this is a model-system guess, not an optimised structure',
  R.notes.some(n => /guess/i.test(n) && /not an optimised structure/i.test(n)));
check('describe() is one sentence with the counts in it',
  /^pMODEL: 6 atoms in the region, 2 cut bonds capped with 2 H, 4 free, 4 held \(2 linkers \+ 2 caps\)\.$/.test(describe(R)), describe(R));
check('buildModel did not touch the structure it was given', JSON.stringify(BUT) === beforeJSON);

/* ---------------------------------------------------------------- the three refusals */

check('an empty region is refused with a sentence', threwSaying(() => buildModel(BUT, []), /region is empty/));
check('a region of indices that are not in the structure is also an empty region',
  threwSaying(() => buildModel(BUT, [999, -3]), /region is empty/));
check('the whole structure as a region says there is nothing to cut',
  threwSaying(() => buildModel(BUT, BUT.atoms.map((_, i) => i)), /nothing to cut/));
check('a structure with no atoms is refused', threwSaying(() => buildModel({ atoms: [], bonds: [] }, [0]), /no atoms/));

/* ---------------------------------------------------------------- ethene: cutting a π bond */

const ETH = ethene();
const E = buildModel(ETH, [0, 2, 3]);                 /* one carbon and its two hydrogens */
check('cutting across a C=C gives one cut of order 2', E.cuts.length === 1 && E.cuts[0].order === 2);
check('a double bond is capped with TWO hydrogens on the same linker',
  E.caps.length === 2 && E.caps[0].linker === E.caps[1].linker);
const eD = E.caps.map(c => dist(E.model.atoms[c.index], E.model.atoms[c.linker]));
/* A multiple bond scales the IDEAL single bond it stands in for, not the shorter measured
   one, so the ratio collapses to rcov(C) + rcov(H) = 1.07 Å — a real C–H, not the 0.94 Å
   the measured 1.33 Å C=C would have given. */
const E_D = (0.76 + 0.76) * (0.76 + 0.31) / (0.76 + 0.76);
check('both caps sit at 1.07 Å, the ideal C–H, not at the scaled measured C=C',
  near(eD[0], E_D, 1e-9) && near(eD[1], E_D, 1e-9) && near(E_D, 1.07, 1e-9)
  && eD[0] > 0.9 && eD[0] < 1.15, eD[0].toFixed(4) + ' Å');
/* The caps must be staggered against the hydrogens the linker already carries — they are
   frozen, so a build that eclipses them can never be relaxed out. */
const linkerH = [2, 3].map(o => E.model.atoms[E.map.indexOf(o)]);
const capH = E.caps.map(c => E.model.atoms[c.index]);
const closest = Math.min(...capH.map(c => Math.min(...linkerH.map(h => dist(c, h)))));
check('the two caps are staggered against the linker\'s own hydrogens, no contact under 1.7 Å',
  closest > 1.7, closest.toFixed(4) + ' Å');
const capSep = dist(E.model.atoms[E.caps[0].index], E.model.atoms[E.caps[1].index]);
check('the two caps are distinct positions, at least 1.5 Å apart', capSep >= 1.5, capSep.toFixed(4) + ' Å');
check('the cut through a double bond is NAMED, not refused',
  E.warnings.some(w => /double bond/.test(w)), E.warnings.join(' | '));
check('cut: "any" turns the warning off and builds the same model',
  (() => { const A = buildModel(ETH, [0, 2, 3], { cut: 'any' }); return A.warnings.length === 0 && A.caps.length === 2; })());

/* A triple bond, for completeness: three caps, all distinct, all at the same distance. */
const ACE = { atoms: [{ elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'C', x: 1.20, y: 0, z: 0 }, { elem: 'H', x: -1.06, y: 0, z: 0 }, { elem: 'H', x: 2.26, y: 0, z: 0 }],
  bonds: [{ a: 0, b: 1, o: 3 }, { a: 0, b: 2, o: 1 }, { a: 1, b: 3, o: 1 }] };
const T = buildModel(ACE, [0, 2]);
const tSep = [dist(T.model.atoms[T.caps[0].index], T.model.atoms[T.caps[1].index]),
  dist(T.model.atoms[T.caps[1].index], T.model.atoms[T.caps[2].index]),
  dist(T.model.atoms[T.caps[0].index], T.model.atoms[T.caps[2].index])];
check('a triple bond is capped with three distinct hydrogens', T.caps.length === 3 && tSep.every(d => d > 1.0), tSep.map(d => d.toFixed(3)).join(', '));
check('a triple-bond cut is named "a triple bond"', T.warnings.some(w => /triple bond/.test(w)));

/* A geometry probe for the azimuth rule, with the linker's remaining substituent bent off
   the axis so that its projection does not vanish: the first cap (azimuth zero) must be the
   one pointing away from that substituent. In linear acetylene the substituent lies along
   the axis and every azimuth is equally good, which is exactly when the world-axis fallback
   takes over — so the rule needs a bent case to be visible at all. */
const BENT = { atoms: [{ elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'C', x: 1.20, y: 0, z: 0 },
  { elem: 'H', x: 0, y: 1.09, z: 0 }, { elem: 'H', x: 2.26, y: 0, z: 0 }],
  bonds: [{ a: 0, b: 1, o: 3 }, { a: 0, b: 2, o: 1 }, { a: 1, b: 3, o: 1 }] };
const B3 = buildModel(BENT, [0, 2]);
const subst = B3.model.atoms[B3.map.indexOf(2)];
const dToSubst = B3.caps.map(c => dist(B3.model.atoms[c.index], subst));
check('azimuth zero points away from the linker\'s other substituent',
  dToSubst[0] === Math.max(...dToSubst) && dToSubst[0] > dToSubst[1] + 0.2,
  dToSubst.map(d => d.toFixed(3)).join(', '));
check('the azimuth rule is deterministic: the same region twice gives identical caps',
  JSON.stringify(buildModel(BENT, [0, 2]).model.atoms) === JSON.stringify(B3.model.atoms));

/* ---------------------------------------------------------------- a metal cut */

const FES = feSH4();
const M = buildModel(FES, [0]);                        /* the iron alone: four Fe–S cuts */
check('four Fe–S bonds leave a region of just the iron', M.cuts.length === 4 && M.caps.length === 4);
check('the metal cut is named, and the sentence says Fe',
  M.warnings.length > 0 && M.warnings.every(w => /Fe/.test(w)) && M.warnings.some(w => /metal/.test(w)), M.warnings[0]);
check('cut: "any" silences the metal warning too', buildModel(FES, [0], { cut: 'any' }).warnings.length === 0);
check('the Fe–S caps use the iron radius: 2.30 × 1.07/2.37',
  M.caps.every(c => near(dist(M.model.atoms[c.index], M.model.atoms[c.linker]), 2.30 * (1.32 + 0.31) / (1.32 + 1.05), 1e-9)));
/* Cutting on the ligand side instead — the removed atom is the metal. */
const M2 = buildModel(FES, [1, 2]);
check('cutting the other way round names the metal that was removed', M2.warnings.some(w => /Fe/.test(w)));

/* ---------------------------------------------------------------- a disconnected region */

const DIS = buildModel(BUT, [0, ...HOF[0], 3, ...HOF[3]]);   /* the two end methyls, unconnected */
check('a region in two separate pieces still builds', DIS.stats.region === 8);
check('one cut per piece: C1–C2 and C3–C4', DIS.cuts.length === 2
  && DIS.cuts.some(c => c.a === 0 && c.b === 1) && DIS.cuts.some(c => c.a === 3 && c.b === 2));
check('each piece has its own linker', DIS.stats.linkers === 2 && DIS.caps.length === 2);
check('the model has no bond between the two pieces',
  !DIS.model.bonds.some(b => {
    const oa = DIS.map[b.a], ob = DIS.map[b.b];
    if (oa < 0 || ob < 0) return false;
    const piece = (o) => (o === 0 || HOF[0].includes(o)) ? 0 : 1;
    return piece(oa) !== piece(ob);
  }));

/* ---------------------------------------------------------------- the helpers */

check('regionClosure returns a Set and drops indices outside the structure',
  (() => { const s = regionClosure(BUT, [1, 2, 2, 99, -1, '3']); return s instanceof Set && s.size === 3 && s.has(1) && s.has(2) && s.has(3); })());
check('cutBonds gives the leaving bonds with the inside atom first',
  (() => { const c = cutBonds(BUT, regionClosure(BUT, midRegion)); return c.length === 2 && c.every(x => midRegion.includes(x.a) && !midRegion.includes(x.b)); })());

/* ---------------------------------------------------------------- applyModel: the round trip */

const relaxed = R.model.atoms.map(a => ({ ...a }));
for (const mi of R.free) relaxed[mi].x += 0.1;
const AP = applyModel(BUT, R, relaxed);

check('applyModel moved exactly the four free hydrogens, by original index',
  JSON.stringify(AP.moved) === JSON.stringify([...HOF[1], ...HOF[2]].sort((a, b) => a - b)), JSON.stringify(AP.moved));
check('maxShift is the 0.1 Å we displaced', near(AP.maxShift, 0.1, 1e-12), AP.maxShift);
check('the moved atoms really moved by +0.1 in x',
  AP.moved.every(i => near(AP.struct.atoms[i].x, BUT.atoms[i].x + 0.1, 1e-12)));
check('the linkers and every outside atom are identical to 1e-12',
  BUT.atoms.every((a, i) => AP.moved.includes(i) || (near(a.x, AP.struct.atoms[i].x, 1e-12) && near(a.y, AP.struct.atoms[i].y, 1e-12) && near(a.z, AP.struct.atoms[i].z, 1e-12))));
check('the atom count is the original one: the caps are gone, the deleted atoms are back',
  AP.struct.atoms.length === BUT.atoms.length && !AP.struct.atoms.some((a, i) => a.elem !== BUT.atoms[i].elem));
check('the bonds come through unchanged', JSON.stringify(AP.struct.bonds) === JSON.stringify(BUT.bonds));
check('applyModel returned a NEW structure and left the original untouched',
  AP.struct !== BUT && AP.struct.atoms[HOF[1][0]] !== BUT.atoms[HOF[1][0]] && JSON.stringify(BUT) === beforeJSON);
check('applying an unrelaxed model moves nothing',
  (() => { const z = applyModel(BUT, R, R.model.atoms); return z.moved.length === 0 && z.maxShift === 0; })());
check('a model of the wrong size is refused with a sentence',
  threwSaying(() => applyModel(BUT, R, [{ x: 0, y: 0, z: 0 }]), /do not belong to each other/));

/* ---------------------------------------------------------------- scale

   A 40,000-atom simple-cubic lattice with ~117,000 bonds and a 30-atom region. The cut
   search walks the bond list once; nothing here is allowed to look at all pairs of atoms. */
const N = 40, LAT = { atoms: [], bonds: [] };
const K = 25;                                                /* 40 × 40 × 25 = 40,000 */
for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) for (let k = 0; k < K; k++) {
  LAT.atoms.push({ elem: 'C', x: i * 1.6, y: j * 1.6, z: k * 1.6 });
}
const at = (i, j, k) => (i * N + j) * K + k;
for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) for (let k = 0; k < K; k++) {
  if (i + 1 < N) LAT.bonds.push({ a: at(i, j, k), b: at(i + 1, j, k), o: 1 });
  if (j + 1 < N) LAT.bonds.push({ a: at(i, j, k), b: at(i, j + 1, k), o: 1 });
  if (k + 1 < K) LAT.bonds.push({ a: at(i, j, k), b: at(i, j, k + 1), o: 1 });
}
const bigRegion = [];
for (let i = 10; i < 13; i++) for (let j = 10; j < 13; j++) for (let k = 10; k < 15; k++) if (bigRegion.length < 30) bigRegion.push(at(i, j, k));
const t0 = Date.now();
const BIG = buildModel(LAT, bigRegion);
const ms = Date.now() - t0;
check('40,000 atoms, a 30-atom region, built in under 200 ms',
  ms < 200 && BIG.stats.region === 30 && BIG.caps.length > 0,
  `${ms} ms, ${LAT.atoms.length} atoms, ${LAT.bonds.length} bonds, ${BIG.caps.length} caps`);
check('the big model contains only the region and its caps',
  BIG.model.atoms.length === 30 + BIG.caps.length);

const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
