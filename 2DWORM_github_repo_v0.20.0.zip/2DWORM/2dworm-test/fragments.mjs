/* THE FRAGMENT LIBRARY AND THE BUILDER — checked without a browser.
   Two halves. The first is DATA: the built-in substituent table has to turn into real
   Cartesian geometry (no NaN, atom 0 the X dummy, methyl tetrahedral, phenyl a proper
   1.395 Å hexagon), and the user-library text format has to survive a round trip through
   a REAL file — fragments_user.xyz as Dante ships it, not a fixture written from memory.
   The second half is GEOMETRY: adding a hydrogen, swapping a hydrogen for a group, and
   deleting atoms with capping. Those three are where a builder is right or embarrassing,
   so the checks are numeric: bond lengths against Cordero radii, angles against the
   hybridisation, and — the one that catches a lazy torsion scan — the demand that a new
   methyl come out STAGGERED rather than eclipsed.
   Every function here must leave its input untouched; the last block deep-compares. */
import fs from 'node:fs';
import {
  FRAGMENTS, listFragments, getFragment, zmatToXYZ, COV, covalentBond,
  parseFragmentXYZ, fragmentToXYZ, registerFragments, removeUserFragment,
  clearUserFragments, userFragmentKeys, userFragmentText, makeFragment,
  normalizeSymbol, formula, perceiveBonds,
  addHydrogenTo, substitute, deleteAtoms,
} from '../2dworm/lib/fragments.js';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const D = (p, q) => Math.hypot(p.x - q.x, p.y - q.y, p.z - q.z);
const near = (a, b, tol) => Math.abs(a - b) <= tol;
const ANG = (p, c, q) => {
  const u = [p.x - c.x, p.y - c.y, p.z - c.z], v = [q.x - c.x, q.y - c.y, q.z - c.z];
  const nu = Math.hypot(...u), nv = Math.hypot(...v);
  return Math.acos(Math.max(-1, Math.min(1, (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (nu * nv)))) * 180 / Math.PI;
};
const finite = a => Number.isFinite(a.x) && Number.isFinite(a.y) && Number.isFinite(a.z);

/* ------------------------------------------------------------------ the built-in table */
{
  const keys = Object.keys(FRAGMENTS);
  let allOk = true, bad = '';
  for (const k of keys) {
    const f = getFragment(k);
    if (!f || !f.atoms.length || f.atoms[0].elem !== 'X' || f.attach !== 1 || !f.atoms.every(finite)) { allOk = false; bad = k; break; }
    if (f.atoms.length < 2) { allOk = false; bad = k; break; }
  }
  check('every built-in fragment resolves: atom 0 is the X dummy, no NaN', allOk, bad ? 'first bad: ' + bad : keys.length + ' fragments');
  check('the aromatic and ring entries are all there', ['Ph', 'Py2', 'Py3', 'Py4', 'Bn', 'Cy'].every(k => FRAGMENTS[k]));
  check('listFragments gives key, label and group for each', (() => {
    const l = listFragments();
    return l.length === keys.length && l.every(e => e.key && e.label && e.group && e.user === false);
  })());
  check('getFragment of an unknown key is null', getFragment('NoSuchThing') === null);
}

/* ------------------------------------------------------------------ the Z-matrix engine */
{
  const a = zmatToXYZ(FRAGMENTS.CH3.zmat);          // X, C, H, H, H
  const C = a[1], H = a.slice(2);
  check('zmat CH3: three hydrogens at 1.09 Å from the carbon', H.length === 3 && H.every(h => near(D(h, C), 1.09, 0.001)));
  const angs = [ANG(H[0], C, H[1]), ANG(H[0], C, H[2]), ANG(H[1], C, H[2])];
  check('zmat CH3: H–C–H is tetrahedral', angs.every(x => near(x, 109.47, 1.0)), angs.map(x => x.toFixed(2)).join(', '));
  check('zmat CH3: the X dummy sits at the origin, the carbon 1.51 Å away', near(Math.hypot(a[0].x, a[0].y, a[0].z), 0, 1e-9) && near(D(a[0], C), 1.51, 1e-6));
}

/* ------------------------------------------------------------------ the phenyl ring */
{
  const f = getFragment('Ph');
  const C = f.atoms.filter(x => x.elem === 'C'), H = f.atoms.filter(x => x.elem === 'H');
  const cx = { x: C.reduce((s, p) => s + p.x, 0) / 6, y: C.reduce((s, p) => s + p.y, 0) / 6, z: C.reduce((s, p) => s + p.z, 0) / 6 };
  check('phenyl: six carbons, all 1.395 Å from the ring centre', C.length === 6 && C.every(p => near(D(p, cx), 1.395, 1e-6)));
  check('phenyl: five hydrogens (the sixth position carries the bond)', H.length === 5);
  check('phenyl: the ring is flat', C.concat(H).every(p => near(p.z, 0, 1e-9)));
}

/* ------------------------------------------------------------------ radii */
{
  check('Cordero radii: C 0.76, H 0.31, O 0.66', COV.C === 0.76 && COV.H === 0.31 && COV.O === 0.66);
  check('covalentBond adds the two radii', near(covalentBond('C', 'C'), 1.52, 1e-9) && near(covalentBond('C', 'H'), 1.07, 1e-9));
  check('an unknown element still gives a usable length', covalentBond('Zz', 'H') > 1 && Number.isFinite(covalentBond('Zz', 'H')));
}

/* ------------------------------------------------------------------ element symbols */
{
  check('normalizeSymbol: symbols, shouting labels, numbered labels', normalizeSymbol('c') === 'C' && normalizeSymbol('FE') === 'Fe' && normalizeSymbol('C12') === 'C' && normalizeSymbol('Cl') === 'Cl');
  check('normalizeSymbol: an atomic number becomes a symbol', normalizeSymbol(8) === 'O' && normalizeSymbol('26') === 'Fe');
  check('normalizeSymbol keeps the X dummy', normalizeSymbol('X') === 'X' && normalizeSymbol('Du') === 'X');
  check('normalizeSymbol on nonsense is null', normalizeSymbol('Qq') === null && normalizeSymbol('') === null);
  check('formula is in Hill order', formula([{ elem: 'O' }, { elem: 'H' }, { elem: 'C' }, { elem: 'H' }, { elem: 'C' }]) === 'C2H2O');
  check('formula without carbon is alphabetical', formula([{ elem: 'O' }, { elem: 'H' }, { elem: 'H' }]) === 'H2O');
}

/* ------------------------------------------------------------------ the real user library */
const USER_TEXT = fs.readFileSync(new URL('../2dworm/fragments_user.xyz', import.meta.url), 'utf8');   // Dante's own library, shipped with the page as the example
{
  const list = parseFragmentXYZ(USER_TEXT);
  check('the real fragments_user.xyz gives four substituents', list.length === 4, list.map(f => f.key).join(', '));
  check('the keys are read from the comment line', list.map(f => f.key).join(',') === 'CF3_example,OTf,OAc,Mes');
  check('a quoted name with spaces is kept whole', list[1] && list[1].name === 'triflate  OSO2CF3');
  check('the group is read too', list.every(f => f.group === 'custom'));
  check('every parsed fragment starts with X and marks the attachment atom as atom 1', list.every(f => f.xyz[0].elem === 'X' && f.xyz.length >= 2));
  /* The attachment atom is the REAL atom closest to the X dummy: carbon in CF3, oxygen in
     both oxygen-donor groups, the ipso carbon in mesityl. */
  check('the attachment atom is the real atom nearest the X dummy', list.map(f => f.xyz[1].elem).join(',') === 'C,O,O,C');
  check('Mes keeps all twenty real atoms', list[3].xyz.length === 21);
  check('bonds are perceived for a fragment given without them', list[2].bonds.length >= 7 && list[2].bonds[0][0] === 0 && list[2].bonds[0][1] === 1);
  check('the label carries the formula', list[0].label.startsWith('CF3'), list[0].label);
}

/* a bare block with no count line and no key= takes the preceding text line as its name */
{
  const bare = 'my little group\nC  0.000  0.000  0.000\nH  0.000  0.000  1.090\nH  1.028  0.000 -0.363\nH -0.514 -0.890 -0.363\nH -0.514  0.890 -0.363\n';
  const l = parseFragmentXYZ(bare);
  check('a headerless block parses, with the text line above it as its name', l.length === 1 && l[0].name === 'my little group', l.length ? l[0].name : 'nothing parsed');
  check('without an X dummy the parent is placed opposite the attachment atom bonds', l.length === 1 && l[0].xyz[0].elem === 'X' && Number.isFinite(l[0].xyz[0].x));
}

/* round trip: a built-in written out and read back gives the same skeleton */
{
  const txt = fragmentToXYZ('Ph');
  const back = parseFragmentXYZ(txt);
  const f = getFragment('Ph');
  check('fragmentToXYZ → parseFragmentXYZ round trip keeps the atoms', back.length === 1 && back[0].xyz.length === f.atoms.length);
  check('the round trip keeps the key and the element sequence', back.length === 1 && back[0].key === 'Ph' && back[0].xyz.map(a => a.elem).join('') === f.atoms.map(a => a.elem).join(''));
  const maxd = back.length ? Math.max(...back[0].xyz.map((a, i) => D(a, f.atoms[i]))) : 9;
  check('the round trip keeps the coordinates to five decimals', maxd < 1e-4, maxd.toExponential(2) + ' Å');
}

/* registering: a user key that collides with a built-in is renamed, never overwritten */
{
  clearUserFragments();
  const mine = parseFragmentXYZ('5\nkey=CH3 name="my methyl" group=custom\nX 0 0 0\nC 0 0 1.51\nH 0 1.028 1.873\nH 0.890 -0.514 1.873\nH -0.890 -0.514 1.873\n');
  const added = registerFragments(mine);
  check('a user key colliding with a built-in gets _u', added[0] === 'CH3_u' && userFragmentKeys().includes('CH3_u'));
  check('the built-in CH3 is untouched', getFragment('CH3').label === FRAGMENTS.CH3.label && getFragment('CH3').user === false);
  check('the user fragment resolves and is flagged user', getFragment('CH3_u').user === true && getFragment('CH3_u').atoms.length === 5);
  check('listFragments now includes the user entry', listFragments().some(e => e.key === 'CH3_u' && e.user === true));
  check('userFragmentText writes the library back out', parseFragmentXYZ(userFragmentText()).length === 1);
  removeUserFragment('CH3_u');
  check('removeUserFragment takes it away again', userFragmentKeys().length === 0 && getFragment('CH3_u') === null);
  registerFragments(parseFragmentXYZ(USER_TEXT));
  check('the whole real library registers at once', userFragmentKeys().length === 4 && getFragment('Mes').atoms.length === 21);
  clearUserFragments();
  check('clearUserFragments empties it', userFragmentKeys().length === 0);
}

/* makeFragment directly, with the X / attach conventions */
{
  const f = makeFragment([{ elem: 'X', x: -1.5, y: 0, z: 0 }, { elem: 'O', x: 0, y: 0, z: 0 }, { elem: 'H', x: 0.3, y: 0.9, z: 0 }], null, { key: 'OHx', name: 'hydroxyl', group: 'hetero' });
  check('makeFragment puts X first, the attachment atom second, and bonds them', f.xyz[0].elem === 'X' && f.xyz[1].elem === 'O' && f.bonds[0][0] === 0 && f.bonds[0][1] === 1);
  check('makeFragment honours an explicit attach= (1-based)', (() => {
    const g = makeFragment([{ elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'O', x: 1.4, y: 0, z: 0 }], null, { key: 'k', attach: 1 });
    return g.xyz[1].elem === 'O';
  })());
}

/* ------------------------------------------------------------------ perceiveBonds */
{
  const b = perceiveBonds([{ elem: 'X', x: -1.5, y: 0, z: 0 }, { elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'H', x: 0, y: 0, z: 1.09 }, { elem: 'H', x: 5, y: 0, z: 0 }]);
  check('perceiveBonds skips the X dummy and ignores distant atoms', b.length === 1 && b[0][0] === 1 && b[0][1] === 2);
}

/* ------------------------------------------------------------------ addHydrogenTo */
const mol = (atoms, bonds) => ({ atoms: atoms.map(a => ({ ...a })), bonds: bonds.map(b => ({ ...b })) });
const minDistTo = (s, i) => Math.min(...s.atoms.map((a, k) => (k === i ? Infinity : D(a, s.atoms[i]))));

{
  /* planar methyl radical: the free direction is straight out of the plane */
  const r3 = 1.09;
  const ch3 = mol([
    { elem: 'C', x: 0, y: 0, z: 0 },
    { elem: 'H', x: r3, y: 0, z: 0 },
    { elem: 'H', x: -r3 / 2, y: r3 * Math.sqrt(3) / 2, z: 0 },
    { elem: 'H', x: -r3 / 2, y: -r3 * Math.sqrt(3) / 2, z: 0 },
  ], [{ a: 0, b: 1, o: 1 }, { a: 0, b: 2, o: 1 }, { a: 0, b: 3, o: 1 }]);
  const out = addHydrogenTo(ch3, 0);
  const h = out.struct.atoms[out.added[0]];
  check('planar CH3 radical: the new H is 1.07 Å from the carbon (Cordero C+H)', near(D(h, out.struct.atoms[0]), 1.07, 1e-6), D(h, out.struct.atoms[0]).toFixed(4));
  check('planar CH3 radical: the new H goes along the plane normal', near(Math.abs(h.z), 1.07, 0.02) && near(Math.hypot(h.x, h.y), 0, 0.05), `z=${h.z.toFixed(3)}`);
  check('planar CH3 radical: the new H is not sitting inside another atom', minDistTo(out.struct, out.added[0]) > 1.0);
  check('the new hydrogen is appended at the END, old indices untouched', out.added[0] === 4 && out.struct.atoms.length === 5 && out.struct.bonds.some(b => (b.a === 0 && b.b === 4) || (b.a === 4 && b.b === 0)));
}
{
  /* water: two saturated bonds, so the new H must leave the plane */
  const th = 104.5 * Math.PI / 180;
  const w = mol([
    { elem: 'O', x: 0, y: 0, z: 0 },
    { elem: 'H', x: 0.96, y: 0, z: 0 },
    { elem: 'H', x: 0.96 * Math.cos(th), y: 0.96 * Math.sin(th), z: 0 },
  ], [{ a: 0, b: 1, o: 1 }, { a: 0, b: 2, o: 1 }]);
  const out = addHydrogenTo(w, 0);
  const h = out.struct.atoms[out.added[0]];
  check('water: the third H is 0.97 Å from O (Cordero O+H)', near(D(h, out.struct.atoms[0]), 0.97, 1e-6));
  check('water: the third H leaves the molecular plane (tetrahedral, not in-plane)', Math.abs(h.z) > 0.5, `|z| = ${Math.abs(h.z).toFixed(3)} Å`);
  const a1 = ANG(h, out.struct.atoms[0], out.struct.atoms[1]);
  check('water: H–O–H to the new hydrogen is near tetrahedral', near(a1, 109.5, 8), a1.toFixed(1) + '°');
}
{
  /* a lone atom: any direction will do, but it must be at the right distance and finite */
  const one = mol([{ elem: 'C', x: 1, y: 2, z: 3 }], []);
  const out = addHydrogenTo(one, 0);
  const h = out.struct.atoms[1];
  check('a lone atom accepts a hydrogen in any direction, at the right length', finite(h) && near(D(h, out.struct.atoms[0]), 1.07, 1e-6));
}
{
  /* ethene with one hydrogen missing: the carbon is unsaturated and two-coordinate, so the
     replacement H belongs in the molecular plane at about 120°, not above it */
  const e = mol([
    { elem: 'C', x: 0, y: 0, z: 0 },
    { elem: 'C', x: 1.33, y: 0, z: 0 },
    { elem: 'H', x: -0.54, y: 0.93, z: 0 },
    { elem: 'H', x: -0.54, y: -0.93, z: 0 },
    { elem: 'H', x: 1.87, y: 0.93, z: 0 },
  ], [{ a: 0, b: 1, o: 2 }, { a: 0, b: 2, o: 1 }, { a: 0, b: 3, o: 1 }, { a: 1, b: 4, o: 1 }]);
  const out = addHydrogenTo(e, 1);
  const h = out.struct.atoms[out.added[0]];
  check('ethene: the missing vinyl H comes back IN the molecular plane', near(h.z, 0, 0.02), `z = ${h.z.toFixed(4)}`);
  const a = ANG(h, out.struct.atoms[1], out.struct.atoms[0]);
  check('ethene: the H–C=C angle is trigonal, about 120°', near(a, 120, 3), a.toFixed(1) + '°');
}

/* ------------------------------------------------------------------ substitute */
const methane = () => {
  const r = 1.09, k = r / Math.sqrt(3);
  return mol([
    { elem: 'C', x: 0, y: 0, z: 0 },
    { elem: 'H', x: k, y: k, z: k },
    { elem: 'H', x: k, y: -k, z: -k },
    { elem: 'H', x: -k, y: k, z: -k },
    { elem: 'H', x: -k, y: -k, z: k },
  ], [{ a: 0, b: 1, o: 1 }, { a: 0, b: 2, o: 1 }, { a: 0, b: 3, o: 1 }, { a: 0, b: 4, o: 1 }]);
};
{
  const out = substitute(methane(), 1, 'CH3');
  const s = out.struct;
  check('methane + CH3 = ethane: eight atoms', s.atoms.length === 8, s.atoms.length + ' atoms');
  check('the new carbon takes the index of the hydrogen it replaced', out.replaced === 1 && s.atoms[1].elem === 'C');
  check('every original index is preserved by the map', out.map.length === 5 && out.map.every((v, i) => v === i));
  check('the three new hydrogens are appended at the end', out.added.join(',') === '5,6,7');
  const cc = D(s.atoms[0], s.atoms[1]);
  check('the C–C bond is the sum of the Cordero radii, 1.52 Å', near(cc, 1.52, 1e-6), cc.toFixed(4) + ' Å');
  const angles = [2, 3, 4].map(i => ANG(s.atoms[i], s.atoms[0], s.atoms[1]));
  check('the old H–C–C angles stay tetrahedral', angles.every(a => near(a, 109.47, 1.5)), angles.map(a => a.toFixed(1)).join(', '));
  const angles2 = out.added.map(i => ANG(s.atoms[i], s.atoms[1], s.atoms[0]));
  check('the new H–C–C angles are tetrahedral too', angles2.every(a => near(a, 109.5, 1.5)), angles2.map(a => a.toFixed(1)).join(', '));
  /* the torsion scan has to choose staggered: eclipsed H···H would be 2.25 Å, staggered 2.47 */
  let mn = Infinity;
  for (const i of out.added) for (const j of [2, 3, 4]) mn = Math.min(mn, D(s.atoms[i], s.atoms[j]));
  check('the new methyl comes out STAGGERED (closest H···H across the bond > 2.3 Å)', mn > 2.3, mn.toFixed(3) + ' Å');
  check('ethane has seven bonds, the C–C one of order 1', s.bonds.length === 7 && s.bonds.some(b => ((b.a === 0 && b.b === 1) || (b.a === 1 && b.b === 0)) && b.o === 1));
  check('substitute says what it did', typeof out.note === 'string' && out.note.length > 10);
}
{
  /* benzene + phenyl: the rings must twist apart, not crash into each other */
  const R = 1.395, atoms = [], bonds = [];
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; atoms.push({ elem: 'C', x: R * Math.cos(a), y: R * Math.sin(a), z: 0 }); }
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, r = R + 1.08; atoms.push({ elem: 'H', x: r * Math.cos(a), y: r * Math.sin(a), z: 0 }); }
  for (let i = 0; i < 6; i++) { bonds.push({ a: i, b: (i + 1) % 6, o: i % 2 ? 2 : 1 }); bonds.push({ a: i, b: 6 + i, o: 1 }); }
  const out = substitute(mol(atoms, bonds), 6, 'Ph');
  const s = out.struct;
  check('benzene + Ph = biphenyl: twenty-two atoms', s.atoms.length === 22, s.atoms.length + ' atoms');
  const oldSet = [1, 2, 3, 4, 5, 7, 8, 9, 10, 11], newSet = out.added.concat([6]);
  let mn = Infinity;
  for (const i of newSet) for (const j of oldSet) mn = Math.min(mn, D(s.atoms[i], s.atoms[j]));
  check('the two rings do not clash: closest inter-ring contact > 1.8 Å', mn > 1.8, mn.toFixed(3) + ' Å');
  const cc = D(s.atoms[0], s.atoms[6]);
  check('the inter-ring C–C bond is 1.52 Å', near(cc, 1.52, 1e-6), cc.toFixed(4));
}
{
  let said = '';
  try { substitute(methane(), 0, 'CH3'); } catch (e) { said = e.message; }
  check('substituting the carbon of methane is refused with a sentence — it has nothing to hang from', said.length > 30 && /hydrogens only/i.test(said), said.slice(0, 60) + '…');
  let said2 = '';
  try { substitute(methane(), 1, 'NoSuchGroup'); } catch (e) { said2 = e.message; }
  check('an unknown fragment key is refused with a sentence', said2.length > 20);
}

/* ------------------------------------------------------------- substitute: whole GROUPS
   Build 26. The atom clicked is the first atom of a group: it leaves with everything on its
   side of the bond to the rest of the molecule, and the substituent takes its place. */
{
  /* ethane: click one methyl carbon — the other carbon is the anchor, the CH3 leaves */
  const e = substitute(methane(), 1, 'CH3').struct;                  // ethane, C at 0 and 1
  const out = substitute(e, 1, 'Ph');
  const s = out.struct;
  check('ethane, click a methyl carbon, Ph: the methyl leaves and toluene comes back (15 atoms)', s.atoms.length === 15, s.atoms.length + ' atoms');
  check('the removed hydrogens are gone from the map, the attachment carbon keeps its slot', out.map[1] === 1 && out.removed === 3 && out.map.filter(v => v < 0).length === 3, JSON.stringify(out.map));
  check('the note names the group by formula', /group of atom 2 \(CH3, 4 atoms\)/.test(out.note), out.note.slice(0, 80));
  const cc = D(s.atoms[0], s.atoms[1]);
  check('the new bond is the covalent length', near(cc, 1.52, 1e-6), cc.toFixed(4));
  check('the ring hydrogens are on the anchor\'s side, not inside the old methyl', s.bonds.length === 15, s.bonds.length + ' bonds');
}
{
  /* tert-butylbenzene: click the central carbon of the tBu — three methyls are bridges too,
     but the ring side is larger, so the whole tBu (13 atoms) is the group that leaves */
  const e0 = substitute(methane(), 1, 'CH3').struct;                 // ethane
  let t = e0;
  t = substitute(t, 2, 'CH3').struct;                                // propane (C0 is now CH2? no: H2 of C0 → CH3)
  t = substitute(t, 3, 'CH3').struct;                                // isobutane: C0 with three CH3
  t = substitute(t, 4, 'Ph').struct;                                 // tBu–Ph: C0 quaternary
  check('tert-butylbenzene is built (24 atoms)', t.atoms.length === 24, t.atoms.length + ' atoms');
  const out = substitute(t, 0, 'CH3');
  check('clicking the quaternary carbon takes the whole tert-butyl with it: toluene (15 atoms)', out.struct.atoms.length === 15 && out.removed === 12, out.struct.atoms.length + ' atoms, ' + out.removed + ' removed — ' + out.note.slice(0, 60));
}
{
  /* propane: the middle carbon has two sides of the same size — refused, with the reason */
  const e0 = substitute(methane(), 1, 'CH3').struct;
  const p = substitute(e0, 5, 'CH3').struct;                          // H on C1 → CH3: propane, C1 in the middle
  let said = '';
  try { substitute(p, 1, 'Ph'); } catch (err) { said = err.message; }
  check('the middle carbon of propane is refused: two groups of the same size', /same size/.test(said), said.slice(0, 70));
  /* and a ring atom, whose every bond is in the ring */
  const R = 1.395, atoms = [], bonds = [];
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; atoms.push({ elem: 'C', x: R * Math.cos(a), y: R * Math.sin(a), z: 0 }); }
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, r = R + 1.08; atoms.push({ elem: 'H', x: r * Math.cos(a), y: r * Math.sin(a), z: 0 }); }
  for (let i = 0; i < 6; i++) { bonds.push({ a: i, b: (i + 1) % 6, o: i % 2 ? 2 : 1 }); bonds.push({ a: i, b: 6 + i, o: 1 }); }
  let said2 = '';
  try { substitute(mol(atoms, bonds), 0, 'CH3'); } catch (err) { said2 = err.message; }
  check('a benzene carbon is refused: every bond in a ring', /in a ring/.test(said2), said2.slice(0, 70));
  /* biphenyl: the ipso carbon has two ring bonds and one bridge — the phenyl leaves */
  const bp = substitute(mol(atoms, bonds), 6, 'Ph').struct;           // 22 atoms, ipso at 6
  const out = substitute(bp, 6, 'OH');
  check('the ipso carbon of biphenyl takes its ring with it: phenol (13 atoms)', out.struct.atoms.length === 13 && out.struct.atoms[6].elem === 'O', out.struct.atoms.length + ' atoms — ' + out.note.slice(0, 70));
}
{
  /* residues ride along: an atom that carries a residue passes it to what is built on it */
  const m = methane(); m.atoms.forEach((a, i) => { a.resn = 'ALA'; a.resi = 7; a.chain = 'B'; a.name = i ? 'H' + i : 'CB'; });
  const h = addHydrogenTo(m, 0);
  const last = h.struct.atoms[h.struct.atoms.length - 1];
  check('a hydrogen added to a residue atom is in that residue, without a name of its own', last.resn === 'ALA' && last.resi === 7 && last.chain === 'B' && !last.name, JSON.stringify(last));
  const s = substitute(m, 1, 'CH3');
  check('a substituent grown on a residue atom is in that residue', s.struct.atoms.slice(1).every(a => a.resn === 'ALA' && a.resi === 7 && a.chain === 'B'));
  check('the attachment atom drops the replaced hydrogen\'s name', !s.struct.atoms[1].name, JSON.stringify(s.struct.atoms[1]));
  const d = deleteAtoms(s.struct, [1]);
  const cap = d.struct.atoms[d.struct.atoms.length - 1];
  check('a cap is in the residue of the atom it caps', cap.elem === 'H' && cap.resn === 'ALA' && cap.resi === 7);
  check('addHydrogenTo reports the closest contact for the crowd warning', typeof h.closest === 'number' && h.closest > 0.5);
}

/* ------------------------------------------------------------------ deleteAtoms */
const ethane = () => {
  const s = substitute(methane(), 1, 'CH3');
  return s.struct;
};
{
  const e = ethane();
  const out = deleteAtoms(e, [1]);                 // the substituted methyl carbon
  const s = out.struct;
  check('deleting a methyl carbon takes its hydrogens with it and caps: methane again', s.atoms.length === 5, s.atoms.length + ' atoms');
  check('one cap was added', out.caps === 1);
  const capIdx = s.atoms.length - 1;
  check('the cap is a hydrogen on the surviving carbon at 1.07 Å', s.atoms[capIdx].elem === 'H' && near(D(s.atoms[capIdx], s.atoms[0]), 1.07, 1e-6), D(s.atoms[capIdx], s.atoms[0]).toFixed(4));
  check('the cap lies along the old C–C direction', (() => {
    const u = [e.atoms[1].x - e.atoms[0].x, e.atoms[1].y - e.atoms[0].y, e.atoms[1].z - e.atoms[0].z];
    const v = [s.atoms[capIdx].x - s.atoms[0].x, s.atoms[capIdx].y - s.atoms[0].y, s.atoms[capIdx].z - s.atoms[0].z];
    const c = (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (Math.hypot(...u) * Math.hypot(...v));
    return near(c, 1, 1e-6);
  })());
  check('the map sends the deleted atoms to -1 and compacts the rest', out.map[0] === 0 && out.map[1] === -1 && out.map[5] === -1 && out.map[2] === 1 && out.map[3] === 2 && out.map[4] === 3, out.map.join(','));
  check('the bonds are remapped, four of them, all to the carbon', s.bonds.length === 4 && s.bonds.every(b => b.a === 0 || b.b === 0));
  check('deleteAtoms says what it did', /cap/i.test(out.note));
}
{
  const e = ethane();
  const out = deleteAtoms(e, [1], { capH: false, withH: true });
  check('with capping off no hydrogen is added', out.caps === 0 && out.struct.atoms.length === 4);
  const out2 = deleteAtoms(e, [1], { capH: true, withH: false });
  check('with withH off only the named atom goes (its hydrogens are left, now bare)', out2.struct.atoms.length === 8 - 1 + 1, out2.struct.atoms.length + ' atoms');
}
{
  let said = '';
  try { deleteAtoms(methane(), [0, 1, 2, 3, 4]); } catch (err) { said = err.message; }
  check('deleting every atom is refused with a sentence', said.length > 20, said.slice(0, 50));
  let said2 = '';
  try { deleteAtoms(methane(), []); } catch (err) { said2 = err.message; }
  check('deleting nothing is refused with a sentence', said2.length > 10);
}

/* ------------------------------------------------------------------ nothing is mutated */
{
  const a = methane(); const before = JSON.stringify(a);
  addHydrogenTo(a, 0); substitute(a, 1, 'CH3'); deleteAtoms(a, [1]);
  check('the input structure is never mutated', JSON.stringify(a) === before);
  const f1 = getFragment('CH3'); f1.atoms[1].x = 99;
  check('getFragment hands out a fresh copy each time', getFragment('CH3').atoms[1].x !== 99);
  const z = JSON.stringify(FRAGMENTS.CH3.zmat);
  zmatToXYZ(FRAGMENTS.CH3.zmat);
  check('zmatToXYZ does not touch the table', JSON.stringify(FRAGMENTS.CH3.zmat) === z);
}

const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
