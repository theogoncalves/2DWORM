/* The RESULTS reader: optimisation steps, IRC points, normal modes.
   The Gaussian checks run against the REAL files in corpus/ and read their expected numbers
   from the files themselves (the first "Frequencies --" line, the list of "SCF Done" values,
   the IRC summary table) rather than from memory. ORCA, xTB and MOPAC have no frequency or
   optimisation output in the corpus, so they are exercised on small fixtures written in each
   program's own format, two cycles each, so that "in order" and "last wins" are proven rather
   than assumed. The point of most checks is PAIRING and UNITS: an energy attached to the wrong
   geometry looks perfectly plausible in a plot, and a heat of formation shown as hartree is
   off by six hundred. */
import { parseResults, parseTrajectoryXYZ, useGeom } from '../2dworm/lib/qcresults.js';
import * as qcgeom from '../2dworm/lib/qcgeom.js';
useGeom(qcgeom);   // the page injects its stamped copy; a test injects the module itself
import { readFileSync } from 'node:fs';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const near = (a, b, t = 1e-6) => Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) <= t;
const finite = (v) => Number.isFinite(v);
const noNaN = (d) => d && Array.from(d).every(finite);
const corpus = (f) => readFileSync(new URL('./corpus/' + f, import.meta.url), 'utf8');
const tryParse = (name, text, fn = parseResults) => {
  try { return fn(text); } catch (e) { check(name + ' parses', false, e.message); return null; }
};

/* ============================================================ Gaussian, real files */
{
  const text = corpus('C18-B9N9.out');
  const t0 = performance.now();
  const r = tryParse('C18-B9N9.out', text);
  const ms = performance.now() - t0;
  if (r) {
    const nStd = (text.match(/Standard orientation:/g) || []).length;
    const scf = [...text.matchAll(/^ SCF Done:\s+E\(\S+\)\s*=\s*(-?\d+\.\d+)/gm)].map(m => +m[1]);
    const freqLines = [...text.matchAll(/^ Frequencies --\s+(.*)$/gm)].map(m => m[1].trim().split(/\s+/).map(Number));
    const nModes = freqLines.reduce((s, l) => s + l.length, 0);
    const firstIR = (text.match(/^ IR Inten\s+--\s+(-?\d+\.\d+)/m) || [])[1];
    check('C18: Gaussian, an optimisation, hartree', r.program === 'Gaussian' && r.kind === 'opt' && r.units.energy === 'hartree', r.note);
    check('C18: one step per Standard orientation block (' + nStd + ')', r.steps.length === nStd && nStd === 43, String(r.steps.length));
    check('C18: every step has 36 atoms and the standard frame', r.steps.every(s => s.atoms && s.atoms.length === 36 && s.frame === 'standard'));
    check('C18: ' + nModes + ' modes, 108 displacements each, no NaN', r.modes.length === nModes && nModes === 102 &&
      r.modes.every(m => m.disp && m.disp.length === 108 && noNaN(m.disp)), String(r.modes.length));
    check('C18: first mode frequency and IR intensity are the first numbers in the file',
      near(r.modes[0].freq, freqLines[0][0], 1e-9) && near(r.modes[0].ir, +firstIR, 1e-9), `${r.modes[0].freq} ${r.modes[0].ir} vs ${freqLines[0][0]} ${firstIR}`);
    check('C18: the modes are in file order and none is imaginary',
      r.modes.every((m, i) => near(m.freq, freqLines.flat()[i], 1e-9)) && r.modes.filter(m => m.freq < 0).length === 0);
    check('C18: first mode vector reads the first row (-0.16 0.08 -0.09) and the last (0.00 0.02 -0.08)',
      near(r.modes[0].disp[0], -0.16, 1e-6) && near(r.modes[0].disp[1], 0.08, 1e-6) && near(r.modes[0].disp[2], -0.09, 1e-6) &&
      near(r.modes[0].disp[105], 0, 1e-6) && near(r.modes[0].disp[106], 0.02, 1e-6) && near(r.modes[0].disp[107], -0.08, 1e-6));
    check('C18: symmetry labels and reduced masses came with the modes', r.modes[0].sym === 'A' && near(r.modes[0].redMass, 12.2181, 1e-9) && near(r.modes[0].frc, 0.0004, 1e-9));
    check('C18: 42 SCF Done lines pair with 43 steps: steps 1-41 in order, the re-print after "Stationary point found" inherits step 41, the freq job has its own',
      scf.length === 42 && r.steps.slice(0, 41).every((s, i) => near(s.energy, scf[i], 1e-12)) &&
      near(r.steps[41].energy, scf[40], 1e-12) && r.steps[41].inherited === true && r.steps[41].final === true &&
      near(r.steps[42].energy, scf[41], 1e-12) && !r.steps[42].inherited, JSON.stringify([r.steps[40].energy, r.steps[41].energy, r.steps[42].energy]));
    check('C18: every step has a finite energy (as many energies as steps)', r.steps.every(s => finite(s.energy)));
    check('C18: the energy of a step is the SCF printed AFTER its geometry, not before (step 2 = second SCF Done)', near(r.steps[1].energy, scf[1], 1e-12) && !near(r.steps[1].energy, scf[0], 1e-12));
    check('C18: the optimisation steps are the first 42, the freq job\'s geometry is a freq step in job 2',
      r.steps.slice(0, 42).every(s => s.kind === 'opt' && s.job === 1) && r.steps[42].kind === 'freq' && r.steps[42].job === 2);
    const tables = r.steps.filter(s => s.converged);
    const lastOpt = r.steps.filter(s => s.kind === 'opt' && s.converged).pop();
    check('C18: 42 convergence tables; the last optimisation step (41) has all four ticks', tables.length === 42 && lastOpt && lastOpt.n === 41 && lastOpt.converged.all &&
      ['maxForce', 'rmsForce', 'maxDisp', 'rmsDisp'].every(k => lastOpt.converged[k].ok && finite(lastOpt.converged[k].value) && finite(lastOpt.converged[k].threshold)), JSON.stringify(lastOpt && lastOpt.converged));
    check('C18: the first step is not converged and its numbers are the file\'s (max force 0.006346 / 0.000450)',
      r.steps[0].converged && !r.steps[0].converged.all && near(r.steps[0].converged.maxForce.value, 0.006346, 1e-9) && near(r.steps[0].converged.maxForce.threshold, 0.00045, 1e-9));
    check('C18: the freq job\'s own table is read honestly — forces YES, displacements NO (the analytic-Hessian quirk)',
      r.steps[42].converged && r.steps[42].converged.maxForce.ok && !r.steps[42].converged.maxDisp.ok && !r.steps[42].converged.rmsDisp.ok && !r.steps[42].converged.all);
    check('C18: stationary point found, normal termination, final energy is the last SCF', r.converged === true && r.termination === 'normal' && near(r.energy, scf[41], 1e-12));
    check('C18: the modes refer to the freq job\'s standard-orientation geometry', r.modeAtoms === r.steps[42].atoms);
    check('C18: 2.5 MB parses in under a second', ms < 1000, ms.toFixed(0) + ' ms');
  }
}
{
  const text = corpus('DA_IRC.out');
  const r = tryParse('DA_IRC.out', text);
  if (r) {
    const nPoints = (text.match(/^ Point Number:\s+\d+\s+Path Number:\s+\d+/gm) || []).length;
    const tsE = +(text.match(/Energies reported relative to the TS energy of\s+(-?\d+\.\d+)/) || [])[1];
    const summary = text.slice(text.indexOf('Summary of reaction path following')).split('\n')
      .map(l => l.match(/^\s*(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$/)).filter(Boolean).map(m => ({ dE: +m[2], rc: +m[3] }));
    check('IRC: kind irc, ' + nPoints + ' points, one per "Point Number:" marker and per summary row',
      r.kind === 'irc' && r.steps.length === nPoints && nPoints === 32 && summary.length === 32, r.note);
    check('IRC: every point has 16 atoms, a finite energy and a reaction coordinate', r.steps.every(s => s.atoms && s.atoms.length === 16 && finite(s.energy) && finite(s.rc) && s.kind === 'irc'));
    check('IRC: sorted along the reaction coordinate, reverse path negative, 13 reverse + TS + 18 forward',
      r.steps.every((s, i) => i === 0 || s.rc > r.steps[i - 1].rc) && r.steps.filter(s => s.rc < 0).length === 13 && r.steps.filter(s => s.rc > 0).length === 18 &&
      r.steps.filter(s => s.path === 2).every(s => s.rc < 0));
    const ts = r.steps.find(s => s.point === 0);
    check('IRC: the transition structure sits at rc 0 with the first SCF Done and is the highest point',
      ts && ts.rc === 0 && near(ts.energy, tsE, 1e-6) && r.steps.every(s => s.energy <= ts.energy + 1e-12), String(ts && ts.energy));
    check('IRC: the reaction coordinates are Gaussian\'s own summary, row for row', r.steps.every((s, i) => near(s.rc, summary[i].rc, 1e-9)));
    check('IRC: the energies are Gaussian\'s own summary (corrected end points), row for row, to its printed precision',
      r.steps.every((s, i) => near(s.energy - tsE, summary[i].dE, 1.5e-5)), JSON.stringify(r.steps.slice(0, 3).map((s, i) => [s.energy - tsE, summary[i].dE])));
    check('IRC: a point\'s geometry is its CURRENT STRUCTURE (point 1 forward, atom 1 = -0.251236 1.575093 0.701131)',
      (() => { const p = r.steps.find(s => s.path === 1 && s.point === 1); return p && near(p.atoms[0].x, -0.251236) && near(p.atoms[0].y, 1.575093) && near(p.atoms[0].z, 0.701131); })());
    check('IRC: the summary table travels with the result', r.irc && near(r.irc.tsEnergy, tsE, 1e-9) && r.irc.summary.length === 32 && near(r.irc.summary[31].rc, 5.04046, 1e-9));
    check('IRC: no modes, normal termination', r.modes.length === 0 && r.termination === 'normal');
  }
}
{
  const text = corpus('opt_N.out');
  const r = tryParse('opt_N.out', text);
  if (r) {
    const scf = [...text.matchAll(/^ SCF Done:\s+E\(\S+\)\s*=\s*(-?\d+\.\d+)/gm)].map(m => +m[1]);
    check('opt_N: more than one step and the optimisation converged', r.kind === 'opt' && r.steps.length > 1 && r.converged === true, `${r.steps.length} steps`);
    const last = r.steps[r.steps.length - 1];
    const lastTable = r.steps.filter(s => s.converged).pop();
    check('opt_N: the last convergence table has all four ticks', lastTable && lastTable.converged.all && lastTable.n === 5);
    check('opt_N: 6 geometries for 5 SCFs — the last is the converged re-print, same coordinates, same energy, flagged',
      r.steps.length === 6 && scf.length === 5 && last.final && last.inherited && near(last.energy, scf[4], 1e-12) &&
      last.atoms.every((a, i) => a.elem === r.steps[4].atoms[i].elem && near(a.x, r.steps[4].atoms[i].x, 1e-9)));
    check('opt_N: energies in order and strictly from SCF Done', r.steps.slice(0, 5).every((s, i) => near(s.energy, scf[i], 1e-12)));
  }
}
{
  const text = corpus('2-methyloxirane_Raman.out');
  const r = tryParse('2-methyloxirane_Raman.out', text);
  if (r) {
    const firstRaman = +(text.match(/^ Raman Activ --\s+(-?\d+\.\d+)/m) || [])[1];
    const nModes = [...text.matchAll(/^ Frequencies --\s+(.*)$/gm)].reduce((s, m) => s + m[1].trim().split(/\s+/).length, 0);
    check('Raman: a freq job — kind freq, one geometry, converged is null (no optimisation ran)', r.kind === 'freq' && r.steps.length === 1 && r.converged === null && r.steps[0].kind === 'freq');
    check('Raman: ' + nModes + ' modes all with a Raman activity, the first equal to the file', r.modes.length === nModes && nModes === 24 &&
      r.modes.every(m => finite(m.raman)) && near(r.modes[0].raman, firstRaman, 1e-9), String(r.modes[0].raman));
    check('Raman: depolarisation ratios read too', near(r.modes[0].depolarP, 0.7340, 1e-9) && near(r.modes[0].depolarU, 0.8466, 1e-9));
    check('Raman: 10 atoms, vectors of 30', r.steps[0].atoms.length === 10 && r.modes.every(m => m.disp.length === 30 && noNaN(m.disp)));
    check('Raman: the note says Raman', /Raman/.test(r.note), r.note);
  }
}

/* ============================================================ Gaussian, fixtures */
// HCN — a LINEAR molecule, 3N-5 = 4 modes, so the last group holds ONE mode and the row width
// follows it. 3N-6 is always a multiple of three, which is why the corpus cannot show this.
const G_HEAD = ` Entering Gaussian System, Link 0=g16
 Gaussian 16:  ES64L-G16RevC.01
 ----------------------------
 # b3lyp/6-31g(d) freq
 ----------------------------
                         Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          1           0        0.000000    0.000000   -1.630000
      2          6           0        0.000000    0.000000   -0.563000
      3          7           0        0.000000    0.000000    0.590000
 ---------------------------------------------------------------------
 SCF Done:  E(RB3LYP) =  -93.4247896543     A.U. after    9 cycles
`;
const G_HCN = G_HEAD + ` Harmonic frequencies (cm**-1), IR intensities (KM/Mole), Raman scattering
 activities (A**4/AMU), depolarization ratios for plane and unpolarized
 incident light, reduced masses (AMU), force constants (mDyne/A),
 and normal coordinates:
                      1                      2                      3
                     PI                     PI                     SG
 Frequencies --    712.3456               712.3456              2120.1234
 Red. masses --      1.0800                 1.0800                11.9000
 Frc consts  --      0.3228                 0.3228                31.5100
 IR Inten    --     40.1234                40.1234                 0.2345
  Atom  AN      X      Y      Z        X      Y      Z        X      Y      Z
     1   1     0.00   0.97   0.00     0.97   0.00   0.00     0.00   0.00   0.05
     2   6     0.00  -0.18   0.00    -0.18   0.00   0.00     0.00   0.00   0.71
     3   7     0.00   0.08   0.00     0.08   0.00   0.00     0.00   0.00  -0.62
                      4
                     SG
 Frequencies --   3450.6789
 Red. masses --      1.0900
 Frc consts  --      7.6500
 IR Inten    --     60.5432
  Atom  AN      X      Y      Z
     1   1     0.00   0.00   0.99
     2   6     0.00   0.00  -0.08
     3   7     0.00   0.00   0.00

 -------------------
 - Thermochemistry -
 -------------------
 Normal termination of Gaussian 16 at Fri Sep 12 10:00:00 2026.
`;
{
  const r = tryParse('HCN fixture', G_HCN);
  if (r) {
    check('HCN: four modes from a group of three and a group of one — no off-by-one', r.modes.length === 4 &&
      near(r.modes[3].freq, 3450.6789, 1e-9) && near(r.modes[3].ir, 60.5432, 1e-9) && r.modes[3].sym === 'SG' && r.modes[2].sym === 'SG' && r.modes[0].sym === 'PI');
    check('HCN: the single-mode group\'s vector is read at full width (0.99 on H z, -0.08 on C z)', r.modes[3].disp.length === 9 &&
      near(r.modes[3].disp[2], 0.99, 1e-6) && near(r.modes[3].disp[5], -0.08, 1e-6) && near(r.modes[3].disp[8], 0, 1e-6));
    check('HCN: the third column of the first group is the third mode (0.71 on C z)', near(r.modes[2].disp[5], 0.71, 1e-6) && near(r.modes[1].disp[0], 0.97, 1e-6) && near(r.modes[0].disp[1], 0.97, 1e-6));
    check('HCN: a freq job — kind freq, geometry with the modes, energy from SCF Done', r.kind === 'freq' && r.modeAtoms && r.modeAtoms.length === 3 && near(r.energy, -93.4247896543, 1e-12));
  }
}
// water with freq=hpmodes: the high-precision block first (five decimals, transposed), then
// the ordinary block; the vectors must come from the first and the count must not double.
const G_HP = G_HEAD.replace(/Standard orientation:[\s\S]*?-{20,}\n/, 'Standard orientation:\n ---\n Center     Atomic      Atomic             Coordinates (Angstroms)\n Number     Number       Type             X           Y           Z\n ---\n      1          8           0        0.000000    0.000000    0.117000\n      2          1           0        0.000000    0.757000   -0.468000\n      3          1           0        0.000000   -0.757000   -0.468000\n ---\n') +
` Harmonic frequencies (cm**-1), IR intensities (KM/Mole), Raman scattering
 activities (A**4/AMU), depolarization ratios for plane and unpolarized
 incident light, reduced masses (AMU), force constants (mDyne/A),
 and normal coordinates:
                            1           2           3
                           A1          A1          B2
       Frequencies ---  1603.2843   3808.1052   3937.6616
    Reduced masses ---     1.0827      1.0449      1.0819
   Force constants ---     1.6398      8.9294      9.8841
    IR Intensities ---    67.9016      3.8003     28.5213
 Coord Atom Element:
   1     1     8          0.00000     0.00000     0.00000
   2     1     8          0.00000     0.00000     0.06883
   3     1     8          0.07070     0.05025     0.00000
   1     2     1          0.00000     0.00000     0.00000
   2     2     1          0.42871    -0.57977    -0.54622
   3     2     1         -0.56110    -0.39869     0.43119
   1     3     1          0.00000     0.00000     0.00000
   2     3     1         -0.42871     0.57977    -0.54622
   3     3     1         -0.56110    -0.39869    -0.43119
                      1                      2                      3
                     A1                     A1                     B2
 Frequencies --   1603.2843              3808.1052              3937.6616
 Red. masses --      1.0827                 1.0449                 1.0819
 Frc consts  --      1.6398                 8.9294                 9.8841
 IR Inten    --     67.9016                 3.8003                28.5213
  Atom  AN      X      Y      Z        X      Y      Z        X      Y      Z
     1   8     0.00   0.00   0.07     0.00   0.00   0.05     0.00   0.07   0.00
     2   1     0.00   0.43  -0.56     0.00  -0.58  -0.40     0.00  -0.55   0.43
     3   1     0.00  -0.43  -0.56     0.00   0.58  -0.40     0.00  -0.55  -0.43

 -------------------
 - Thermochemistry -
 -------------------
`;
{
  const r = tryParse('hpmodes fixture', G_HP);
  if (r) {
    check('hpmodes: three modes, not six, from the high-precision block', r.modes.length === 3 && /high precision/.test(r.note), r.note);
    check('hpmodes: five-decimal vectors, transposed correctly (mode 1: O z 0.07070, H1 y 0.42871, H1 z -0.56110)',
      near(r.modes[0].disp[2], 0.07070, 1e-6) && near(r.modes[0].disp[4], 0.42871, 1e-6) && near(r.modes[0].disp[5], -0.56110, 1e-6) && near(r.modes[0].disp[0], 0, 1e-9));
    check('hpmodes: mode 3 (B2) reads its own column (O y 0.06883, H2 z -0.43119)', near(r.modes[2].disp[1], 0.06883, 1e-6) && near(r.modes[2].disp[8], -0.43119, 1e-6) &&
      near(r.modes[2].ir, 28.5213, 1e-9) && near(r.modes[2].redMass, 1.0819, 1e-9) && r.modes[2].sym === 'B2');
  }
}
// a transition structure: the imaginary mode is negative and printed first
const G_TS = G_HEAD + ` Harmonic frequencies (cm**-1), IR intensities (KM/Mole), Raman scattering
 activities (A**4/AMU), depolarization ratios for plane and unpolarized
 incident light, reduced masses (AMU), force constants (mDyne/A),
 and normal coordinates:
                      1                      2                      3
                      A                      A                      A
 Frequencies --   -456.7890               712.3456              2120.1234
 Red. masses --      1.0800                 1.0800                11.9000
 Frc consts  --      0.3228                 0.3228                31.5100
 IR Inten    --     40.1234                40.1234                 0.2345
  Atom  AN      X      Y      Z        X      Y      Z        X      Y      Z
     1   1     0.00   0.97   0.00     0.97   0.00   0.00     0.00   0.00   0.05
     2   6     0.00  -0.18   0.00    -0.18   0.00   0.00     0.00   0.00   0.71
     3   7     0.00   0.08   0.00     0.08   0.00   0.00     0.00   0.00  -0.62
`;
{
  const r = tryParse('imaginary fixture', G_TS);
  if (r) check('TS: an imaginary frequency is negative, first, and counted', r.modes.length === 3 && r.modes[0].freq < 0 && near(r.modes[0].freq, -456.789, 1e-9) && r.modes.filter(m => m.freq < 0).length === 1);
}

/* ============================================================ ORCA (fixtures, ORCA 5 layout) */
const ORCA_A = `  O      0.000000    0.000000    0.000000
  H      0.960000    0.000000    0.000000
  H     -0.240000    0.930000    0.000000
`;
const ORCA_B = `  O      0.000000    0.000000    0.000000
  H      0.958000    0.000000    0.000000
  H     -0.240000    0.927000    0.000000
`;
const orcaCoords = (xyz) => `---------------------------------
CARTESIAN COORDINATES (ANGSTROEM)
---------------------------------
${xyz}
----------------------------
CARTESIAN COORDINATES (A.U.)
----------------------------
  NO LB      ZA    FRAG     MASS         X           Y           Z
   0 O     8.0000    0    15.999    0.000000    0.000000    0.000000
   1 H     1.0000    0     1.008    1.814137    0.000000    0.000000
   2 H     1.0000    0     1.008   -0.453534    1.757445    0.000000

`;
const ORCA = `
                                 * O   R   C   A *
           Program Version 5.0.4 -  RELEASE  -

================================================================================
                                       INPUT FILE
================================================================================
NAME = water.inp
|  1> ! B3LYP def2-SVP Opt Freq
|  2> * xyz 0 1
|  6> *
|  7>
` + orcaCoords(ORCA_A) + `
                       *****************************
                       * Geometry Optimization Run *
                       *****************************

                    *************************************************
                    *                GEOMETRY OPTIMIZATION CYCLE   1            *
                    *************************************************
` + orcaCoords(ORCA_A) + `
-------------------------   --------------------
FINAL SINGLE POINT ENERGY       -76.328135001523
-------------------------   --------------------

                                .--------------------.
          ----------------------|Geometry convergence|-------------------------
          Item                value                   Tolerance       Converged
          ---------------------------------------------------------------------
          RMS gradient        0.0123456789            0.0001000000      NO
          MAX gradient        0.0234567890            0.0003000000      NO
          RMS step            0.0234567890            0.0020000000      NO
          MAX step            0.0345678901            0.0040000000      NO
          ........................................................
          Max(Bonds)      0.0183      Max(Angles)    1.52
          Max(Dihed)        0.00      Max(Improp)    0.00
          ---------------------------------------------------------------------

                    *************************************************
                    *                GEOMETRY OPTIMIZATION CYCLE   2            *
                    *************************************************
` + orcaCoords(ORCA_B) + `
-------------------------   --------------------
FINAL SINGLE POINT ENERGY       -76.330012345678
-------------------------   --------------------

                                .--------------------.
          ----------------------|Geometry convergence|-------------------------
          Item                value                   Tolerance       Converged
          ---------------------------------------------------------------------
          Energy change      -0.0000012345            0.0000050000      YES
          RMS gradient        0.0000456789            0.0001000000      YES
          MAX gradient        0.0000789012            0.0003000000      YES
          RMS step            0.0004567890            0.0020000000      YES
          MAX step            0.0007890123            0.0040000000      YES
          ........................................................
          Max(Bonds)      0.0003      Max(Angles)    0.02
          Max(Dihed)        0.00      Max(Improp)    0.00
          ---------------------------------------------------------------------

                    ***********************HURRAY********************
                    ***        THE OPTIMIZATION HAS CONVERGED     ***
                    *************************************************

` + orcaCoords(ORCA_B) + `
                 *******************************************************
                 *** FINAL ENERGY EVALUATION AT THE STATIONARY POINT ***
                 *******************************************************

-------------------------   --------------------
FINAL SINGLE POINT ENERGY       -76.330012345678
-------------------------   --------------------

-----------------------
VIBRATIONAL FREQUENCIES
-----------------------

Scaling factor for frequencies =  1.000000000  (already applied!)

     0:         0.00 cm**-1
     1:         0.00 cm**-1
     2:         0.00 cm**-1
     3:         0.00 cm**-1
     4:         0.00 cm**-1
     5:         0.00 cm**-1
     6:      1638.71 cm**-1
     7:      3795.07 cm**-1
     8:      3907.42 cm**-1


------------
NORMAL MODES
------------

These modes are the Cartesian displacements weighted by the diagonal matrix
M(i,i)=1/sqrt(m[i]) where m[i] is the mass of the displaced atom
Thus, these vectors are normalized but *not* orthogonal

                  0          1          2          3          4          5
      0       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      1       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      2       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      3       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      4       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      5       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      6       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      7       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
      8       0.000000   0.000000   0.000000   0.000000   0.000000   0.000000
                  6          7          8
      0      -0.000000   0.000000   0.070214
      1      -0.049829   0.031253  -0.000000
      2       0.000000   0.000000   0.000000
      3       0.425000  -0.580000  -0.546000
      4       0.395000   0.398000   0.431000
      5       0.000000   0.000000   0.000000
      6      -0.425000   0.580000  -0.546000
      7       0.395000   0.398000  -0.431000
      8       0.000000   0.000000   0.000000


-----------
IR SPECTRUM
-----------

 Mode   freq       eps      Int      T**2         TX        TY        TZ
       cm**-1   L/(mol*cm) km/mol    a.u.^2      (a.u.)    (a.u.)    (a.u.)
----------------------------------------------------------------------------
  6:   1638.71   0.001103   67.90  0.002343  (-0.000000 -0.048410  0.000000)
  7:   3795.07   0.000012    3.80  0.000060  ( 0.000000  0.000000  0.007746)
  8:   3907.42   0.000234   28.52  0.000440  (-0.020976  0.000000  0.000000)

* The epsilon (eps) is given for a Lorentzian that has a width of 40 cm**-1.
* The dipole moment derivative (T) already includes vibrational quantum numbers.

--------------
RAMAN SPECTRUM
--------------

 Mode    freq (cm**-1)   Activity   Depolarization
-------------------------------------------------------------------
   6:      1638.71      3.905010      0.749987
   7:      3795.07     56.123456      0.107654
   8:      3907.42     23.456789      0.750000

                             ****ORCA TERMINATED NORMALLY****
`;
{
  const r = tryParse('ORCA fixture', ORCA);
  if (r) {
    check('ORCA: program, kind opt, hartree', r.program === 'ORCA' && r.kind === 'opt' && r.units.energy === 'hartree', r.note);
    check('ORCA: the input echo folds into cycle 1 — three steps: cycle 1, cycle 2, the final evaluation', r.steps.length === 3 &&
      r.steps[0].cycle === 1 && r.steps[1].cycle === 2 && r.steps[2].final === true, JSON.stringify(r.steps.map(s => [s.cycle, s.energy, s.final])));
    check('ORCA: energies in order, each from the FINAL SINGLE POINT ENERGY after its geometry', near(r.steps[0].energy, -76.328135001523, 1e-12) &&
      near(r.steps[1].energy, -76.330012345678, 1e-12) && near(r.steps[2].energy, -76.330012345678, 1e-12) && near(r.energy, -76.330012345678, 1e-12));
    check('ORCA: geometries in order — cycle 1 is A (H at 0.96), cycle 2 is B (H at 0.958), last wins', near(r.steps[0].atoms[1].x, 0.96) && near(r.steps[1].atoms[1].x, 0.958) && near(r.steps[2].atoms[1].x, 0.958));
    check('ORCA: cycle 1 table without an energy-change row, all NO; cycle 2 all YES, mapped onto the Gaussian names',
      r.steps[0].converged && !r.steps[0].converged.all && !r.steps[0].converged.energyChange && near(r.steps[0].converged.maxForce.value, 0.0234567890, 1e-12) &&
      near(r.steps[0].converged.maxForce.threshold, 0.0003, 1e-12) && r.steps[1].converged.all && r.steps[1].converged.energyChange.ok &&
      near(r.steps[1].converged.rmsDisp.value, 0.0004567890, 1e-12) && r.steps[1].converged.maxDisp.ok, JSON.stringify(r.steps[1].converged));
    check('ORCA: converged, terminated normally', r.converged === true && r.termination === 'normal');
    check('ORCA: three modes, the six zeros left out, ORCA indices kept', r.modes.length === 3 && r.modes.map(m => m.index).join() === '6,7,8' &&
      near(r.modes[0].freq, 1638.71, 1e-9) && near(r.modes[2].freq, 3907.42, 1e-9));
    check('ORCA 5: IR intensity is the Int column (km/mol), not eps and not T**2', near(r.modes[0].ir, 67.90, 1e-9) && near(r.modes[1].ir, 3.80, 1e-9) && near(r.modes[2].ir, 28.52, 1e-9) && near(r.modes[0].eps, 0.001103, 1e-12));
    check('ORCA: Raman activities by column name', near(r.modes[0].raman, 3.905010, 1e-9) && near(r.modes[1].raman, 56.123456, 1e-9));
    check('ORCA: NORMAL MODES column 6 is mode 1\'s vector, 9 long (O y -0.049829, H1 x 0.425, H2 y 0.395)', r.modes[0].disp && r.modes[0].disp.length === 9 &&
      near(r.modes[0].disp[1], -0.049829, 1e-6) && near(r.modes[0].disp[3], 0.425, 1e-6) && near(r.modes[0].disp[7], 0.395, 1e-6) && near(r.modes[2].disp[0], 0.070214, 1e-6));
    check('ORCA: the modes refer to the last geometry', r.modeAtoms === r.steps[2].atoms);
  }
  // ORCA 4 printed "Mode freq (cm**-1) T**2 TX TY TZ" with T**2 already in km/mol: the columns
  // are read by name, so the intensity still comes out right
  const ORCA4 = ORCA.replace(/ Mode   freq       eps      Int      T\*\*2         TX        TY        TZ\n       cm\*\*-1   L\/\(mol\*cm\) km\/mol    a\.u\.\^2      \(a\.u\.\)    \(a\.u\.\)    \(a\.u\.\)\n/,
    ' Mode    freq (cm**-1)   T**2         TX         TY         TZ\n')
    .replace(/  6:   1638.71   0.001103   67.90  0.002343  \(/, '   6:      1638.71   67.900000  (')
    .replace(/  7:   3795.07   0.000012    3.80  0.000060  \(/, '   7:      3795.07    3.800000  (')
    .replace(/  8:   3907.42   0.000234   28.52  0.000440  \(/, '   8:      3907.42   28.520000  (');
  const r4 = tryParse('ORCA 4 table', ORCA4);
  if (r4) check('ORCA 4: with no Int column T**2 is the km/mol intensity', r4.modes.length === 3 && near(r4.modes[0].ir, 67.9, 1e-9) && near(r4.modes[2].ir, 28.52, 1e-9) && r4.modes[0].eps === undefined);
  // an imaginary mode carries ORCA's suffix and a minus sign
  const rI = tryParse('ORCA imaginary', ORCA.replace('     6:      1638.71 cm**-1', '     6:      -456.12 cm**-1 ***imaginary mode***'));
  if (rI) check('ORCA: "***imaginary mode***" is a negative frequency, kept first', rI.modes.length === 3 && near(rI.modes[0].freq, -456.12, 1e-9) && rI.modes.filter(m => m.freq < 0).length === 1);
  // an ORCA trajectory file
  const TRJ = `3
Coordinates from ORCA-job water E -76.328135001523
  O   0.000000   0.000000   0.000000
  H   0.960000   0.000000   0.000000
  H  -0.240000   0.930000   0.000000
3
Coordinates from ORCA-job water E -76.330012345678
  O   0.000000   0.000000   0.000000
  H   0.958000   0.000000   0.000000
  H  -0.240000   0.927000   0.000000
`;
  const rt = tryParse('ORCA _trj.xyz', TRJ);
  if (rt) check('ORCA _trj.xyz: a trajectory, not an ORCA output — two frames, energies from "E", hartree',
    rt.program === 'ORCA' && rt.kind === 'traj' && rt.steps.length === 2 && near(rt.steps[0].energy, -76.328135001523, 1e-12) &&
    near(rt.steps[1].energy, -76.330012345678, 1e-12) && rt.units.energy === 'hartree' && near(rt.steps[1].atoms[1].x, 0.958), rt.note);
}

/* ============================================================ xTB (fixtures, xtb 6.6 layout) */
const XTB = `      -----------------------------------------------------------
     |                   =====================                   |
     |                           x T B                           |
     |                   =====================                   |
     |                         S. Grimme                         |
      -----------------------------------------------------------

   * xtb version 6.6.1 (8d0f1dd) compiled by 'conda@1efc2f54142f' on 2023-08-01

           -------------------------------------------------
          |                   * xtb ANCopt *                 |
           -------------------------------------------------

........................................................................
.............................. CYCLE    1 ..............................
........................................................................
   1     -5.0700000 -0.507000E+01  0.238E-01    2.32       0.0  T
   2     -5.0701300 -0.130000E-03  0.123E-01    2.32       1.0  T
     SCC iter.                  ...        0 min,  0.001 sec
     gradient                   ...        0 min,  0.001 sec
 * total energy  :    -5.0701300 Eh     change       -0.5070130E+01 Eh
   gradient norm :     0.0123456 Eh/α   predicted    -0.0000000E+00 (-100.00%)
   displ. norm   :     0.0234567 α      lambda       -0.1234567E-03
   maximum displ.:     0.0123456 α      in ANC's #3, #1, #2, ...

........................................................................
.............................. CYCLE    2 ..............................
........................................................................
   1     -5.0705444 -0.507054E+01  0.120E-02    2.32       0.0  T
     SCC iter.                  ...        0 min,  0.001 sec
     gradient                   ...        0 min,  0.001 sec
 * total energy  :    -5.0705444 Eh     change       -0.4144000E-03 Eh
   gradient norm :     0.0001553 Eh/α   predicted    -0.4000000E-03 (  -3.47%)
   displ. norm   :     0.0012345 α      lambda       -0.1234567E-06
   maximum displ.:     0.0009876 α      in ANC's #1, #3, #2, ...

   *** GEOMETRY OPTIMIZATION CONVERGED AFTER 2 ITERATIONS ***

------------------------------------------------------------------------
 total energy gain   :        -0.0004144 Eh       -0.2600 kcal/mol
 total RMSD          :         0.0123456 a0        0.0065 Å
------------------------------------------------------------------------

 final structure:
================
$coord
        0.00000000000000        0.00000000000000        0.00000000000000      o
        1.81032183167855        0.00000000000000        0.00000000000000      h
       -0.45354338293264        1.75182258959268        0.00000000000000      h
$end

           -------------------------------------------------
          |               Frequency Printout                |
           -------------------------------------------------
 projected vibrational frequencies (cm⁻¹)
eigval :       -0.00    -0.00    -0.00     0.00     0.00     0.00
eigval :     1538.46  3620.15  3679.56
 reduced masses (amu)
   1:  4.63   2: 12.33   3:  6.59   4:  6.61   5:  4.42   6:  7.37   7:  1.07   8:  1.05
   9:  1.08
 IR intensities (km·mol⁻¹)
   1:  0.00   2:  0.00   3:  0.00   4:  0.00   5:  0.00   6:  0.00   7: 32.32   8:  0.20
   9:  4.32
 Raman intensities (Ä⁴*amu⁻¹)
   1:  0.00   2:  0.00   3:  0.00   4:  0.00   5:  0.00   6:  0.00   7:  0.00   8:  0.00
   9:  0.00
 output can be read by thermo (or use thermo option).
 writing <g98.out> molden fake output.

          -------------------------------------------------
          | TOTAL ENERGY               -5.070544440612 Eh   |
          | GRADIENT NORM               0.000155326990 Eh/α |
          | HOMO-LUMO GAP              14.391396106832 eV   |
          -------------------------------------------------

------------------------------------------------------------------------
 * finished run on 2026/09/12 at 10:00:00.000
------------------------------------------------------------------------
normal termination of xtb
`;
{
  const r = tryParse('xtb output', XTB);
  if (r) {
    check('xtb: program, kind opt, hartree, converged, normal termination', r.program === 'xTB' && r.kind === 'opt' && r.units.energy === 'hartree' && r.converged === true && r.termination === 'normal', r.note);
    check('xtb: two cycles in order with their total energies and gradient norms', r.steps.length === 2 && near(r.steps[0].energy, -5.0701300, 1e-12) &&
      near(r.steps[1].energy, -5.0705444, 1e-12) && near(r.steps[0].gnorm, 0.0123456, 1e-12) && r.steps[0].cycle === 1 && r.steps[1].cycle === 2);
    check('xtb: no geometry per cycle (atoms null) except the final structure on the last, converted from bohr',
      r.steps[0].atoms === null && r.steps[1].final === true && r.steps[1].atoms && r.steps[1].atoms.length === 3 && near(r.steps[1].atoms[1].x, 0.958, 1e-4) && r.steps[1].atoms[0].elem === 'O');
    check('xtb: the final TOTAL ENERGY is the result\'s energy', near(r.energy, -5.070544440612, 1e-12));
    check('xtb: three frequencies after the six projected zeros, IR in km/mol by index, no vectors',
      r.modes.length === 3 && near(r.modes[0].freq, 1538.46, 1e-9) && near(r.modes[0].ir, 32.32, 1e-9) && near(r.modes[2].ir, 4.32, 1e-9) &&
      near(r.modes[0].redMass, 1.07, 1e-9) && r.modes.every(m => m.disp === null) && /g98\.out/.test(r.note), r.note);
    check('xtb: the note sends the reader to xtbopt.log for the geometries', /xtbopt\.log/.test(r.note));
  }
  const XTBOPT_LOG = `3
 energy: -5.070130000000 gnorm: 0.012345678900 xtb: 6.6.1 (8d0f1dd)
O            0.00000000000000        0.00000000000000        0.00000000000000
H            0.96000000000000        0.00000000000000        0.00000000000000
H           -0.24000000000000        0.93000000000000        0.00000000000000
3
 energy: -5.070544440612 gnorm: 0.000155326990 xtb: 6.6.1 (8d0f1dd)
O            0.00000000000000        0.00000000000000        0.00000000000000
H            0.95800000000000        0.00000000000000        0.00000000000000
H           -0.24000000000000        0.92700000000000        0.00000000000000
`;
  const rl = tryParse('xtbopt.log', XTBOPT_LOG);
  if (rl) {
    check('xtbopt.log: two frames, xTB, energies from "energy:", hartree, in order', rl.program === 'xTB' && rl.kind === 'traj' && rl.steps.length === 2 &&
      near(rl.steps[0].energy, -5.07013, 1e-12) && near(rl.steps[1].energy, -5.070544440612, 1e-12) && rl.units.energy === 'hartree' && rl.steps.every(s => s.kind === 'traj'), rl.note);
    check('xtbopt.log: frames in order, ångström as written', near(rl.steps[0].atoms[1].x, 0.96) && near(rl.steps[1].atoms[1].x, 0.958) && rl.steps[1].atoms[2].elem === 'H');
    const rl2 = tryParse('parseTrajectoryXYZ', XTBOPT_LOG, parseTrajectoryXYZ);
    check('parseTrajectoryXYZ is the same reader, exported', rl2 && rl2.steps.length === 2 && near(rl2.steps[1].energy, -5.070544440612, 1e-12));
  }
  // an xtb g98.out — Gaussian-98 style, read by the Gaussian reader, labelled xTB
  const G98 = ` Entering Gaussian System
 *********************************************
 Gaussian 98:
 frequency output generated by the xtb code
 *********************************************
                         Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic     Atomic              Coordinates (Angstroms)
 Number     Number      Type              X           Y           Z
 ---------------------------------------------------------------------
    1          8             0       -0.000000    0.000000    0.114523
    2          1             0        0.000000    0.762851   -0.458092
    3          1             0       -0.000000   -0.762851   -0.458092
 ---------------------------------------------------------------------
     1 basis functions        1 primitive gaussians
     1 alpha electrons        1 beta electrons

 Harmonic frequencies (cm**-1), IR intensities (km*mol⁻¹),
 Raman scattering activities (A**4/amu), Raman depolarization ratios,
 reduced masses (AMU), force constants (mDyne/A) and normal coordinates:
                     1                      2                      3
                     a                      a                      a
 Frequencies --  1538.4636              3620.1478              3679.5563
 Red. masses --     1.0731                 1.0456                 1.0826
 Frc consts  --     1.4969                 8.0704                 8.6390
 IR Inten    --    32.3183                 0.2000                 4.3170
 Raman Activ --     0.0000                 0.0000                 0.0000
 Depolar     --     0.0000                 0.0000                 0.0000
 Atom AN      X      Y      Z        X      Y      Z        X      Y      Z
   1   8     0.00   0.00   0.07     0.00   0.00   0.05     0.00   0.07   0.00
   2   1     0.00   0.42  -0.56     0.00  -0.58  -0.40     0.00  -0.55   0.43
   3   1     0.00  -0.42  -0.56     0.00   0.58  -0.40     0.00  -0.55  -0.43
`;
  const rg = tryParse('g98.out', G98);
  if (rg) check('g98.out: read by the Gaussian reader, labelled xTB, three modes with vectors on the Standard orientation geometry',
    rg.program === 'xTB' && rg.kind === 'freq' && rg.modes.length === 3 && near(rg.modes[0].freq, 1538.4636, 1e-9) && near(rg.modes[0].ir, 32.3183, 1e-9) &&
    rg.modes[0].disp.length === 9 && near(rg.modes[0].disp[4], 0.42, 1e-6) && rg.modeAtoms && rg.modeAtoms.length === 3 && near(rg.modeAtoms[0].z, 0.114523) && rg.steps[0].energy === null, rg.note);
  const VIB = `$vibrational spectrum
#  mode     symmetry     wave number   IR intensity    selection rules
#                         cm**-1        (km/mol)         IR     RAMAN
     1                        -0.00         0.00000        -       -
     2                        -0.00         0.00000        -       -
     3                         0.00         0.00000        -       -
     4                         0.00         0.00000        -       -
     5                         0.00         0.00000        -       -
     6                         0.00         0.00000        -       -
     7        a             1538.46        32.31834        YES     YES
     8        a             3620.15         0.20000        YES     YES
     9        a             3679.56         4.31700        YES     YES
$end
`;
  const rv = tryParse('vibspectrum', VIB);
  if (rv) check('vibspectrum: three modes with symmetry and km/mol, the zero rows (no symmetry field) left out, no vectors',
    rv.program === 'xTB' && rv.kind === 'freq' && rv.modes.length === 3 && rv.modes[0].sym === 'a' && near(rv.modes[0].freq, 1538.46, 1e-9) &&
    near(rv.modes[0].ir, 32.31834, 1e-9) && rv.modes[2].index === 9 && rv.modes.every(m => m.disp === null) && rv.steps.length === 0, rv.note);
}

/* ============================================================ MOPAC (fixture, MOPAC2016/22 layout) */
const MOPAC = ` *******************************************************************************
 ** Cite this program as: MOPAC2016, Version: 22.058W, James J. P. Stewart,   **
 *******************************************************************************
 **                                                                           **
 **                                MOPAC v22.0.6 for Windows                  **
 **                                                                           **
 *******************************************************************************

                              PM7 CALCULATION RESULTS

 *******************************************************************************
 *  CALCULATION DONE:                                Fri Sep 12 10:00:00 2026  *
 *  PM7        - The PM7 Hamiltonian to be used
 *  FORCE      - FORCE CALCULATION SPECIFIED
 *******************************************************************************
PM7 FORCE
 water

   ATOM   CHEMICAL          X               Y               Z
  NUMBER   SYMBOL      (ANGSTROMS)     (ANGSTROMS)     (ANGSTROMS)

     1       O          0.00000000  *   0.00000000  *   0.00000000  *
     2       H          0.96000000  *   0.00000000  *   0.00000000  *
     3       H         -0.24000000  *   0.93000000  *   0.00000000  *



          CARTESIAN COORDINATES

    NO.       ATOM           X           Y           Z

     1         O          0.0000      0.0000      0.0000
     2         H          0.9600      0.0000      0.0000
     3         H         -0.2400      0.9300      0.0000

 CYCLE:     1 TIME:   0.004 TIME LEFT:  2.00D  GRAD.:    27.607 HEAT: -57.13010
 CYCLE:     2 TIME:   0.000 TIME LEFT:  2.00D  GRAD.:     0.598 HEAT: -57.79963

     GRADIENT =  0.59838 IS LESS THAN CUTOFF =  1.00000

 -------------------------------------------------------------------------------
 PM7 FORCE
 water


     GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).
     SCF FIELD WAS ACHIEVED

          FINAL HEAT OF FORMATION =        -57.79963 KCAL/MOL =    -241.83366 KJ/MOL

          GRADIENT NORM           =          0.59838          =       0.34548 PER ATOM
          MOLECULAR WEIGHT        =         18.0152         POINT GROUP:  C2v

           CARTESIAN COORDINATES

    NO.       ATOM           X           Y           Z

     1         O          0.0000      0.0000      0.0000
     2         H          0.9580      0.0000      0.0000
     3         H         -0.2400      0.9270      0.0000

          FORCE CONSTANT IN CARTESIAN COORDINATES (Millidynes/A)

          NORMAL COORDINATE ANALYSIS (Total motion = 1 Angstrom)


   Root No.       1         2         3

                 1 A1      2 A1      3 B2

               1543.9    3639.9    3771.2

           1  -0.0000    0.0000    0.0000
           2  -0.0435    0.0000   -0.0435
           3  -0.0000   -0.0299    0.0000
           4   0.0000    0.0000    0.0000
           5   0.3452   -0.0000    0.3452
           6   0.0000    0.2373   -0.0000
           7   0.0000    0.0000    0.0000
           8   0.3452    0.0000   -0.3452
           9  -0.0000    0.2373    0.0000

          DESCRIPTION OF VIBRATIONS


 VIBRATION    1       1A1       ATOM PAIR     ENERGY CONTRIBUTION    RADIAL
 FREQ.      1543.89              O 1 -- H 2         +50.0% ( 60.1%)    100.0%
 T-DIPOLE    2.0893              O 1 -- H 3         +50.0% ( 60.1%)    100.0%
 TRAVEL      0.0851
 RED. MASS   1.0817
 EFF. MASS   1.5891

 VIBRATION    2       2A1       ATOM PAIR     ENERGY CONTRIBUTION    RADIAL
 FREQ.      3639.86              O 1 -- H 2         +50.0% ( 50.0%)    100.0%
 T-DIPOLE    0.4121              O 1 -- H 3         +50.0% ( 50.0%)    100.0%
 TRAVEL      0.0592
 RED. MASS   1.0453
 EFF. MASS   1.5210

 VIBRATION    3       3B2       ATOM PAIR     ENERGY CONTRIBUTION    RADIAL
 FREQ.      3771.23              O 1 -- H 2         +50.0% ( 50.0%)    100.0%
 T-DIPOLE    0.9182              O 1 -- H 3         +50.0% ( 50.0%)    100.0%
 TRAVEL      0.0582
 RED. MASS   1.0826
 EFF. MASS   1.6019

          FINAL GEOMETRY OBTAINED
PM7 FORCE
 water

  O     0.00000000 +1   0.00000000 +1   0.00000000 +1
  H     0.95800000 +1   0.00000000 +1   0.00000000 +1
  H    -0.24000000 +1   0.92700000 +1   0.00000000 +1

 == MOPAC DONE ==
`;
{
  const r = tryParse('MOPAC fixture', MOPAC);
  if (r) {
    check('MOPAC: program, kind opt, and the unit is kcal/mol — NOT converted', r.program === 'MOPAC' && r.kind === 'opt' && r.units.energy === 'kcal/mol', r.note);
    check('MOPAC: two cycles in order (heats and gradients) plus the final step with the FINAL HEAT OF FORMATION', r.steps.length === 3 &&
      near(r.steps[0].energy, -57.13010, 1e-9) && near(r.steps[1].energy, -57.79963, 1e-9) && near(r.steps[0].grad, 27.607, 1e-9) &&
      r.steps[2].final === true && near(r.steps[2].energy, -57.79963, 1e-9) && near(r.energy, -57.79963, 1e-9), JSON.stringify(r.steps.map(s => s.energy)));
    check('MOPAC: no geometry per cycle; the final geometry (0.958, not the input\'s 0.96) sits on the last step', r.steps[0].atoms === null && r.steps[1].atoms === null &&
      r.steps[2].atoms && r.steps[2].atoms.length === 3 && near(r.steps[2].atoms[1].x, 0.958) && r.modeAtoms === r.steps[2].atoms);
    check('MOPAC: optimised, MOPAC DONE', r.converged === true && r.termination === 'normal');
    check('MOPAC: three vibrations with frequency, symmetry, reduced mass, transition dipole, and ir null (no km/mol in MOPAC)',
      r.modes.length === 3 && near(r.modes[0].freq, 1543.89, 1e-9) && r.modes[0].sym === '1A1' && near(r.modes[0].redMass, 1.0817, 1e-9) &&
      near(r.modes[0].tdipole, 2.0893, 1e-9) && r.modes.every(m => m.ir === null) && near(r.modes[2].freq, 3771.23, 1e-9));
    check('MOPAC: vectors from the Root No. matrix, 9 long, by column (mode 1 row 2 = -0.0435, row 5 = 0.3452; mode 2 row 6 = 0.2373)',
      r.modes.every(m => m.disp && m.disp.length === 9 && noNaN(m.disp)) && near(r.modes[0].disp[1], -0.0435, 1e-6) && near(r.modes[0].disp[4], 0.3452, 1e-6) &&
      near(r.modes[1].disp[5], 0.2373, 1e-6) && near(r.modes[2].disp[7], -0.3452, 1e-6), r.modes[0].disp && Array.from(r.modes[0].disp).join(' '));
  }
  // a single point: no cycles, one step carrying the heat and the geometry
  const SP = MOPAC.replace(/ CYCLE:.*\n/g, '').replace('GEOMETRY OPTIMISED USING EIGENVECTOR FOLLOWING (EF).', '1SCF WAS SPECIFIED, SO BFGS WAS NOT USED');
  const rs = tryParse('MOPAC 1SCF', SP);
  if (rs) check('MOPAC 1SCF: one sp step with the heat of formation and the geometry, converged null', rs.steps.length === 1 && rs.steps[0].kind === 'sp' &&
    near(rs.steps[0].energy, -57.79963, 1e-9) && rs.steps[0].atoms.length === 3 && rs.converged === null && rs.kind === 'freq');
  // without the FINAL GEOMETRY OBTAINED block the last "CARTESIAN COORDINATES" in the file is
  // the force-constant matrix heading, which holds no atoms: the last block WITH atoms wins
  const NOFIN = MOPAC.replace(/          FINAL GEOMETRY OBTAINED[\s\S]*?\n\n/, '');
  const rn = tryParse('MOPAC without FINAL GEOMETRY', NOFIN);
  if (rn) check('MOPAC: with no FINAL GEOMETRY block the optimised CARTESIAN COORDINATES (0.958) are still found, not the input\'s',
    !/FINAL GEOMETRY OBTAINED/.test(NOFIN) && rn.steps[2].atoms && near(rn.steps[2].atoms[1].x, 0.958) && rn.modes.every(m => m.disp && m.disp.length === 9));
}

/* ============================================================ refusals and shape */
{
  let threw = null;
  try { parseResults('Dear colleague,\nplease find attached the Gaussian results.\n'); } catch (e) { threw = e.message; }
  check('a letter that mentions Gaussian is refused with a message naming the program', threw && /mentions Gaussian/.test(threw), threw || 'no throw');
  threw = null;
  try { parseResults('nothing to see here\n'); } catch (e) { threw = e.message; }
  check('unrecognised text is refused', threw && /not one the RESULTS window reads/.test(threw), threw || 'no throw');
  threw = null;
  try { parseTrajectoryXYZ('not an xyz\n'); } catch (e) { threw = e.message; }
  check('parseTrajectoryXYZ refuses non-xyz text', !!threw, threw || 'no throw');
  const r = parseResults(G_HCN);
  check('every result has the one shape: program, kind, units, steps, modes, modeAtoms, energy, converged, termination, note',
    ['program', 'kind', 'units', 'steps', 'modes', 'modeAtoms', 'energy', 'converged', 'termination', 'note'].every(k => k in r) &&
    Array.isArray(r.steps) && Array.isArray(r.modes) && typeof r.note === 'string' && r.units.length === 'angstrom' && r.units.freq === 'cm-1');
  check('a bare xyz trajectory with energy= on the comment line, unit unknown', (() => {
    const t = parseResults('2\nLattice="10 0 0 0 10 0 0 0 10" energy=-1234.5678 pbc="F F F"\nH 0 0 0\nH 0 0 0.74\n2\nenergy=-1234.6\nH 0 0 0\nH 0 0 0.75\n');
    return t.program === 'XYZ trajectory' && t.units.energy === 'unknown' && t.steps.length === 2 && near(t.steps[0].energy, -1234.5678, 1e-12) && near(t.steps[1].energy, -1234.6, 1e-12);
  })());
  check('a comment holding a single number is the energy; one with none gives null', (() => {
    const t = parseResults('1\n -76.5\nO 0 0 0\n1\nframe two\nO 0 0 0.1\n');
    return near(t.steps[0].energy, -76.5, 1e-12) && t.steps[1].energy === null;
  })());
}

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
