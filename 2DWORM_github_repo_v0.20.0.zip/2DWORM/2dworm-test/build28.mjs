/* BUILD 28 — Dante's second list from the Quest, the tablet and the PC.
   Forty thousand picked atoms no longer take a minute; the ENERGY row has a switch and waits
   for it above 2,000 atoms; a press on a slider row picks nothing behind it; DEL and REPLACE
   light the atom before taking it; one picked atom turns the three rows into X, Y, Z; FREEZE
   holds the structure; LABEL PICKED is one press; a double-click opens the atom window
   (number, element, coordinates, name, residue, charge, UFF type, bonds, TO NOTE); the note
   has sizes and five colours; PAUSED! has MODEL / REST / ALL and TAIL; pREST relaxes the
   surroundings of a held model; in VR the hand panel stays outside the molecule and the
   floor is a metre grid fixed to the room, on Y. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { buildModel, buildRest, applyModel, describe } from '../2dworm/lib/pmodel.js';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8828;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP], { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/* ============================================================ pmodel.js: methyl caps, the grown region, pREST */
{
  const at = (e, x, y, z) => ({ elem: e, x, y, z });
  /* propane: C0–C1–C2, three hydrogens on C0 and C2, two on C1 */
  const atoms = [at('C', 0, 0, 0), at('C', 1.54, 0, 0), at('C', 2.05, 1.45, 0),
    at('H', -0.36, 1.03, 0), at('H', -0.36, -0.51, 0.89), at('H', -0.36, -0.51, -0.89),
    at('H', 1.90, -0.51, 0.89), at('H', 1.90, -0.51, -0.89),
    at('H', 3.14, 1.45, 0), at('H', 1.69, 1.96, 0.89), at('H', 1.69, 1.96, -0.89)];
  const bonds = [{ a: 0, b: 1, o: 1 }, { a: 1, b: 2, o: 1 }, { a: 0, b: 3, o: 1 }, { a: 0, b: 4, o: 1 }, { a: 0, b: 5, o: 1 }, { a: 1, b: 6, o: 1 }, { a: 1, b: 7, o: 1 }, { a: 2, b: 8, o: 1 }, { a: 2, b: 9, o: 1 }, { a: 2, b: 10, o: 1 }];
  const st = { atoms, bonds };
  const dist = (p, q) => Math.hypot(p.x - q.x, p.y - q.y, p.z - q.z);
  const rH = buildModel(st, [0, 3, 4, 5], { cap: 'H' });
  const rM = buildModel(st, [0, 3, 4, 5], { cap: 'CH3' });
  check('a hydrogen cap is one atom; a methyl cap is four, all held', rH.model.atoms.length === 5 && rM.model.atoms.length === 8 && rM.caps[0].kind === 'CH3' && rM.caps[0].hydrogens.length === 3 && rM.frozen.length === 5 && rM.free.length === 3, `${rH.model.atoms.length} / ${rM.model.atoms.length} atoms, frozen ${rM.frozen.join(',')}`);
  const C = rM.model.atoms[rM.caps[0].index];
  check('the methyl carbon sits where the cut carbon was: a C–C cut keeps its 1.54 Å', Math.abs(dist(C, atoms[0]) - 1.54) < 1e-9 && Math.abs(C.x - 1.54) < 1e-9, `${dist(C, atoms[0]).toFixed(3)} Å`);
  const Hs = rM.caps[0].hydrogens.map(h => rM.model.atoms[h]);
  const ang = (p, q, r) => { const u = [p.x - q.x, p.y - q.y, p.z - q.z], v = [r.x - q.x, r.y - q.y, r.z - q.z]; return Math.acos((u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (Math.hypot(...u) * Math.hypot(...v))) * 180 / Math.PI; };
  check('its three hydrogens are 1.07 Å from it at the tetrahedral angle to the linker', Hs.every(H => Math.abs(dist(H, C) - 1.07) < 1e-9 && Math.abs(ang(atoms[0], C, H) - 109.47) < 0.05), Hs.map(H => ang(atoms[0], C, H).toFixed(2)).join(', '));
  const dih = (p, q, r, t) => { const s = (a, b) => [a.x - b.x, a.y - b.y, a.z - b.z]; const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; const b1 = s(q, p), b2 = s(r, q), b3 = s(t, r); const n1 = cr(b1, b2), n2 = cr(b2, b3); const m = cr(n1, b2.map(x => x / Math.hypot(...b2))); return Math.atan2(dot(m, n2), dot(n1, n2)) * 180 / Math.PI; };
  const dihs = Hs.map(H => Math.round(dih(H, C, atoms[0], atoms[3])));
  check('and staggered against the linker\'s own hydrogens: 60°, 180°, −60°', dihs.slice().sort((a, b) => a - b).join(',') === '-60,60,180', dihs.join(', '));
  check('the same region twice gives byte-identical methyls', JSON.stringify(buildModel(st, [0, 3, 4, 5], { cap: 'CH3' }).model.atoms) === JSON.stringify(rM.model.atoms));
  check('describe() says CH3', /capped with 1 CH3/.test(describe(rM)) && /capped with 1 H/.test(describe(rH)), describe(rM));
  /* the grown region: a heavy atom picked alone takes its hydrogens with it */
  const g = buildModel(st, [0]);
  check('a carbon picked alone draws its hydrogens in — an X–H bond is never cut', g.stats.region === 4 && g.grown.join(',') === '3,4,5' && g.cuts.length === 1 && g.free.length === 3, `region ${g.stats.region}, grown ${g.grown.join(',')}, ${g.cuts.length} cut`);
  check('and the description says so', /3 drawn in/.test(describe(g)), describe(g));
  /* an outside atom bonded twice to the region would get two caps on top of each other: it joins instead */
  const ring = { atoms: [at('C', 0, 0, 0), at('C', 1.4, 0, 0), at('C', 2.1, 1.2, 0), at('C', 1.4, 2.4, 0), at('C', 0, 2.4, 0), at('C', -0.7, 1.2, 0), at('H', -0.5, -0.9, 0), at('H', 2.9, 3.0, 0)],
    bonds: [{ a: 0, b: 1, o: 1 }, { a: 1, b: 2, o: 1 }, { a: 2, b: 3, o: 1 }, { a: 3, b: 4, o: 1 }, { a: 4, b: 5, o: 1 }, { a: 5, b: 0, o: 1 }, { a: 0, b: 6, o: 1 }, { a: 3, b: 7, o: 1 }] };
  const two = buildModel(ring, [0, 2]);
  check('an atom bonded to two region atoms is drawn in rather than capped twice', two.grown.includes(1) && two.caps.every((c, i, arr) => arr.every((d, j) => i === j || dist(two.model.atoms[c.index], two.model.atoms[d.index]) > 0.5)), `grown ${two.grown.join(',')}, ${two.caps.length} caps`);
  /* pREST */
  const rr = buildRest(st, [2, 8, 9, 10], { shell: 2.6 });
  check('pREST: the picked atoms are held, the shell around them is free, the far rest is left out', rr.rest && rr.stats.model === 4 && rr.free.length > 0 && rr.free.every(mi => ![2, 8, 9, 10].includes(rr.map[mi])) && rr.frozen.some(mi => rr.map[mi] === 2), describe(rr));
  const ra = buildRest(st, [2, 8, 9, 10], { shell: Infinity });
  check('pREST with the whole rest cuts nothing: 7 free, 4 held', ra.free.length === 7 && ra.frozen.length === 4 && ra.caps.length === 0 && /all of it/.test(describe(ra)), describe(ra));
  const back = applyModel(st, rr, rr.model.atoms.map(a => ({ ...a, x: a.x + 0.1 })));
  check('applyModel puts a pREST result back under the original numbers, the model untouched', back.moved.every(i => ![2, 8, 9, 10].includes(i)) && back.moved.length === rr.free.length && Math.abs(back.maxShift - 0.1) < 1e-9, back.moved.join(','));
  let msg = ''; try { buildRest(st, atoms.map((_, i) => i)); } catch (e) { msg = e.message; }
  check('pREST refuses when everything is picked', /no rest/.test(msg), msg);
  msg = ''; try { buildRest(st, [2], { shell: 0.3 }); } catch (e) { msg = e.message; }
  check('and when the shell holds nothing', /within 0.3 Å/.test(msg), msg);
}

/* ============================================================ the page */
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
const D = (fn, arg) => page.evaluate(fn, arg);
const status = () => page.textContent('#status3d');
const sel = (idx) => D((s) => { window.dworm2d.state3d.sel = s; window.dworm2d.applyStyle(window.dworm2d.viewer); window.dworm2d.saySelection(); }, idx);
const build = async (smiles, n) => {
  await page.evaluate(async (s) => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule(s); }, smiles);
  await page.click('#btnMake3d');
  await page.waitForFunction((m) => window.dworm2d.state3d.nAtoms === m, n, { timeout: 120000 });
  await page.waitForTimeout(300);
};
const range = async (id, value) => D(([i, v]) => { const r = document.getElementById(i); r.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); r.value = String(v); r.dispatchEvent(new Event('input', { bubbles: true })); r.dispatchEvent(new Event('change', { bubbles: true })); r.dispatchEvent(new PointerEvent('pointerup', { bubbles: true })); }, [id, value]);
const typed = async (id, value) => D(([i, v]) => { const n = document.getElementById(i); n.value = String(v); n.dispatchEvent(new Event('change', { bubbles: true })); }, [id, value]);
const dnaLines = readFileSync(APP + '../2dworm-test/corpus/DNA.pdb', 'utf8').split('\n').filter(l => /^(ATOM|HETATM)/.test(l));
const dnaTimes = (k) => { let t = ''; for (let m = 0; m < k; m++) for (const l of dnaLines) { const x = (parseFloat(l.slice(30, 38)) + m * 40).toFixed(3).padStart(8); t += l.slice(0, 30) + x + l.slice(38) + '\n'; } return t + 'END\n'; };

/* ------------------------------------------------------------ 1. a large selection */
await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'DNA8.pdb'), dnaTimes(8));
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 5104, null, { timeout: 60000 });
await page.waitForTimeout(500);
const big = await D(async () => {
  const t0 = performance.now(); await window.dworm2d.selectBy('*'); const t1 = performance.now();
  const s0 = performance.now(); window.dworm2d.applyStyle(window.dworm2d.viewer); const s1 = performance.now();
  return { select: Math.round(t1 - t0), style: Math.round(s1 - s0), n: window.dworm2d.state3d.sel.length, text: window.dworm2d.selectionText(), measure: window.dworm2d.measureOf(), max: window.dworm2d.MARK_SHAPES_MAX };
});
check(`every atom of a ${big.n}-atom structure picked: the marks are a bulk tint above ${big.max}, drawn in ${big.style} ms (was a minute at 40,000)`, big.n === 5104 && big.style < 4000 && big.max === 400, `${big.style} ms`);
check('the status line names thirty atoms and counts the rest; nothing is measured', /… and 5074 more/.test(big.text) && big.measure === null, big.text.slice(-60));

/* ------------------------------------------------------------ 2. the ENERGY switch */
await page.click('#btnEdit'); await page.waitForTimeout(300);
const swBig = await D(() => ({ text: document.getElementById('energySw').textContent, on: document.getElementById('energySw').classList.contains('on'), wanted: window.dworm2d.energyWanted(window.dworm2d.state3d.nAtoms), limit: window.dworm2d.ENERGY_AUTO_MAX }));
check('above 2,000 atoms the switch is OFF by itself', swBig.text === 'OFF' && !swBig.on && !swBig.wanted && swBig.limit === 2000, JSON.stringify(swBig));
await sel([0]);
await range('geoBondR', 0.5); await page.waitForTimeout(900);
const rowOff = await D(() => ({ v: document.getElementById('energyV').textContent, scrubs: !document.getElementById('energyR').disabled, e: window.dworm2d.energySlide && window.dworm2d.energySlide.eAfter }));
check('an edit arms the slider — it scrubs — and the row says the energies wait for the switch', rowOff.scrubs && /wait for the switch/.test(rowOff.v) && rowOff.e == null, rowOff.v);
await D(() => window.dworm2d.energySeek(0, false)); await page.waitForTimeout(100);
check('scrubbing to BEFORE moves the atoms without an energy', (await D(() => window.dworm2d.energySlide.t)) === 0);
await page.click('#energySw');
await page.waitForFunction(() => Number.isFinite(window.dworm2d.energySlide && window.dworm2d.energySlide.eAfter), null, { timeout: 120000 });
const swOn = await D(() => ({ text: document.getElementById('energySw').textContent, v: document.getElementById('energyV').textContent, user: window.dworm2d.energyUser }));
check('pressing ON computes the two single points and prints them', swOn.text === 'ON' && /kcal\/mol UFF/.test(swOn.v) && swOn.user === true, swOn.v.slice(0, 80));

/* ------------------------------------------------------------ 3. no picks through the slider rows */
await D(() => window.dworm2d.clearSelection());
await page.click('#toolSeg button[data-tool="del"]'); await page.waitForTimeout(100);
const findUnder = () => D(() => { const bar = document.getElementById('geoBar').getBoundingClientRect(); const v = window.dworm2d.viewer; const atoms = v.getModel().selectedAtoms({}); const pts = v.modelToScreen(atoms.map(a => ({ x: a.x, y: a.y, z: a.z }))); for (let i = 0; i < pts.length; i++) { const x = pts[i].x - window.pageXOffset, y = pts[i].y - window.pageYOffset; if (x > bar.left + 5 && x < bar.right - 5 && y > bar.top + 5 && y < bar.bottom - 5) return { i, x, y }; } return null; });
let under = null;
for (let z = 0; z < 6 && !under; z++) { await D(() => { const v = window.dworm2d.viewer; v.zoom(2); v.render(); }); await page.waitForTimeout(150); under = await findUnder(); }
if (under) {
  await page.mouse.click(under.x, under.y); await page.waitForTimeout(700);
  check('zoomed in, an atom projects under the slider rows; a press there with DEL armed takes nothing', (await D(() => window.dworm2d.state3d.nAtoms)) === 5104 && (await D(() => window.dworm2d.toolFlash)) === -1, `atom ${under.i} at ${Math.round(under.x)},${Math.round(under.y)}`);
} else check('zoomed in, an atom projects under the slider rows (none found — the layout changed?)', false);
await page.click('#toolSeg button[data-tool=""]');

/* ------------------------------------------------------------ 4. X, Y, Z for one atom */
await build('CCO', 9);
const swSmall = await D(() => ({ text: document.getElementById('energySw').textContent, user: window.dworm2d.energyUser }));
check('a new small structure: the switch is ON again and the pressed choice is forgotten', swSmall.text === 'ON' && swSmall.user === null, JSON.stringify(swSmall));
await sel([0]);
const xyz = await D(() => ({ labels: ['bond', 'angle', 'dihedral'].map(k => document.querySelector(`#geoBar .georow[data-kind="${k}"] b`).textContent).join(''), cls: document.getElementById('geoBar').classList.contains('xyz'), min: document.getElementById('geoBondR').min, max: document.getElementById('geoDihR').max, step: document.getElementById('geoAngR').step, live: !document.getElementById('geoBondR').disabled && !document.getElementById('geoAngR').disabled && !document.getElementById('geoDihR').disabled, v: document.getElementById('geoBondV').textContent, n: document.getElementById('geoBondN').value, seg: getComputedStyle(document.querySelector('#geoBar .geomode[data-for="bond"]')).display, more: document.getElementById('geoMoreR').disabled, x0: window.dworm2d.viewer.getModel().selectedAtoms({})[0].x }));
check('one atom picked: the three rows are X, Y, Z, ±2 Å in hundredths, all live, the side rule hidden, the fourth row off', xyz.labels === 'XYZ' && xyz.cls && xyz.min === '-2' && xyz.max === '2' && xyz.step === '0.01' && xyz.live && xyz.seg === 'none' && xyz.more, JSON.stringify(xyz));
check('each box holds the coordinate itself and the readout names the axis', xyz.n === xyz.x0.toFixed(3) && new RegExp('^x = ' + xyz.x0.toFixed(3) + ' Å').test(xyz.v), xyz.v + ' / ' + xyz.n);
const undo0 = await D(() => window.dworm2d.undoDepth);
await range('geoBondR', 1); await page.waitForTimeout(300);
const moved = await D(() => ({ x: window.dworm2d.viewer.getModel().selectedAtoms({})[0].x, r: document.getElementById('geoBondR').value, n: document.getElementById('geoBondN').value, undo: window.dworm2d.undoDepth, v: document.getElementById('geoBondV').textContent }));
check('the X slider moves the atom one ångström; on release the slider is back at zero, the box shows the new x, one undo', Math.abs(moved.x - xyz.x0 - 1) < 1e-6 && moved.r === '0' && moved.n === moved.x.toFixed(3) && moved.undo === undo0 + 1, JSON.stringify(moved));
await typed('geoAngN', 5); await page.waitForTimeout(300);
const ty = await D(() => ({ y: window.dworm2d.viewer.getModel().selectedAtoms({})[0].y, undo: window.dworm2d.undoDepth, v: document.getElementById('geoAngV').textContent }));
check('a coordinate typed into the Y box is applied exactly, beyond the slider\'s ±2, one undo', Math.abs(ty.y - 5) < 1e-9 && ty.undo === undo0 + 2 && /^y = 5\.000 Å/.test(ty.v), JSON.stringify(ty));
await sel([0, 1]);
const two = await D(() => ({ labels: ['bond', 'angle'].map(k => document.querySelector(`#geoBar .georow[data-kind="${k}"] b`).textContent).join('|'), min: document.getElementById('geoBondR').min, cls: document.getElementById('geoBar').classList.contains('xyz'), ang: document.getElementById('geoAngR').disabled, seg: getComputedStyle(document.querySelector('#geoBar .geomode[data-for="bond"]')).display }));
check('two atoms picked: BOND, ANGLE, DIHEDRAL again with their own ranges and side rules', two.labels === 'BOND|ANGLE' && two.min === '-300' && !two.cls && two.ang && two.seg !== 'none', JSON.stringify(two));
await page.click('#btnResetAll'); await page.waitForTimeout(300);

/* ------------------------------------------------------------ 5. FREEZE */
const box = await D(() => { const r = document.getElementById('viewer3d').getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; });
const turn = async () => { await page.mouse.move(box.x + box.w * 0.12, box.y + box.h * 0.12); await page.mouse.down(); await page.mouse.move(box.x + box.w * 0.5, box.y + box.h * 0.6, { steps: 8 }); await page.mouse.up(); await page.waitForTimeout(200); };
const view = () => D(() => window.dworm2d.viewer.getView());
check('FREEZE sits beside FIT, off, not red', await page.isVisible('#btnFreeze') && !(await D(() => document.getElementById('btnFreeze').classList.contains('on'))));
await page.click('#btnFreeze'); await page.waitForTimeout(100);
const v0 = await view(); await turn(); const v1 = await view();
check('FREEZE on: the button is red and a mouse drag does not turn the structure', (await D(() => document.getElementById('btnFreeze').classList.contains('on') && getComputedStyle(document.getElementById('btnFreeze')).backgroundColor === 'rgb(211, 47, 47)')) && v0.slice(4).every((x, i) => Math.abs(x - v1[i + 4]) < 1e-12) && v0.slice(0, 3).every((x, i) => Math.abs(x - v1[i]) < 1e-12), JSON.stringify(v1.map(x => +x.toFixed(3))));
await page.click('#btnFit'); await page.waitForTimeout(100);
check('FIT is refused while frozen, and says so', /FROZEN/.test(await status()));
await page.keyboard.press('Enter'); await page.waitForTimeout(100);
const v2 = await view();
check('ENTER (re-frame) is refused too — the view is exactly as it was', v1.every((x, i) => Math.abs(x - v2[i]) < 1e-12));
await page.mouse.move(box.x + box.w / 2, box.y + box.h / 2); await page.mouse.wheel(0, -300); await page.waitForTimeout(300);
const v3 = await view();
check('the wheel still zooms', Math.abs(v3[3] - v2[3]) > 1e-6, `${v2[3].toFixed(2)} → ${v3[3].toFixed(2)}`);
await D(() => window.dworm2d.clearSelection());
const oAt = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({})[2]; const p = window.dworm2d.viewer.modelToScreen({ x: a.x, y: a.y, z: a.z }); return { x: p.x - window.pageXOffset, y: p.y - window.pageYOffset }; });
await page.mouse.click(oAt.x, oAt.y); await page.waitForTimeout(300);
check('a click on an atom still picks it while frozen', (await D(() => window.dworm2d.state3d.sel.join(','))) === '2', await D(() => window.dworm2d.state3d.sel.join(',')));
await page.click('#btnFreeze'); await page.waitForTimeout(100);
await turn(); const v4 = await view();
check('released: the structure turns again and the hint is cleared', !v3.slice(4).every((x, i) => Math.abs(x - v4[i + 4]) < 1e-9) && !(await D(() => document.getElementById('btnFreeze').classList.contains('on'))));
await page.click('#btnFreeze'); await page.waitForTimeout(100);
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CO'); }); await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 6, null, { timeout: 120000 }); await page.waitForTimeout(300);
check('a new structure releases FREEZE (it is re-framed anyway)', !(await D(() => window.dworm2d.freezeOn)));

/* ------------------------------------------------------------ 6. LABEL PICKED */
await build('CCO', 9);
check('LABELS (on the picked atoms only) is not there without a pick', !(await page.isVisible('#btnLabelsPicked')));
await sel([1]);
check('…and appears with one', await page.isVisible('#btnLabelsPicked'));
await page.click('#btnLabelsPicked'); await page.waitForTimeout(300);
const lp = await D(() => ({ picked: window.dworm2d.opts.labelsPicked, mode: window.dworm2d.opts.labels, menu: document.getElementById('selLabels').value, on: document.getElementById('btnLabelsPicked').classList.contains('on'), box: document.getElementById('selListOnly').checked }));
check('one press: captions on the picked atoms only, turned on as numbers, the menu and the window\'s box agree', lp.picked === true && lp.mode === 'num' && lp.menu === 'num' && lp.on && lp.box, JSON.stringify(lp));
await page.click('#btnLabelsPicked'); await page.waitForTimeout(200);
check('a second press: every atom again', (await D(() => window.dworm2d.opts.labelsPicked)) === false);

/* ------------------------------------------------------------ 7. DEL and REPLACE light the atom first */
await page.click('#toolSeg button[data-tool="del"]'); await page.waitForTimeout(100);
const t0 = Date.now();
const going = D(() => window.dworm2d.builderClick('del', 8));
await page.waitForTimeout(120);
const mid = await D(() => ({ flash: window.dworm2d.toolFlash, colour: window.dworm2d.SEL_COLOUR_DEL, n: window.dworm2d.state3d.nAtoms }));
await going;
const gone = await D(() => ({ n: window.dworm2d.state3d.nAtoms, flash: window.dworm2d.toolFlash, ms: window.dworm2d.TOOL_FLASH_MS }));
check('DEL: the atom is lit red for 0.3 s, still there — then gone', mid.flash === 8 && mid.n === 9 && mid.colour === '#ff3b30' && gone.n === 8 && gone.flash === -1 && gone.ms === 300 && Date.now() - t0 >= 290, `${Date.now() - t0} ms`);
await page.click('#toolSeg button[data-tool="subst"]'); await page.waitForTimeout(300);
await page.selectOption('#selFrag', 'CH3');
const t1 = Date.now();
const swapping = D(() => window.dworm2d.builderClick('subst', 7));
await page.waitForTimeout(120);
const midS = await D(() => ({ flash: window.dworm2d.toolFlash, n: window.dworm2d.state3d.nAtoms }));
await swapping;
check('REPLACE lights the hydrogen it is about to replace, blue, then replaces it', midS.flash === 7 && midS.n === 8 && (await D(() => window.dworm2d.state3d.nAtoms)) === 11 && Date.now() - t1 >= 290);
await page.click('#toolSeg button[data-tool=""]');
await page.click('#btnResetAll'); await page.waitForTimeout(300);

/* ------------------------------------------------------------ 8. the atom window */
await build('CCO', 9);
const at = async (i) => D((k) => { const a = window.dworm2d.viewer.getModel().selectedAtoms({})[k]; const p = window.dworm2d.viewer.modelToScreen({ x: a.x, y: a.y, z: a.z }); return { x: p.x - window.pageXOffset, y: p.y - window.pageYOffset }; }, i);
let o = await at(2);
await page.mouse.click(o.x, o.y); await page.waitForTimeout(90); await page.mouse.click(o.x, o.y);
await page.waitForTimeout(400);
const win = await D(() => ({ open: !document.getElementById('atomWin').hidden, title: document.getElementById('atomWinTitle').textContent, num: document.getElementById('atomWinNum').value, elem: document.getElementById('atomWinElem').value, x: document.getElementById('atomWinX').value, info: document.getElementById('atomWinInfo').textContent, sel: window.dworm2d.state3d.sel.slice(), opts: document.getElementById('atomWinElem').options.length }));
/* the first click is 3Dmol's own pick, which in this headless renderer lands beside the atom
   or not at all; what is asserted is that the double-click's atom IS picked afterwards —
   the second click did not un-pick it */
check('a double-click on the oxygen opens the atom window, and the atom stays picked (the second click does not un-pick)', win.open && win.title === 'Atom 3 · O' && win.num === '3' && win.sel.includes(2), JSON.stringify(win).slice(0, 160));
check('the element menu is the periodic table and reads O; the coordinates and the bonds with their lengths are shown', win.opts === 118 && win.elem === 'O' && /^-?\d+\.\d{3}$/.test(win.x) && /bonds C2 \d\.\d{3} Å, H9 \d\.\d{3} Å/.test(win.info), win.info);
await page.waitForFunction(() => /UFF type O/.test(document.getElementById('atomWinInfo').textContent), null, { timeout: 20000 });
check('the UFF type arrives: O_3', /UFF type O_3/.test(await D(() => document.getElementById('atomWinInfo').textContent)));
const u0 = await D(() => window.dworm2d.undoDepth);
await page.selectOption('#atomWinElem', 'S'); await page.waitForTimeout(700);
const el = await D(() => ({ elems: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join(''), title: document.getElementById('atomWinTitle').textContent, undo: window.dworm2d.undoDepth, s: document.getElementById('status3d').textContent, open: !document.getElementById('atomWin').hidden }));
check('the element changed in place: ethanol became ethanethiol, the hydrogens untouched, one undo, the window still open on it', el.elems === 'CCSHHHHHH' && el.title === 'Atom 3 · S' && el.undo === u0 + 1 && /O → S/.test(el.s) && el.open, el.s.slice(0, 80));
await typed('atomWinX', 9); await page.waitForTimeout(300);
check('a typed x moves the atom exactly there, one undo', Math.abs((await D(() => window.dworm2d.viewer.getModel().selectedAtoms({})[2].x)) - 9) < 1e-9 && (await D(() => window.dworm2d.undoDepth)) === u0 + 2);
await typed('atomWinNum', 1); await page.waitForTimeout(900);
const rn = await D(() => ({ elems: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join(''), title: document.getElementById('atomWinTitle').textContent, sel: window.dworm2d.state3d.sel.join(','), undo: window.dworm2d.undoDepth, s: document.getElementById('status3d').textContent }));
check('typing number 1 renumbers: the sulfur is atom 1, the rest follow, the window follows it, one undo', rn.elems === 'SCCHHHHHH' && rn.title === 'Atom 1 · S' && rn.sel === '0' && rn.undo === u0 + 3 && /Atom 3 is now atom 1/.test(rn.s), rn.s.slice(0, 80));
await page.click('#atomWinNote'); await page.waitForTimeout(300);
const note = await D(() => ({ text: document.getElementById('noteText').value, panel: !document.getElementById('panelNote').hidden }));
check('TO NOTE puts the atom\'s line into the note — a chip that picks it, coordinates, UFF type, bonds — and opens NOTES', /^\[\[0\|Atom 1 S\]\] x 9\.000 y -?\d+\.\d{3} z -?\d+\.\d{3} Å · UFF S_3\+2 · bonds: /.test(note.text) && note.panel, note.text.slice(0, 90));
await page.click('#atomWinNext'); await page.waitForTimeout(200);
check('▶ moves to the next atom by number', (await D(() => document.getElementById('atomWinTitle').textContent)) === 'Atom 2 · C');
await page.click('#btnResetAll'); await page.waitForTimeout(400);
check('RESET ALL walks the three steps back, the window following', (await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join(''))) === 'CCOHHHHHH');
await page.keyboard.press('Escape'); await page.waitForTimeout(100);
check('Escape closes it', await D(() => document.getElementById('atomWin').hidden && !window.dworm2d.atomWin));
o = await at(0);
await page.mouse.click(o.x, o.y); await page.waitForTimeout(90); await page.mouse.click(o.x, o.y); await page.waitForTimeout(300);
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CO'); }); await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 6, null, { timeout: 120000 }); await page.waitForTimeout(300);
check('and a new structure closes it', await D(() => document.getElementById('atomWin').hidden));
await D(() => { document.getElementById('noteText').value = ''; });

/* ------------------------------------------------------------ 9. NOTES: sizes and five colours */
const rendered = await D(() => window.dworm2d.renderNote('{big}Big{/} and {small}small{/}, {red}r{/} {blue}b{/} {green}g{/} {orange}o{/} {grey}y{/}, {purple}no{/}, {red}<b>x</b>{/} **bold**'));
check('{big} {small} and the five colours render as classes and nothing else', /<span class="nx-big">Big<\/span>/.test(rendered) && /<span class="nx-small">small<\/span>/.test(rendered) && ['red', 'blue', 'green', 'orange', 'grey'].every(c => rendered.includes(`<span class="nx-${c}">`)), rendered);
check('a name that is not in the set is left as typed; markup inside is still escaped; bold still works', /\{purple\}no\{\/\}/.test(rendered) && /<span class="nx-red">&lt;b&gt;x&lt;\/b&gt;<\/span>/.test(rendered) && /<b>bold<\/b>/.test(rendered) && !/style=/.test(rendered));
await page.click('#panelNote #noteText'); await D(() => { const t = document.getElementById('noteText'); t.value = 'hot spot'; t.setSelectionRange(0, 3); });
await page.selectOption('#selNoteSpan', 'red'); await page.waitForTimeout(100);
check('the SIZE / COLOUR menu wraps the selected words in the syntax', (await D(() => document.getElementById('noteText').value)) === '{red}hot{/} spot');
await page.selectOption('#selNoteSize', '18'); await page.waitForTimeout(100);
const sz = await D(() => ({ v: getComputedStyle(document.getElementById('panelNote')).getPropertyValue('--note-size').trim(), px: getComputedStyle(document.getElementById('noteText')).fontSize, ls: localStorage.getItem('dworm2d.noteSize') }));
check('TEXT 18 sets the panel\'s text size on this device and remembers it', sz.v === '18px' && sz.px === '18px' && sz.ls === '18', JSON.stringify(sz));
await page.selectOption('#selNoteSize', '14'); await D(() => { document.getElementById('noteText').value = ''; });

/* ------------------------------------------------------------ 10. PAUSED!: MODEL / REST / ALL and TAIL; pREST */
await build('CCCCO', 15);
await sel([3, 4]);
await D(() => window.dworm2d.optSet('pause', 'always'));
check('pREST appears beside pMODEL when atoms are picked', await page.isVisible('#btnPRest') && await page.isVisible('#btnPModel'));
await D(() => { window.dworm2d.runPModel(); });
await page.waitForFunction(() => !document.getElementById('pauseBar').hidden, null, { timeout: 30000 }); await page.waitForTimeout(300);
const pz = await D(() => ({ what: document.getElementById('pauseWhat').textContent, view: !document.getElementById('pauseView').hidden, tail: !document.getElementById('pauseTail').hidden, tailOn: document.querySelector('#pauseTail button.on').dataset.tail, viewOn: document.querySelector('#pauseView button.on').dataset.view }));
check('pMODEL pauses with MODEL / REST / ALL and TAIL H / CH3 on the bar, ALL and H on', pz.view && pz.tail && pz.tailOn === 'H' && pz.viewOn === 'all' && /drawn in/.test(pz.what), pz.what.slice(0, 120));
await page.click('#pauseView button[data-view="model"]'); await page.waitForTimeout(200);
const vm = await D(() => ({ hidden: window.dworm2d.pauseHidden ? window.dworm2d.pauseHidden.length : 0, on: document.querySelector('#pauseView button.on').dataset.view }));
check('MODEL hides the rest — the region as built, hydrogens drawn in, stays', vm.hidden === 15 - 5 && vm.on === 'model', `${vm.hidden} hidden`);
await page.click('#pauseView button[data-view="rest"]'); await page.waitForTimeout(200);
check('REST hides the model', (await D(() => window.dworm2d.pauseHidden.length)) === 5);
await page.click('#pauseTail button[data-tail="CH3"]'); await page.waitForTimeout(600);
const tl = await D(() => ({ what: document.getElementById('pauseWhat').textContent, on: document.querySelector('#pauseTail button.on').dataset.tail, temp: (() => { const m = window.dworm2d.viewer.getModel(1); return m ? m.selectedAtoms({}).length : 0; })() }));
check('TAIL CH3 rebuilds the intermediate with a methyl on the spot: the bar says CH3, the preview has four cap atoms', /capped with 1 CH3/.test(tl.what) && tl.on === 'CH3' && tl.temp === 4, JSON.stringify(tl).slice(0, 160));
await page.click('#pauseView button[data-view="all"]'); await page.waitForTimeout(200);
await page.click('#pauseGo');
await page.waitForFunction(() => document.getElementById('pauseBar').hidden && !document.getElementById('btnPModel').classList.contains('running') && /model system/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
const pmd = await D(() => ({ s: document.getElementById('status3d').textContent, hidden: window.dworm2d.pauseHidden, temp: window.dworm2d.viewer.getModel(1) !== window.dworm2d.viewer.getModel(0), bar: document.getElementById('pauseView').hidden }));
check('CONTINUE runs with what was shown — the methyl-capped model — and the pause leaves nothing behind', /capped with 1 CH3/.test(pmd.s) && pmd.hidden === null && !pmd.temp && pmd.bar, pmd.s.slice(0, 100));
/* pREST */
await D(() => window.dworm2d.optSet('rest', '3'));
await D(() => { window.dworm2d.runPRest(); });
await page.waitForFunction(() => !document.getElementById('pauseBar').hidden, null, { timeout: 30000 }); await page.waitForTimeout(300);
const pr = await D(() => ({ what: document.getElementById('pauseWhat').textContent, btn: document.getElementById('btnPRest').textContent }));
check('pREST pauses too, naming the held model and the free shell', /^the shell, capped: pREST: 2 atoms held as the model/.test(pr.what) && pr.btn === 'PAUSED!', pr.what.slice(0, 120));
const heldBefore = await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).slice(3, 5).map(a => [a.x, a.y, a.z]));
await page.click('#pauseGo');
await page.waitForFunction(() => document.getElementById('pauseBar').hidden && !document.getElementById('btnPRest').classList.contains('running') && /pREST/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
const prd = await D(() => ({ s: document.getElementById('status3d').textContent, held: window.dworm2d.viewer.getModel().selectedAtoms({}).slice(3, 5).map(a => [a.x, a.y, a.z]), undo: window.dworm2d.undoDepth }));
check('pREST relaxed the shell around the held model: the model did not move, the energy is sane and in brackets, one whole-structure undo', JSON.stringify(prd.held) === JSON.stringify(heldBefore) && /\[E \d+\.\d → \d+\.\d kcal\/mol \(UFF, the shell around a held model/.test(prd.s) && /atoms moved/.test(prd.s) && (await D(() => document.querySelector('#status3d .approx') !== null)), prd.s.slice(0, 200));
await D(() => window.dworm2d.optSet('pause', 'never')); await D(() => window.dworm2d.optSet('rest', 'all'));
await D(() => { window.dworm2d.runPRest(); });
await page.waitForFunction(() => !document.getElementById('btnPRest').classList.contains('running') && /all of it/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
check('pREST with the whole rest cuts nothing: 13 free, no caps', /13 free, 0 held at the cuts, no bonds to cut/.test(await status()), (await status()).slice(0, 120));
await D(() => window.dworm2d.optSet('rest', '5'));
/* MIN pPERIODIC has MODEL / REST / ALL and no TAIL */
await D(() => window.dworm2d.optSet('pause', 'always'));
await page.click('#btnPPBC'); await page.waitForTimeout(600);
await page.click('#btnMinPeriodic');
await page.waitForFunction(() => !document.getElementById('pauseBar').hidden, null, { timeout: 30000 }); await page.waitForTimeout(300);
const pp = await D(() => ({ view: !document.getElementById('pauseView').hidden, tail: !document.getElementById('pauseTail').hidden }));
await page.click('#pauseView button[data-view="rest"]'); await page.waitForTimeout(200);
const ppRest = await D(() => window.dworm2d.pauseHidden ? window.dworm2d.pauseHidden.length : 0);
await page.click('#pauseStop'); await page.waitForTimeout(500);
check('MIN pPERIODIC\'s pause has the three views and no TAIL; REST shows the image shell alone', pp.view && !pp.tail && ppRest === 15 && (await D(() => window.dworm2d.pauseHidden)) === null, `${ppRest} hidden`);
await D(() => window.dworm2d.optSet('pause', 'never'));
check('the OPTIONS know the caps and the shell', (await D(() => window.dworm2d.optGet('cap'))) === 'H' && (await D(() => window.dworm2d.optGet('rest'))) === '5' && (await D(() => !!document.getElementById('optCap') && !!document.getElementById('optRest') && document.getElementById('optRest').options.length === 4)));

/* ------------------------------------------------------------ 11. VR: the panel outside, the room-fixed grid, Y */
await build('CCO', 9);
await D(() => window.dworm2d.goVR());
await page.waitForFunction(() => window.dwormVR && window.dwormVR.booted, null, { timeout: 90000 }); await page.waitForTimeout(1200);
await D(async () => { await window.dwormVR.buildVRMenu(); });
const kp = await D(() => { const V = window.dwormVR; const s = V.vrMenuSphere; const c = s.center; const d = p => Math.hypot(p[0] - c[0], p[1] - c[1], p[2] - c[2]);
  const p0 = [c[0], c[1], c[2]]; V.keepPanelOutside(p0); const p1 = [c[0] + s.radius * 0.5, c[1], c[2]]; V.keepPanelOutside(p1); const far = [c[0] + s.radius * 3, c[1] + 1, c[2]]; const fc = far.slice(); V.keepPanelOutside(far);
  return { R: s.radius, clear: V.VR_PANEL_CLEAR, d0: d(p0), d1: d(p1), farSame: far.every((x, i) => x === fc[i]), out: (p1[0] - c[0]) > 0 }; });
check('the hand panel is kept outside the structure\'s sphere with a margin — a hand inside the molecule puts it on the near side, a hand outside is left alone', kp.clear === 1.15 && kp.d0 > kp.R * 1.15 && Math.abs(kp.d0 - kp.d1) < 1e-9 && kp.farSame && kp.out, JSON.stringify(kp));
const snap = await D(() => JSON.stringify([window.dwormVR.groundCentreFor(0.4, -1.6, 0.7), window.dwormVR.groundCentreFor(-1.51, -1.6, 2.49), window.dwormVR.VR_GROUND_STEP_M, window.dwormVR.VR_GROUND_RADIUS_M]));
check('the floor\'s centre snaps to whole metres under the head — a metre grid fixed to the room, following in jumps the grid cannot show', snap === '[[0,-1.6,1],[-2,-1.6,2],1,10]', snap);
const fl = await D(async () => { const V = window.dwormVR; V.toggleFloor(); await new Promise(r => setTimeout(r, 600)); const on = { bg: window.__plugin.canvas3d.props.renderer.backgroundColor, ground: V.vrDyn.ground.on && !!V.vrDyn.ground.repr, msg: document.getElementById('msg').textContent };
  V.toggleFloor(); await new Promise(r => setTimeout(r, 400)); const off = { bg: window.__plugin.canvas3d.props.renderer.backgroundColor, ground: V.vrDyn.ground.on };
  V.setVRBackground(V.VR_BG_COLOURS.findIndex(c => c.name === 'dark blue')); V.toggleFloor(); await new Promise(r => setTimeout(r, 300)); V.toggleFloor(); await new Promise(r => setTimeout(r, 300));
  return { on, off, back: window.__plugin.canvas3d.props.renderer.backgroundColor }; });
check('Y toggles the floor: HORIZON with its grid, then the background you had before it', fl.on.bg === 0x2b3a4d && fl.on.ground && /Floor on/.test(fl.on.msg) && fl.off.bg === 0 && !fl.off.ground && fl.back === 0x14335c, JSON.stringify(fl));
const help = await D(() => window.dwormVR.VR_HELP_LINES.join('|'));
check('the help card says Y is the floor and the picture is on the menu', /Y\s+FLOOR ON OFF/.test(help) && /PICTURE\s+ON THE MENU/.test(help), help);
check('and the flat HELP overlay agrees', /floor/i.test(await D(() => document.getElementById('helpDlg').textContent)));
await D(() => document.getElementById('btnReturn').click());
await page.waitForFunction(() => /Back from/.test(document.getElementById('msg').textContent), null, { timeout: 90000 });

/* ------------------------------------------------------------ the versions and the errors */
const src = readFileSync(APP + 'index.html', 'utf8');
const vr = readFileSync(APP + '2dworm-vr.html', 'utf8');
check('index.html and 2dworm-vr.html are 0.20.0, build 28 or later', /version:\s*'0\.(20|2[1-9]|[3-9]\d)\.\d+'/.test(src) && /build:\s*(2[89]|[3-9]\d)/.test(src) && /version:\s*'0\.(20|2[1-9]|[3-9]\d)\.\d+'/.test(vr));
check('no page errors along the way', errors.length === 0, errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const passed = results.filter(r => r.ok).length;
console.log(`\n${passed}/${results.length} passed`);
process.exit(passed === results.length ? 0 : 1);
