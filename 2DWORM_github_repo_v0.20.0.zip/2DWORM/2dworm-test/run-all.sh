#!/bin/sh
# Every suite, one after another — they each start their own PHP server and a browser, so
# running them at the same time makes them fight for the CPU and fail for reasons that are
# not real. The tally at the end is what the README quotes.
cd "$(dirname "$0")" || exit 1
OUT="${1:-/tmp/suite}"
mkdir -p "$OUT"
: > "$OUT/summary.txt"
for s in test qcgeom mdgeom qcresults crystal names sellang session fragments pmodel ppbc periodic frame cube geo reps fetchdb server lang qcopen field terms admin settings counts edit notes vr uff bench select build24 build25 build26 build27 build28 bigmol memory uff-cross; do
  printf '%-10s ' "$s" >> "$OUT/summary.txt"
  start=$(date +%s)
  node "$s.mjs" > "$OUT/$s.log" 2>&1
  rc=$?
  line=$(grep -E '^[0-9]+/[0-9]+ passed' "$OUT/$s.log" | tail -1)
  fails=$(grep -c '^FAIL' "$OUT/$s.log")
  printf '%s  rc=%s  fails=%s  %ss\n' "${line:-NO TALLY}" "$rc" "$fails" "$(( $(date +%s) - start ))" >> "$OUT/summary.txt"
  cat "$OUT/summary.txt" | tail -1
done
echo "--- done" >> "$OUT/summary.txt"
