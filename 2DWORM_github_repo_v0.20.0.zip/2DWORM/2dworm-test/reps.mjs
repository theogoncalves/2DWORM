/* ONE LOOK FOR PART OF THE STRUCTURE — per-selection representations, glass, and neon.
 *
 * A figure of a protein with its ligand in space filling is one picture, and a single global
 * representation menu cannot make it. These are exceptions to the global scheme: a list of
 * (atoms, scheme) applied over it.
 *
 * What is worth asserting is not "it looks different" — anything looks different — but that
 * the RIGHT atoms changed and the others did not, that the exceptions survive a share (a
 * figure that arrives looking unlike the one that was sent is the one thing a link must not
 * do), that they are filtered against the structure that actually arrived, and that they go
 * with the structure they were made for.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8804;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));

await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CC(=O)Oc1ccccc1C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 120000 });
await page.waitForTimeout(400);
if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
await page.waitForSelector('#selRepSel', { state: 'visible', timeout: 10000 });

/** What 3Dmol has actually been told to draw for each atom — its own record, not ours. */
const styles = () => page.evaluate(() =>
  window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => Object.keys(a.style || {}).sort().join('+')));
const pick = (idx) => page.evaluate((ids) => {
  window.dworm2d.state3d.sel = ids.slice();
  window.dworm2d.saySelection();
}, idx);
const applyTo = async (kind) => {
  await page.selectOption('#selRepSel', kind);
  await page.waitForTimeout(500);
};

const before = await styles();
check('every atom starts in the global scheme', new Set(before).size === 1, before[0]);

/* 3Dmol selects on any atom property, `index` included, and on an array of values for it —
   which is what makes "these atoms and no others" one call rather than one call per atom. */
await pick([0, 1, 2]);
await applyTo('cpk');
const after = await styles();
check('the picked atoms take the new scheme and nothing else does',
  after.slice(0, 3).every(x => x === 'sphere') && after.slice(3).every(x => x === before[3]),
  `${after.slice(0, 3).join(' ')} | rest ${after[5]}`);
check('and the button that undoes it appears only now that there is something to undo',
  await page.isVisible('#btnRepClear'));

/* Space filling has per-element radii, like the global pass does — an oxygen must not come
   out the size of a carbon just because it is in an exception. */
const radii = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  const seen = {};
  for (let i = 0; i < 3; i++) seen[a[i].elem] = (a[i].style.sphere || {}).radius || (a[i].style.sphere || {}).scale;
  return seen;
});
check('and they keep their own van der Waals radii, element by element',
  Object.keys(radii).length >= 2 && new Set(Object.values(radii)).size >= 2, JSON.stringify(radii));

/* A second exception over overlapping atoms replaces the first for those atoms — later wins,
   which is the only rule that makes "apply, look, apply again" behave as it reads. */
await pick([2, 3]);
await applyTo('wire');
const two = await styles();
check('a later scheme wins where two overlap, so applying again is a correction not a blend',
  two[0] === 'sphere' && two[2] === 'line' && two[3] === 'line', two.slice(0, 5).join(' '));

await pick([4]);
await applyTo('hide');
check('“hidden” draws nothing at all for those atoms', (await styles())[4] === '');

/* ------------------------------------------------------------------ it travels */
const shared = await page.evaluate(async () => {
  const st = await window.dworm2d.buildState('full');
  return { reps: st.reps, n: (st.reps || []).length };
});
check('the schemes travel inside a shared link, beside the dashed lines',
  shared.n === 3 && shared.reps[0].k === 'cpk' && shared.reps[2].k === 'hide',
  shared.reps.map(r => r.k + '×' + r.i.length).join(', '));

const round = await page.evaluate(async () => {
  const st = await window.dworm2d.buildState('full');
  window.dworm2d.state3d.reps = [];
  window.dworm2d.applyStyle(window.dworm2d.viewer);
  await new Promise(r => setTimeout(r, 300));
  const cleared = window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => Object.keys(a.style || {}).sort().join('+'));
  await window.dworm2d.applyState(st);
  await new Promise(r => setTimeout(r, 1200));
  return { cleared, back: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => Object.keys(a.style || {}).sort().join('+')) };
});
check('and opening that link gives back the same picture, not a different one',
  new Set(round.cleared).size === 1 && round.back[0] === 'sphere' && round.back[2] === 'line' && round.back[4] === '',
  round.back.slice(0, 6).join(' '));

/* A link is text somebody else can edit. An index past the end of the structure would style
   an atom that is not there — or, worse, a different one. */
const hostile = await page.evaluate(async () => {
  const st = await window.dworm2d.buildState('full');
  st.reps = [{ k: 'cpk', i: [0, 99999, -3, 1.5] }, { k: 'not-a-scheme', i: [1] }, { k: 'wire', i: [] }];
  await window.dworm2d.applyState(st);
  await new Promise(r => setTimeout(r, 1000));
  return window.dworm2d.state3d.reps.map(r => r.kind + ':' + r.idx.join(','));
});
check('rubbish in the link is filtered out rather than drawn',
  hostile.length === 1 && hostile[0] === 'cpk:0', hostile.join(' | '));

/* ------------------------------------------------------------------ they belong to the structure */
const gone = await page.evaluate(async () => {
  const D = window.dworm2d;
  D.state3d.reps = [{ kind: 'cpk', idx: [0, 1] }];
  const k = await D.whenKetcher(); await k.setMolecule('CCO');
  document.getElementById('btnMake3d').click();
  await new Promise(r => setTimeout(r, 3500));
  return { reps: D.state3d.reps.length, hidden: document.getElementById('btnRepClear').hidden };
});
/* The list is atom INDICES, and index 0 means a different atom in a different structure. */
check('building another structure takes the schemes with the old one',
  gone.reps === 0 && gone.hidden === true);

/* ------------------------------------------------------------------ undo */
const undo = await page.evaluate(async () => {
  const D = window.dworm2d;
  D.state3d.sel = [0, 1]; D.saySelection();
  const sel = document.getElementById('selRepSel');
  sel.value = 'glass'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 500));
  const on = D.state3d.reps.length;
  document.getElementById('btnUndo').click();
  await new Promise(r => setTimeout(r, 500));
  return { on, off: D.state3d.reps.length };
});
check('UNDO takes a scheme back off', undo.on === 1 && undo.off === 0, `${undo.on} → ${undo.off}`);

/* ------------------------------------------------------------------ the two new looks */
const glass = await page.evaluate(() => {
  const st = window.dworm2d.styleFor('glass');
  return { stick: st.stick.opacity, sphere: st.sphere.opacity };
});
/* A transparent stick is the point of glass: a group inside a cage has to be visible THROUGH
   what surrounds it, and an opaque one at 100 % is just ball and stick. */
check('glass is transparent in both the sticks and the spheres',
  glass.stick > 0 && glass.stick < 1 && glass.sphere > 0 && glass.sphere < 1,
  `stick ${glass.stick}, sphere ${glass.sphere}`);

const neon = await page.evaluate(() => {
  const st = window.dworm2d.styleFor('neon');
  return { stickR: st.stick.radius, stickC: st.stick.color, sphereC: st.sphere.color,
           bloom: st.sphere.opacity, outline: window.dworm2d.OUTLINE_COLOUR.neon };
});
/* Neon is a THIN BRIGHT FILAMENT inside a soft halo of the same colour. Two bright colours
   side by side — which is what it was — is not neon, it is two bright colours. The halo is
   a translucent sphere in the filament's own colour, and the outline is a second one. */
check('neon is a thin filament inside a halo of its own colour, not two bright colours',
  neon.stickR <= 0.08 && neon.stickC === neon.sphereC && neon.bloom > 0 && neon.bloom < 0.5 &&
  neon.outline === neon.stickC,
  `filament ${neon.stickR} A in ${neon.stickC}, halo at ${neon.bloom}, outline ${neon.outline}`);
const dark = await page.evaluate(async () => {
  const sel = document.getElementById('selStyle');
  sel.value = 'neon'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 700));
  return { bg: window.dworm2d.opts.bg, outline: window.dworm2d.opts.outline };
});
check('and choosing it darkens the background and switches the outline on, because it only reads as light in the dark',
  dark.bg === '#000000' && dark.outline > 0, `bg ${dark.bg}, outline ${dark.outline}`);

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
