/* BUILD 24 — what it added, checked in a real browser.
   The session file round trip (a cube's surface frozen into a .2dworm.zip and opened again),
   the cube thinning, the coloured marks and the DOUBLE halo, the SELECT menu and the
   expression window, GROW, the three-state ⛶, OPTIONS and the Ketcher keyboard rule, the
   MolStar-VR button, HD/MED/FAST, right-click, the periodic CELL FIX, the share fallback for
   a structure that came from a file, the RESULTS window on a real Gaussian output, a CIF with
   symmetry and the crystal builder, CELL EXTEND asking above its threshold, the whole-structure
   UNDO and RESET ALL, a retired code, and the molecule of the day. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const CORPUS = fileURLToPath(new URL('./corpus/', import.meta.url));
const PORT = 8824;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP], { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
const D = (fn, arg) => page.evaluate(fn, arg);

/* ------------------------------------------------ a cube, thinned, frozen, saved, reopened */
/** a 120^3 cube = 1.73 million points, just over the thinning threshold; a p-like function */
function makeCube(n, name) {
  const L = [' 2D-WORM build-24 test cube', ' p-like', `    2   -6.000000   -6.000000   -6.000000    1`,
    `  ${n}     0.100000    0.000000    0.000000`, `  ${n}     0.000000    0.100000    0.000000`, `  ${n}     0.000000    0.000000    0.100000`,
    '    1    1.000000   -1.400000    0.000000    0.000000', '    1    1.000000    1.400000    0.000000    0.000000'];
  const rows = [];
  for (let ix = 0; ix < n; ix++) for (let iy = 0; iy < n; iy++) {
    let row = '';
    for (let iz = 0; iz < n; iz++) {
      const x = -6 + ix * 0.1, y = -6 + iy * 0.1, z = -6 + iz * 0.1;
      row += ' ' + (Math.exp(-(x * x + y * y + z * z) / 6) * Math.tanh(x)).toExponential(4);
      if (iz % 6 === 5) { rows.push(row); row = ''; }
    }
    if (row) rows.push(row);
  }
  return L.join('\n') + '\n' + rows.join('\n') + '\n';
}
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'b24-'));
const cubePath = path.join(tmp, 'big.cube');
fs.writeFileSync(cubePath, makeCube(120, 'big.cube'));
await page.setInputFiles('#fileInput', [cubePath]);
await page.waitForFunction(() => window.dworm2d.state3d.field, null, { timeout: 120000 });
await page.waitForTimeout(1200);
const f1 = await D(() => { const f = window.dworm2d.state3d.field; return { stride: f.stride, points: f.points, shapes: window.dworm2d.state3d.fieldShapes.length, nvl: f.text.split('\n')[3].trim(), original: !!f.original }; });
check('a cube with an NVAL field on line 3 opens (the Gaussian fifth number)', f1.points === 120 * 120 * 120, JSON.stringify(f1));
check('a 1.7-million-point grid is thinned to every second point before marching', f1.stride === 2 && /^\s*60\b/.test(f1.nvl), f1.nvl);
check('and the original text is kept for a "+ volumes" save', f1.original);
check('both lobes are drawn and remembered as the field\'s shapes', f1.shapes === 2);
check('the status line says the grid was thinned', /thinned to every second point/.test(await page.textContent('#msg')));

/* mark two atoms, keep them as a mark, then save the session */
await D(() => { window.dworm2d.state3d.sel = [0]; window.dworm2d.saySelection(); });
await page.click('#btnEdit');
await page.waitForTimeout(300);
await page.selectOption('#selMarkColour', '#ffd400');
await page.click('#btnMark');
await page.waitForTimeout(300);
const marks = await D(() => ({ n: window.dworm2d.state3d.marks.length, colour: window.dworm2d.state3d.marks[0].colour, legend: !document.getElementById('markLegend').hidden, sel: window.dworm2d.state3d.sel.length }));
check('KEEP turns the picked atoms into a mark in the chosen colour and clears the pick', marks.n === 1 && marks.colour === '#ffd400' && marks.sel === 0, JSON.stringify(marks));
check('and the legend appears in the corner', marks.legend);
const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), D(() => window.dworm2d.doSave('session'))]);
const sessPath = path.join(tmp, dl.suggestedFilename());
await dl.saveAs(sessPath);
const sessBytes = fs.readFileSync(sessPath);
check('SAVE SESSION downloads a .2dworm.zip', /\.2dworm\.zip$/.test(dl.suggestedFilename()) && sessBytes[0] === 0x50 && sessBytes[1] === 0x4b, dl.suggestedFilename() + ' ' + sessBytes.length + ' bytes');
check('which is a few hundred kB at most — the mesh, not the 30 MB grid', sessBytes.length < 3 * 1024 * 1024 && sessBytes.length > 20 * 1024, (sessBytes.length / 1024).toFixed(0) + ' kB');
check('the page said what went in', /frozen surface/.test(await page.textContent('#msg')), (await page.textContent('#msg')).slice(0, 120));

/* open it again in a fresh page */
const page2 = await ctx.newPage();
await page2.goto(`http://127.0.0.1:${PORT}/index.html`);
await page2.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
await page2.setInputFiles('#fileInput', [sessPath]);
await page2.waitForFunction(() => /Opened .*2dworm\.zip/.test(document.getElementById('msg').textContent) || /Could not/.test(document.getElementById('msg').textContent), null, { timeout: 120000 });
await page2.waitForTimeout(1200);
const back = await page2.evaluate(() => ({
  msg: document.getElementById('msg').textContent, atoms: window.dworm2d.state3d.nAtoms, frozen: (window.dworm2d.state3d.frozen || []).length,
  shapes: (window.dworm2d.viewer.shapes || []).filter(Boolean).length, isoDisabled: document.getElementById('selIso').disabled,
  isoHidden: document.getElementById('selIso').hidden, marks: (window.dworm2d.state3d.marks || []).length,
  markColour: window.dworm2d.state3d.marks[0] && window.dworm2d.state3d.marks[0].colour, original: window.dworm2d.state3d.original && window.dworm2d.state3d.original.name,
  field: !!window.dworm2d.state3d.field, tris: (window.dworm2d.state3d.frozen || []).reduce((n, m) => n + m.indices.length / 3, 0) }));
check('the session opens: the structure is back', back.atoms === 2, JSON.stringify(back).slice(0, 200));
check('the two lobes come back as FROZEN surfaces, drawn, with no grid behind them', back.frozen === 2 && back.shapes >= 2 && !back.field, `${back.frozen} frozen, ${back.shapes} shapes, ${back.tris} triangles`);
check('the isovalue menu is greyed with the reason rather than offering values it cannot honour', back.isoDisabled && !back.isoHidden);
check('the mark came back in its colour', back.marks === 1 && back.markColour === '#ffd400');
check('a cube is not stored as the "original" — it is a volume, and volumes are opt-in', !back.original, String(back.original));
check('and the message says a frozen surface is a picture, not a field', /frozen surface/.test(back.msg) && /original cube/.test(back.msg), back.msg.slice(0, 160));
/* dropping the original cube back replaces the frozen mesh and the sliders return */
await page2.setInputFiles('#fileInput', [cubePath]);
await page2.waitForFunction(() => window.dworm2d.state3d.field, null, { timeout: 120000 });
await page2.waitForTimeout(800);
check('dropping the original cube on a restored session brings the live field back', await page2.evaluate(() => !!window.dworm2d.state3d.field && !document.getElementById('selIso').disabled && (window.dworm2d.state3d.frozen || []).length === 0));
await page2.close();

/* ------------------------------------------------ the SELECT menu, the expression window, GROW */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CC(=O)Oc1ccccc1C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 21, null, { timeout: 120000 });
await page.waitForTimeout(500);
const elems = await page.$$eval('#selPickElems option', o => o.map(x => x.value));
check('the SELECT menu lists the elements of THIS structure, with counts', elems.includes('elem:O') && elems.includes('elem:C') && elems.includes('elem:H') && !elems.includes('elem:Fe'), elems.join(','));
await page.selectOption('#selPick', 'elem:O');
await page.waitForTimeout(400);
check('"by element" picks every oxygen', await D(() => window.dworm2d.state3d.sel.length) === 4);
await page.selectOption('#selPick', 'invert');
await page.waitForTimeout(400);
check('"invert" picks everything else', await D(() => window.dworm2d.state3d.sel.length) === 17);
await page.selectOption('#selPick', 'custom');
await page.waitForTimeout(400);
check('"expression…" opens the window with the worked examples', await page.isVisible('#selDlg') && (await page.$$eval('#selExamples code', c => c.length)) >= 10);
await page.fill('#selExpr', 'O(<3A) _NOT_ H');
await page.waitForTimeout(150);
check('a well-formed expression gets a tick as it is typed', (await page.textContent('#selExprMsg')).trim() === '✓');
await page.fill('#selExpr', 'O(<3A _NOT_ H');
await page.waitForTimeout(150);
check('a malformed one gets a sentence, not a silence', /expected|found|missing/.test(await page.textContent('#selExprMsg')), await page.textContent('#selExprMsg'));
await page.fill('#selExpr', 'O(<1.5A) _NOT_ H');
await page.click('#selExprGo');
await page.waitForTimeout(500);
const custom = await D(() => ({ n: window.dworm2d.state3d.sel.length, open: document.getElementById('selDlg').classList.contains('open'), msg: document.getElementById('status3d').textContent }));
check('SELECT applies it: the heavy atoms within 1.5 Å of an oxygen', custom.n > 0 && custom.n < 10 && !custom.open, JSON.stringify(custom).slice(0, 160));
await D(() => { window.dworm2d.state3d.sel = [0]; window.dworm2d.saySelection(); });
await page.waitForTimeout(200);
const growEnabled = await page.$eval('#growR', r => !r.disabled);
check('GROW arms once something is picked', growEnabled);
await page.evaluate(() => { const r = document.getElementById('growR'); r.value = '2'; r.dispatchEvent(new Event('input', { bubbles: true })); });
await page.waitForTimeout(400);
const grown = await D(() => ({ n: window.dworm2d.state3d.sel.length, v: document.getElementById('growV').textContent }));
check('two bonds out from one atom is more atoms, and the readout says how many', grown.n > 1 && new RegExp('2 bonds · ' + grown.n + ' atoms').test(grown.v), JSON.stringify(grown));
await page.evaluate(() => { const r = document.getElementById('growR'); r.value = '0'; r.dispatchEvent(new Event('input', { bubbles: true })); });
await page.waitForTimeout(300);
check('and walking back to zero is exactly what was picked — reference-based, no drift', await D(() => window.dworm2d.state3d.sel.join(',')) === '0');
await page.evaluate(() => document.getElementById('growR').dispatchEvent(new Event('change', { bubbles: true })));

/* ------------------------------------------------ the DOUBLE mark */
await D(() => { window.dworm2d.state3d.sel = [1]; window.dworm2d.opts.halo = 'double'; window.dworm2d.saySelection(); window.dworm2d.applyStyle(window.dworm2d.viewer); });
await page.waitForTimeout(400);
const dbl = await D(() => { const v = window.dworm2d.viewer; const a = v.getModel().selectedAtoms({})[1];
  const cages = v.shapes.filter(sh => sh && sh.wireframe); return { cages: cages.length, cageCol: cages[0] ? [cages[0].color.r, cages[0].color.g, cages[0].color.b].map(x => +x.toFixed(2)) : null, atomCol: a.style.sphere && a.style.sphere.color, keys: Object.keys(a.style).sort().join('+') }; });
check('DOUBLE is a tinted atom inside a wireframe cage', dbl.cages === 1 && dbl.atomCol === '#ffd400' || dbl.cages === 1 && !!dbl.atomCol, JSON.stringify(dbl));
check('and the cage is the contrast colour — near black on a white page — never the mark colour', dbl.cageCol && dbl.cageCol[0] < 0.1 && dbl.cageCol[1] < 0.1, JSON.stringify(dbl.cageCol));
check('tint recolours only what the atom already draws, adding no primitive', dbl.keys === 'sphere+stick', dbl.keys);
await page.click('#btnEdit');

/* ------------------------------------------------ the export carries the legend */
const png = await D(() => window.dworm2d.render3dImage(1, 'image/png'));
check('a PNG export with kept marks is drawn through the canvas that carries the legend', typeof png === 'string' && png.startsWith('data:image/png') && png.length > 20000);

/* ------------------------------------------------ HD / MED / FAST, right-click, MolStar-VR */
const segs = await page.$$eval('#renderSeg button', b => b.map(x => x.dataset.render + ':' + x.textContent.trim()));
check('the render modes are HD, MED and FAST', segs.join(' ') === 'hd:HD quality:MED fast:FAST', segs.join(' '));
check('FAST is red, always — it is the one that withholds', await page.$eval('#renderSeg button[data-render="fast"]', b => getComputedStyle(b).color) === 'rgb(200, 53, 43)');
await page.click('#renderSeg button[data-render="hd"]');
await page.waitForTimeout(300);
check('HD is a real mode the page remembers', await D(() => window.dworm2d.opts.render) === 'hd');
await page.click('#renderSeg button[data-render="quality"]');
await D(() => { window.dworm2d.state3d.sel = [0, 1]; window.dworm2d.saySelection(); });
await page.click('#viewer3d', { button: 'right', position: { x: 50, y: 50 } });
await page.waitForTimeout(200);
check('the right mouse button clears the selection', await D(() => window.dworm2d.state3d.sel.length) === 0);
check('the one VR button says MolStar-VR, wears goggles, and stands next to NOTES (the copy in the 3D row went in build 27)',
  /MolStar-VR/.test(await page.textContent('#btnVR')) && /🥽/.test(await page.textContent('#btnVR')) && (await page.$$('.vrbtn')).length === 1);
check('MIN PERIODIC is MIN pPERIODIC — the p says it is an approximation', (await page.textContent('#btnMinPeriodic')).trim() === 'MIN pPERIODIC');

/* ------------------------------------------------ ⛶ three states, OPTIONS, the keyboard rule */
const solo = await D(() => {
  const app = document.getElementById('app'), b = document.getElementById('btnSolo3d');
  b.click(); const one = app.classList.contains('solo') && !app.classList.contains('barsoff');
  b.click(); const two = app.classList.contains('solo') && app.classList.contains('barsoff') && !document.getElementById('barsBtn').hidden;
  b.click(); const three = !app.classList.contains('solo');
  return { one, two, three };
});
check('⛶ is three states: solo, then MAX with the way out still on screen, then back', solo.one && solo.two && solo.three, JSON.stringify(solo));
check('no requestFullscreen anywhere — one behaviour on every platform, iPhone included', !/requestFullscreen/.test(fs.readFileSync(APP + 'index.html', 'utf8').replace(/\/\*[\s\S]*?\*\/|<!--[\s\S]*?-->/g, '')));
check('a web app manifest exists, with standalone display and icons', (() => { try { const m = JSON.parse(fs.readFileSync(APP + 'manifest.json', 'utf8')); return m.display === 'standalone' && m.icons.length >= 2 && fs.existsSync(APP + 'icons/icon-192.png'); } catch (e) { return false; } })());
await page.click('#btnOptions');
await page.waitForTimeout(200);
check('OPTIONS opens as a window with the keyboard rule in it', await page.isVisible('#optDlg') && await page.isVisible('#optKbd'));
await page.selectOption('#optKbd', 'never');
await page.waitForTimeout(300);
const kbd = await D(() => { const d = document.getElementById('ketcherFrame').contentDocument; const t = d.querySelector('textarea[class*="cliparea"]'); return { im: t && t.getAttribute('inputmode'), url: location.search }; });
check('"never" puts inputmode=none on Ketcher\'s hidden textarea, the thing that raised the keyboard', kbd.im === 'none', JSON.stringify(kbd));
check('and the choice is a parameter in the address, so it travels with a link', /kbd=never/.test(kbd.url), kbd.url);
await page.selectOption('#optKbd', 'always');
await page.waitForTimeout(200);
check('"always" takes it off again', await D(() => { const d = document.getElementById('ketcherFrame').contentDocument; const t = d.querySelector('textarea[class*="cliparea"]'); return t && !t.hasAttribute('inputmode'); }));
await page.selectOption('#optKbd', 'auto');
await page.keyboard.press('Escape');

/* ------------------------------------------------ CELL FIX, periodic */
const split = `SPLIT WATER
   1.00000000000000
    10.0000000  0.0000000  0.0000000
     0.0000000 10.0000000  0.0000000
     0.0000000  0.0000000 10.0000000
   O  H
   1  2
Cartesian
 0.30 5.00 5.00
 1.26 5.00 5.00
 9.64 5.70 5.00
`;
fs.writeFileSync(path.join(tmp, 'POSCAR'), split);
await page.setInputFiles('#fileInput', [path.join(tmp, 'POSCAR')]);
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 3, null, { timeout: 60000 });
await page.waitForTimeout(400);
check('the periodic fix is the default CELL FIX mode', await page.$eval('#selCellFix', s => s.value) === 'periodic');
await D(() => window.dworm2d.cellFix('periodic'));
await page.waitForTimeout(500);
const fixed = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({}); const d = (i, j) => Math.hypot(a[i].x - a[j].x, a[i].y - a[j].y, a[i].z - a[j].z); return { oh1: d(0, 1), oh2: d(0, 2), bonds: a[0].bonds.length, msg: document.getElementById('status3d').textContent }; });
check('a water the cell wall split is reassembled: both O–H under 1 Å', fixed.oh1 < 1.0 && fixed.oh2 < 1.0, JSON.stringify(fixed).slice(0, 200));
check('and the bond the wall had cut is drawn, because the walk knew it', fixed.bonds === 2);
check('the message says it was reassembled from pieces', /reassembled/.test(fixed.msg), fixed.msg.slice(0, 120));

/* ------------------------------------------------ the share fallback for a file-derived structure */
await page.setInputFiles('#fileInput', [CORPUS + '8yax.fw2.cif']);
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 40000, null, { timeout: 120000 });
check('the 40,738-atom mmCIF names itself as PDB entry 8YAX', await D(() => window.dworm2d.pdbIdOf(window.dworm2d.state3d.data)) === '8YAX');
check('a structure that came from a file is known to be one', await D(() => window.dworm2d.structureFromFile()));
await page.click('#btnShare');
await page.waitForTimeout(400);
await D(() => window.dworm2d.setShareMode('short'));
await page.waitForFunction(() => document.getElementById('askDlg').classList.contains('open'), null, { timeout: 60000 });
const offer = await D(() => ({ title: document.getElementById('askTitle').textContent, yes: document.getElementById('askYes').textContent }));
check('the short link offers to share it as rcsb:8YAX instead of stepping down to an empty drawing', /8YAX/.test(offer.title) && /SHARE AS 8YAX/.test(offer.yes), JSON.stringify(offer));
await page.waitForTimeout(300);
await D(() => document.getElementById('askNo').click());
await page.waitForFunction(() => /none was made|permanent store/.test(document.getElementById('shareModeNote').textContent), null, { timeout: 60000 });
const refused = await D(() => ({ url: document.getElementById('shareUrl').value, note: document.getElementById('shareModeNote').textContent }));
check('declined: NO link is made, and the sentence names the size, SAVE SESSION and the permanent store', refused.url === '' && /MB/.test(refused.note) && /SAVE SESSION/.test(refused.note) && /permanent store/.test(refused.note), refused.note.slice(0, 160));

await D(() => document.getElementById('shareDlg').classList.remove('open'));

/* ------------------------------------------------ RESULTS: the optimisation and the modes of a real output */
await page.setInputFiles('#fileInput', [CORPUS + 'C18-B9N9.out']);
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 36, null, { timeout: 120000 });
await page.waitForTimeout(400);
check('a Gaussian output opens on its last geometry and the RESULTS button appears', !(await page.$eval('#btnResults', b => b.hidden)));
check('the summary knows the file before the window is opened', await D(() => { const q = window.dworm2d.state3d.qcSummary; return q && q.steps === 43 && q.modes === 102 && q.program === 'Gaussian'; }));
await page.click('#btnResults');
await page.waitForFunction(() => document.getElementById('resDlg').classList.contains('open'), null, { timeout: 60000 });
await page.waitForTimeout(800);
const res = await D(() => ({ title: document.getElementById('resTitle').textContent, head: document.getElementById('resHead').textContent, steps: window.dworm2d.resData.steps.length, modes: window.dworm2d.resData.modes.length, stepV: document.getElementById('resStepV').textContent, conv: document.getElementById('resConv').textContent }));
check('RESULTS: 43 steps, converged, 102 modes, energies in hartree', res.steps === 43 && res.modes === 102 && /converged/.test(res.head) && /hartree/.test(res.head), res.head.slice(0, 120));
check('the last step is shown with its energy and ΔE 0.00', /step 43 of 43/.test(res.stepV) && /-1402\.0973/.test(res.stepV) && /ΔE 0\.00/.test(res.stepV), res.stepV);
check('the convergence ticks name the four criteria with value / threshold', /max force/.test(res.conv) && /RMS force/.test(res.conv) && /displacement/.test(res.conv) && /\//.test(res.conv), res.conv.slice(0, 100));
await D(() => window.dworm2d.setResTab('freq'));
await page.waitForTimeout(300);
check('the FREQUENCIES tab lists every mode, lowest first, with the IR intensity', (await page.$$eval('#resModes button', b => b.length)) === 102 && /7\.2 cm/.test(await page.$eval('#resModes button', b => b.textContent)));
await page.click('#resModes button');
await page.waitForTimeout(800);
const mode = await D(() => ({ v: document.getElementById('resModeV').textContent, frames: window.dworm2d.resViewer.getModel().getNumFrames(), anim: window.dworm2d.resViewer.isAnimated() }));
check('a mode animates in the small viewer: 3Dmol made the frames and is playing them', mode.frames >= 10 && mode.anim && /km\/mol/.test(mode.v), JSON.stringify(mode));
await D(() => window.dworm2d.setResTab('opt'));
await D(() => window.dworm2d.resShowStep(0));
const beforeUse = await D(() => window.dworm2d.state3d.data);
await D(() => window.dworm2d.resUseGeometry());
await page.waitForTimeout(500);
const used = await D(() => ({ s: document.getElementById('status3d').textContent, undo: window.dworm2d.undoDepth, open: document.getElementById('resDlg').classList.contains('open'), btn: document.getElementById('btnResults').hidden, reset: document.getElementById('btnResetAll').disabled }));
check('USE THIS GEOMETRY takes step 1 into the page, with its energy, and closes the window', /step 1 taken/.test(used.s) && /-1402\.0959/.test(used.s) && !used.open, used.s.slice(0, 120));
check('the file stays known, so RESULTS can be opened again on the new structure', !used.btn);
check('and it is one whole-structure change on the undo stack — RESET ALL arms', used.undo === 1 && !used.reset);
await D(() => window.dworm2d.editUndo());
await page.waitForTimeout(300);
check('UNDO brings the last geometry back exactly', (await D(() => window.dworm2d.state3d.data)) === beforeUse && /USE THIS GEOMETRY undone/.test(await page.textContent('#status3d')));

/* ------------------------------------------------ a CIF with symmetry, and the crystal builder */
await page.setInputFiles('#fileInput', [CORPUS + 'Urea.cif']);
await page.waitForFunction(() => /Urea/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
await page.waitForTimeout(400);
const urea = await D(() => ({ n: window.dworm2d.state3d.nAtoms, msg: document.getElementById('msg').textContent, cell: !!window.dworm2d.state3d.cell, cr: window.dworm2d.state3d.crystal }));
check('Urea.cif: the 5 atoms of the asymmetric unit become the 16 of the P-421m cell', urea.n === 16 && urea.cell && /5 atoms in the asymmetric unit → 16 in the cell/.test(urea.msg), urea.msg.slice(0, 140));
check('and the space group is named with its number', /P-421M \(No\. 113\)/i.test(urea.msg) && urea.cr && urea.cr.spaceGroup.number === 113);
await page.click('#btnEdit'); await page.waitForTimeout(300);
await page.click('#btnCrystal');
await page.waitForFunction(() => document.getElementById('crysDlg').classList.contains('open'), null, { timeout: 60000 });
await page.waitForTimeout(300);
const cd = await D(() => ({ sys: document.getElementById('crysSys').value, sg: document.getElementById('crysSG').value, nsg: document.getElementById('crysSG').options.length, bDisabled: document.getElementById('crysB').disabled, alDisabled: document.getElementById('crysAl').disabled }));
check('CRYSTAL opens on cubic Fm-3m with all 230 groups in the menu', cd.sys === 'cubic' && cd.sg === '225' && cd.nsg === 230, JSON.stringify(cd));
check('the lattice system greys what it fixes: b, c and the angles follow a', cd.bDisabled && cd.alDisabled);
await page.fill('#crysAtoms', 'Na 0 0 0\nCl 0.5 0.5 0.5');
await page.waitForTimeout(200);
check('the preview counts as you type: 2 atoms → 8 in the cell', /2 atoms → 8 in the cell/.test(await page.$eval('#crysPreview', e => e.textContent)), await page.$eval('#crysPreview', e => e.textContent));
await page.fill('#crysNa', '2'); await page.fill('#crysNb', '2'); await page.fill('#crysNc', '2');
await page.waitForTimeout(200);
check('and a 2×2×2 supercell says 64', /64 in the 2×2×2 supercell/.test(await page.$eval('#crysPreview', e => e.textContent)));
await page.click('#crysBuild');
await page.waitForFunction(() => !document.getElementById('crysDlg').classList.contains('open'), null, { timeout: 60000 });
await page.waitForTimeout(400);
const built = await D(() => ({ n: window.dworm2d.state3d.nAtoms, cell: window.dworm2d.state3d.cell, periodic: window.dworm2d.state3d.periodic, msg: document.getElementById('msg').textContent, cr: window.dworm2d.state3d.crystal }));
check('BUILD: 64 atoms of rock salt with the supercell as the cell', built.n === 64 && built.cell && Math.abs(Math.hypot(...built.cell.a) - 11.28) < 0.01 && /crystallographic/.test(built.periodic), JSON.stringify(built.cell && built.cell.a));
check('the message says what was built and how to save it', /Built F m -3 m \(No\. 225\)/.test(built.msg) && /SAVE writes it as a CIF or a POSCAR/.test(built.msg), built.msg.slice(0, 140));
await page.click('#btnCrystal'); await page.waitForTimeout(300);
await page.click('#crysFromView'); await page.waitForTimeout(300);
const fv = await D(() => ({ sys: document.getElementById('crysSys').value, sg: document.getElementById('crysSG').value, a: document.getElementById('crysA').value, lines: document.getElementById('crysAtoms').value.trim().split('\n').length, preview: document.getElementById('crysPreview').textContent }));
check('FROM THE 3D VIEW turns the screen into a P1 asymmetric unit of 64 atoms with its cell', fv.sys === 'triclinic' && fv.sg === '1' && Math.abs(parseFloat(fv.a) - 11.28) < 0.01 && fv.lines === 64 && /64 atoms → 64 in the cell/.test(fv.preview), JSON.stringify(fv));
await D(() => document.getElementById('crysDlg').classList.remove('open'));

/* ------------------------------------------------ CELL EXTEND asks above the threshold, and UNDO takes it back */
await page.setInputFiles('#fileInput', [CORPUS + 'zeolite.cif']);
await page.waitForFunction(() => /zeolite/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
await page.waitForTimeout(400);
const nz = await D(() => window.dworm2d.state3d.nAtoms);
const extending = D(() => window.dworm2d.cellExtend());
await page.waitForFunction(() => document.getElementById('askDlg').classList.contains('open'), null, { timeout: 60000 });
const askE = await D(() => ({ t: document.getElementById('askTitle').textContent, x: document.getElementById('askText').textContent, yes: document.getElementById('askYes').textContent }));
check('a framework asks before building: the numbers are known before anything is built', /Extend the cell/.test(askE.t) && /216 become 60,000/.test(askE.x) && /framework/.test(askE.x) && /BUILD/.test(askE.yes), askE.x.slice(0, 120));
await D(() => document.getElementById('askYes').click());
await extending;
await page.waitForTimeout(800);
const ext = await D(() => ({ n: window.dworm2d.state3d.nAtoms, undo: window.dworm2d.undoDepth, reset: document.getElementById('btnResetAll').disabled }));
check('BUILD makes the 60,000-atom block and puts one whole-structure record on the stack', ext.n === 60000 && ext.undo === 1 && !ext.reset, JSON.stringify(ext));
await D(() => window.dworm2d.editUndo());
await page.waitForTimeout(500);
check('UNDO returns the 216-atom cell with its periodicity', (await D(() => window.dworm2d.state3d.nAtoms)) === nz && (await D(() => !!window.dworm2d.state3d.cell && /cell/.test(window.dworm2d.state3d.periodic || ''))) && /CELL EXTEND undone/.test(await page.textContent('#status3d')));

/* ------------------------------------------------ a structure BUILT FROM THE DRAWING survives a session */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 9, null, { timeout: 120000 });
await page.waitForTimeout(300);
const xyz0 = await D(() => window.dworm2d.toXYZ(window.dworm2d.viewerStruct()));
{
  /* a link carries a drawing-built structure as the drawing alone (MAKE 3D on the other side);
     a session must carry the conformer itself — the unpacked-archive smoke test of build 24
     found it did not */
  const [dl2] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), D(() => window.dworm2d.doSave('session'))]);
  const p2 = path.join(tmp, 'drawn' + dl2.suggestedFilename());
  await dl2.saveAs(p2);
  await D(() => document.getElementById('btnClear3d').click());
  await page.waitForTimeout(300);
  await page.setInputFiles('#fileInput', [p2]);
  await page.waitForFunction(() => /Opened .*2dworm\.zip/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
  await page.waitForTimeout(500);
  const back2 = await D(() => ({ n: window.dworm2d.state3d.nAtoms, xyz: window.dworm2d.toXYZ(window.dworm2d.viewerStruct()), fromDrawing: window.dworm2d.state3d.fromDrawing }));
  check('a session of a structure built with MAKE 3D reopens with that conformer, not an empty panel', back2.n === 9 && back2.xyz === xyz0, JSON.stringify({ n: back2.n, same: back2.xyz === xyz0 }));
  check('and it still counts as built from the drawing, so MINIMIZE works on the drawing as before', back2.fromDrawing === true, String(back2.fromDrawing));
}

/* ------------------------------------------------ MINIMIZE is undoable, and RESET ALL unwinds everything */
check('a fresh structure starts with an empty stack: UNDO and RESET ALL are grey', await D(() => window.dworm2d.undoDepth === 0 && document.getElementById('btnUndo').disabled && document.getElementById('btnResetAll').disabled));
await page.click('#btnMinimize');
await page.waitForFunction(() => /kcal\/mol/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
await page.waitForTimeout(300);
const m1 = await D(() => ({ undo: window.dworm2d.undoDepth, btn: document.getElementById('btnUndo').disabled, reset: document.getElementById('btnResetAll').disabled }));
check('a minimisation is one record on the stack — it used to be the one change you could not take back', m1.undo === 1 && !m1.btn && !m1.reset, JSON.stringify(m1));
await page.click('#btnMinimize');
await page.waitForFunction(() => window.dworm2d.undoDepth === 2, null, { timeout: 120000 });
await page.waitForTimeout(300);
check('a second minimisation is a second record — show3d no longer wipes the stack for a same-structure change', await D(() => window.dworm2d.undoDepth) === 2);
await page.click('#btnResetAll');
await page.waitForTimeout(600);
const rs = await D(() => ({ xyz: window.dworm2d.toXYZ(window.dworm2d.viewerStruct()), undo: window.dworm2d.undoDepth, hint: document.getElementById('editHint').textContent, reset: document.getElementById('btnResetAll').disabled }));
check('RESET ALL: back to the coordinates MAKE 3D produced, the stack empty, the hint counting the changes', rs.xyz === xyz0 && rs.undo === 0 && /2 changes undone/.test(rs.hint) && rs.reset, rs.hint);
await page.click('#btnEdit');

/* ------------------------------------------------ a retired code explains itself */
await page.route('**/QRsharing/share.php?k=RETIRED1', route => route.fulfill({ status: 410, contentType: 'application/json', body: JSON.stringify({ ok: false, error: 'retired', message: 'This code was retired on 2026-09-01 after 200 downloads. For long-term support write to contact@dworm.org.' }) }));
await page.fill('#idInput', 'RETIRED1');
await page.click('#btnGo');
await page.waitForFunction(() => document.getElementById('errDlg').classList.contains('open'), null, { timeout: 20000 });
const ret = await D(() => ({ t: document.getElementById('errTitle').textContent, x: document.getElementById('errText').textContent }));
check('HTTP 410 from the sharing service is shown as "retired", with the server\'s own sentence and the address to write to', /retired/.test(ret.t) && /contact@dworm\.org/.test(ret.x) && /200 downloads/.test(ret.x), ret.x);
await D(() => document.getElementById('errDlg').classList.remove('open'));

/* ------------------------------------------------ the molecule of the day, on an empty page */
const page3 = await ctx.newPage();
let listHits = 0, keyHits = 0;
await page3.route('**/QRsharing/featured.php?list=1', route => { listHits++; route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify([{ fkey: 'urea', title: 'Urea', credit: 'Materials Studio example', kind: 'file', bytes: 1456 }]) }); });
await page3.route('**/QRsharing/featured.php?key=urea', route => { keyHits++; route.fulfill({ status: 200, contentType: 'application/octet-stream', body: fs.readFileSync(CORPUS + 'Urea.cif') }); });
await page3.goto(`http://127.0.0.1:${PORT}/index.html`);
await page3.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
await page3.waitForTimeout(1500);
const motd = await page3.evaluate(() => ({ hidden: document.getElementById('motd').hidden, title: document.getElementById('motdTitle').textContent, credit: document.getElementById('motdCredit').textContent, n: window.dworm2d.state3d.nAtoms }));
check('an empty page offers the molecule of the day by name, with its credit, and fetches nothing else yet', !motd.hidden && motd.title === 'Urea' && /Materials Studio/.test(motd.credit) && motd.n === 0 && listHits === 1 && keyHits === 0, JSON.stringify(motd));
await page3.click('#motdOpen');
await page3.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 60000 });
await page3.waitForTimeout(300);
const opened = await page3.evaluate(() => ({ n: window.dworm2d.state3d.nAtoms, hidden: document.getElementById('motd').hidden, msg: document.getElementById('msg').textContent }));
check('OPEN fetches the entry once and opens it through the ordinary readers — a CIF, expanded', opened.n === 16 && opened.hidden && keyHits === 1 && /16 in the cell/.test(opened.msg), JSON.stringify(opened).slice(0, 160));
await page3.close();

check('no page errors', errors.filter(e => !/favicon|ResizeObserver|WebGL|swiftshader|Could not create|410 \(Gone\)/i.test(e)).length === 0, errors.slice(0, 3).join(' | '));
await browser.close(); server.kill();
fs.rmSync(tmp, { recursive: true, force: true });
const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
