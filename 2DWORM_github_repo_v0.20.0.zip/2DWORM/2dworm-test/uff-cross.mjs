/* Cross-validation of lib/uff.js against an independent UFF implementation.
 *
 * uff-reference.json holds, for every element RDKit's UFF atom typer can handle, a small
 * test system (the element with 1–6 fluorine or chlorine ligands), its UFF energy at a
 * fixed starting geometry, and the bond length RDKit minimises it to. Those numbers were
 * MEASURED from RDKit (BSD-3) — no code and no parameter file was copied, which matters
 * because this project is AGPL-3.0 and Open Babel's UFF, the other obvious reference, is
 * GPL-2-only and therefore off limits. Regenerate with 2dworm-test/regen-uff-reference.py.
 *
 * Agreement on the minimised bond length pins r1 and the GMP electronegativity.
 * Agreement on the energy pins theta0, Z1, x1, D1 and the functional forms as well.
 *
 * Known, deliberate differences are listed in EXPECTED_DIFFERENCES below, with the reason.
 */
import fs from 'node:fs';
import { uffEnergy, uffMinimize, assignTypes, UFF_PARAMS, UFF_ELEMENTS } from '../2dworm/lib/uff.js';

const cases = JSON.parse(fs.readFileSync(new URL('./uff-reference.json', import.meta.url)));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/* Where we knowingly differ from RDKit, and why. Both are defensible readings; ours
   follows the paper, and in the two typing cases ours uses the geometry it can see. */
const EXPECTED_DIFFERENCES = {
  'H/6': 'six ligands on hydrogen: no UFF type exists, RDKit substitutes an octahedral angle form',
  'F/6': 'six ligands on fluorine: no UFF type exists',
  'Cl/6': 'six ligands on chlorine: no UFF type exists',
  'Br/6': 'six ligands on bromine: no UFF type exists',
  'I/6': 'six ligands on iodine: no UFF type exists',
  'At/6': 'six ligands on astatine: no UFF type exists',
  'P/6': 'six ligands on phosphorus: UFF has no octahedral P type',
  'Sb/6': 'six ligands on antimony: UFF has no octahedral Sb type',
  'Te/6': 'six ligands on tellurium: UFF has no octahedral Te type',
  'Bi/6': 'six ligands on bismuth: UFF has no octahedral Bi type',
  'Po/6': 'six ligands on polonium: UFF has no octahedral Po type',
  'Ti/4': 'four ligands placed square planar: we type from the geometry (Ti6+4), RDKit does not (Ti3+4)',
  'N/4': 'four ligands placed square planar: we type from the geometry, RDKit does not',
  'N/3': 'three ligands placed flat: we read that as N_2, RDKit assumes N_3',
};

let sameBond = 0, sameEnergy = 0, expected = 0, bad = [];
for (const c of cases) {
  const atoms = c.start.map((p, i) => ({ x: p[0], y: p[1], z: p[2], elem: c.symbols[i] }));
  const bonds = c.bonds.map(([a, b]) => ({ a, b, o: 1 }));
  const key = `${c.el}/${c.n}`;
  let e, m;
  try {
    e = uffEnergy({ atoms, bonds }).E;
    m = uffMinimize({ atoms: atoms.map(a => ({ ...a })), bonds }, { maxIts: 2000 });
  } catch (err) { bad.push([key, 'threw: ' + err.message]); continue; }
  const d = Math.hypot(m.atoms[0].x - m.atoms[1].x, m.atoms[0].y - m.atoms[1].y, m.atoms[0].z - m.atoms[1].z);
  const dBond = Math.abs(d - c.bond);
  const relE = Math.abs(e - c.e0) / Math.max(1, Math.abs(c.e0));
  if (dBond < 0.006) sameBond++;
  if (relE < 0.005) sameEnergy++;
  if (dBond >= 0.006 || relE >= 0.005) {
    if (EXPECTED_DIFFERENCES[key]) expected++;
    else bad.push([key, `bond ${c.bond.toFixed(4)} vs ${d.toFixed(4)}`, `E ${c.e0.toFixed(2)} vs ${e.toFixed(2)}`]);
  }
}

check('every reference case is typed and minimises without throwing', !bad.some(b => /threw/.test(b[1])),
  bad.filter(b => /threw/.test(b[1])).map(b => b.join(' ')).join('; '));
check('no unexplained disagreement with the independent implementation', bad.length === 0,
  bad.length ? bad.map(b => b.join('  ')).join(' | ') : `${cases.length} cases, ${expected} known differences, all documented`);
check('minimised bond lengths agree', sameBond >= cases.length - Object.keys(EXPECTED_DIFFERENCES).length,
  `${sameBond}/${cases.length}`);
check('total energies agree', sameEnergy >= cases.length - Object.keys(EXPECTED_DIFFERENCES).length,
  `${sameEnergy}/${cases.length}`);

/* --- the table itself ---------------------------------------------------- */
const types = Object.keys(UFF_PARAMS);
check('the whole of Table 1 is present', types.length === 127, types.length + ' atom types');
check('the periodic table is covered through lawrencium', UFF_ELEMENTS.length === 103,
  UFF_ELEMENTS.length + ' elements');
const badRow = types.filter(t => {
  const p = UFF_PARAMS[t];
  return p.length !== 8 || !p.every(Number.isFinite) ||
         p[0] <= 0 || p[0] > 3 ||          // valence radius
         p[1] < 60 || p[1] > 180 ||        // equilibrium angle
         p[2] <= 0 || p[2] > 6 ||          // van der Waals distance
         p[3] < 0 || p[3] > 1 ||           // well depth
         p[4] <= 0 || p[4] > 6;            // effective charge
});
check('every row is physically plausible', badRow.length === 0, badRow.join(', '));
const noType = UFF_ELEMENTS.filter(el => {
  const a = [{ elem: el, x: 0, y: 0, z: 0 }, { elem: 'F', x: 2, y: 0, z: 0 }];
  const t = assignTypes(a, [{ a: 0, b: 1, o: 1 }]);
  return !t.types[0];
});
check('every element in the table can actually be typed', noType.length === 0, noType.join(', '));
// lawrencium is Lw in the 1992 paper and Lr in a modern file: both must work
const lr = assignTypes([{ elem: 'Lr', x: 0, y: 0, z: 0 }, { elem: 'F', x: 2, y: 0, z: 0 }], [{ a: 0, b: 1, o: 1 }]);
check('Lr is understood as the paper\'s Lw', lr.types[0] === 'Lw6+3', String(lr.types[0]));

const failed = results.filter(r => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
