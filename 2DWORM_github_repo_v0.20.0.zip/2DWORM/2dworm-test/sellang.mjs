/* THE SELECTION LANGUAGE — a parser and an evaluator, tested without a browser.
   Every rule in the help text has a check here, and the ones that are easy to get wrong
   (1-based numbers, left-to-right operators, distance conditions selecting OTHER atoms,
   M() taking whole molecules) have several. */
import { parseSelection, evaluateSelection, SELECTION_EXAMPLES } from '../2dworm/lib/select.js';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const same = (set, arr) => set.size === arr.length && arr.every(i => set.has(i));
const list = (set) => [...set].sort((a, b) => a - b).join(',');

/* A small "structure": ethanol-ish fragment + a chloride + an iron with two waters, as 3Dmol
   would hold it — 0-based bonds, 1-based numbers in the language. */
const A = (elem, x, y, z, extra = {}) => ({ elem, x, y, z, bonds: [], ...extra });
const atoms = [
  A('C', 0, 0, 0, { resn: 'ETH', resi: 1, chain: 'A' }),        // 1
  A('C', 1.5, 0, 0, { resn: 'ETH', resi: 1, chain: 'A' }),      // 2
  A('O', 2.2, 1.2, 0, { resn: 'ETH', resi: 1, chain: 'A' }),    // 3
  A('H', -0.6, 0.9, 0, { resn: 'ETH', resi: 1, chain: 'A' }),   // 4
  A('H', -0.6, -0.9, 0, { resn: 'ETH', resi: 1, chain: 'A' }),  // 5
  A('H', 3.1, 1.0, 0, { resn: 'ETH', resi: 1, chain: 'A' }),    // 6
  A('Cl', 10, 10, 10, { resn: 'CL', resi: 2, chain: 'B' }),     // 7  alone
  A('Fe', 20, 0, 0, { resn: 'FE', resi: 3, chain: 'B' }),       // 8
  A('O', 22, 0, 0, { resn: 'HOH', resi: 4, chain: 'B' }),       // 9   2.0 Å from Fe
  A('H', 22.6, 0.8, 0, { resn: 'HOH', resi: 4, chain: 'B' }),   // 10
  A('O', 20, 2.1, 0, { resn: 'HOH', resi: 5, chain: 'B' }),     // 11  2.1 Å from Fe
  A('H', 20, 3.0, 0, { resn: 'HOH', resi: 5, chain: 'B' }),     // 12
  A('N', 0, 0, 7.0, { resn: 'HIS', resi: 6, chain: 'A' }),      // 13
];
const bond = (i, j) => { atoms[i].bonds.push(j); atoms[j].bonds.push(i); };
bond(0, 1); bond(1, 2); bond(0, 3); bond(0, 4); bond(2, 5); bond(8, 9); bond(10, 11);
const ev = (s, sel = []) => evaluateSelection(s, atoms, { sel });

/* ---------------------------------------------------------------- subjects */
check('C selects the carbons', same(ev('C'), [0, 1]));
check('names are case-insensitive: fe, FE', same(ev('fe'), [7]) && same(ev('FE'), [7]));
check('* is every atom', ev('*').size === atoms.length);
check('ALL is every atom', ev('ALL').size === atoms.length);
check('a residue name selects its atoms', same(ev('HOH'), [8, 9, 10, 11]));
check('SEL is the current selection', same(ev('SEL', [2, 4]), [2, 4]));
check('SEL with nothing picked is empty', ev('SEL').size === 0);

/* ---------------------------------------------------------------- numbers, 1-based */
check('12 is the twelfth atom, 1-based', same(ev('12'), [11]));
check('a range 12-20 is inclusive and stops at the end', same(ev('12-20'), [11, 12]));
check('a list 1,3,5-6', same(ev('1,3,5-6'), [0, 2, 4, 5]));
check('H(<5): hydrogens numbered below 5', same(ev('H(<5)'), [3]));
check('H(<=5)', same(ev('H(<=5)'), [3, 4]));
check('C(>1): carbons above 1', same(ev('C(>1)'), [1]));
check('O(3-9): oxygens 3 to 9', same(ev('O(3-9)'), [2, 8]));
check('O(13-16) reads as 13 to 16, not 13 to 60', same(ev('O(13-16)'), []));
let threw = false; try { ev('0'); } catch (e) { threw = /start at 1/.test(e.message); }
check('atom number 0 is refused with a sentence', threw);

/* ---------------------------------------------------------------- distance */
check('Fe(<2.4A): atoms within 2.4 Å of any iron, NOT the iron', same(ev('Fe(<2.4A)'), [8, 10]));
check('Fe(<2.4A) _OR_ Fe puts the iron back', same(ev('Fe(<2.4A) _OR_ Fe'), [7, 8, 10]));
check('Fe(>2.4A): everything farther than 2.4 Å from every iron', same(ev('Fe(>2.4A)'), [0, 1, 2, 3, 4, 5, 6, 9, 11, 12]));
check('SEL(<3A) grows a selection by distance', same(ev('SEL(<3A)', [7]), [8, 10, 9, 11].sort()) || list(ev('SEL(<3A)', [7])) === '8,9,10,11', list(ev('SEL(<3A)', [7])));
check('the A is what makes it a distance: O(<3) is numbers', same(ev('O(<3)'), []) && same(ev('O(<4)'), [2]));

/* ---------------------------------------------------------------- bonds */
check('SEL(+1): one bond out', same(ev('SEL(+1)', [1]), [1, 0, 2].sort()) || list(ev('SEL(+1)', [1])) === '0,1,2');
check('SEL(+2): two bonds out', list(ev('SEL(+2)', [1])) === '0,1,2,3,4,5');
check('growing an isolated atom stays put', same(ev('SEL(+3)', [6]), [6]));

/* ---------------------------------------------------------------- axes */
check('*(Z>5.6): the histidine N and the chloride at z=10', same(ev('*(Z>5.6)'), [6, 12]));
check('*(X<0)', same(ev('*(X<0)'), [3, 4]), list(ev('*(X<0)')));
check('*(1.6<X<5.6)', same(ev('*(1.6<X<5.6)'), [2, 5]));
check('axis on an element: O(X>21)', same(ev('O(X>21)'), [8]));

/* ---------------------------------------------------------------- molecules */
check('M(Cl): the lone chloride is its own molecule', same(ev('M(Cl)'), [6]));
check('M(O(<4)): the whole ethanol from its oxygen', list(ev('M(O(<4))')) === '0,1,2,3,4,5');
check('M(Fe(<2.4A)): both waters, whole, without the iron', list(ev('M(Fe(<2.4A))')) === '8,9,10,11');

/* ---------------------------------------------------------------- operators, left to right */
check('A _AND_ B', same(ev('HOH _AND_ H'), [9, 11]));
check('A _OR_ B', same(ev('Cl _OR_ Fe'), [6, 7]));
check('A _NOT_ B', same(ev('* _NOT_ H'), [0, 1, 2, 6, 7, 8, 10, 12]));
check('left to right: C _OR_ O _NOT_ 1 removes atom 1 from (C or O)', same(ev('C _OR_ O _NOT_ 1'), [1, 2, 8, 10]));
check('parentheses group: C _OR_ (O _NOT_ 3)', same(ev('C _OR_ (O _NOT_ 3)'), [0, 1, 8, 10]));
check('AND/OR/NOT without underscores, and & |', same(ev('Cl OR Fe'), [6, 7]) && same(ev('Cl | Fe'), [6, 7]) && same(ev('HOH & H'), [9, 11]));

/* ---------------------------------------------------------------- residues and chains */
check('RES(4-5) by residue number', list(ev('RES(4-5)')) === '8,9,10,11');
check('CHAIN(A)', list(ev('CHAIN(A)')) === '0,1,2,3,4,5,12');
check('CHAIN(A) _NOT_ HOH', list(ev('CHAIN(A) _NOT_ HOH')) === '0,1,2,3,4,5,12');
check('HIS _AND_ *(1.6<X<5.6) is empty here', ev('HIS _AND_ *(1.6<X<5.6)').size === 0);

/* ---------------------------------------------------------------- errors say something */
const bad = ['', 'C(', 'Q', 'C(banana)', 'C _AND_', ')', 'CHAIN'];
let allSaid = true;
for (const b of bad) { try { ev(b); allSaid = false; } catch (e) { if (!e.message || e.message.length < 8) allSaid = false; } }
check('every malformed expression throws a sentence', allSaid);
check('parseSelection alone validates as you type', (() => { try { parseSelection('Fe(<2.4A) _OR_ M(N)'); return true; } catch (e) { return false; } })());

/* ---------------------------------------------------------------- the examples all parse */
let allEx = true;
for (const [ex] of SELECTION_EXAMPLES) { try { ev(ex, [0]); } catch (e) { allEx = false; console.log('  example failed:', ex, e.message); } }
check('every worked example in the help evaluates', allEx);

/* ---------------------------------------------------------------- scale */
const big = [];
for (let i = 0; i < 40000; i++) big.push(A(i % 7 === 0 ? 'Fe' : 'C', (i % 100) * 1.5, Math.floor(i / 100) * 1.5, 0, { bonds: [] }));
const t0 = Date.now();
const r = evaluateSelection('Fe(<1.6A)', big);
const ms = Date.now() - t0;
check('40,000 atoms, a distance condition on 5,714 irons, in under four seconds', ms < 4000 && r.size > 0, ms + ' ms, ' + r.size + ' atoms');

const bad2 = results.filter(x => !x.ok);
console.log(`\n${results.length - bad2.length}/${results.length} passed`);
process.exit(bad2.length ? 1 : 0);
