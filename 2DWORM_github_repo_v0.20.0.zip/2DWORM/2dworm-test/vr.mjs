/* 2DWORM-VR: the hand-over from 2D-WORM, and the camera lock between two engines that
 * describe a view in completely different terms.
 *
 * A headset cannot be tested here, so this suite tests everything around it — which is where
 * the arithmetic is. The lock is asserted as three physical quantities rather than as a
 * screenshot: that Mol* ends up looking along the same axis 3Dmol was looking along, from the
 * same point in the structure's own coordinates, with the same amount of the structure in
 * frame, and with the same direction pointing up. A rotated view is checked as well as a
 * square-on one, because a rotation convention that is wrong is wrong only when there is a
 * rotation.
 *
 * Mol* needs a WebGL context that the default headless Chromium does not give it, hence the
 * ANGLE flags; the page itself needs nothing special.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8797;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

check('Mol* is installed beside the page, not fetched from anywhere',
  existsSync(APP + 'molstar/molstar.js') && existsSync(APP + 'molstar/molstar.css'));

const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await context.newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
const outside = [];
page.on('request', r => { if (!r.url().startsWith(`http://127.0.0.1:${PORT}/`) && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) outside.push(r.url()); });

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const norm = (v) => { const L = Math.hypot(...v) || 1; return v.map(x => x / L); };

const openApp = async () => {
  await page.goto(`http://127.0.0.1:${PORT}/index.html`);
  await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
};
const build = async (smiles) => {
  await page.evaluate(async (s) => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule(s); }, smiles);
  await page.click('#btnMake3d');
  await page.waitForFunction(() => window.dworm2d && window.dworm2d.state3d && window.dworm2d.state3d.nAtoms > 0, null, { timeout: 120000 });
  await page.waitForTimeout(250);
};
/** The view axes 3Dmol is actually using, measured through its own projection at the centre
    of the view — the same measurement the drag tools make, so one is a check on the other. */
const axes3d = () => page.evaluate(() => {
  const rec = window.dworm2d.viewRecord();
  const c = { x: rec.centre[0], y: rec.centre[1], z: rec.centre[2] };
  const b = window.dworm2d.dragBasis(c);
  const r = [b.right.x, b.right.y, b.right.z], d = [b.down.x, b.down.y, b.down.z];
  const n = [r[1] * d[2] - r[2] * d[1], r[2] * d[0] - r[0] * d[2], r[0] * d[1] - r[1] * d[0]];
  const L = Math.hypot(...n);
  return { right: r, down: d, axis: n.map(v => v / L), rec };
});
const molstarCam = () => page.evaluate(() => {
  const s = window.__plugin.canvas3d.camera.getSnapshot();
  const A = (v) => Array.from(v);
  return { target: A(s.target), position: A(s.position), up: A(s.up), radius: s.radius, fov: s.fov, mode: s.mode };
});
const goVR = async () => {
  await page.click('#btnVR');
  await page.waitForFunction(() => location.pathname.endsWith('2dworm-vr.html'), null, { timeout: 20000 });
  await page.waitForFunction(() => window.dwormVR && window.dwormVR.booted, null, { timeout: 90000 });
};

/* --------------------------------------------------------- nothing to show yet */
await page.goto(`http://127.0.0.1:${PORT}/2dworm-vr.html`);
await page.waitForFunction(() => window.dwormVR && window.dwormVR.booted, null, { timeout: 90000 });
check('opened on its own the page says so instead of showing an empty box',
  /Nothing has been sent here yet/.test(await page.textContent('#msgOver')) &&
  /No structure/.test(await page.textContent('#msg')));
check('and it offers the way to 2D-WORM rather than leaving you stuck',
  (await page.getAttribute('#msgOver a', 'href')) === 'index.html');
check('LAUNCH VR is offered but disabled where there is no headset',
  await page.isVisible('#btnVR') && await page.getAttribute('#btnVR', 'disabled') !== null &&
  /headset/i.test(await page.getAttribute('#btnVR', 'title')),
  (await page.getAttribute('#btnVR', 'title')).slice(0, 60));
check('the page asks not to be indexed: it only ever shows somebody else\'s structure',
  (await page.getAttribute('meta[name="robots"]', 'content')) === 'noindex');

/* ------------------------------------------------------------- the hand-over */
await openApp();
await build('CC(=O)Oc1ccccc1C(=O)O');
check('2D-WORM offers VR once there is something to send', await page.isVisible('#btnVR'));
const rec0 = await page.evaluate(() => window.dworm2d.viewRecord());
check('the view record is three physical quantities and nothing engine-specific',
  Object.keys(rec0).sort().join(',') === 'centre,half,quat' && rec0.half > 0 &&
  rec0.centre.length === 3 && rec0.quat.length === 4,
  `half ${rec0.half.toFixed(2)} A`);
const a0 = await axes3d();
await goVR();
check('the VR button hands the structure over and the page loads it',
  /Ready/.test(await page.textContent('#msg')) &&
  (await page.evaluate(() => window.dwormVR.plugin.managers.structure.hierarchy.current.structures.length)) === 1,
  await page.textContent('#msg'));
check('and it says what it is showing', /21 atoms/.test(await page.textContent('#what')),
  await page.textContent('#what'));
let cam = await molstarCam();
check('Mol* looks along the axis 3Dmol was looking along',
  Math.abs(Math.abs(dot(norm(cam.position.map((p, i) => p - cam.target[i])), a0.axis)) - 1) < 0.01,
  'dot = ' + dot(norm(cam.position.map((p, i) => p - cam.target[i])), a0.axis).toFixed(4));
check('from the same point in the structure, not from its own idea of the centre',
  Math.hypot(...cam.target.map((t, i) => t - rec0.centre[i])) < 1e-5,
  `[${cam.target.map(n => n.toFixed(3))}] vs [${rec0.centre.map(n => n.toFixed(3))}]`);
check('with the same amount of the structure in frame',
  Math.abs(cam.radius - rec0.half) < 1e-5, `${cam.radius.toFixed(3)} vs ${rec0.half.toFixed(3)} A`);
check('and the same way up', Math.abs(dot(cam.up, a0.down) + 1) < 0.02,
  'dot with 3Dmol screen-down = ' + dot(cam.up, a0.down).toFixed(4));

/* ------------------------------------------------- and now with a real rotation
   A rotation convention that is wrong is only wrong when there is a rotation: square-on, the
   quaternion is the identity and every convention agrees. */
await page.click('#btnReturn');
await page.waitForFunction(() => location.pathname.endsWith('index.html'), null, { timeout: 20000 });
/* the structure appears part-way through the restore, so wait for the sentence that is
   written when the whole of it has finished rather than for the first sign of life. Either
   sentence will do: the lock now runs both ways, so an ordinary return says it is showing
   what the headset was showing, and only a return with no view to bring back says the older
   "as you left it". */
const HOME = /as you left it|looking at in the headset/;
await page.waitForFunction(() => /as you left it|looking at in the headset/.test(document.getElementById('msg').textContent), null, { timeout: 90000 });
check('RETURN brings back the structure, not just the drawing',
  (await page.evaluate(() => window.dworm2d.state3d.nAtoms)) === 21 &&
  HOME.test(await page.textContent('#msg')),
  'atoms ' + await page.evaluate(() => window.dworm2d.state3d.nAtoms));
check('and the drawing with it', (await page.evaluate(async () => (await window.dworm2d.whenKetcher()).getSmiles())).length > 5);
check('the way home is consumed on arrival, so a reload is a fresh page and not a second return',
  (await page.evaluate(() => sessionStorage.getItem('dworm2d.back'))) === null);
await page.evaluate(() => { window.dworm2d.viewer.rotate(37, 'y'); window.dworm2d.viewer.rotate(-24, 'x'); window.dworm2d.viewer.render(); });
await page.waitForTimeout(300);
const rec1 = await page.evaluate(() => window.dworm2d.viewRecord());
check('turning the structure changes the record that will be sent',
  Math.abs(rec1.quat[3] - 1) > 0.01, 'w = ' + rec1.quat[3].toFixed(4));
const a1 = await axes3d();
await goVR();
cam = await molstarCam();
const toCam = norm(cam.position.map((p, i) => p - cam.target[i]));
check('a ROTATED view survives the crossing: same axis',
  Math.abs(Math.abs(dot(toCam, a1.axis)) - 1) < 0.01, 'dot = ' + dot(toCam, a1.axis).toFixed(4));
check('same way up, which is the half a rotation gets wrong quietly',
  Math.abs(dot(cam.up, a1.down) + 1) < 0.02, 'dot with 3Dmol screen-down = ' + dot(cam.up, a1.down).toFixed(4));
check('same centre and same framing',
  Math.hypot(...cam.target.map((t, i) => t - rec1.centre[i])) < 1e-5 && Math.abs(cam.radius - rec1.half) < 1e-5,
  `centre off by ${Math.hypot(...cam.target.map((t, i) => t - rec1.centre[i])).toExponential(1)} A`);
check('and the up vector is square to the view, as an up vector has to be',
  Math.abs(dot(cam.up, toCam)) < 0.01, dot(cam.up, toCam).toExponential(1));

/* ---------------------------------------------------------------- the controls */
await page.evaluate(() => { const c = window.__plugin.canvas3d.camera; const s = c.getSnapshot(); s.radius = 999; c.setState(s); });
await page.click('#btnLock');
/* the handler waits for the viewer to be idle before it touches the camera, so wait for the
   answer rather than for a fixed time */
let relocked = true;
try { await page.waitForFunction((r) => Math.abs(window.__plugin.canvas3d.camera.getSnapshot().radius - r) < 1e-5, rec1.half, { timeout: 8000 }); }
catch (e) { relocked = false; }
cam = await molstarCam();
check('SAME VIEW puts the handed-over view back after the camera has been moved',
  relocked && Math.abs(cam.radius - rec1.half) < 1e-5, cam.radius.toFixed(3) + ' vs ' + rec1.half.toFixed(3));
await page.selectOption('#selStyle', 'cpk');
await page.waitForTimeout(900);
check('the representation menu redraws without losing the structure',
  (await page.evaluate(() => window.dwormVR.plugin.managers.structure.hierarchy.current.structures.length)) === 1 &&
  !/could not be built/.test(await page.textContent('#msg')), await page.textContent('#msg'));
await page.selectOption('#selStyle', 'bs');
await page.waitForTimeout(700);
await page.click('#themeSeg button[data-theme="black"]');
await page.waitForTimeout(300);
check('the four backgrounds are the same four as 2D-WORM, and they reach the 3D canvas',
  (await page.getAttribute('html', 'data-theme')) === 'black' &&
  (await page.evaluate(() => window.__plugin.canvas3d.props.renderer.backgroundColor)) === 0x000000,
  'renderer bg 0x' + (await page.evaluate(() => window.__plugin.canvas3d.props.renderer.backgroundColor)).toString(16));
await page.click('#themeSeg button[data-theme="white"]');
await page.click('#btnLock');
try { await page.waitForFunction((r) => Math.abs(window.__plugin.canvas3d.camera.getSnapshot().radius - r) < 1e-5, rec1.half, { timeout: 8000 }); } catch (e) { /* reported by the check below */ }
const before = (await molstarCam()).radius;
const sphere = await page.evaluate(() => window.__plugin.canvas3d.boundingSphereVisible.radius);
await page.click('#btnFit');
/* Mol* flies the camera rather than jumping it, so this waits for the move to arrive instead
   of guessing how long it takes. */
let flew = true;
try { await page.waitForFunction((r) => Math.abs(window.__plugin.canvas3d.camera.getSnapshot().radius - r) > 0.5, before, { timeout: 6000 }); }
catch (e) { flew = false; }
const after = (await molstarCam()).radius;
/* Since build 25 a structure opens in 2D-WORM framed to its measured extent, which is tighter
   than Mol*'s sphere fit, so FIT here can move the camera OUT as well as in. What is asserted
   is that it moved, and to a fit of the structure — not the direction. */
check('FIT re-frames on the structure rather than on the view that was sent',
  flew && Math.abs(after - before) > 0.5 && after < sphere * 2.5,
  `${before.toFixed(2)} -> ${after.toFixed(2)} A, structure radius ${sphere.toFixed(2)}`);

/* -------------------------------------------------------- what it does not do */
check('nothing is fetched from any other host — Mol* included',
  outside.length === 0, outside.slice(0, 3).join(' | '));
check('the hand-over is in this tab only, and nothing is written to disk',
  (await page.evaluate(() => Object.keys(localStorage).filter(k => /vr/i.test(k)).length)) === 0 &&
  (await page.evaluate(() => !!sessionStorage.getItem('dworm2d.vr'))) === true);
/* ------------------------------------------------- what happens inside the headset
   The session itself cannot be entered here, but everything it depends on can be: the menu
   that carries the controls, what each control does, the measurement arithmetic, and the four
   things about Mol* that have to be held down for the length of a session and put back
   afterwards. Those are the parts that break silently.

   THERE IS NO HTML IN THE HEADSET, AND THERE MUST NOT BE. The first version of this page put
   the controls in a WebXR DOM overlay. The Quest browser does not implement dom-overlay: the
   feature comes back NOT GRANTED and the bar is simply not there, which was tested on the
   device. So the check below is the opposite of what it used to be — no overlay element, no
   dom-overlay request anywhere in the page. */
const src = await page.content();
check('there is no DOM overlay, and nothing asks for one — the Quest browser has no such thing',
  await page.$('#xrOverlay') === null && !/dom-overlay/.test(src) && !/domOverlay/.test(src));

/* Each button presses the flat page's own control, so the two interfaces cannot disagree. */
const themeNow = () => page.evaluate(() => document.documentElement.getAttribute('data-theme') || 'white');
const before2 = await themeNow();
await page.evaluate(() => window.dwormVR.XR_ACTIONS.bg());
check('BACKGROUND moves the page\'s own theme buttons, not a second copy of the setting',
  (await themeNow()) !== before2 &&
  (await page.$eval('#themeSeg button.on', b => b.dataset.theme)) === (await themeNow()),
  before2 + ' -> ' + await themeNow());
const styleBefore = await page.$eval('#selStyle', e => e.value);
await page.evaluate(() => window.dwormVR.XR_ACTIONS.render());
await page.waitForTimeout(900);
check('RENDER moves the representation menu itself',
  (await page.$eval('#selStyle', e => e.value)) !== styleBefore &&
  (await page.evaluate(() => window.dwormVR.style)) === (await page.$eval('#selStyle', e => e.value)),
  styleBefore + ' -> ' + await page.$eval('#selStyle', e => e.value));
await page.evaluate(() => window.dwormVR.XR_ACTIONS.save());
check('SAVE VIEW keeps the camera, and SAME VIEW then prefers it over the handed-over one',
  await page.evaluate(() => !!window.dwormVR.savedView));

/* ----------------------------------------------------------------- measuring */
const picks = await page.evaluate(() => {
  /* the same picks the controller makes, put in directly — what is being checked is the
     arithmetic and the readout, not Mol*'s ray casting */
  const P = window.dwormVR.picked;
  P.length = 0;
  P.push({ name: 'C1', label: 'C1', pos: [0, 0, 0] });
  P.push({ name: 'C2', label: 'C2', pos: [1.5, 0, 0] });
  const two = window.dwormVR.measureText();
  P.push({ name: 'C3', label: 'C3', pos: [1.5, 1.5, 0] });
  const three = window.dwormVR.measureText();
  P.push({ name: 'C4', label: 'C4', pos: [1.5, 1.5, 1.5] });
  const four = window.dwormVR.measureText();
  return { two, three, four,
    ang: window.dwormVR.angleDeg([0, 0, 0], [1.5, 0, 0], [1.5, 1.5, 0]),
    dih: window.dwormVR.dihedralDeg([0, 0, 0], [1.5, 0, 0], [1.5, 1.5, 0], [1.5, 1.5, 1.5]) };
});
check('two picks give a distance, in angstrom', /DISTANCE\s+1\.500 Å/.test(picks.two), picks.two);
check('three give the angle at the middle atom', /ANGLE\s+90\.0°/.test(picks.three) && Math.abs(picks.ang - 90) < 1e-9, picks.three);
check('four give a dihedral WITH ITS SIGN — an unsigned one is half an answer',
  /DIHEDRAL\s+-?90\.0°/.test(picks.four) && Math.abs(Math.abs(picks.dih) - 90) < 1e-9, picks.four);
check('and the readout names the atoms, not just the number', /C1 – C2 – C3 – C4/.test(picks.four));
await page.evaluate(() => window.dwormVR.clearPicks());
/* AND THE REAL CLICK PATH. The picks above are injected; this clicks where Mol* actually draws
   the atoms. Build 26: a click on one atom gives a loci whose `indices` is an Interval packed
   in a float64, and atomFromLoci() did not know the packed form — every real click, in the
   headset and on this page, came back null, and nobody could pick an atom (Dante's report).
   The projection here is Mol*'s own camera, so the click lands on the atom it names. */
await page.evaluate(() => { window.dwormVR.picked.length = 0; });
const onScreen = await page.evaluate(() => {
  const plugin = window.__plugin, cam = plugin.canvas3d.camera;
  const st = plugin.managers.structure.hierarchy.current.structures[0].cell.obj.data;
  const Vec3 = molstar.lib.math.LinearAlgebra.Vec3;
  const canvas = plugin.canvas3d.webgl.gl.canvas, r = canvas.getBoundingClientRect();
  const out = [];
  for (const unit of st.units) for (let i = 0; i < unit.elements.length; i++) {
    const p = Vec3(); unit.conformation.position(unit.elements[i], p);
    const s = cam.project(Vec3(), p);
    out.push({ x: r.x + (s[0] / canvas.width) * r.width, y: r.y + (1 - s[1] / canvas.height) * r.height, n: unit.elements[i] + 1 });
  }
  return out;
});
let realPicks = 0, realText = '';
/* a frame first, and four atoms rather than two: under a loaded machine the first click can
   land before the software renderer has drawn the frame Mol* picks against */
await page.waitForTimeout(800);
for (const h of onScreen.slice(0, 4)) { await page.mouse.click(h.x, h.y); await page.waitForTimeout(500); if ((await page.evaluate(() => window.dwormVR.picked.length)) >= 2) break; }
realPicks = await page.evaluate(() => window.dwormVR.picked.length);
realText = await page.textContent('#measure');
check('a real click on an atom picks it — the packed single-element loci is decoded (build 26)', realPicks >= 1, `${realPicks} picked — ${realText}`);
check('and a drawn molecule\'s atoms are named element + number, as 2D-WORM numbers them', realPicks >= 1 && /^(Picked |DISTANCE.*Å\s+)[A-Z][a-z]?\d+/.test(realText), realText);
await page.evaluate(() => window.dwormVR.clearPicks());
check('CLEAR wipes them', (await page.evaluate(() => window.dwormVR.picked.length)) === 0 &&
  await page.getAttribute('#measure', 'hidden') !== null);

/* --------------------------------- the four things a session has to hold down */
const held = await page.evaluate(async () => {
  const p = window.__plugin, V = window.dwormVR;
  const Mat4 = molstar.lib.math.LinearAlgebra.Mat4;
  const before = {
    head: Array.from(p.canvas3d.camera.headRotation || []).slice(0, 4),
    manual: !!p.canvas3d.props.camera.manualReset,
    dragFocus: JSON.stringify(p.canvas3d.attribs.trackball.bindings.dragFocus),
  };
  V.freezeTextBillboards(true); V.holdCamera(true); V.holdBindings(true); await V.holdClickFocus(true);
  const during = {
    headIsZero: Mat4.isZero ? Mat4.isZero(p.canvas3d.camera.headRotation) : Array.from(p.canvas3d.camera.headRotation).every(x => x === 0),
    manual: !!p.canvas3d.props.camera.manualReset,
    dragFocusEmpty: p.canvas3d.attribs.trackball.bindings.dragFocus.triggers.length === 0,
    focusBindingsEmpty: (() => { const c = p.state.behaviors.cells.get('ms-plugin.camera-focus-loci');
      return !c || Object.values(c.transform.params.bindings).every(b => !b.triggers || !b.triggers.length); })(),
  };
  V.endSessionTidy();
  await new Promise(r => setTimeout(r, 300));
  const after = {
    manual: !!p.canvas3d.props.camera.manualReset,
    dragFocus: JSON.stringify(p.canvas3d.attribs.trackball.bindings.dragFocus),
    focusBindingsBack: (() => { const c = p.state.behaviors.cells.get('ms-plugin.camera-focus-loci');
      return !c || Object.values(c.transform.params.bindings).some(b => b.triggers && b.triggers.length); })(),
  };
  return { before, during, after };
});
check('the head rotation is forced to zero, or every label goes edge-on and spins',
  held.during.headIsZero === true);
check('the camera stops re-fitting itself, or the molecule jumps away on every button press',
  held.during.manual === true && held.before.manual === false);
check('the button that loses the molecule is disarmed', held.during.dragFocusEmpty === true);
check('and so is the click that re-fits the camera on empty space', held.during.focusBindingsEmpty === true);
check('leaving the session puts all of it back, so the flat page behaves normally again',
  held.after.manual === false && held.after.dragFocus === held.before.dragFocus && held.after.focusBindingsBack === true,
  `manualReset ${held.after.manual}, dragFocus restored ${held.after.dragFocus === held.before.dragFocus}`);

/* ------------------------------------------------ where the molecule turns up */
/* let the representation the RENDER check changed finish building: the visible bounding
   sphere is what the placement is computed from, and measuring it mid-rebuild compares two
   different spheres */
await page.evaluate(() => window.dwormVR.whenIdle(3000));
await page.waitForTimeout(600);
const placed = await page.evaluate(() => {
  const p = window.__plugin, V = window.dwormVR;
  /* the same order the button uses, and the order matters: without the hold, Mol*'s own
     re-fit moves the camera straight back out again and the placement is wasted */
  V.holdCamera(true);
  /* Twice, which is what the real flow does — placeForSession() before the request and
     placeAfterSession() once the session has chosen its scale. The first call is computed
     against whatever the visible sphere happened to be; the second is computed against the
     sphere as it is once the camera has moved, and that is the one that lands. */
  V.placeForSession();
  const out = V.placeForSession();
  const s = p.canvas3d.camera.getSnapshot();
  const sph = p.canvas3d.boundingSphereVisible;
  const d = Math.hypot(s.position[0] - s.target[0], s.position[1] - s.target[1], s.position[2] - s.target[2]);
  /* what the placement asked for, in scene units, beside what the camera actually holds:
     comparing metres separately would fold in a bounding sphere that has moved since */
  V.holdCamera(false);
  return { out, centre: out ? out.centre : Array.from(sph.center), target: Array.from(s.target),
           wantUnits: out ? out.metres / out.scale : 0, gotUnits: d };
});
/* BOTH TOLERANCES ARE DELIBERATE, and neither is slack. Mol* adjusts whatever camera state
   it is handed — against its own near plane, its minimum target distance and the viewport's
   aspect — so it settles near the request rather than on it, and how near depends on the
   state the viewer happens to be in. Measured across runs: the target lands within about 1%
   of the structure's radius and the distance within about 10%. Neither is perceptible, and
   the real flow places a second time once the session has chosen its scale.

   The failure this is guarding against is not a few per cent. It is the molecule turning up
   inside your head or three metres behind your shoulder, which is what happens when the
   placement is skipped altogether and whatever the flat page was zoomed to becomes where the
   structure sits. Both bands catch that and nothing innocent. */
check('with the camera held, the structure lands in front of you at roughly arm\'s length rather than wherever the page was zoomed',
  !!placed.out &&
  Math.hypot(...placed.target.map((t, i) => t - placed.centre[i])) < 0.05 * placed.out.radius &&
  placed.gotUnits / placed.wantUnits > 0.6 && placed.gotUnits / placed.wantUnits < 1.6,
  `target [${placed.target.map(n => n.toFixed(3))}] vs centre [${placed.centre.map(n => n.toFixed(3))}]; ` +
  `camera at ${placed.gotUnits.toFixed(3)} of ${placed.wantUnits.toFixed(3)} scene units ` +
  `(${(placed.gotUnits / placed.wantUnits).toFixed(3)}x)`);

/* ======================================================== THE MENU ON YOUR HAND
   The controls are geometry in the scene rather than HTML over it, and that is what makes
   them testable at all: a flat browser can build the whole panel, read back every rectangle
   the controller ray would be tested against, and press them through the same click stream a
   trigger uses. The only part that cannot be reached from here is the controller pose itself.

   The panel is built before the session opens, which is also when a headset builds it — so
   what is exercised below is the real path, not a rehearsal of it. */
const menu = await page.evaluate(async () => {
  const V = window.dwormVR;
  const ok = await V.buildVRMenu();
  return { ok, on: V.vrMenuOn, parts: V.vrMenuReprs.length,
           buttons: V.vrMenuButtons.map(b => b.id),
           rows: V.VR_MENU_ROWS.map(r => r.map(b => b.id).join('+')),
           plate: V.VR_PLATE(),
           atoms: V.structureRef ? V.structureRef.data.elementCount : 0,
           geom: V.vrMenuGeometry() };
});
/* MVS may split one primitives group across SEVERAL representations — boxes in one, meshes in
   another — and a transform set on only the first tears the panel in half: in the headset the
   buttons went to the hand and the text stayed behind on the far wall. Every representation
   the build produced is collected and moved together, however many that turns out to be. */
check('the hand menu builds, and every representation it produced is collected to move together',
  menu.ok === true && menu.on === true && menu.parts >= 1,
  `${menu.parts} representation${menu.parts === 1 ? '' : 's'}, ${menu.buttons.length} buttons`);
/* loadMVS replaces the whole state tree. If the structure is not rebuilt on top of the menu,
   the headset shows a panel floating in an empty room — which is exactly what happened the
   first time. */
check('and the structure is still there afterwards, because loadMVS wipes the state tree',
  menu.atoms === 21, menu.atoms + ' atoms after the menu was built');
/* Asserted against XR_ACTIONS rather than against a list written out here: a button with no
   action does nothing when pressed, and an action with no button can never be reached, and
   both are silent failures in a headset. Checking the two sets against each other catches
   either one and does not have to be edited every time a control is added. */
const wiring = await page.evaluate(() => {
  const V = window.dwormVR;
  const ids = V.vrMenuButtons.filter(b => !b.card).map(b => b.id);
  const actions = Object.keys(V.XR_ACTIONS);
  return { ids, actions,
           noAction: ids.filter(id => typeof V.XR_ACTIONS[id] !== 'function'),
           noButton: actions.filter(a => ids.indexOf(a) < 0) };
});
check('every control on the panel has an action behind it, and no action is orphaned',
  wiring.noAction.length === 0 && wiring.noButton.length === 0 && wiring.ids.length === 15,
  `${wiring.ids.length} buttons: ${wiring.ids.join(' ')}`);
check('all fifteen controls are on the panel, and they are the ones that were asked for (Help and Picture since build 27)',
  wiring.ids.join(' ') === 'render chain hide surface field resid slab bg fit save recall clear help picture leave',
  wiring.ids.join(' '));
/* Three columns and a full-width way out. A row that overflows the grid would put a button
   half off the edge of the panel, where the ray can reach it but you cannot see it. */
const grid = await page.evaluate(() => {
  const V = window.dwormVR, L = V.vrMenuLayout();
  const right = L.g.x0 + L.g.totalW, left = L.g.x0;
  return { cols: V.VR_MENU_COLS(), rows: V.VR_MENU_ROWS.length,
           over: L.buttons.filter(b => b.cx - b.hw < left - 1e-6 || b.cx + b.hw > right + 1e-6).map(b => b.id),
           overlap: L.buttons.some((a, i) => L.buttons.some((b, j) => j > i &&
             Math.abs(a.cx - b.cx) < a.hw + b.hw - 1e-6 && Math.abs(a.cy - b.cy) < a.hh + b.hh - 1e-6)),
           leaveW: (L.buttons.find(b => b.id === 'leave') || {}).w, rowW: L.g.totalW };
});
check('the panel is a three-column grid and nothing hangs over its edge',
  grid.cols === 3 && grid.rows === 6 && grid.over.length === 0 && grid.overlap === false,
  `${grid.cols} x ${grid.rows}, over: ${grid.over.join(',') || 'none'}`);
check('the way out is one wide button across the bottom, so it cannot be pressed by mistake',
  Math.abs(grid.leaveW - grid.rowW) < 1e-6, `${grid.leaveW.toFixed(2)} of ${grid.rowW.toFixed(2)}`);
check('the name plate is there, and it names the project and the version',
  /^2D-WORM-VR \d+\.\d+\.\d+$/.test(menu.plate), menu.plate);
/* A press that landed on the name plate would be a press that did something the person did
   not ask for. It is a sign, so it is not in the list the ray is tested against at all. */
check('and the name plate is NOT a button: it carries no action and no rectangle',
  !menu.buttons.includes('name') && !menu.buttons.includes('plate'));
check('the panel is sized from the structure, so it is the same size beside a benzene and a protein',
  menu.geom.R >= 6 && menu.geom.bw > 0 && menu.geom.totalW > menu.geom.bw, JSON.stringify(menu.geom.R));

/* HOW A BUTTON IS RECOGNISED. A click gives a group-loci whose ids are a Mol* OrderedSet —
   an Int32Array, or an interval packed as two int32s inside one float64. Both shapes turn up
   depending on how many groups were hit, and getting the second one wrong means the menu
   works until two buttons overlap on screen and then silently stops. */
const unpack = await page.evaluate(() => {
  const V = window.dwormVR;
  const f = new Float64Array(1); const i = new Int32Array(f.buffer);
  i[0] = 7; i[1] = 11;                       // an interval packed as two int32s
  return { arr: V.firstGroupId(new Int32Array([5, 9])), packed: V.firstGroupId(f[0]),
           none: V.firstGroupId(null) };
});
check('a group id comes back from either shape of OrderedSet Mol* uses',
  unpack.arr === 5 && unpack.packed === 7 && unpack.none === null, JSON.stringify(unpack));
const routed = await page.evaluate(() => {
  const V = window.dwormVR;
  const fake = (label) => ({ kind: 'group-loci', shape: { getLabel: () => label },
                             groups: [{ ids: new Int32Array([0]) }] });
  return { btn: V.menuActionFromLoci(fake('BTN:render')),
           plate: V.menuActionFromLoci(fake('NAME')),
           molecule: V.menuActionFromLoci({ kind: 'element-loci' }) };
});
check('each button carries its own action in its tooltip and comes back identified',
  routed.btn === 'render' && routed.plate === null && routed.molecule === null, JSON.stringify(routed));

/* ------------------------------------------------- the readout above the top row
   The number used to be drawn in the scene on the bar between the two atoms, where it spent
   its life inside somebody's side chain. It is now a card above the top row of the menu,
   carried by the menu's own transform — always at the hand, always the right way round. */
const card = await page.evaluate(async () => {
  const V = window.dwormVR;
  const P = V.picked; P.length = 0;
  P.push({ name: 'C1', label: 'C1', pos: [0, 0, 0] });
  P.push({ name: 'C2', label: 'C2', pos: [1.5, 0, 0] });
  V.rebuildMeasurement();
  await new Promise(r => setTimeout(r, 700));
  const withTwo = { text: V.vrDyn.meas.text, hasRepr: !!V.vrDyn.meas.repr,
                    line: !!V.vrDyn.line.repr,
                    cardBtn: V.vrMenuButtons.filter(b => b.card).map(b => b.id) };
  V.clearPicks();
  await new Promise(r => setTimeout(r, 700));
  return { withTwo, afterClear: { text: V.vrDyn.meas.text,
                                  cardBtn: V.vrMenuButtons.filter(b => b.card).length } };
});
check('two picks put a distance on the card, and a bar between the atoms in the scene',
  /^DIST 1\.500 A\|C1 - C2/.test(card.withTwo.text) && card.withTwo.hasRepr && card.withTwo.line,
  card.withTwo.text);
/* The card is the thing you look at when you want the measurement gone, so it is also the
   button that clears it — one target, no hunting for Clear two rows down. */
check('and the card is itself the Clear button, in the same list the ray is tested against',
  card.withTwo.cardBtn.join(',') === 'clear', card.withTwo.cardBtn.join(','));
check('clearing takes the card, its rectangle and the bar away together',
  card.afterClear.text === '' && card.afterClear.cardBtn === 0);

/* A press on a menu button must not also count as an atom pick: the click stream is one
   stream, and counting both would add an atom every time you changed the background. */
const notAPick = await page.evaluate(() => {
  const V = window.dwormVR;
  V.picked.length = 0;
  const before = document.documentElement.getAttribute('data-theme') || 'white';
  V.plugin.behaviors.interaction.click.next({ current: { loci: {
    kind: 'group-loci', shape: { getLabel: () => 'BTN:bg' }, groups: [{ ids: new Int32Array([0]) }] } } });
  return { picks: V.picked.length, before,
           after: document.documentElement.getAttribute('data-theme') || 'white' };
});
check('a press on a button changes the setting and does NOT count as an atom pick',
  notAPick.picks === 0 && notAPick.after !== notAPick.before,
  `${notAPick.before} -> ${notAPick.after}, ${notAPick.picks} picks`);

/* ================================================ THE OTHER NINE CONTROLS

   Each of these presses the flat control rather than reaching into the viewer, which is the
   whole point of the design — so what is checked here is that the press lands, that the
   picture actually changed, and that the page can say what it is showing. */
const nRepr = () => page.evaluate(() => {
  let n = 0;
  window.dwormVR.plugin.state.data.cells.forEach((c) => {
    if (c.transform && c.transform.transformer.id === 'ms-plugin.structure-representation-3d') n++;
  });
  return n;
});

const colour = await page.evaluate(async () => {
  const V = window.dwormVR;
  const before = V.colourBy;
  V.XR_ACTIONS.chain();
  await new Promise(r => setTimeout(r, 900));
  return { before, after: V.colourBy, sel: document.getElementById('selColour').value,
           spec: V.colourSpec().color, lit: V.buttonLit('chain') };
});
check('CHAIN moves the page’s own colour menu, and the theme follows it',
  colour.before === 'element' && colour.after === 'chain' && colour.sel === 'chain' && colour.spec === 'chain-id',
  `${colour.before} -> ${colour.after} (${colour.spec})`);
check('and the button lights up, so a toggle in a headset is not a coin flip', colour.lit === true);
await page.selectOption('#selColour', 'element');
await page.waitForTimeout(700);

const surf = await page.evaluate(async () => {
  const V = window.dwormVR;
  const sel = document.getElementById('selSurface');
  const out = {};
  for (const mode of ['ses', 'sas']) {
    sel.value = mode; sel.dispatchEvent(new Event('change'));
    await new Promise(r => setTimeout(r, 2500));
    let types = [];
    V.plugin.state.data.cells.forEach((c) => {
      if (c.transform && c.transform.transformer.id === 'ms-plugin.structure-representation-3d') {
        types.push(c.transform.params.type.name);
      }
    });
    out[mode] = { types, params: V.SURFACE[mode].typeParams };
  }
  sel.value = 'off'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 1200));
  let after = 0;
  V.plugin.state.data.cells.forEach((c) => { if (c.transform && c.transform.transformer.id === 'ms-plugin.structure-representation-3d') after++; });
  out.offCount = after;
  return out;
});
/* THE SURFACE GOES ON TOP OF THE STICKS, not instead of them: a surface on its own hides
   where the atoms are, and that is not what a surface is for. */
check('SURFACE adds a second representation over the sticks rather than replacing them',
  surf.ses.types.length === 2 && surf.ses.types.indexOf('molecular-surface') >= 0 &&
  surf.ses.types.indexOf('ball-and-stick') >= 0, surf.ses.types.join(' + '));
/* The two surfaces are a probe radius apart: the molecular surface is where a 1.4 A ball
   touches the atoms, the solvent-accessible one is where its CENTRE goes — the same shape
   with every radius 1.4 A larger. Asking for the second and getting the first is a silent
   wrong answer, so the parameters are asserted, not just the names. */
check('and SOLVENT ACCESSIBLE is a different surface, not the same one under another name',
  surf.sas.types.indexOf('gaussian-surface') >= 0 && surf.sas.params.radiusOffset === 1.4 &&
  surf.ses.params.probeRadius === 1.4,
  `${surf.ses.types.join('+')} probe ${surf.ses.params.probeRadius} → ${surf.sas.types.join('+')} offset +${surf.sas.params.radiusOffset}`);
check('and switching it off takes it away again', surf.offCount === 1, surf.offCount + ' representation left');

const resid = await page.evaluate(async () => {
  const V = window.dwormVR;
  V.XR_ACTIONS.resid();
  await new Promise(r => setTimeout(r, 1500));
  let labels = 0;
  V.plugin.state.data.cells.forEach((c) => {
    if (c.transform && c.transform.transformer.id === 'ms-plugin.structure-representation-3d' &&
        c.transform.params.type.name === 'label') labels++;
  });
  const on = { labels, lit: V.buttonLit('resid'), checked: document.getElementById('chkRes').checked };
  V.XR_ACTIONS.resid();
  await new Promise(r => setTimeout(r, 1200));
  let after = 0;
  V.plugin.state.data.cells.forEach((c) => {
    if (c.transform && c.transform.transformer.id === 'ms-plugin.structure-representation-3d' &&
        c.transform.params.type.name === 'label') after++;
  });
  return { on, off: after };
});
check('RESIDUES puts a label on every residue, and takes them off again',
  resid.on.labels === 1 && resid.on.checked === true && resid.off === 0,
  `on: ${resid.on.labels} label representation, off: ${resid.off}`);

/* THE SLAB. Not canvas3d.cameraClipping, which works by shrinking the camera radius and so
   does nothing in a session, where the near and far planes come from the headset. A clip
   object on every representation is discarded in the shader and therefore works in both. */
const slab = await page.evaluate(async () => {
  const V = window.dwormVR;
  const read = () => {
    const out = [];
    V.plugin.state.data.cells.forEach((c) => {
      if (c.transform && c.transform.transformer.id === 'ms-plugin.structure-representation-3d') {
        const clip = c.transform.params.type.params.clip;
        out.push(clip && clip.objects ? clip.objects.length : -1);
      }
    });
    return out;
  };
  const sel = document.getElementById('selSlab');
  sel.value = '30'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 800));
  const spec = V.clipSpec();
  const on = { objs: read(), pct: V.slabPct, lit: V.buttonLit('slab'),
               type: spec.objects[0] && spec.objects[0].type,
               invert: spec.objects[0] && spec.objects[0].invert,
               d: spec.objects[0] && spec.objects[0].scale[0],
               R: V.structureRef.data.boundary.sphere.radius };
  sel.value = '0'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 800));
  return { on, off: read() };
});
check('SLAB clips the geometry itself, so it works in a headset as well as on the page',
  slab.on.objs.length > 0 && slab.on.objs.every(n => n === 1) && slab.on.type === 'sphere' && slab.on.invert === true,
  `${slab.on.objs.length} representation(s) clipped, ${slab.on.type} invert=${slab.on.invert}`);
check('and 30% keeps 30% of the structure, measured against its own radius',
  Math.abs(slab.on.d - 2 * slab.on.R * 0.30) < 1e-6,
  `${slab.on.d.toFixed(2)} A across, structure radius ${slab.on.R.toFixed(2)} A`);
check('and switching it off puts the whole structure back',
  slab.off.length > 0 && slab.off.every(n => n === 0), JSON.stringify(slab.off));

/* IGM/FIELD. Nothing was handed over in this test, so the honest answer is to say so rather
   than to cycle a menu with one entry in it and appear to have done something. */
const noField = await page.evaluate(() => {
  const V = window.dwormVR;
  V.XR_ACTIONS.field();
  return { msg: document.getElementById('msg').textContent, opts: document.getElementById('selField').options.length,
           idx: V.fieldIdx, lit: V.buttonLit('field') };
});
check('IGM says plainly that no field was handed over, rather than pretending to switch one on',
  /no field was handed over/i.test(noField.msg) && noField.opts === 1 && noField.idx === -1 && noField.lit === false,
  noField.msg);

/* A cube read straight into the scene, both lobes, hidden until asked for. This is the same
   path a field handed over from 2D-WORM takes — addVolume is what loadVolumes calls. */
const field = await page.evaluate(async () => {
  const V = window.dwormVR;
  const head = [' probe cube', ' density',
    '    2    0.000000    0.000000    0.000000',
    '    8    0.500000    0.000000    0.000000',
    '    8    0.000000    0.500000    0.000000',
    '    8    0.000000    0.000000    0.500000',
    '    1    1.000000    1.000000    1.000000    1.000000',
    '    1    1.000000    2.400000    1.000000    1.000000'];
  const vals = [];
  for (let i = 0; i < 8 * 8 * 8; i++) {
    const x = (i >> 6) - 3.5, y = ((i >> 3) & 7) - 3.5, z = (i & 7) - 3.5;
    vals.push(Math.exp(-(x * x + y * y + z * z) / 6) * (x > 0 ? 1 : -1));
  }
  for (let i = 0; i < vals.length; i += 6) head.push(vals.slice(i, i + 6).map(v => '  ' + v.toExponential(5)).join(''));
  const rec = await V.addVolume('probe.cube', head.join('\n') + '\n');
  const sel = document.getElementById('selField');
  const o = document.createElement('option'); o.value = String(V.volumes.length - 1); o.textContent = 'probe.cube';
  sel.appendChild(o); sel.disabled = false;
  const built = { ok: !!rec, refs: rec ? rec.refs.length : 0, hidden: rec ? !rec.on : null,
                  atoms: V.structureRef ? V.structureRef.data.elementCount : 0 };
  V.XR_ACTIONS.field();
  await new Promise(r => setTimeout(r, 900));
  const on = { idx: V.fieldIdx, on: V.volumes[0] && V.volumes[0].on, lit: V.buttonLit('field'),
               msg: document.getElementById('msg').textContent };
  V.XR_ACTIONS.field();
  await new Promise(r => setTimeout(r, 700));
  const off = { idx: V.fieldIdx, on: V.volumes[0] && V.volumes[0].on };
  /* AND BACK ON AGAIN. Hiding is cell state, not a transform parameter; changing it through
     the state builder rewrites the parameters instead, and an isosurface whose parameters
     have been replaced by an empty object never comes back. It looks like a working toggle
     exactly once. */
  V.XR_ACTIONS.field();
  await new Promise(r => setTimeout(r, 900));
  let intact = 0, named = [];
  for (const ref of V.volumes[0].refs) {
    const c = V.plugin.state.data.cells.get(ref);
    if (c && c.transform && c.transform.transformer.id === 'ms-plugin.volume-representation-3d') {
      intact++; named.push(c.transform.params && c.transform.params.type && c.transform.params.type.name);
    }
  }
  return { built, on, off, again: { on: V.volumes[0].on, intact, named } };
});
check('a .cube handed over is read into the scene whole, with a lobe of each sign',
  field.built.ok === true && field.built.refs >= 2, field.built.refs + ' state cells');
/* The cube carries its own copy of the atoms in its header. Keeping those would put a second
   structure half an angstrom from the first, which is worse than having none. */
check('and the atoms from the cube’s header are thrown away, because the structure is already here',
  field.built.atoms === 21, field.built.atoms + ' atoms, unchanged');
check('and switching it off and on again leaves the isosurface intact, parameters and all',
  field.again.on === true && field.again.intact === 2 &&
  field.again.named.every(n => n === 'isosurface'), field.again.named.join(','));
check('it arrives switched off, and IGM is what switches it on and off again',
  field.built.hidden === true && field.on.on === true && field.on.idx === 0 &&
  field.on.lit === true && field.off.on === false && field.off.idx === -1,
  `hidden -> ${field.on.on} -> ${field.off.on}`);

/* AN ELECTRON DENSITY HAS NO SECOND LOBE — every value in the grid is positive. Asking for
   an isosurface at a level the data never reaches gives a mesh with no triangles, which
   becomes a texture with no pixels, which WebGL refuses: "empty textures are not allowed",
   and the field does not appear at all. The grid's own statistics are what decide. */
const errBeforeDensity = errors.length;
const density = await page.evaluate(async () => {
  const V = window.dwormVR;
  const head = [' density only', ' rho',
    '    1    0.000000    0.000000    0.000000',
    '    8    0.500000    0.000000    0.000000',
    '    8    0.000000    0.500000    0.000000',
    '    8    0.000000    0.000000    0.500000',
    '    1    1.000000    1.000000    1.000000    1.000000'];
  const vals = [];
  for (let i = 0; i < 8 * 8 * 8; i++) {
    const x = (i >> 6) - 3.5, y = ((i >> 3) & 7) - 3.5, z = (i & 7) - 3.5;
    vals.push(Math.exp(-(x * x + y * y + z * z) / 6));       // never negative
  }
  for (let i = 0; i < vals.length; i += 6) head.push(vals.slice(i, i + 6).map(v => '  ' + v.toExponential(5)).join(''));
  const n0 = V.volumes.length;
  const rec = await V.addVolume('density.cube', head.join('\n') + '\n');
  await new Promise(r => setTimeout(r, 900));
  let isos = 0;
  if (rec) for (const ref of rec.refs) {
    const c = V.plugin.state.data.cells.get(ref);
    if (c && c.transform && c.transform.transformer.id === 'ms-plugin.volume-representation-3d') isos++;
  }
  return { ok: !!rec, isos, added: V.volumes.length - n0 };
});
await page.waitForTimeout(600);
check('a cube with no negative values gets one lobe, not an empty one WebGL refuses to draw',
  density.ok === true && density.isos === 1 && density.added === 1 &&
  errors.slice(errBeforeDensity).filter(e => /empty texture/i.test(e)).length === 0,
  density.isos + ' isosurface' + (density.isos === 1 ? '' : 's'));

/* ---------------------------------------------------- the lock, read backwards
   Coming in is tested above. Going out is the same three physical quantities read off Mol*'s
   camera — and a round trip is the only check that catches a convention that is wrong in
   both directions at once, because it would cancel. So the numbers are compared against the
   record that was SENT, which came from 3Dmol and knows nothing about Mol*. */
const roundTrip = await page.evaluate(async () => {
  const V = window.dwormVR;
  V.applyCamera(V.payload.cam);
  await new Promise(r => setTimeout(r, 500));
  const back = V.viewRecord();
  const sent = V.payload.cam;
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  /* q and -q are the same rotation, so the quaternions are compared as rotations: the axis
     each one sends +z to, which is what the view actually looks along. */
  const axis = (q) => V.qrot(V.qconj(q), [0, 0, 1]);
  const up = (q) => V.qrot(V.qconj(q), [0, 1, 0]);
  return { sent, back,
           centre: Math.hypot(back.centre[0] - sent.centre[0], back.centre[1] - sent.centre[1], back.centre[2] - sent.centre[2]),
           half: Math.abs(back.half - sent.half) / sent.half,
           axisDot: dot(axis(back.quat), axis(sent.quat)),
           upDot: dot(up(back.quat), up(sent.quat)) };
});
check('the view Mol* is showing reads back as the same record 3Dmol sent — same centre',
  roundTrip.centre < 0.01, roundTrip.centre.toExponential(1) + ' A apart');
check('— the same amount of the structure in frame',
  roundTrip.half < 0.01, (roundTrip.half * 100).toFixed(2) + '% out');
check('— looking along the same axis, and the same way up',
  roundTrip.axisDot > 0.9999 && roundTrip.upDot > 0.9999,
  `axis ${roundTrip.axisDot.toFixed(5)}, up ${roundTrip.upDot.toFixed(5)}`);

/* THE LOCK HAS NO SWITCH. Leaving by any route writes the view down, so 2D-WORM comes back
   to what the headset was showing without anybody having pressed anything. */
const back = await page.evaluate(() => {
  const V = window.dwormVR;
  sessionStorage.removeItem(V.VR_BACK);
  const rec = V.writeBack();
  const stored = JSON.parse(sessionStorage.getItem(V.VR_BACK) || 'null');
  return { rec: !!rec, stored, keys: stored ? Object.keys(stored).sort().join(' ') : '' };
});
check('leaving writes the view back for 2D-WORM, with no button to remember to press',
  back.rec && back.stored && Array.isArray(back.stored.cam.centre) && back.stored.cam.half > 0,
  back.keys);

/* MACMOLPLT PROPORTIONS, not Mol*'s. Its ball-and-stick defaults to spheres a quarter of an
   angstrom across with sticks nearly as fat; 2D-WORM draws at 0.26 of the van der Waals
   radius with a 0.13 A stick, which is what this project's figures are made in. The same
   structure must not change shape when it crosses over. */
check('the structure is drawn in the same proportions it had in 2D-WORM, not in Mol*’s',
  Math.abs((await page.evaluate(() => window.dwormVR.MACMOLPLT.sizeFactor)) - 0.26) < 1e-9 &&
  Math.abs((await page.evaluate(() => window.dwormVR.MACMOLPLT.sizeAspectRatio)) - 0.30) < 1e-9,
  '0.26 x vdW spheres, 0.13 A sticks');

/* THE LAMPS. Rebuilt on their own rather than by rebuilding the menu — the menu is a state
   tree reload and the lamps are seven quads, and a toggle in a headset must not cost a
   reload. */
const lamps = await page.evaluate(async () => {
  const V = window.dwormVR;
  const chk = document.getElementById('chkH');
  chk.checked = false; chk.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 600));
  V.refreshLamps();
  await new Promise(r => setTimeout(r, 500));
  const before = { ref: !!V.vrDyn.lamps.ref, lit: V.buttonLit('hide') };
  V.XR_ACTIONS.hide();
  await new Promise(r => setTimeout(r, 900));
  V.refreshLamps();
  await new Promise(r => setTimeout(r, 600));
  const after = { ref: !!V.vrDyn.lamps.ref, lit: V.buttonLit('hide'),
                  rides: V.vrDyn.lamps.menu === true,
                  cardStillThere: V.vrMenuButtons.filter(b => b.card).length };
  V.XR_ACTIONS.hide();
  await new Promise(r => setTimeout(r, 900));
  return { before, after };
});
check('a toggle that is on lights a lamp under its own button on the panel',
  lamps.before.lit === false && lamps.after.lit === true && lamps.after.ref === true,
  `HIDE H off -> on, lamp group ${lamps.after.ref}`);
check('and the lamps ride the panel like the readout card, without stealing its rectangle',
  lamps.after.rides === true && lamps.after.cardStillThere === 0);

const gone = await page.evaluate(async () => {
  const V = window.dwormVR;
  await V.removeVRMenu();
  await new Promise(r => setTimeout(r, 400));
  return { on: V.vrMenuOn, parts: V.vrMenuReprs.length,
           atoms: V.structureRef ? V.structureRef.data.elementCount : 0 };
});
check('leaving VR takes the panel away and leaves the structure alone',
  gone.on === false && gone.parts === 0 && gone.atoms === 21, JSON.stringify(gone));

check('no page errors', errors.filter(e => !/favicon|ResizeObserver|WebGL|Could not create/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
