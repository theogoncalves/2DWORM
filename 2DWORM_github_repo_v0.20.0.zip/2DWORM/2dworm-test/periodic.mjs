/* THE CELL AND THE CHARGES — what a file brings with it besides coordinates.
 *
 * Two things were being read out of files and thrown away. A periodic structure kept only a
 * phrase saying a cell existed, so the box could not be drawn and a POSCAR saved as a CIF came
 * out as a molecule floating in vacuum — a different substance, and nothing in the picture
 * said so. And a population analysis was not read at all, though it is often the only reason
 * somebody opens a finished job.
 *
 * The checks below are about the round trip above all: a structure that goes out of this page
 * in one format and comes back in another has to be the same crystal, to the sixth decimal.
 * That is what "seamless interconversion" has to mean if it is to mean anything.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const OUT = fileURLToPath(new URL('./out', import.meta.url));
const PORT = 8801;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
fs.mkdirSync(OUT, { recursive: true });

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });

const open = async (name, text) => {
  await page.setInputFiles('#fileInput', { name, mimeType: 'text/plain', buffer: Buffer.from(text) });
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 60000 });
  await page.waitForTimeout(350);
};
const cellNow = () => page.evaluate(() => window.dworm2d.state3d.cell);
const params = (c) => {
  const L = (v) => Math.hypot(v[0], v[1], v[2]);
  const ang = (u, v) => Math.acos(Math.max(-1, Math.min(1,
    (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / ((L(u) * L(v)) || 1)))) * 180 / Math.PI;
  return [L(c.a), L(c.b), L(c.c), ang(c.b, c.c), ang(c.a, c.c), ang(c.a, c.b)];
};
const save = async (what) => {
  const [dl] = await Promise.all([
    page.waitForEvent('download', { timeout: 30000 }),
    page.evaluate((w) => document.querySelector(`[data-save="${w}"]`).click(), what)]);
  const p = OUT + '/p_' + dl.suggestedFilename();
  await dl.saveAs(p);
  return { name: dl.suggestedFilename(), text: fs.readFileSync(p, 'utf8') };
};

/* ------------------------------------------------------------------ a POSCAR
   Silicon, the smallest thing that is unmistakably a crystal: two atoms, a cell whose angles
   are 60° rather than 90°, so nothing can pass by assuming an orthorhombic box. */
const POSCAR = `Si diamond
   1.00000000000000
     0.0000000000000000    2.7150000000000000    2.7150000000000000
     2.7150000000000000    0.0000000000000000    2.7150000000000000
     2.7150000000000000    2.7150000000000000    0.0000000000000000
   Si
     2
Direct
  0.0000000000000000  0.0000000000000000  0.0000000000000000
  0.2500000000000000  0.2500000000000000  0.2500000000000000
`;
await open('POSCAR', POSCAR);
const c1 = await cellNow();
check('a POSCAR arrives with its three lattice vectors, not just the word "cell"',
  !!c1 && Math.abs(params(c1)[0] - 3.83959) < 1e-3 && Math.abs(params(c1)[3] - 60) < 1e-3,
  c1 ? params(c1).map(x => x.toFixed(4)).join(' ') : 'no cell');
check('and the page says so, with the six numbers',
  /3\.840 × 3\.840 × 3\.840 Å, 60\.00° 60\.00° 60\.00°/.test(await page.textContent('#status3d')),
  (await page.textContent('#status3d')).slice(0, 130));
check('the cell checkbox appears only when there is a cell, and is on',
  await page.isVisible('#cellChk') && await page.isChecked('#chkCell'));
const boxOn = await page.evaluate(() => window.dworm2d.viewer.shapes.length);
await page.uncheck('#chkCell');
await page.waitForTimeout(200);
const boxOff = await page.evaluate(() => window.dworm2d.viewer.shapes.length);
check('the box is twelve edges and three axis stubs, and the checkbox takes them away',
  boxOn - boxOff === 15, `${boxOn} shapes with the box, ${boxOff} without`);
await page.check('#chkCell');
await page.waitForTimeout(200);

/* ------------------------------------------------- out one way, back in another
   The whole point. Each of these is written from the same atoms and the same three vectors,
   and each has to come back as the same crystal — which is only true if the writer and the
   reader agree about the convention, and they disagree in different ways for every format:
   nanometres in GROMACS, six numbers instead of nine in CIF and PDB, fractions in both. */
for (const [what, ext] of [['cif', 'cif'], ['poscar', 'POSCAR'], ['gro', 'gro']]) {
  const f = await save(what);
  if (what === 'poscar') {
    check('a POSCAR is called POSCAR, with nothing appended — VASP reads no other name',
      f.name === 'POSCAR', f.name);
  }
  await open(ext === 'POSCAR' ? 'POSCAR' : 'roundtrip.' + ext, f.text);
  const c = await cellNow();
  const p0 = params(c1), p = c ? params(c) : null;
  check(`a cell survives being written as ${f.name} and opened again`,
    !!p && p.every((x, i) => Math.abs(x - p0[i]) < 3e-3),
    p ? p.map(x => x.toFixed(4)).join(' ') : 'no cell came back');
}
/* Gaussian and xtb do not come back through this page — they are inputs to other programs —
   so what is checked is that the cell is IN them, in the form each program expects. */
await open('POSCAR', POSCAR);
const gjf = await save('gjf');
check('a Gaussian input carries the cell as three TV lines, which is how Gaussian says periodic',
  (gjf.text.match(/^ TV /gm) || []).length === 3, (gjf.text.match(/^ TV.*$/gm) || []).join(' | ').slice(0, 90));
const coord = await save('coord');
check('an xtb coord is in BOHR and says $periodic 3',
  /\$periodic 3/.test(coord.text) && /\$lattice angs/.test(coord.text) &&
  /\$coord/.test(coord.text) && /\s+si\s*$/m.test(coord.text),
  coord.text.split('\n').slice(0, 3).join(' | '));
const cif = await save('cif');
check('a CIF written here is P 1 with fractional coordinates — no space group is invented',
  /_symmetry_space_group_name_H-M\s+'P 1'/.test(cif.text) && /_atom_site_fract_x/.test(cif.text),
  cif.text.split('\n').filter(l => /_cell_length_a|_symmetry_Int/.test(l)).join(' | '));
/* VASP will only read a file called POSCAR, and xtb only one called coord. A browser handed
   text/plain for a name with NO extension appends ".txt" to it — so both of the formats whose
   names are fixed by their own programs came out of this page unusable, and it took unpacking
   a release zip to notice. Asserted here by name, not by content. */
check('the two formats whose names their programs fix keep those names exactly',
  coord.name === 'coord' && /\.gjf$/.test(gjf.name) && /\.cif$/.test(cif.name),
  [gjf.name, coord.name, cif.name].join(' '));
const gro = await save('gro');
/* GROMACS will not accept a box whose first vector has a y or z component, so the cell is put
   in the standard setting (a along x, b in the xy plane) and THE ATOMS ARE TURNED WITH IT.
   The nine numbers come in GROMACS's own order, v1x v2y v3z v1y v1z v2x v2z v3x v3y, and the
   three that must be zero are v1y, v1z and v2z. */
const groBox = gro.text.trim().split('\n').pop().trim().split(/\s+/).map(Number);
check('a .gro is in nanometres, and its box is lower triangular as GROMACS demands',
  Math.abs(groBox[0] - 0.38396) < 1e-4 && groBox.length === 9 &&
  Math.abs(groBox[3]) < 1e-9 && Math.abs(groBox[4]) < 1e-9 && Math.abs(groBox[6]) < 1e-9,
  groBox.join(' '));

/* ------------------------------------------------------------- CELL FIX
   A periodic structure does not stop being itself when an atom leaves the cell — the cell
   repeats, so the atom outside IS the atom inside. What changes is the picture, and a
   molecule that has drifted out of the box reads as one that has fallen off the crystal.

   The rule being tested is that WHOLE MOLECULES move. Wrapping one atom on its own tears the
   molecule and leaves a bond stretched across the cell: correct, and unreadable. */
{
  /* two water molecules in a 10 A box — one inside, one pushed a whole cell out along x and
     y, and deliberately straddling nothing, so the arithmetic is unambiguous */
  const two = `TWO WATERS
   1.00000000000000
    10.0000000  0.0000000  0.0000000
     0.0000000 10.0000000  0.0000000
     0.0000000  0.0000000 10.0000000
   O  H
   2  4
Cartesian
   2.0000000  2.0000000  2.0000000
  13.0000000 13.0000000  3.0000000
   2.9600000  2.0000000  2.0000000
   1.7600000  2.9300000  2.0000000
  13.9600000 13.0000000  3.0000000
  12.7600000 13.9300000  3.0000000
`;
  await open('POSCAR', two);
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 6, null, { timeout: 30000 });
  if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
  check('CELL FIX is offered only when there is a cell to put things back into',
    await page.isVisible('#btnCellFix'));
  const geom = () => page.evaluate(() => {
    const a = window.dworm2d.viewer.getModel().selectedAtoms({});
    const d = (i, j) => Math.hypot(a[i].x - a[j].x, a[i].y - a[j].y, a[i].z - a[j].z);
    const cell = window.dworm2d.state3d.cell;
    const L = cell.a[0];
    const out = a.filter(p => [p.x, p.y, p.z].some(t => t < -1e-9 || t >= L)).length;
    return { out, n: a.length, oh: [d(1, 4), d(1, 5)].map(x => +x.toFixed(4)),
             oo: +d(0, 1).toFixed(3), pos: [a[1].x, a[1].y, a[1].z].map(x => +x.toFixed(3)) };
  });
  const was = await geom();
  check('the second water starts a whole cell away, outside the box',
    was.out === 3 && Math.abs(was.pos[0] - 13) < 1e-6, JSON.stringify(was));
  await page.click('#btnCellFix');
  await page.waitForTimeout(400);
  const now = await geom();
  check('CELL FIX brings it back, by exactly one lattice vector in each direction it had left',
    now.out === 0 && Math.abs(now.pos[0] - 3) < 1e-6 && Math.abs(now.pos[1] - 3) < 1e-6,
    JSON.stringify(now.pos));
  /* the whole point: the molecule is not torn. Its O–H bonds are unchanged to six figures. */
  check('and the molecule is moved WHOLE — its bonds are exactly what they were',
    now.oh.every((d, i) => Math.abs(d - was.oh[i]) < 1e-6), was.oh.join(', ') + ' -> ' + now.oh.join(', '));
  check('the other molecule, which was already inside, did not move',
    Math.abs(now.oo - Math.hypot(1, 1, 1) * 0) >= 0 &&
    (await page.evaluate(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({});
      return Math.abs(a[0].x - 2) < 1e-9 && Math.abs(a[0].y - 2) < 1e-9; })));
  check('pressing it again says there is nothing to do rather than doing it twice',
    (await (async () => { await page.click('#btnCellFix'); await page.waitForTimeout(300);
      return page.textContent('#status3d'); })()).match(/Nothing was outside|already whole and inside|already where the walk/),
    (await page.textContent('#status3d')).slice(0, 70));
  /* it is a change to the structure, so UNDO has to take it back */
  await page.click('#btnUndo');
  await page.waitForTimeout(300);
  check('UNDO puts it back outside, because CELL FIX is an edit like any other',
    (await geom()).out === 3);

  /* ---------------------------------------------------- the strict mode
     Every atom inside, which is what a code reading fractional coordinates in [0,1) wants —
     and which necessarily tears any molecule that crosses a face. A water straddling a
     boundary is the smallest case that shows it: one atom goes to the far corner and its
     bond is drawn right across the cell. The page says so rather than leaving it to be
     discovered in the picture. */
  const straddle = `STRADDLING WATER
   1.00000000000000
    10.0000000  0.0000000  0.0000000
     0.0000000 10.0000000  0.0000000
     0.0000000  0.0000000 10.0000000
   O  H
   1  2
Cartesian
   0.3000000  5.0000000  5.0000000
   1.2600000  5.0000000  5.0000000
  -0.4000000  5.9300000  5.0000000
`;
  await open('POSCAR', straddle);
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 3, null, { timeout: 30000 });
  if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
  await page.waitForSelector('#selCellFix', { state: 'visible', timeout: 15000 });
  const bond = () => page.evaluate(() => {
    const a = window.dworm2d.viewer.getModel().selectedAtoms({});
    const cell = window.dworm2d.state3d.cell, L = cell.a[0];
    return { oh: +Math.hypot(a[0].x - a[2].x, a[0].y - a[2].y, a[0].z - a[2].z).toFixed(4),
             out: a.filter(p => [p.x, p.y, p.z].some(t => t < -1e-9 || t >= L)).length };
  });
  const intact = (await bond()).oh;
  check('one hydrogen of this water sits outside the cell', (await bond()).out === 1, JSON.stringify(await bond()));
  await page.selectOption('#selCellFix', 'molecules');
  await page.click('#btnCellFix');
  await page.waitForTimeout(350);
  const whole = await bond();
  check('“Fix: molecules” leaves it alone and says why — the molecule is already in its own cell',
    whole.out === 1 && Math.abs(whole.oh - intact) < 1e-6 &&
    /Fix: atoms|already in its own image/.test(await page.textContent('#status3d')),
    (await page.textContent('#status3d')).slice(0, 100));
  await page.selectOption('#selCellFix', 'atoms');
  await page.click('#btnCellFix');
  await page.waitForTimeout(350);
  const strict = await bond();
  check('“Fix: atoms” forces every atom inside, which is what the option is for',
    strict.out === 0, JSON.stringify(strict));
  check('and it says the bond it had to split is now drawn across the cell, rather than leaving it to be found',
    /drawn stretched across it/.test(await page.textContent('#status3d')) && strict.oh > 5,
    `O–H drawn as ${strict.oh} A · ` + (await page.textContent('#status3d')).slice(0, 80));
  await page.click('#btnUndo');
  await page.waitForTimeout(300);
  check('and UNDO puts that molecule back together',
    Math.abs((await bond()).oh - intact) < 1e-6, JSON.stringify(await bond()));
  await page.selectOption('#selCellFix', 'molecules');
  await page.click('#btnEdit');
}

/* --------------------------------------------------------- CELL EXTEND
   A crystallographic file lists ONE cell, so a molecule straddling a face is listed as two
   pieces at opposite corners. Both are there, neither is bonded to the other, and what you
   see is fragments. That is the commonest reason a CIF looks wrong on opening — and it is
   not wrong, it is the cell. */
{
  /* A water whose hydrogen belongs at x = -0.36 but is listed, as a CIF would, at x = 9.64:
     the same atom, one cell over. Its O–H is therefore drawn 9.6 A long and 3Dmol perceives
     no bond at all, so the molecule arrives as an oxygen, a hydrogen, and a lone hydrogen. */
  const cut = `SPLIT WATER
   1.00000000000000
    10.0000000  0.0000000  0.0000000
     0.0000000 10.0000000  0.0000000
     0.0000000  0.0000000 10.0000000
   O  H
   1  2
Cartesian
   0.3000000  5.0000000  5.0000000
   1.2600000  5.0000000  5.0000000
   9.6400000  5.7000000  5.0000000
`;
  await open('POSCAR', cut);
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 3, null, { timeout: 30000 });
  if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
  await page.waitForSelector('#btnCellExtend', { state: 'visible', timeout: 15000 });
  const bonds = () => page.evaluate(() =>
    window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => (a.bonds || []).length));
  check('the split water arrives with a hydrogen bonded to nothing — the cell cut it',
    (await bonds()).includes(0), JSON.stringify(await bonds()));
  await page.click('#btnCellExtend');
  await page.waitForTimeout(700);
  const after = await page.evaluate(() => ({
    n: window.dworm2d.state3d.nAtoms,
    lone: window.dworm2d.viewer.getModel().selectedAtoms({}).filter(a => !(a.bonds || []).length).length,
    cell: !!window.dworm2d.state3d.cell, src: window.dworm2d.state3d.source }));
  /* THREE atoms in, three atoms out — and that is the point. Completing the molecule from
     each listed fragment gives two whole waters, one lattice vector apart: both are really
     in the crystal and drawing both would still be wrong, because the cell held one. */
  check('CELL EXTEND rejoins the molecule and does NOT leave a duplicate of it behind',
    after.n === 3 && after.lone === 0, JSON.stringify(after));
  check('the cell comes with it, so the box is still drawn and can still be written out',
    after.cell === true);
  check('and it says the duplicate was left out, rather than silently doubling the contents',
    /duplicate/.test(await page.textContent('#status3d')),
    (await page.textContent('#status3d')).slice(0, 120));
  check('and the page says plainly that this is no longer a unit cell',
    /not a unit cell/.test(await page.textContent('#status3d')),
    (await page.textContent('#status3d')).slice(0, 110));
  await page.click('#btnCellExtend');
  await page.waitForTimeout(500);
  check('running it again finds nothing to do, rather than growing the crystal each press',
    /already whole/.test(await page.textContent('#status3d')),
    (await page.textContent('#status3d')).slice(0, 60));

  /* THE WALK HAS TO END. A chain of atoms bonded to their own periodic images never
     terminates — follow it and you walk out of the crystal for ever — so the cap is what
     makes this safe to press on a framework at all. */
  const chain = `INFINITE CHAIN
   1.00000000000000
     1.3000000  0.0000000  0.0000000
     0.0000000 12.0000000  0.0000000
     0.0000000  0.0000000 12.0000000
   C
   1
Cartesian
   0.0000000  6.0000000  6.0000000
`;
  await open('POSCAR', chain);
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 1, null, { timeout: 30000 });
  if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
  await page.click('#btnCellExtend');
  await page.waitForTimeout(700);
  const grown = await page.evaluate(() => ({ n: window.dworm2d.state3d.nAtoms,
                                             cap: window.dworm2d.CELL_EXTEND_IMAGES }));
  check('a chain bonded to its own image walks to the cap and stops, rather than for ever',
    grown.n === 2 * grown.cap + 1, `${grown.n} atoms at a cap of ${grown.cap} images`);
  check('and it says that is what happened, so a block of a framework is not mistaken for a molecule',
    /stopped at 4 images/.test(await page.textContent('#status3d')),
    (await page.textContent('#status3d')).slice(0, 110));
  await page.click('#btnEdit');
}

/* ------------------------------------------------ a molecule is not a crystal */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 9 && !document.getElementById('btnMake3d').classList.contains('running'), null, { timeout: 120000 });
await page.waitForTimeout(300);
const afterBuild = await page.evaluate(() => ({
  cell: window.dworm2d.state3d.cell, n: window.dworm2d.state3d.nAtoms,
  hidden: document.getElementById('cellChk').hidden, per: window.dworm2d.state3d.periodic }));
check('building from the drawing drops the cell — it belonged to the file, not to the page',
  afterBuild.cell === null && afterBuild.hidden === true, JSON.stringify(afterBuild));
const noCell = await save('cif');
check('and a CIF of a molecule is written with Cartesian coordinates rather than a made-up cell',
  /_atom_site_Cartn_x/.test(noCell.text) && !/_cell_length_a/.test(noCell.text));

/* --------------------------------------------------------------- the charges */
const LOG = ` Entering Gaussian System, Link 0=g16
                         Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        0.000000    0.000000    0.117300
      2          1           0        0.000000    0.757200   -0.469200
      3          1           0        0.000000   -0.757200   -0.469200
 ---------------------------------------------------------------------
 Mulliken charges:
               1
     1  O   -0.660000
     2  H    0.330000
     3  H    0.330000
 Sum of Mulliken charges =   0.00000
 Hirshfeld charges, spin densities, dipoles, and CM5 charges using IRadAn=      5:
              Q-H        S-H        Dx         Dy         Dz        Q-CM5
     1  O   -0.250000   0.000000   0.000000   0.000000   0.100000  -0.400000
     2  H    0.125000   0.000000   0.000000   0.050000  -0.050000   0.200000
     3  H    0.125000   0.000000   0.000000  -0.050000  -0.050000   0.200000
 Normal termination of Gaussian 16
`;
await open('water.log', LOG);
const q = await page.evaluate(() => ({
  sets: Object.keys(window.dworm2d.state3d.charges || {}),
  chosen: window.dworm2d.opts.charge, mode: window.dworm2d.opts.labels,
  menu: [...document.querySelectorAll('#selCharge option')].map(o => o.value),
  shown: document.getElementById('selCharge').hidden === false,
  labels: (window.dworm2d.viewer.labels || []).map(l => l.text || ''),
}));
check('every analysis in the file is kept, under the name its own program used',
  JSON.stringify(q.sets.slice().sort()) === '["CM5","Hirshfeld","Mulliken"]', q.sets.join(', '));
check('the file opens SHOWING them — it is why the file was opened',
  q.mode === 'charge' && q.shown, `label mode ${q.mode}, menu ${q.shown ? 'shown' : 'hidden'}`);
check('and it opens on the best available, which is CM5 before Hirshfeld before Mulliken',
  q.chosen === 'CM5', q.chosen);
const shown = await page.evaluate(() => (window.dworm2d.viewer.labels || []).map(l => l.text));
check('the captions are the charges, signed, to two decimals',
  shown.length === 3 && shown.includes('−0.40') && shown.filter(t => t === '+0.20').length === 2,
  JSON.stringify(shown));
await page.selectOption('#selCharge', 'Mulliken');
await page.waitForTimeout(300);
const shown2 = await page.evaluate(() => (window.dworm2d.viewer.labels || []).map(l => l.text));
check('choosing another analysis shows that one — nothing is averaged between them',
  shown2.includes('−0.66') && shown2.filter(t => t === '+0.33').length === 2, JSON.stringify(shown2));
check('and the status line gives the sum, which is how you notice the wrong table was read',
  /sum \+0\.000 e/.test(await page.textContent('#status3d')),
  (await page.textContent('#status3d')).slice(0, 100));

/* --------------------------------------------------------------- in a link */
const st = await page.evaluate(async () => await window.dworm2d.buildState('full'));
check('a shared link carries every charge set, and the cell when there is one',
  st.chg && Object.keys(st.chg).length === 3 && st.chg.CM5[0] === -0.4,
  Object.keys(st.chg || {}).join(', '));
await page.evaluate(async (s) => { await window.dworm2d.applyState(s); }, st);
await page.waitForTimeout(700);
check('and opening that link brings the charges back, on the same atoms',
  await page.evaluate(() => (window.dworm2d.state3d.charges || {}).CM5?.[0]) === -0.4);
/* A link is text somebody else can edit, so everything in one is checked before it is used. */
await page.evaluate(async (s) => {
  await window.dworm2d.applyState({ ...s, chg: { Bad: [1, 2], Fine: [0.1, 0.2, -0.3] }, cel: [[1, 0, 0], [2, 0, 0], [3, 0, 0]] });
}, st);
await page.waitForTimeout(700);
const guard = await page.evaluate(() => ({
  sets: Object.keys(window.dworm2d.state3d.charges || {}), cell: window.dworm2d.state3d.cell,
  atoms: window.dworm2d.state3d.nAtoms }));
check('a charge list of the wrong length is dropped rather than put on whichever atoms it reaches',
  JSON.stringify(guard.sets) === '["Fine"]', guard.sets.join(', ') + ' for ' + guard.atoms + ' atoms');
check('and three vectors that lie in a plane are refused: that is not a cell, it is a flat box',
  guard.cell === null, JSON.stringify(guard.cell));
await page.evaluate(async (s) => {
  await window.dworm2d.applyState({ ...s, cel: 'not a cell', chg: [1, 2, 3] });
}, st);
await page.waitForTimeout(600);
check('and rubbish in either field opens the structure anyway rather than an empty page',
  await page.evaluate(() => window.dworm2d.state3d.nAtoms) === 3 &&
  await page.evaluate(() => window.dworm2d.state3d.cell) === null);

/* ============================================ MINIMISING INSIDE THE SURROUNDINGS

   A unit cell relaxed as if it were a molecule in vacuum contracts: most of its atoms are at
   a surface that does not exist, and the force field pulls them inwards to satisfy contacts
   that in the crystal are satisfied by the next cell along. MIN PERIODIC builds those
   neighbours explicitly, freezes them, and relaxes the cell against them.

   A small cell of two waters, one of them pressed against a face so that its neighbour
   across the wall is a contact rather than a bond — which is the case a shell grown along
   bonds alone would miss, and the reason the seed has a distance criterion as well. */
{
  const wet = `TWO WATERS
   1.00000000000000
     7.0000000  0.0000000  0.0000000
     0.0000000  7.0000000  0.0000000
     0.0000000  0.0000000  7.0000000
   O  H
   2  4
Cartesian
   1.2000000  3.5000000  3.5000000
   6.2000000  3.5000000  3.5000000
   1.9500000  3.5000000  3.5000000
   0.9400000  4.2700000  3.6000000
   6.9500000  3.5000000  3.5000000
   5.9400000  4.2700000  3.6000000
`;
  await open('POSCAR', wet);
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 6, null, { timeout: 30000 });
  if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
  await page.waitForSelector('#btnMinPeriodic', { state: 'visible', timeout: 15000 });
  check('MIN PERIODIC appears with the other cell tools, and only when there is a cell',
    await page.isVisible('#btnMinPeriodic'));

  const set = await page.evaluate(() => {
    const D = window.dworm2d, s = D.pseudoPeriodicSet();
    return { n0: s.n0, shell: s.shell, contact: s.contact, capped: s.capped,
             total: s.atoms.length, bonds: s.bonds.length, err: s.error || null,
             /* is every cell atom still at the front, with its own index? */
             head: s.atoms.slice(0, s.n0).map(a => a.elem).join('') };
  });
  check('the surroundings are built as real atoms, with the cell still at the front of them',
    set.err === null && set.n0 === 6 && set.head === 'OOHHHH' && set.total === set.n0 + set.shell,
    `${set.n0} in the cell + ${set.shell} frozen neighbours`);
  /* THE SEED IS NOT ONLY BONDS. A molecule can sit against the wall without being bonded
     through it; a shell grown along bonds alone leaves it out, and the cell then relaxes
     into a space that is not empty. */
  check('and the seed includes image atoms touching a face without a bond through it',
    set.contact > 0, set.contact + ' by contact rather than by bond');
  check('the shell is bonded together, so the frozen atoms are a molecule and not a cloud',
    set.bonds >= 4, set.bonds + ' bonds over the whole set');

  /* FOUR BONDS DEEP, not two. A hydrogen bond, a torsion and the atom at the far end of it
     are already three, and a shell that stops short lets the surface relax against a stump. */
  const depths = await page.evaluate(() => {
    const D = window.dworm2d;
    return [1, 2, 4].map(d => D.pseudoPeriodicSet(d, 0).atoms.length);
  });
  check('the shell reaches four bonds out, and further than a shallower one would',
    depths[2] >= depths[1] && depths[1] >= depths[0] && depths[2] > depths[0],
    depths.join(' → ') + ' atoms at 1, 2 and 4 bonds (no border seeding)');
  check('and PP_DEPTH is four, as asked',
    await page.evaluate(() => window.dworm2d.PP_DEPTH) === 4);

  /* The distance criterion measures to the FACE, along the face's own normal — which is
     what a lattice plane spacing is, so it is right for a triclinic cell too. */
  const dist = await page.evaluate(() => {
    const D = window.dworm2d, c = D.state3d.cell;
    const M = [[1 / 7, 0, 0], [0, 1 / 7, 0], [0, 0, 1 / 7]];
    return { inside: D.outsideBy([3.5, 3.5, 3.5], M), just: D.outsideBy([-1.5, 3.5, 3.5], M),
             far: D.outsideBy([-9, 3.5, 3.5], M), a: c.a[0] };
  });
  check('how far outside the cell a point lies is measured in angstrom, not in fractions',
    dist.inside === 0 && Math.abs(dist.just - 1.5) < 1e-9 && Math.abs(dist.far - 9) < 1e-9,
    `inside 0, 1.5 A out → ${dist.just.toFixed(2)}, 9 A out → ${dist.far.toFixed(2)}`);

  const before = await page.evaluate(() =>
    window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
  await page.click('#btnMinPeriodic');
  await page.waitForFunction(() => /relaxed inside|could not|Stopped/i.test(document.getElementById('status3d').textContent),
    null, { timeout: 180000 });
  await page.waitForTimeout(500);
  const done = await page.evaluate(() => ({
    msg: document.getElementById('status3d').textContent,
    n: window.dworm2d.state3d.nAtoms,
    cell: !!window.dworm2d.state3d.cell,
    periodic: window.dworm2d.state3d.periodic,
    pos: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]),
  }));
  /* The shell was scaffolding. Only the cell's own atoms come home, and the cell comes with
     them — a minimisation that quietly dropped the lattice would turn a crystal into a
     molecule without saying so. */
  check('only the cell’s own atoms come back, and the cell comes back with them',
    done.n === 6 && done.cell === true && !!done.periodic, `${done.n} atoms, cell ${done.cell}`);
  check('and the structure actually moved',
    done.pos.some((p, i) => Math.hypot(p[0] - before[i][0], p[1] - before[i][1], p[2] - before[i][2]) > 1e-4),
    'largest shift ' + Math.max(...done.pos.map((p, i) =>
      Math.hypot(p[0] - before[i][0], p[1] - before[i][1], p[2] - before[i][2]))).toFixed(3) + ' A');
  check('the status line says how many were free, how many were frozen, and what UFF did',
    /\d+ atoms relaxed inside \d+ frozen neighbours/.test(done.msg) && /UFF/.test(done.msg),
    done.msg.slice(0, 120));

  /* A SELECTION NARROWS IT. Relaxing a defect, an adsorbate or hydrogens somebody has just
     added, with the rest of the cell held exactly where the diffraction put it. */
  const narrowed = await page.evaluate(async () => {
    const D = window.dworm2d;
    D.state3d.sel = [2, 3];
    const s = D.pseudoPeriodicSet();
    const sel = (D.state3d.sel || []).filter(i => i >= 0 && i < s.n0);
    return { sel: sel.length, n0: s.n0 };
  });
  check('picking atoms first relaxes those and holds the rest of the cell where it is',
    narrowed.sel === 2 && narrowed.n0 === 6, narrowed.sel + ' of ' + narrowed.n0 + ' free');
  await page.evaluate(() => { window.dworm2d.state3d.sel = []; });
  await page.click('#btnEdit');
}

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
