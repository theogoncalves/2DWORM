/* Regenerate QRsharing/lib/coastlines.php from Natural Earth.
 *
 *   npm pack world-atlas@2 && tar xzf world-atlas-*.tgz
 *   node make-coastlines.mjs package/land-110m.json
 *
 * Natural Earth 1:110m land is PUBLIC DOMAIN — no attribution required and no licence to
 * inherit. That is why it is this dataset and not one of the prettier ones. world-atlas is a
 * redistribution of it as TopoJSON (ISC, Michael Bostock); this script decodes that here so
 * the admin page needs no TopoJSON reader of its own.
 *
 * What is thrown away, and why:
 *   · holes — in the land layer they are lakes, and a lake is not worth 30 kB on a page one
 *     person looks at;
 *   · rings under 2 square degrees — invisible at the size this is drawn;
 *   · vertices closer than half a degree to the one before, which is under two pixels wide.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const src = process.argv[2];
if (!src) { console.error('usage: node make-coastlines.mjs <land-110m.json>'); process.exit(2); }
const OUT = fileURLToPath(new URL('../2dworm/QRsharing/lib/coastlines.php', import.meta.url));

const t = JSON.parse(readFileSync(src, 'utf8'));
const { scale: [sx, sy], translate: [tx, ty] } = t.transform;
/* TopoJSON arcs are delta-encoded integers over a shared quantisation grid */
const arcs = t.arcs.map(a => { let x = 0, y = 0; return a.map(([dx, dy]) => { x += dx; y += dy; return [x * sx + tx, y * sy + ty]; }); });
const ring = (idxs) => {
  const out = [];
  for (const i of idxs) {
    const rev = i < 0, a = arcs[rev ? ~i : i];
    const pts = rev ? a.slice().reverse() : a;
    for (let k = (out.length ? 1 : 0); k < pts.length; k++) out.push(pts[k]);
  }
  return out;
};
const polys = [];
for (const g of t.objects.land.geometries) {
  for (const p of (g.type === 'Polygon' ? [g.arcs] : g.arcs)) polys.push(ring(p[0]));
}
const area = (p) => { let s = 0; for (let i = 0, j = p.length - 1; i < p.length; j = i++) s += p[j][0] * p[i][1] - p[i][0] * p[j][1]; return Math.abs(s / 2); };
/* Radial thinning rather than Douglas–Peucker: a CLOSED ring starts and ends at the same
   point, so Douglas–Peucker's base line is degenerate and it collapses the whole ring to two
   points — which it duly did, the first time this was written. */
const thin = (p, d) => {
  const out = [p[0]];
  for (let i = 1; i < p.length - 1; i++) {
    const q = out[out.length - 1];
    if (Math.hypot(p[i][0] - q[0], p[i][1] - q[1]) >= d) out.push(p[i]);
  }
  out.push(p[p.length - 1]);
  return out;
};
/* CUT AT THE ANTIMERIDIAN. A landmass that crosses 180° arrives as one ring whose longitude
   jumps from +179 to -179, and an equirectangular projection draws that jump as a straight
   line clean across the map — which is what put a bar through the Arctic the first time this
   was drawn. Split the ring there, walk each part out to the edge at the latitude it crossed
   at, and close it along that edge. Runs left with fewer than four points are the slivers the
   source leaves behind at the seam, and are dropped. */
function cutAtSeam(p) {
  const runs = [];
  let cur = [p[0]];
  for (let i = 1; i < p.length; i++) {
    const [x0, y0] = p[i - 1], [x1, y1] = p[i];
    if (Math.abs(x1 - x0) > 180) {
      // interpolate the latitude where the path meets the edge
      const east = x0 > 0;                       // leaving through +180?
      const dx = (east ? 180 - x0 : -180 - x0);
      const wrap = (east ? x1 + 360 : x1 - 360) - x0;
      const yEdge = y0 + (y1 - y0) * (dx / (wrap || 1));
      cur.push([east ? 180 : -180, yEdge]);
      runs.push(cur);
      cur = [[east ? -180 : 180, yEdge], [x1, y1]];
    } else {
      cur.push([x1, y1]);
    }
  }
  runs.push(cur);
  return runs.filter(r => r.length >= 4);
}
const sel = polys.filter(p => area(p) >= 2).map(p => thin(p, 0.5)).filter(p => p.length >= 4)
  .flatMap(cutAtSeam)
  .map(p => p.map(([a, b]) => [Math.round(a * 10) / 10, Math.round(b * 10) / 10]))
  .sort((a, b) => area(b) - area(a));

const body = sel.map(p => "    '" + p.map(([a, b]) => a + ',' + b).join(' ') + "',").join('\n');
writeFileSync(OUT, `<?php
/* Coastlines for the administrator's map.
 *
 * Natural Earth 1:110m land, version 4.1.0, PUBLIC DOMAIN — no attribution required and no
 * licence to inherit, which is why it is this dataset and not one of the others. Taken from
 * the world-atlas TopoJSON redistribution (ISC), decoded to plain longitude/latitude here so
 * that the page needs no TopoJSON reader at all.
 *
 * Outer rings only — the holes in Natural Earth's land layer are lakes, and a lake is not
 * worth 30 kB on a page one person looks at. Rings smaller than 2 square degrees are dropped
 * and the rest thinned to half a degree, which is under two pixels at the size this is drawn.
 *
 * Each ring is 'lon,lat lon,lat …'. Regenerate with 2dworm-test/make-coastlines.mjs.
 */
const DW_COAST = [
${body}
];
`);
console.log(`${sel.length} rings, ${sel.reduce((a, p) => a + p.length, 0)} points -> ${OUT}`);
