/* Geometry readers for computational-chemistry files.
   Every fixture below is a real excerpt shape. The point of most checks is UNITS and
   ELEMENTS: a bohr file read as angstrom gives a molecule half its size and looks
   entirely plausible, and a Gaussian output gives atomic numbers rather than symbols. */
import { parseGeometry, sniff, toXYZText, BOHR, WRITERS, cellParams } from '../2dworm/lib/qcgeom.js';
import { readFileSync, openSync, readSync, closeSync, statSync } from 'node:fs';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const near = (a, b, t = 1e-4) => Math.abs(a - b) <= t;
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);

/* ------------------------------------------------------------------ fixtures */
// water, O–H ~0.96 A, in every format. Two optimisation steps where the format has them,
// so "take the LAST geometry" is actually tested rather than assumed.
const ORCA = `
                                 * O   R   C   A *
           Program Version 5.0.4 -  RELEASE  -

---------------------------------
CARTESIAN COORDINATES (ANGSTROEM)
---------------------------------
  O      9.000000    0.000000    0.000000
  H      9.900000    0.000000    0.000000
  H      8.760000    0.930000    0.000000

----------------------------
CARTESIAN COORDINATES (A.U.)
----------------------------
  NO LB      ZA    FRAG     MASS         X           Y           Z
   0 O     8.0000    0    15.999   17.007535    0.000000    0.000000

---------------------------------
CARTESIAN COORDINATES (ANGSTROEM)
---------------------------------
  O      0.000000    0.000000    0.000000
  H      0.958000    0.000000    0.000000
  H     -0.240000    0.927000    0.000000

----------------------------
CARTESIAN COORDINATES (A.U.)
----------------------------
   0 O     8.0000    0    15.999    0.000000    0.000000    0.000000
`;

const GAUSSIAN = ` Entering Gaussian System, Link 0=g16
 Gaussian 16:  ES64L-G16RevC.01

                          Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        5.000000    0.000000    0.000000
      2          1           0        5.900000    0.000000    0.000000
      3          1           0        4.760000    0.930000    0.000000
 ---------------------------------------------------------------------

                          Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        0.000000    0.000000    0.000000
      2          1           0        0.958000    0.000000    0.000000
      3          1           0       -0.240000    0.927000    0.000000
 ---------------------------------------------------------------------
 Normal termination of Gaussian 16.
`;

const GAUSSIAN_GHOST = ` Entering Gaussian System, Link 0=g16
                          Input orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        0.000000    0.000000    0.000000
      2          1           0        0.958000    0.000000    0.000000
      3          1           0       -0.240000    0.927000    0.000000
      4          0           0        3.000000    3.000000    3.000000
 ---------------------------------------------------------------------
`;

const CP2K = ` DBCSR| Multiplication driver
 CP2K| version string:                            CP2K version 2023.1
 PROGRAM STARTED AT              2026-09-09 06:00:00.000

 MODULE QUICKSTEP:  ATOMIC COORDINATES IN angstrom

  Atom  Kind  Element       X           Y           Z          Z(eff)       Mass

       1     1      O    8    0.000000    0.000000    0.000000      6.0000   15.9994
       2     2      H    1    0.958000    0.000000    0.000000      1.0000    1.0079
       3     2      H    1   -0.240000    0.927000    0.000000      1.0000    1.0079
`;

const MOPAC_OUT = `                        MOPAC v22.0.6 for Windows
                     PM7 CALCULATION RESULTS

          CARTESIAN COORDINATES

   NO.       ATOM         X         Y         Z

    1         O        0.0000    0.0000    0.0000
    2         H        0.9580    0.0000    0.0000
    3         H       -0.2400    0.9270    0.0000
`;

const MOPAC_ARC = `          FINAL GEOMETRY OBTAINED                                    CHARGE
PM7 EF PRECISE
 water

  O     0.00000000 +1   0.00000000 +1   0.00000000 +1
  H     0.95800000 +1   0.00000000 +1   0.00000000 +1
  H    -0.24000000 +1   0.92700000 +1   0.00000000 +1
`;

// xtb writes its final structure in Turbomole coord format, IN BOHR
const XTB = `      -----------------------------------------------------------
     |                   =====================                   |
     |                           x T B                           |
      -----------------------------------------------------------
   * xtb version 6.6.1 (8d0f1dd) compiled by 'ci@ci'

 final structure:
================
$coord
        0.00000000000000        0.00000000000000        0.00000000000000      o
        1.81032183167855        0.00000000000000        0.00000000000000      h
       -0.45354338293264        1.75182258959268        0.00000000000000      h
$end
`;

const VASP = ` vasp.6.3.2 complex
 POTCAR:    PAW_PBE O 08Apr2002
 POTCAR:    PAW_PBE H 15Jun2001
 POTCAR:    PAW_PBE O 08Apr2002
 POTCAR:    PAW_PBE H 15Jun2001

   ions per type =               1   2

 POSITION                                       TOTAL-FORCE (eV/Angst)
 -----------------------------------------------------------------------------------
      5.00000      0.00000      0.00000         0.100000      0.000000      0.000000
      5.95800      0.00000      0.00000         0.000000      0.000000      0.000000
      4.76000      0.93000      0.00000         0.000000      0.000000      0.000000
 -----------------------------------------------------------------------------------

 POSITION                                       TOTAL-FORCE (eV/Angst)
 -----------------------------------------------------------------------------------
      0.00000      0.00000      0.00000         0.000000      0.000000      0.000000
      0.95800      0.00000      0.00000         0.000000      0.000000      0.000000
     -0.24000      0.93000      0.00000         0.000000      0.000000      0.000000
 -----------------------------------------------------------------------------------
`;

const ORCA_IN = `! B3LYP def2-SVP Opt
%pal nprocs 8 end

* xyz 0 1
O   0.000000   0.000000   0.000000
H   0.958000   0.000000   0.000000
H  -0.240000   0.927000   0.000000
*
`;

const GAUSSIAN_IN = `%nprocshared=8
%mem=8GB
#p B3LYP/6-31G(d) Opt

water optimisation

0 1
O   0.000000   0.000000   0.000000
H   0.958000   0.000000   0.000000
H  -0.240000   0.927000   0.000000

`;

const CP2K_IN = `&FORCE_EVAL
  &SUBSYS
    &COORD
      O   0.000000   0.000000   0.000000
      H   0.958000   0.000000   0.000000
      H  -0.240000   0.927000   0.000000
    &END COORD
  &END SUBSYS
&END FORCE_EVAL
`;

const CP2K_IN_BOHR = `&FORCE_EVAL
  &SUBSYS
    &COORD
      UNIT bohr
      O   0.000000   0.000000   0.000000
      H   1.810322   0.000000   0.000000
      H  -0.453543   1.751823   0.000000
    &END COORD
  &END SUBSYS
&END FORCE_EVAL
`;

/* --------------------------------------------------------------------- tests */
const cases = [
  ['ORCA output',      ORCA,          'orca-out',        'ORCA'],
  ['Gaussian output',  GAUSSIAN,      'gaussian-out',    'Gaussian'],
  ['CP2K output',      CP2K,          'cp2k-out',        'CP2K'],
  ['MOPAC output',     MOPAC_OUT,     'mopac',           'MOPAC'],
  ['MOPAC .arc',       MOPAC_ARC,     'mopac',           'MOPAC'],
  ['xTB output',       XTB,           'xtb-out',         'xTB'],
  ['VASP OUTCAR',      VASP,          'vasp-outcar',     'VASP'],
  ['ORCA input',       ORCA_IN,       'orca-in',         'ORCA input'],
  ['Gaussian input',   GAUSSIAN_IN,   'gaussian-in',     'Gaussian input'],
  ['CP2K input',       CP2K_IN,       'cp2k-in',         'CP2K input'],
];
for (const [name, text, kind, program] of cases) {
  check(`${name}: recognised from its content`, sniff(text) === kind, String(sniff(text)));
  check(`${name}: classified without a tie`, !sniff.lastTie, JSON.stringify(sniff.lastTie) + ' ' + JSON.stringify(sniff.lastScores));
  let r;
  try { r = parseGeometry(text); } catch (e) { check(`${name}: parses`, false, e.message); continue; }
  check(`${name}: three atoms, O H H`, r.atoms.length === 3 && r.atoms.map(a => a.elem).join('') === 'OHH',
    r.atoms.map(a => a.elem).join(''));
  const oh1 = dist(r.atoms[0], r.atoms[1]), oh2 = dist(r.atoms[0], r.atoms[2]);
  check(`${name}: O–H comes out at 0.958 A`, near(oh1, 0.958, 0.002) && near(oh2, 0.958, 0.01),
    `${oh1.toFixed(4)} and ${oh2.toFixed(4)} A`);
  check(`${name}: says which program`, r.program === program, r.program);
}

/* the point of "last geometry": every output above has a decoy first step at x = 5 or 9 */
for (const [name, text] of [['ORCA', ORCA], ['Gaussian', GAUSSIAN], ['VASP', VASP]]) {
  const r = parseGeometry(text);
  check(`${name}: takes the LAST geometry, not the first`, Math.abs(r.atoms[0].x) < 1e-6,
    `first atom at x = ${r.atoms[0].x}`);
}

/* units */
{
  const r = parseGeometry(XTB);
  check('xTB: the bohr coordinates are converted, not taken as angstrom',
    near(dist(r.atoms[0], r.atoms[1]), 0.958, 0.002),
    `${dist(r.atoms[0], r.atoms[1]).toFixed(4)} A — 1.81 bohr x ${BOHR.toFixed(6)}`);
  const raw = parseGeometry(CP2K_IN_BOHR);
  check('CP2K input: UNIT bohr is honoured', near(dist(raw.atoms[0], raw.atoms[1]), 0.958, 0.002),
    `${dist(raw.atoms[0], raw.atoms[1]).toFixed(4)} A`);
  check('and it says so', /bohr/.test(raw.note), raw.note);
}
/* the ORCA A.U. block must never be the one that gets read */
{
  const r = parseGeometry(ORCA);
  check('ORCA: the (A.U.) block in bohr is ignored', near(dist(r.atoms[0], r.atoms[1]), 0.958, 0.002),
    `${dist(r.atoms[0], r.atoms[1]).toFixed(4)} A`);
}

/* elements */
{
  const r = parseGeometry(GAUSSIAN);
  check('Gaussian: atomic numbers become symbols', r.atoms.map(a => a.elem).join(',') === 'O,H,H',
    r.atoms.map(a => a.elem).join(','));
  const g = parseGeometry(GAUSSIAN_GHOST);
  check('Gaussian: a ghost centre (atomic number 0) is skipped', g.atoms.length === 3, 'atoms ' + g.atoms.length);
  const v = parseGeometry(VASP);
  check('VASP: elements come from POTCAR plus "ions per type"',
    v.atoms.map(a => a.elem).join(',') === 'O,H,H', v.atoms.map(a => a.elem).join(','));
  const noSpecies = VASP.replace(/POTCAR:.*\n/g, '').replace(/ions per type.*\n/, '');
  const n = parseGeometry(noSpecies);
  check('VASP: says so plainly when the elements are not in the file',
    /element symbols were not found/.test(n.note), n.note);
}
/* CP2K writes its optimised structure elsewhere: do not pretend otherwise */
{
  const opt = CP2K + '\n GEOMETRY OPTIMIZATION COMPLETED\n';
  const r = parseGeometry(opt);
  check('CP2K: an optimisation run says where the optimised geometry really is',
    /-pos-1\.xyz|restart/.test(r.note), r.note);
}
/* failure modes must explain themselves */
{
  const bad = [
    ['a text file that is not a chemistry file', 'hello world\nthis is not a calculation\n', /not one 2D-WORM recognises/],
    ['an ORCA input pointing at an external xyz', '! Opt\n* xyzfile 0 1 water.xyz\n', /separate \.xyz file/],
    ['a Gaussian input holding a Z-matrix', '#p opt\n\ntitle\n\n0 1\nO\nH 1 0.96\nH 1 0.96 2 104.5\n\n', /Z-matrix|could not be read/],
  ];
  for (const [name, text, re] of bad) {
    let msg = '';
    try { parseGeometry(text); } catch (e) { msg = e.message; }
    check(`refusing ${name} explains why`, re.test(msg), msg || 'no error thrown');
  }
  /* a file that merely MENTIONS a program is not that program's output, and the message
     must not pretend it is: "no coordinate block in this ORCA output" would send somebody
     looking for a bug in ORCA */
  let msg = '';
  try { parseGeometry('Notes on running ORCA and Gaussian on the cluster.\nSee the wiki.\n'); } catch (e) { msg = e.message; }
  check('a text that only mentions a program is refused as a mention, not as a broken output',
    /mention/i.test(msg) && !/^no /.test(msg), msg || 'no error thrown');
}
/* the xyz handed to the viewer */
{
  const r = parseGeometry(ORCA);
  const xyz = toXYZText(r.atoms, 'test');
  const lines = xyz.trim().split('\n');
  check('the geometry becomes a valid .xyz for the viewer',
    parseInt(lines[0], 10) === 3 && lines.length === 5 && /^O\s+0\.000000/.test(lines[2]), lines[2]);
}


/* ============================ the three files that are read for their geometry ONLY
   A cube carries a volume, an fchk and a wfn carry a wavefunction. None of that is read
   here — turning a wavefunction into something to look at is a calculation, and belongs in
   D-WORM. All three do name their nuclei near the top, and that is what is taken. Units are
   again the whole game: all three are in bohr unless a cube says otherwise, and the sign of
   a cube's voxel count is what says otherwise. */
{
  const cube = `water density
generated for a test
    3    0.000000    0.000000    0.000000
    2    0.200000    0.000000    0.000000
    2    0.000000    0.200000    0.000000
    2    0.000000    0.000000    0.200000
    8    8.000000    0.000000    0.000000    0.000000
    1    1.000000    1.809000    0.000000    0.000000
    1    1.000000   -0.453000    1.751000    0.000000
 1.0E-03 1.0E-03 1.0E-03 1.0E-03
`;
  check('a cube is recognised by its shape, not by its name', sniff(cube) === 'cube', String(sniff(cube)));
  const c = parseGeometry(cube);
  check('it gives the three atoms in the header', c.atoms.length === 3 && c.atoms.map(a => a.elem).join('') === 'OHH',
    JSON.stringify(c.atoms.map(a => a.elem)));
  check('a positive voxel count means bohr, and is converted', near(dist(c.atoms[0], c.atoms[1]), 0.957, 0.01),
    dist(c.atoms[0], c.atoms[1]).toFixed(3) + ' A');
  check('and it says the volume itself was not read', /geometry only/.test(c.note), c.note);

  const cubeA = cube.replace('    2    0.200000    0.000000    0.000000', '   -2    0.200000    0.000000    0.000000')
                    .replace('    1    1.000000    1.809000', '    1    1.000000    0.957000');
  check('a NEGATIVE voxel count means angstrom, and is not converted a second time',
    near(dist(parseGeometry(cubeA).atoms[0], parseGeometry(cubeA).atoms[1]), 0.957, 0.001),
    dist(parseGeometry(cubeA).atoms[0], parseGeometry(cubeA).atoms[1]).toFixed(3) + ' A');
}
{
  const fchk = `water test
SP        RB3LYP                                                      6-31G(d)
Number of atoms                            I                3
Charge                                     I                0
Atomic numbers                             I   N=           3
           8           1           1
Current cartesian coordinates              R   N=           9
  0.00000000E+00  0.00000000E+00  0.00000000E+00  1.80900000E+00  0.00000000E+00
  0.00000000E+00 -4.53000000E-01  1.75100000E+00  0.00000000E+00
Force Field                                I                0
`;
  check('an fchk is recognised', sniff(fchk) === 'fchk', String(sniff(fchk)));
  const f = parseGeometry(fchk);
  check('its atomic numbers become elements', f.atoms.map(a => a.elem).join('') === 'OHH',
    JSON.stringify(f.atoms.map(a => a.elem)));
  check('an fchk is always in bohr, whatever the input was written in',
    near(dist(f.atoms[0], f.atoms[1]), 0.957, 0.01), dist(f.atoms[0], f.atoms[1]).toFixed(3) + ' A');
  check('a coordinate block that runs over several lines is read to the end',
    f.atoms.length === 3 && near(f.atoms[2].y, 1.751 * BOHR, 1e-3), JSON.stringify(f.atoms[2]));
}
{
  const wfn = `water
GAUSSIAN            5 MOL ORBITALS     30 PRIMITIVES        3 NUCLEI
  O    1    (CENTRE  1)   0.00000000  0.00000000  0.00000000  CHARGE =  8.0
  H    2    (CENTRE  2)   1.80900000  0.00000000  0.00000000  CHARGE =  1.0
  H    3    (CENTRE  3)  -0.45300000  1.75100000  0.00000000  CHARGE =  1.0
CENTRE ASSIGNMENTS
`;
  check('a .wfn is recognised', sniff(wfn) === 'wfn', String(sniff(wfn)));
  const w = parseGeometry(wfn);
  check('its nuclei are read, in bohr', w.atoms.length === 3 && near(dist(w.atoms[0], w.atoms[1]), 0.957, 0.01),
    dist(w.atoms[0], w.atoms[1]).toFixed(3) + ' A');
  /* A centre whose LABEL is not an element at all — a ghost, a dummy, a bond critical point —
     falls back to the charge, and X1 is then still an oxygen. */
  check('a centre named anything is still typed from its charge',
    parseGeometry(wfn.replace('  O    1    (CENTRE  1)', '  XX   1    (CENTRE  1)')).atoms[0].elem === 'O');
  check('an all-electron file says nothing about core potentials',
    !/core potential/.test(w.note), w.note);
}
{
  /* THE ECP TRAP, and it shipped for several builds. Under an effective core potential the
     CHARGE column is the number of electrons the basis set treats, NOT the atomic number.
     Chlorine writes 7.0 and element 7 is nitrogen, so Pt(NH3)2Cl2 arrived with two nitrogens
     where its chlorines belong — which is what was reported — and platinum, on a 60-electron
     ECP, wrote 18.0 and arrived as argon, which was not reported because nobody was looking
     at the metal. The label is right in every one of these cases. */
  const ecp = `Pt(NH3)2Cl2
GAUSSIAN              5 MOL ORBITALS    116 PRIMITIVES        5 NUCLEI
  Pt   1    (CENTRE  1)   0.00000000  0.00000000  0.00000000  CHARGE = 18.0
  Cl   2    (CENTRE  2)   4.40000000  0.00000000  0.00000000  CHARGE =  7.0
  Cl   3    (CENTRE  3)  -4.40000000  0.00000000  0.00000000  CHARGE =  7.0
  N    4    (CENTRE  4)   0.00000000  3.90000000  0.00000000  CHARGE =  7.0
  N    5    (CENTRE  5)   0.00000000 -3.90000000  0.00000000  CHARGE =  7.0
CENTRE ASSIGNMENTS
`;
  const e = parseGeometry(ecp);
  check('a wavefunction with core potentials keeps its real elements, not the ones its charges name',
    e.atoms.map(a => a.elem).join(' ') === 'Pt Cl Cl N N', e.atoms.map(a => a.elem).join(' '));
  check('and the note says why the charges in that file are not atomic numbers',
    /3 of 5 atoms carry an effective core potential/.test(e.note), e.note.slice(-80));
}
{
  /* none of the three describes a repeating cell, so MINIMIZE must not be blocked on them —
     the periodic guard exists for VASP and CP2K, and it should not catch a cube by accident */
  const cube = `x\ny\n    1    0.0    0.0    0.0\n    2    0.2    0.0    0.0\n    2    0.0    0.2    0.0\n    2    0.0    0.0    0.2\n    6    6.0    0.0    0.0    0.0\n`;
  check('a cube is not treated as a crystal', !parseGeometry(cube).periodic);
}

/* ============================== FOUR MORE READERS, and one trap they share

   Every wavefunction format gives a label AND a nuclear charge, and they can disagree in two
   opposite ways. An effective core potential makes the CHARGE wrong — chlorine writes 7 and
   reads as nitrogen, which is the bug Dante found in a .wfn. A shouting output makes the
   LABEL wrong — GAMESS capitalises everything, so a carbon labelled CO reads as cobalt.
   Neither can be preferred outright; the resolution is that when either reading of the label
   agrees with the charge, the agreement settles it, and only when nothing agrees does the
   label win. Both traps are checked below with the file that springs them. */
{
  const gamess = `          ******************************************************
          *         GAMESS VERSION = 30 JUN 2020 (R1)          *
          ******************************************************

 COORDINATES OF ALL ATOMS ARE (ANGS)
   ATOM   CHARGE       X              Y              Z
 ------------------------------------------------------------
 CO          6.0   0.0000000000   0.0000000000   0.0000000000
 O           8.0   1.1280000000   0.0000000000   0.0000000000

 NSERCH:   1
 COORDINATES OF ALL ATOMS ARE (ANGS)
   ATOM   CHARGE       X              Y              Z
 ------------------------------------------------------------
 CO          6.0   0.0000000000   0.0000000000   0.0000000000
 O           8.0   1.1350000000   0.0000000000   0.0000000000

          TOTAL MULLIKEN AND LOWDIN ATOMIC POPULATIONS
       ATOM         MULL.POP.    CHARGE          LOW.POP.     CHARGE
    1 C             5.900000   0.100000         5.950000   0.050000
    2 O             8.100000  -0.100000         8.050000  -0.050000

`;
  check('a GAMESS-US output is recognised', sniff(gamess) === 'gamess', String(sniff(gamess)));
  const g = parseGeometry(gamess);
  check('and it takes the LAST geometry, not the first', Math.abs(g.atoms[1].x - 1.135) < 1e-9,
    g.atoms[1].x.toFixed(4) + ' A');
  /* CO with a charge of 6 is a carbon somebody labelled CO, not cobalt — and the charge is
     what says so. Reading the label alone gets this wrong; so does reading it first. */
  check('a carbon labelled CO in a shouting output is carbon, because the charge says 6',
    g.atoms.map(a => a.elem).join('') === 'CO', g.atoms.map(a => a.elem).join(''));
  check('and both population analyses come with it',
    g.charges && g.charges.Mulliken && g.charges.Mulliken[0] === 0.1 && g.charges['Löwdin'][1] === -0.05,
    Object.keys(g.charges || {}).join(', '));
  /* the same label with cobalt's own charge is cobalt: the rule is the agreement, not the
     length of the symbol */
  const co = parseGeometry(gamess.replace(/ CO          6\.0/g, ' CO         27.0'));
  check('while CO with a charge of 27 is cobalt', co.atoms[0].elem === 'Co', co.atoms[0].elem);

  const dat = ` $CONTRL SCFTYP=RHF RUNTYP=ENERGY $END
 $DATA
carbon monoxide
C1
 C      6.0    0.0000000    0.0000000    0.0000000
 O      8.0    1.1280000    0.0000000    0.0000000
 $END
`;
  check('a GAMESS input is read from its $DATA group',
    sniff(dat) === 'gamess' && parseGeometry(dat).atoms.length === 2,
    parseGeometry(dat).note);

  /* ---------------------------------------------------------------- Molden
     The units are on the section header — [Atoms] AU or [Atoms] Angs — which is unusually
     civilised of the format and is why this needs no guessing at all. */
  const mAng = `[Molden Format]
[Atoms] Angs
 C     1    6    0.000000    0.000000    0.000000
 Cl    2   17    1.760000    0.000000    0.000000
[GTO]
`;
  check('a Molden file is recognised', sniff(mAng) === 'molden', String(sniff(mAng)));
  check('and its angstrom coordinates are taken as angstrom',
    Math.abs(parseGeometry(mAng).atoms[1].x - 1.76) < 1e-9);
  const mAu = mAng.replace('[Atoms] Angs', '[Atoms] AU').replace('1.760000', '1.810000');
  check('while AU on the same header means bohr, and is converted',
    Math.abs(parseGeometry(mAu).atoms[1].x - 1.81 * 0.529177210903) < 1e-9,
    parseGeometry(mAu).atoms[1].x.toFixed(4) + ' A');
  check('a Molden file with only [FR-COORD] is read too — those are always bohr',
    Math.abs(parseGeometry(`[Molden Format]\n[FREQ]\n 1000.0\n[FR-COORD]\n O 0.0 0.0 0.0\n H 1.81 0.0 0.0\n`)
      .atoms[1].x - 1.81 * 0.529177210903) < 1e-9);

  /* ---------------------------------------------------------------- Multiwfn .mwfn
     $Centers gives the symbol, the true Z, and the EFFECTIVE charge an ECP has reduced. */
  const mwfn = `# Generated by Multiwfn
Wfntype= 0
Ncenter= 2
$Centers
1 Cl  17  7.0   0.000000  0.000000  0.000000
2 H    1  1.0   2.410000  0.000000  0.000000
$End
`;
  check('a .mwfn is recognised', sniff(mwfn) === 'mwfn', String(sniff(mwfn)));
  const mw = parseGeometry(mwfn);
  check('and an ECP does not turn its chlorine into nitrogen',
    mw.atoms[0].elem === 'Cl' && mw.atoms.length === 2, mw.atoms.map(a => a.elem).join(''));
  check('and it says how many atoms carried one', /effective core potential/.test(mw.note), mw.note.slice(-80));

  /* ---------------------------------------------------------------- NBO .47
     Atomic number, MASS number, then x y z — in bohr, which the format never says. */
  const nbo = ` $GENNBO NATOMS=2 NBAS=10 $END
 $NBO $END
 $COORD
 water, sort of
    8    16    0.000000    0.000000    0.000000
    1     1    1.810000    0.000000    0.000000
 $END
`;
  check('an NBO .47 archive is recognised', sniff(nbo) === 'nbo47', String(sniff(nbo)));
  const nb = parseGeometry(nbo);
  check('its free-text title line is stepped over rather than counted',
    nb.atoms.length === 2 && nb.atoms[0].elem === 'O' && nb.atoms[1].elem === 'H',
    nb.atoms.map(a => a.elem).join(''));
  /* The second column is a MASS number, not a charge. Reading it as one would make this
     oxygen sulphur — and nothing in the file says which it is. */
  check('and the second column is a mass number, not a charge — 16 is oxygen-16, not sulphur',
    Math.abs(nb.atoms[1].x - 1.81 * 0.529177210903) < 1e-9, nb.atoms[1].x.toFixed(4) + ' A');
}

/* ============================== TWO BUGS THE REAL CUBES SPRANG, both from the order of tests

   (a) A cube's third line is "natoms x0 y0 z0" and MAY carry a fifth field, NVAL — the number
       of values per grid point, written by Gaussian's cubegen and by Multiwfn. The header
       check insisted on exactly three numbers after the count, so every one of Dante's
       Jumanah-*.cube files (line 3: "  -38  -14.539081  -14.529676   -6.512966    1") was
       rejected outright. The same file has a NEGATIVE atom count, which is a molecular-orbital
       cube and is legal.
   (b) A cube written by ORCA says so in its title line, and the ORCA banner test ran first,
       so a 7 MB electron density came back as an ORCA output with no coordinates in it. A cube
       is a cube whatever its title says: the structure of the header is the evidence, and a
       word in a free-text line is not. */
{
  const nval = `Cube title mentioning nothing
MO coefficients
  -3  -14.539081  -14.529676   -6.512966    1
   2    0.166667    0.000000    0.000000
   2    0.000000    0.166667    0.000000
   2    0.000000    0.000000    0.166667
   8    8.000000    0.000000    0.000000    0.000000
   1    1.000000    1.809000    0.000000    0.000000
   1    1.000000   -0.453000    1.751000    0.000000
    1   81
 -4.60530E-19 -6.44229E-19 -8.92182E-19 -1.22315E-18 -1.65997E-18 -2.22997E-18
`;
  check('cube: line 3 may carry the optional NVAL field (bug a)', sniff(nval) === 'cube', String(sniff(nval)));
  let r = null;
  try { r = parseGeometry(nval); } catch (e) { /* reported below */ }
  check('cube: a negative atom count (an MO cube) still yields its atoms',
    r && r.atoms.length === 3 && r.atoms.map(a => a.elem).join('') === 'OHH', r ? r.atoms.length + ' atoms' : 'threw');
  const orcaCube = `Cube data generated by ORCA
Total electron density
   3  -16.729678  -13.219684  -13.273337
   2    0.423536    0.000000    0.000000
   2    0.000000    0.383494    0.000000
   2    0.000000    0.000000    0.340743
   8    8.000000    0.000000    0.000000    0.000000
   1    1.000000    1.809000    0.000000    0.000000
   1    1.000000   -0.453000    1.751000    0.000000
 1.0E-03 1.0E-03 1.0E-03 1.0E-03 1.0E-03 1.0E-03
`;
  check('cube: a cube whose title says ORCA is still a cube (bug b)', sniff(orcaCube) === 'cube', String(sniff(orcaCube)));
  check('cube: and no tie was needed to decide it', sniff(orcaCube) === 'cube' && !sniff.lastTie,
    JSON.stringify(sniff.lastTie || null));
}

/* ============================== THE REAL FILES
   Every file in the corpus that qcgeom should read must classify to the expected kind, with
   no tie between recognisers — a tie means two of them scored the same and the answer came
   from the table order rather than from the evidence. Files 3Dmol reads itself (CIF, PDB,
   POSCAR) must come back null: a wrong kind is worse than none, because the page would then
   hand the file to the wrong reader instead of to the viewer. Big files are read by their
   head only, which is how the page itself opens a cube. */
{
  const dir = new URL('./corpus/', import.meta.url).pathname;
  const headOf = (path, bytes) => {
    const fd = openSync(path, 'r');
    const buf = Buffer.alloc(bytes);
    const n = readSync(fd, buf, 0, bytes, 0);
    closeSync(fd);
    return buf.subarray(0, n).toString('latin1');
  };
  const expect = {
    'C18-B9N9.out': 'gaussian-out', 'DA_IRC.out': 'gaussian-out', 'opt_N.out': 'gaussian-out',
    '2-methyloxirane_Raman.out': 'gaussian-out',
    'NWChem_molden.nw': 'nwchem-in', 'psi4_fch.inp': 'psi4-in',
    'GAMESS_US.inp': 'gamess', 'UKS_cc-pVDZ.gms': 'gamess',
    'CP2K_diamond_2x2_DZVP-MOLOPT.inp': 'cp2k-in',
    'FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube': 'cube',
    'Jumanah-HOMO.cub': 'cube', 'Jumanah-ESP-dens.cube': 'cube', 'Jumanah-densityForESP-dens.cube': 'cube',
    /* 3Dmol's own formats: qcgeom must stay out of the way */
    '2hydronium_30w_-sol.vasp': null, 'Urea.cif': null, 'zeolite.cif': null, 'COF_12000N2.cif': null,
    '8yax.fw2.cif': null, 'DNA.pdb': null, 'Urea_crystal.pdb': null,
  };
  for (const [name, kind] of Object.entries(expect)) {
    const path = dir + name;
    let text;
    try {
      const size = statSync(path).size;
      text = size > 8 * 1024 * 1024 ? headOf(path, 64 * 1024) : readFileSync(path, 'latin1');
    } catch (e) { check(`corpus ${name}: readable`, false, e.message); continue; }
    const t0 = Date.now();
    const got = sniff(text);
    const ms = Date.now() - t0;
    check(`corpus ${name}: sniff → ${kind}`, got === kind, `got ${got}${sniff.lastTie ? ' TIE ' + JSON.stringify(sniff.lastTie) : ''} in ${ms} ms`);
    if (kind) check(`corpus ${name}: decided without a tie`, !sniff.lastTie, JSON.stringify(sniff.lastTie || null));
    if (kind) {
      let r = null, msg = '';
      try { r = parseGeometry(text); } catch (e) { msg = e.message; }
      check(`corpus ${name}: parses to atoms`, r && r.atoms.length > 0, r ? `${r.atoms.length} atoms, ${r.program}: ${r.note}` : msg);
    }
  }
  /* the four molecular-dynamics shapes the separate mdgeom module owns: not ours, and not a
     false positive either — each must come back null so the page consults mdgeom instead */
  const LAMMPS_DATA = `LAMMPS data file via write_data, version 23 Jun 2022, timestep = 0

3 atoms
2 atom types
2 bonds
1 bond types

0.0 20.0 xlo xhi
0.0 20.0 ylo yhi
0.0 20.0 zlo zhi

Masses

1 15.9994
2 1.008

Atoms # full

1 1 1 -0.8476 0.0 0.0 0.0 0 0 0
2 1 2 0.4238 0.9572 0.0 0.0 0 0 0
3 1 2 0.4238 -0.24 0.927 0.0 0 0 0

Bonds

1 1 1 2
2 1 1 3
`;
  const AMBER_RST7 = `ACE
     3  0.0000000E+00
   0.0000000   0.0000000   0.0000000   0.9572000   0.0000000   0.0000000
  -0.2400000   0.9270000   0.0000000
  20.0000000  20.0000000  20.0000000  90.0000000  90.0000000  90.0000000
`;
  const CHARMM_CRD = `* WATER
*  DATE:     9/12/26     10:00:00      CREATED BY USER: dante
*
    3
    1    1 TIP3 OH2    0.00000   0.00000   0.00000 WAT  1      0.00000
    2    1 TIP3 H1     0.95720   0.00000   0.00000 WAT  1      0.00000
    3    1 TIP3 H2    -0.24000   0.92700   0.00000 WAT  1      0.00000
`;
  const NAMD_XSC = `# NAMD extended system configuration output file
#$LABELS step a_x a_y a_z b_x b_y b_z c_x c_y c_z o_x o_y o_z
500 20 0 0 0 20 0 0 0 20 0 0 0
`;
  for (const [name, text] of [['a LAMMPS data file', LAMMPS_DATA], ['an AMBER .rst7', AMBER_RST7],
                              ['a CHARMM .crd', CHARMM_CRD], ['a NAMD .xsc', NAMD_XSC]]) {
    check(`${name} is not claimed (mdgeom's job)`, sniff(text) === null, String(sniff(text)));
  }
}

/* ============================== SEVEN MORE PROGRAMS, input and output each
   The fixtures are the real shapes of the real outputs; each has a decoy geometry first so
   that "last wins" is proven, a bohr block where the program writes one, and one atom whose
   element is a trap. The same helpers as above: the last geometry must be water with O–H at
   0.958 Å and the first atom at the origin. */
const water = (name, r, extra = '') => {
  check(`${name}: three atoms, O H H${extra}`, r.atoms.length === 3 && r.atoms.map(a => a.elem).join('') === 'OHH',
    r.atoms.map(a => a.elem).join('') + ` (${r.atoms.length})`);
  const oh1 = dist(r.atoms[0], r.atoms[1]), oh2 = dist(r.atoms[0], r.atoms[2]);
  check(`${name}: O–H comes out at 0.958 A${extra}`, near(oh1, 0.958, 0.002) && near(oh2, 0.958, 0.01),
    `${oh1.toFixed(4)} and ${oh2.toFixed(4)} A`);
  check(`${name}: takes the LAST geometry${extra}`, Math.abs(r.atoms[0].x) < 1e-6, `first atom at x = ${r.atoms[0].x}`);
};
const tryParse = (name, text) => {
  let r;
  try { r = parseGeometry(text); } catch (e) { check(`${name}: parses`, false, e.message); return null; }
  /* every fixture must be decided by evidence, never by the order of the recogniser table */
  check(`${name}: classified without a tie`, !sniff.lastTie, JSON.stringify(sniff.lastTie) + ' ' + JSON.stringify(sniff.lastScores));
  /* Windows line ends must change nothing: the same atoms, the same cell, the same kind */
  try {
    const c = parseGeometry(text.replace(/\n/g, '\r\n'));
    check(`${name}: reads the same with CRLF line ends`,
      c.program === r.program && c.atoms.length === r.atoms.length && dist(c.atoms[0], r.atoms[0]) < 1e-9 &&
      JSON.stringify(c.cell || null) === JSON.stringify(r.cell || null),
      `${c.program} ${c.atoms.length} atoms vs ${r.program} ${r.atoms.length}`);
  } catch (e) { check(`${name}: reads the same with CRLF line ends`, false, e.message); }
  return r;
};
const thrown = (text) => { try { parseGeometry(text); return ''; } catch (e) { return e.message; } };

/* ---------------------------------------------------------------- NWChem */
{
  const NW_OUT = `          Northwest Computational Chemistry Package (NWChem) 7.0.2
          --------------------------------------------------------

============================== echo of input deck ==============================
geometry units angstrom noautosym
  O1     9.00000000   0.00000000   0.00000000
  Hwat   9.95800000   0.00000000   0.00000000
  Hwat   8.76000000   0.92700000   0.00000000
end
task scf optimize
================================================================================

                                NWChem Input Module
                                -------------------

 Scaling coordinates for geometry "geometry" by  1.889725989
 (inverse scale =  0.529177249)

                             Geometry "geometry" -> ""
                             -------------------------

 Output coordinates in angstroms (scale by  1.889725989 to convert to a.u.)

  No.       Tag          Charge          X              Y              Z
 ---- ---------------- ---------- -------------- -------------- --------------
    1 O1                   8.0000     9.00000000     0.00000000     0.00000000
    2 Hwat                 1.0000     9.95800000     0.00000000     0.00000000
    3 Hwat                 1.0000     8.76000000     0.92700000     0.00000000

      Atomic Mass
      -----------

      O1                15.994910
      Hwat               1.007825

      Optimization converged

                             Geometry "geometry" -> ""
                             -------------------------

 Output coordinates in angstroms (scale by  1.889725989 to convert to a.u.)

  No.       Tag          Charge          X              Y              Z
 ---- ---------------- ---------- -------------- -------------- --------------
    1 O1                   8.0000     0.00000000     0.00000000     0.00000000
    2 Hwat                 1.0000     0.95800000     0.00000000     0.00000000
    3 Hwat                 1.0000    -0.24000000     0.92700000     0.00000000
    4 bqH                  0.0000     3.00000000     3.00000000     3.00000000

      Atomic Mass
      -----------
`;
  check('NWChem output: recognised', sniff(NW_OUT) === 'nwchem-out', String(sniff(NW_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  const r = tryParse('NWChem output', NW_OUT);
  if (r) {
    water('NWChem output', r);
    check('NWChem output: tags O1 and Hwat are oxygen and hydrogen, and bqH is a ghost and is dropped',
      r.atoms.map(a => a.elem).join('') === 'OHH', r.atoms.map(a => a.elem).join(''));
    check('NWChem output: says which program', r.program === 'NWChem', r.program);
  }
  /* the a.u. variant, and the shouting trap: CO with a charge of 6 is a carbon */
  const NW_AU = ` Output coordinates in a.u. (scale by  1.000000000 to convert to a.u.)

  No.       Tag          Charge          X              Y              Z
 ---- ---------------- ---------- -------------- -------------- --------------
    1 CO                   6.0000     0.00000000     0.00000000     0.00000000
    2 O                    8.0000     2.13000000     0.00000000     0.00000000
`;
  const a = tryParse('NWChem a.u. table', NW_AU);
  if (a) {
    check('NWChem output: an a.u. table is converted from bohr', near(dist(a.atoms[0], a.atoms[1]), 2.13 * BOHR, 1e-6),
      dist(a.atoms[0], a.atoms[1]).toFixed(4) + ' A');
    check('NWChem output: a carbon tagged CO with charge 6 is carbon, not cobalt',
      a.atoms.map(x => x.elem).join('') === 'CO', a.atoms.map(x => x.elem).join(''));
    check('NWChem output: the note says bohr', /bohr/.test(a.note), a.note);
  }
  const NW_IN = `title "water"
geometry "start" units angstrom
  O   9.0 0.0 0.0
  H   9.958 0.0 0.0
  H   8.76 0.927 0.0
end
geometry units bohr noautosym
  symmetry c1
  O1     0.00000000   0.00000000   0.00000000
  Hwat   1.81032183   0.00000000   0.00000000
  Hwat  -0.45354338   1.75182259   0.00000000
  bq     5.0 5.0 5.0 charge 0.0
end
basis
  * library 6-31G*
end
task scf
`;
  check('NWChem input: recognised', sniff(NW_IN) === 'nwchem-in', String(sniff(NW_IN)));
  const i = tryParse('NWChem input', NW_IN);
  if (i) {
    water('NWChem input', i);
    check('NWChem input: "units bohr" is honoured and said', /bohr/.test(i.note), i.note);
    check('NWChem input: says which program', i.program === 'NWChem input', i.program);
  }
  /* `set geometry` picks a named block over the last one */
  const named = NW_IN + 'set geometry "start"\n';
  const s = tryParse('NWChem input with set geometry', named);
  check('NWChem input: `set geometry "name"` selects that block rather than the last',
    s && Math.abs(s.atoms[0].x - 9) < 1e-9, s ? 'x = ' + s.atoms[0].x : '');
  check('NWChem input: a zmatrix is refused with a plain message',
    /Z-matrix|zmatrix/i.test(thrown('geometry\n zmatrix\n  O\n  H 1 0.96\n  H 1 0.96 2 104.5\n end\nend\n')),
    thrown('geometry\n zmatrix\n  O\n  H 1 0.96\n  H 1 0.96 2 104.5\n end\nend\n'));
  check('NWChem input: `load file.xyz` says to open that file',
    /separate|open that file/i.test(thrown('geometry\n load water.xyz\nend\n')), thrown('geometry\n load water.xyz\nend\n'));
  /* the real corpus input */
  const corp = parseGeometry(readFileSync(new URL('./corpus/NWChem_molden.nw', import.meta.url), 'latin1'));
  check('NWChem input: the corpus NWChem_molden.nw reads as water', corp.atoms.map(a => a.elem).join('') === 'OHH' &&
    near(dist(corp.atoms[0], corp.atoms[1]), 0.9657, 0.001), dist(corp.atoms[0], corp.atoms[1]).toFixed(4) + ' A');
}

/* ---------------------------------------------------------------- CASTEP */
{
  const CELL = `%BLOCK LATTICE_ABC
ang
  5.43 5.43 5.43
  90.0 90.0 90.0
%ENDBLOCK LATTICE_ABC

%BLOCK POSITIONS_FRAC
  Si    0.00 0.00 0.00   ! a comment
  Si:1  0.25 0.25 0.25
%ENDBLOCK POSITIONS_FRAC

KPOINTS_MP_GRID 4 4 4
FIX_ALL_CELL : true
`;
  check('CASTEP .cell: recognised', sniff(CELL) === 'castep-cell', String(sniff(CELL)));
  const c = tryParse('CASTEP .cell', CELL);
  if (c) {
    check('CASTEP .cell: fractional positions become cartesian through the cell',
      c.atoms.length === 2 && near(c.atoms[1].x, 0.25 * 5.43, 1e-9) && near(c.atoms[1].z, 0.25 * 5.43, 1e-9),
      JSON.stringify(c.atoms[1]));
    check('CASTEP .cell: the species label Si:1 is silicon', c.atoms.map(a => a.elem).join('') === 'SiSi', c.atoms.map(a => a.elem).join(''));
    check('CASTEP .cell: LATTICE_ABC gives the cell and the structure is periodic',
      c.cell && near(cellParams(c.cell).a, 5.43, 1e-9) && near(cellParams(c.cell).gamma, 90, 1e-9) && /CASTEP/.test(c.periodic || ''),
      JSON.stringify(c.cell) + ' ' + c.periodic);
    check('CASTEP .cell: says which program', c.program === 'CASTEP cell', c.program);
  }
  const CELL_BOHR = `%BLOCK lattice_cart
bohr
  18.897261 0.0 0.0
  0.0 18.897261 0.0
  0.0 0.0 18.897261
%ENDBLOCK lattice_cart
%BLOCK positions_abs
bohr
  8   0.0 0.0 0.0
  H   1.810322 0.0 0.0
  H  -0.453543 1.751823 0.0
%ENDBLOCK positions_abs
`;
  const b = tryParse('CASTEP .cell in bohr', CELL_BOHR);
  if (b) {
    water('CASTEP .cell in bohr', b);
    check('CASTEP .cell: a species given as an atomic number is typed from it', b.atoms[0].elem === 'O', b.atoms[0].elem);
    check('CASTEP .cell: a bohr lattice is converted', b.cell && near(cellParams(b.cell).a, 10, 1e-4),
      b.cell ? cellParams(b.cell).a.toFixed(4) : 'no cell');
  }
  const CASTEP_OUT = ` +-------------------------------------------------+
 |                                                 |
 |      CCC   AA    SSS  TTTTT  EEEEE  PPPP        |
 |     C     A  A  S       T    E      P   P       |
 |     C     AAAA   SS     T    EEE    PPPP        |
 |     C     A  A     S    T    E      P           |
 |      CCC  A  A  SSS     T    EEEEE  P           |
 |                                                 |
 +-------------------------------------------------+
 |                                                 |
 | Welcome to Academic Release CASTEP version 20.11|
 | Ab Initio Total Energy Program                  |
 |                                                 |
 +-------------------------------------------------+

                           -------------------------------
                                      Unit Cell
                           -------------------------------
        Real Lattice(A)                      Reciprocal Lattice(1/A)
     5.4300000     0.0000000     0.0000000        1.157123    0.000000    0.000000
     0.0000000     5.4300000     0.0000000        0.000000    1.157123    0.000000
     0.0000000     0.0000000     5.4300000        0.000000    0.000000    1.157123

                       Lattice parameters(A)       Cell Angles
                    a =      5.430000          alpha =   90.000000
                    b =      5.430000          beta  =   90.000000
                    c =      5.430000          gamma =   90.000000

                       Current cell volume =           160.103007       A**3

                           -------------------------------
                                     Cell Contents
                           -------------------------------
                         Total number of ions in cell =    2
                      Total number of species in cell =    1
                        Max number of any one species =    2

            xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
            x  Element    Atom        Fractional coordinates of atoms  x
            x            Number           u          v          w      x
            x----------------------------------------------------------x
            x  Si           1         0.000000   0.000000   0.000000   x
            x  Si:1         2         0.250000   0.250000   0.250000   x
            xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

 LBFGS: finished iteration     3 with enthalpy= -2.16345678E+002 eV

 LBFGS: Geometry optimization completed successfully.

 LBFGS: Final Configuration:
                           -------------------------------
                                      Unit Cell
                           -------------------------------
        Real Lattice(A)                      Reciprocal Lattice(1/A)
     5.4600000     0.0000000     0.0000000        1.150766    0.000000    0.000000
     0.0000000     5.4600000     0.0000000        0.000000    1.150766    0.000000
     0.0000000     0.0000000     5.4600000        0.000000    0.000000    1.150766

                       Lattice parameters(A)       Cell Angles
                    a =      5.460000          alpha =   90.000000
                    b =      5.460000          beta  =   90.000000
                    c =      5.460000          gamma =   90.000000

                           -------------------------------
                                     Cell Contents
                           -------------------------------

            xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
            x  Element    Atom        Fractional coordinates of atoms  x
            x            Number           u          v          w      x
            x----------------------------------------------------------x
            x  Si           1         0.000000   0.000000   0.000000   x
            x  Si:1         2         0.260000   0.250000   0.250000   x
            xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

 LBFGS: Final Enthalpy     = -2.16345678E+002 eV
`;
  check('CASTEP .castep: recognised', sniff(CASTEP_OUT) === 'castep-out', String(sniff(CASTEP_OUT)));
  const o = tryParse('CASTEP .castep', CASTEP_OUT);
  if (o) {
    check('CASTEP .castep: the LAST Cell Contents block wins (u = 0.26, not 0.25)',
      o.atoms.length === 2 && near(o.atoms[1].x, 0.26 * 5.46, 1e-9), JSON.stringify(o.atoms[1]));
    check('CASTEP .castep: and it is placed in the LAST cell (5.46, not 5.43)',
      o.cell && near(cellParams(o.cell).a, 5.46, 1e-9), o.cell ? cellParams(o.cell).a.toFixed(4) : 'no cell');
    check('CASTEP .castep: labels Si and Si:1 are both silicon', o.atoms.map(a => a.elem).join('') === 'SiSi', o.atoms.map(a => a.elem).join(''));
    check('CASTEP .castep: the note says the final configuration was taken', /final/i.test(o.note), o.note);
    check('CASTEP .castep: periodic', /CASTEP/.test(o.periodic || ''), String(o.periodic));
  }
}

/* ---------------------------------------------------------------- Q-Chem */
{
  const QC_OUT = `
                  Welcome to Q-Chem
     A Quantum Leap Into The Future Of Chemistry

 Q-Chem 5.4, Q-Chem, Inc., Pleasanton, CA (2021)

--------------------------------------------------------------
User input:
--------------------------------------------------------------
$molecule
0 1
O  9.0 0.0 0.0
H  9.958 0.0 0.0
H  8.76 0.927 0.0
$end

$rem
   JOBTYPE  opt
   METHOD   b3lyp
   BASIS    6-31G*
$end
--------------------------------------------------------------

             Standard Nuclear Orientation (Angstroms)
    I     Atom           X                Y                Z
 ----------------------------------------------------------------
    1      O       9.0000000000     0.0000000000     0.0000000000
    2      H       9.9580000000     0.0000000000     0.0000000000
    3      H       8.7600000000     0.9270000000     0.0000000000
 ----------------------------------------------------------------

 **  OPTIMIZATION CONVERGED  **

             Standard Nuclear Orientation (Angstroms)
    I     Atom           X                Y                Z
 ----------------------------------------------------------------
    1      O       0.0000000000     0.0000000000     0.0000000000
    2      H       0.9580000000     0.0000000000     0.0000000000
    3      H      -0.2400000000     0.9270000000     0.0000000000
 ----------------------------------------------------------------
`;
  check('Q-Chem output: recognised', sniff(QC_OUT) === 'qchem-out', String(sniff(QC_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  check('Q-Chem output: the echoed $molecule does not tie with the output', !sniff.lastTie, JSON.stringify(sniff.lastTie));
  const r = tryParse('Q-Chem output', QC_OUT);
  if (r) {
    water('Q-Chem output', r);
    check('Q-Chem output: notes OPTIMIZATION CONVERGED', /converged/i.test(r.note), r.note);
    check('Q-Chem output: says which program', r.program === 'Q-Chem', r.program);
  }
  const QC_IN = `$comment
  two jobs in one file
$end

$molecule
0 1
O  9.0 0.0 0.0
H  9.958 0.0 0.0
H  8.76 0.927 0.0
$end

$rem
   JOBTYPE  sp
   METHOD   b3lyp
   BASIS    6-31G*
$end

@@@

$molecule
0 1
--
0 1
O   0.000000   0.000000   0.000000
H   0.958000   0.000000   0.000000
--
0 1
H  -0.240000   0.927000   0.000000
$end

$rem
   JOBTYPE  eda
$end
`;
  check('Q-Chem input: recognised', sniff(QC_IN) === 'qchem-in', String(sniff(QC_IN)));
  const i = tryParse('Q-Chem input', QC_IN);
  if (i) {
    water('Q-Chem input', i);
    check('Q-Chem input: fragment separators and their charge lines are stepped over', i.atoms.length === 3, i.atoms.length + ' atoms');
    check('Q-Chem input: says which program', i.program === 'Q-Chem input', i.program);
  }
  check('Q-Chem input: a Z-matrix is refused with a plain message',
    /Z-matrix/i.test(thrown('$molecule\n0 1\nO\nH 1 0.96\nH 1 0.96 2 104.5\n$end\n$rem\n$end\n')),
    thrown('$molecule\n0 1\nO\nH 1 0.96\nH 1 0.96 2 104.5\n$end\n$rem\n$end\n'));
  check('Q-Chem input: "$molecule read" alone says there is nothing to read',
    /read|previous/i.test(thrown('$molecule\nread\n$end\n$rem\n$end\n')), thrown('$molecule\nread\n$end\n$rem\n$end\n'));
}

/* ---------------------------------------------------------------- Molpro */
{
  const MP_OUT = `
 ***  PROGRAM SYSTEM MOLPRO  ***
 Copyright, TTI GmbH Stuttgart, 2015
                                    Version 2015.1 linked Jan 1 2016 00:00:00

 ***,water
 memory,100,m
 geometry={
 O
 H,1,0.96
 H,1,0.96,2,104.5
 }
 basis=vdz
 hf

 Commands  initialized (702), CPU time= 0.01 sec, 572 directives.

 ATOMIC COORDINATES

 NR  ATOM    CHARGE       X              Y              Z

   1  O       8.00   17.007535196    0.000000000    0.000000000
   2  H       1.00   18.817857028    0.000000000    0.000000000
   3  H       1.00   16.553991813    1.751822590    0.000000000

 Bond lengths in Bohr (Angstrom)

 ATOMIC COORDINATES

 NR  ATOM    CHARGE       X              Y              Z

   1  O       8.00    0.000000000    0.000000000    0.000000000
   2  H       1.00    1.810321832    0.000000000    0.000000000
   3  H       1.00   -0.453543383    1.751822590    0.000000000

 Bond lengths in Bohr (Angstrom)

 1-2  1.810321832     1-3  1.810321832
     ( 0.958000000)       ( 0.958000000)
`;
  check('Molpro output: recognised', sniff(MP_OUT) === 'molpro-out', String(sniff(MP_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  check('Molpro output: the echoed input does not tie with the output', !sniff.lastTie, JSON.stringify(sniff.lastTie));
  const r = tryParse('Molpro output', MP_OUT);
  if (r) {
    water('Molpro output', r);
    check('Molpro output: ATOMIC COORDINATES are in bohr and are converted', /bohr/.test(r.note), r.note);
    check('Molpro output: says which program', r.program === 'Molpro', r.program);
  }
  /* an ECP: platinum with a charge of 18 is still platinum, and the label says so */
  const ecp = MP_OUT.replace('   1  O       8.00    0.000000000    0.000000000    0.000000000',
                             '   1  PT     18.00    0.000000000    0.000000000    0.000000000');
  const e = tryParse('Molpro output with an ECP', ecp);
  check('Molpro output: PT with an ECP charge of 18 is platinum, not argon', e && e.atoms[0].elem === 'Pt', e ? e.atoms[0].elem : '');
  /* an optimisation: the "Current geometry" block printed by OPTG comes later in the file
     than the last ATOMIC COORDINATES, and it is in angstrom */
  const opt = MP_OUT + `
 Optimization point 3

 Current geometry (xyz format, in Angstrom)

     3
 HF-SCF000/VDZ  ENERGY=-76.02
 O          0.0000000000        0.0000000000        0.0000000000
 H          0.9600000000        0.0000000000        0.0000000000
 H         -0.2404000000        0.9295000000        0.0000000000

 END OF GEOMETRY OPTIMIZATION.
`;
  const p = tryParse('Molpro optimisation', opt);
  check('Molpro output: a later "Current geometry" block from OPTG wins and is taken as angstrom',
    p && near(dist(p.atoms[0], p.atoms[1]), 0.96, 1e-6) && /angstrom/i.test(p.note), p ? dist(p.atoms[0], p.atoms[1]).toFixed(4) + ' ' + p.note : '');

  const MP_IN = `***,water two ways
memory,100,m
geometry={
 3
 first guess
 O1, 9.0, 0.0, 0.0
 H1, 9.958, 0.0, 0.0
 H2, 8.76, 0.927, 0.0
}
hf
geometry={
 O1   8   0.000000   0.000000   0.000000
 H1   1   0.958000   0.000000   0.000000
 H2   1  -0.240000   0.927000   0.000000
}
hf
optg
`;
  check('Molpro input: recognised', sniff(MP_IN) === 'molpro-in', String(sniff(MP_IN)));
  const i = tryParse('Molpro input', MP_IN);
  if (i) {
    water('Molpro input', i);
    check('Molpro input: a charge column between the label and x is allowed and used', i.atoms.map(a => a.elem).join('') === 'OHH',
      i.atoms.map(a => a.elem).join(''));
    check('Molpro input: says which program', i.program === 'Molpro input', i.program);
  }
  const bohrIn = 'bohr\ngeometry={\n O, 0.0, 0.0, 0.0\n H, 1.810322, 0.0, 0.0\n H, -0.453543, 1.751823, 0.0\n}\n';
  const b = tryParse('Molpro input in bohr', bohrIn);
  check('Molpro input: a `bohr` directive before the block is honoured', b && near(dist(b.atoms[0], b.atoms[1]), 0.958, 0.002),
    b ? dist(b.atoms[0], b.atoms[1]).toFixed(4) + ' A' : '');
  check('Molpro input: a Z-matrix is refused with a plain message',
    /Z-matrix/i.test(thrown('geometry={\nO\nH,1,0.96\nH,1,0.96,2,104.5\n}\n')), thrown('geometry={\nO\nH,1,0.96\nH,1,0.96,2,104.5\n}\n'));
}

/* ---------------------------------------------------------------- Psi4 */
{
  const PSI_OUT = `
    -----------------------------------------------------------------------
          Psi4: An Open-Source Ab Initio Electronic Structure Package
                               Psi4 1.7 release

                         Git: Rev {HEAD} 6ce35a5
    -----------------------------------------------------------------------

  ==> Geometry <==

    Molecular point group: c1
    Full point group: C1

    Geometry (in Bohr), charge = 0, multiplicity = 1:

       Center              X                  Y                   Z               Mass
    ------------   -----------------  -----------------  -----------------  -----------------
         O            9.000000000000     0.000000000000     0.000000000000    15.994914619570
         H           10.810321831679     0.000000000000     0.000000000000     1.007825032230
         H            8.546456617067     1.751822589593     0.000000000000     1.007825032230

  ==> Geometry <==

    Molecular point group: c1
    Full point group: C1

    Geometry (in Angstrom), charge = 0, multiplicity = 1:

       Center              X                  Y                   Z               Mass
    ------------   -----------------  -----------------  -----------------  -----------------
         O            0.000000000000     0.000000000000     0.000000000000    15.994914619570
         H1           0.958000000000     0.000000000000     0.000000000000     1.007825032230
         H           -0.240000000000     0.927000000000     0.000000000000     1.007825032230
         Gh(He)       3.000000000000     3.000000000000     3.000000000000     4.002602000000

  Running in c1 symmetry.
`;
  check('Psi4 output: recognised', sniff(PSI_OUT) === 'psi4-out', String(sniff(PSI_OUT)));
  /* Psi4's "Geometry (in Angstrom), charge = …" must not be taken for ADF's "Geometry (in
     angstrom)" heading: a tie here would be decided by table order, not by evidence */
  check('Psi4 output: decided without a tie (not mistaken for an ADF geometry block)', !sniff.lastTie,
    JSON.stringify(sniff.lastTie) + ' ' + JSON.stringify(sniff.lastScores));
  const r = tryParse('Psi4 output', PSI_OUT);
  if (r) {
    water('Psi4 output', r);
    check('Psi4 output: H1 is hydrogen and Gh(He) is a ghost and is dropped', r.atoms.map(a => a.elem).join('') === 'OHH',
      r.atoms.map(a => a.elem).join(''));
    check('Psi4 output: says which program', r.program === 'Psi4', r.program);
  }
  /* the same file with only the bohr table: the heading's unit is what decides */
  const onlyBohr = PSI_OUT.slice(0, PSI_OUT.lastIndexOf('  ==> Geometry <=='));
  const b = tryParse('Psi4 output in bohr', onlyBohr);
  check('Psi4 output: "(in Bohr)" in the heading is honoured', b && near(dist(b.atoms[0], b.atoms[1]), 0.958, 0.002),
    b ? dist(b.atoms[0], b.atoms[1]).toFixed(4) + ' A' : '');
  /* optking's final block, printed after the last table, wins */
  const fin = PSI_OUT + `
	Final optimized geometry and variables:
	Cartesian Geometry (in Angstrom)
	    O   0.0000000000   0.0000000000   0.0000000000
	    H   0.9600000000   0.0000000000   0.0000000000
	    H  -0.2404000000   0.9295000000   0.0000000000
`;
  const f = tryParse('Psi4 optimisation', fin);
  check('Psi4 output: "Final optimized geometry" printed later wins', f && near(dist(f.atoms[0], f.atoms[1]), 0.96, 1e-6),
    f ? dist(f.atoms[0], f.atoms[1]).toFixed(4) : '');

  const PSI_IN = `#! water, twice
molecule dimer {
0 1
O  9.0 0.0 0.0
H  9.958 0.0 0.0
H  8.76 0.927 0.0
--
0 1
Gh(He)  0.0 0.0 3.0
units angstrom
}

molecule water {
  0 1
  O1     0.000000   0.000000   0.000000
  H@2.014  1.810322   0.000000   0.000000
  H     -0.453543   1.751823   0.000000
  units bohr
  symmetry c1
  no_com
  no_reorient
}

set basis cc-pvdz
energy('scf')
`;
  check('Psi4 input: recognised', sniff(PSI_IN) === 'psi4-in', String(sniff(PSI_IN)));
  const i = tryParse('Psi4 input', PSI_IN);
  if (i) {
    water('Psi4 input', i);
    check('Psi4 input: O1 and a deuterium written H@2.014 are typed from their labels', i.atoms.map(a => a.elem).join('') === 'OHH',
      i.atoms.map(a => a.elem).join(''));
    check('Psi4 input: "units bohr" inside the block is honoured and said', /bohr/.test(i.note), i.note);
    check('Psi4 input: says which program', i.program === 'Psi4 input', i.program);
  }
  check('Psi4 input: a pubchem: block says the geometry is not in the file',
    /pubchem/i.test(thrown('molecule {\n  pubchem:water\n}\n')), thrown('molecule {\n  pubchem:water\n}\n'));
  const corp = parseGeometry(readFileSync(new URL('./corpus/psi4_fch.inp', import.meta.url), 'latin1'));
  check('Psi4 input: the corpus psi4_fch.inp reads as water', corp.atoms.map(a => a.elem).join('') === 'OHH' &&
    near(dist(corp.atoms[0], corp.atoms[1]), 0.9455, 0.001), dist(corp.atoms[0], corp.atoms[1]).toFixed(4) + ' A');
}

/* ---------------------------------------------------------------- Turbomole */
{
  const GRAD = `$grad          cartesian gradients
  cycle =      1    SCF energy =      -76.0245678901   |dE/dxyz| =  0.012345
   17.00753519600000      0.00000000000000      0.00000000000000      o
   18.81785702800000      0.00000000000000      0.00000000000000      h
   16.55399181300000      1.75182259000000      0.00000000000000      h
   0.1234567890123D-02   0.0000000000000D+00   0.0000000000000D+00
  -0.1234567890123D-02   0.0000000000000D+00   0.0000000000000D+00
   0.0000000000000D+00   0.0000000000000D+00   0.0000000000000D+00
  cycle =      2    SCF energy =      -76.0256789012   |dE/dxyz| =  0.001234
    0.00000000000000      0.00000000000000      0.00000000000000      o
    1.81032183167855      0.00000000000000      0.00000000000000      h
   -0.45354338293264      1.75182258959268      0.00000000000000      h
   0.1234567890123D-04   0.0000000000000D+00   0.0000000000000D+00
  -0.1234567890123D-04   0.0000000000000D+00   0.0000000000000D+00
   0.0000000000000D+00   0.0000000000000D+00   0.0000000000000D+00
$end
`;
  check('Turbomole gradient: recognised', sniff(GRAD) === 'turbomole-gradient', String(sniff(GRAD)));
  const g = tryParse('Turbomole gradient', GRAD);
  if (g) {
    water('Turbomole gradient', g);
    check('Turbomole gradient: the last cycle and its energy are named', /cycle 2/.test(g.note) && /-76\.0256789012/.test(g.note), g.note);
    check('Turbomole gradient: gradient rows (with D exponents) are not mistaken for atoms', g.atoms.length === 3, g.atoms.length + ' atoms');
    check('Turbomole gradient: says which program', /Turbomole/.test(g.program), g.program);
  }
  const ENERGY = `$energy      SCF               SCFKIN            SCFPOT
     1   -76.02456789012    75.9876543210   -152.0122222111
     2   -76.02567890123    75.9887654321   -152.0144443333
$end
`;
  check('Turbomole energy: recognised for what it is', sniff(ENERGY) === 'turbomole-energy', String(sniff(ENERGY)));
  check('Turbomole energy: refused with a message naming the coord or gradient file',
    /coord|gradient/.test(thrown(ENERGY)) && /energ/i.test(thrown(ENERGY)), thrown(ENERGY));
  const TM_OUT = ` ridft (node01) : TURBOMOLE rev. V7.5.1 compiled 23 Nov 2020 at 12:00:00

              +--------------------------------------------------+
              | Atomic coordinate, charge and isotop information |
              +--------------------------------------------------+

                    atomic coordinates            atom    charge  isotop
         17.00753520    0.00000000    0.00000000    o      8.000     0
         18.81785703    0.00000000    0.00000000    h      1.000     0
         16.55399181    1.75182259    0.00000000    h      1.000     0

       center of nuclear mass  :   17.10000000    0.00000000    0.00000000

              +--------------------------------------------------+
              | Atomic coordinate, charge and isotop information |
              +--------------------------------------------------+

                    atomic coordinates            atom    charge  isotop
          0.00000000    0.00000000    0.00000000    o      8.000     0
          1.81032183    0.00000000    0.00000000    h      1.000     0
         -0.45354338    1.75182259    0.00000000    h      1.000     0

       center of nuclear mass  :    0.10000000    0.00000000    0.00000000
`;
  check('Turbomole output: recognised', sniff(TM_OUT) === 'turbomole-out', String(sniff(TM_OUT)));
  const o = tryParse('Turbomole output', TM_OUT);
  if (o) {
    water('Turbomole output', o);
    check('Turbomole output: says bohr was converted', /bohr/.test(o.note), o.note);
  }
  const ecp = TM_OUT.replace('          0.00000000    0.00000000    0.00000000    o      8.000     0',
                             '          0.00000000    0.00000000    0.00000000    pt    18.000     0');
  const e = tryParse('Turbomole output with an ECP', ecp);
  check('Turbomole output: pt with an ECP charge of 18 is platinum, not argon', e && e.atoms[0].elem === 'Pt', e ? e.atoms[0].elem : '');
}

/* ---------------------------------------------------------------- Quantum ESPRESSO */
{
  const QE_IN = `&CONTROL
  calculation = 'relax'
  prefix = 'wat'
/
&SYSTEM
  ibrav = 0
  nat = 3
  ntyp = 3
  ecutwfc = 40
/
&ELECTRONS
/
ATOMIC_SPECIES
  Ow   15.999  O.pbe-n-kjpaw_psl.1.0.0.UPF
  H1    1.008  H.pbe-kjpaw_psl.1.0.0.UPF
  H_b   1.008  H.pbe-kjpaw_psl.1.0.0.UPF
CELL_PARAMETERS angstrom
  10.0  0.0  0.0
   0.0 10.0  0.0
   0.0  0.0 10.0
ATOMIC_POSITIONS crystal
  Ow   0.000  0.0000  0.0   0 0 0
  H1   0.0958 0.0000  0.0
  H_b -0.024  0.0927  0.0   1 1 1
K_POINTS gamma
`;
  check('QE input: recognised', sniff(QE_IN) === 'qe-in', String(sniff(QE_IN)));
  const i = tryParse('QE input', QE_IN);
  if (i) {
    water('QE input', i);
    check('QE input: species Ow, H1 and H_b are typed from their leading letters', i.atoms.map(a => a.elem).join('') === 'OHH',
      i.atoms.map(a => a.elem).join(''));
    check('QE input: ibrav=0 cell from CELL_PARAMETERS angstrom', i.cell && near(cellParams(i.cell).a, 10, 1e-9) && /ESPRESSO/i.test(i.periodic || ''),
      JSON.stringify(i.cell) + ' ' + i.periodic);
    check('QE input: says which program', /ESPRESSO/i.test(i.program), i.program);
  }
  /* ibrav from celldm: fcc silicon, alat = 10.2 bohr */
  const FCC = `&system\n  ibrav = 2, celldm(1) = 10.2, nat = 2, ntyp = 1, ecutwfc = 30\n/\nATOMIC_SPECIES\n Si 28.086 Si.UPF\nATOMIC_POSITIONS crystal\n Si 0.00 0.00 0.00\n Si 0.25 0.25 0.25\n`;
  const f = tryParse('QE input ibrav=2', FCC);
  if (f) {
    const p = cellParams(f.cell);
    check('QE input: ibrav=2 with celldm(1) builds the fcc cell in angstrom (|a| = alat/sqrt2)',
      f.cell && near(p.a, 10.2 * BOHR / Math.SQRT2, 1e-6) && near(p.alpha, 60, 1e-6), JSON.stringify(p));
    check('QE input: crystal coordinates are placed with that cell',
      near(f.atoms[1].x, 0.25 * (f.cell.a[0] + f.cell.b[0] + f.cell.c[0]), 1e-9), JSON.stringify(f.atoms[1]));
  }
  /* alat positions are multiples of A (3 Å here), not of the cell's own c: z = 0.5 × 3 */
  const HEX = `&system\n  ibrav = 4, A = 3.0, C = 5.0, nat = 1, ntyp = 1\n/\nATOMIC_SPECIES\n Mg 24.305 Mg.UPF\nATOMIC_POSITIONS alat\n Mg 0.5 0.0 0.5\n`;
  const h = tryParse('QE input ibrav=4', HEX);
  check('QE input: ibrav=4 with A and C in angstrom (gamma = 120, c = 5) and alat positions in units of A',
    h && near(cellParams(h.cell).gamma, 120, 1e-6) && near(cellParams(h.cell).c, 5, 1e-9) && near(h.atoms[0].z, 1.5, 1e-9),
    h ? JSON.stringify(cellParams(h.cell)) + ' ' + JSON.stringify(h.atoms[0]) : '');
  check('QE input: an unsupported ibrav is refused by number, naming ibrav=0 as the way out',
    /ibrav\s*=?\s*5/.test(thrown(FCC.replace('ibrav = 2', 'ibrav = 5'))) && /ibrav\s*=?\s*0|CELL_PARAMETERS/.test(thrown(FCC.replace('ibrav = 2', 'ibrav = 5'))),
    thrown(FCC.replace('ibrav = 2', 'ibrav = 5')));
  const bohrIn = QE_IN.replace('CELL_PARAMETERS angstrom', 'CELL_PARAMETERS bohr');
  const b = tryParse('QE input, bohr cell', bohrIn);
  check('QE input: CELL_PARAMETERS bohr is converted', b && near(cellParams(b.cell).a, 10 * BOHR, 1e-9), b ? cellParams(b.cell).a.toFixed(4) : '');

  /* THE TRAP: a vc-relax. The cell changes, the last positions are in crystal units of the
     LAST cell, and alat stays what it was at the start. */
  const QE_OUT = `
     Program PWSCF v.7.2 starts on 12Sep2026 at 10: 0: 0

     lattice parameter (alat)  =      10.2000  a.u.
     unit-cell volume          =    1061.2080 (a.u.)^3
     number of atoms/cell      =            2
     number of atomic types    =            1

     crystal axes: (cart. coord. in units of alat)
               a(1) = (   1.000000   0.000000   0.000000 )
               a(2) = (   0.000000   1.000000   0.000000 )
               a(3) = (   0.000000   0.000000   1.000000 )

     site n.     atom                  positions (alat units)
         1           Si  tau(   1) = (   0.0000000   0.0000000   0.0000000  )
         2           Si  tau(   2) = (   0.2500000   0.2500000   0.2500000  )

     number of k points=     1

CELL_PARAMETERS (alat= 10.20000000)
   1.020000000   0.000000000   0.000000000
   0.000000000   1.020000000   0.000000000
   0.000000000   0.000000000   1.020000000

ATOMIC_POSITIONS (crystal)
Si            0.0000000000        0.0000000000        0.0000000000
Si            0.2500000000        0.2500000000        0.2500000000

     Begin final coordinates
     new unit-cell volume =   1234.5678 a.u.^3 (   182.9538 Ang^3 )
     density =      2.23456 g/cm^3

CELL_PARAMETERS (alat= 10.20000000)
   1.050000000   0.000000000   0.000000000
   0.000000000   1.050000000   0.000000000
   0.000000000   0.000000000   1.050000000

ATOMIC_POSITIONS (crystal)
Si            0.0000000000        0.0000000000        0.0000000000
Si            0.2600000000        0.2500000000        0.2500000000
End final coordinates

     A final scf calculation at the relaxed structure.
`;
  check('QE output: recognised', sniff(QE_OUT) === 'qe-out', String(sniff(QE_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  const o = tryParse('QE output', QE_OUT);
  if (o) {
    const a = 1.05 * 10.2 * BOHR;
    check('QE output: the last cell is 1.05 alat, in angstrom', o.cell && near(cellParams(o.cell).a, a, 1e-9), o.cell ? cellParams(o.cell).a.toFixed(5) : 'no cell');
    check('QE output: the last crystal positions are placed in THAT cell (x = 0.26 x 1.05 alat)',
      o.atoms.length === 2 && near(o.atoms[1].x, 0.26 * a, 1e-9) && near(o.atoms[1].y, 0.25 * a, 1e-9), JSON.stringify(o.atoms[1]));
    check('QE output: periodic, and says which program', /ESPRESSO/i.test(o.periodic || '') && /ESPRESSO/i.test(o.program), o.periodic + ' ' + o.program);
    check('QE output: the note says the final coordinates were taken', /final/i.test(o.note), o.note);
  }
  /* a plain scf output has only the header blocks: crystal axes times alat, positions in alat */
  const scf = QE_OUT.slice(0, QE_OUT.indexOf('CELL_PARAMETERS'));
  const s = tryParse('QE scf output', scf);
  check('QE output: without a relaxation, the header cell and the alat positions are used',
    s && near(cellParams(s.cell).a, 10.2 * BOHR, 1e-9) && near(s.atoms[1].x, 0.25 * 10.2 * BOHR, 1e-9),
    s ? cellParams(s.cell).a.toFixed(4) + ' ' + JSON.stringify(s.atoms[1]) : '');
}

/* ---------------------------------------------------------------- ABINIT */
{
  const AB_IN = `# water in a box, two datasets
ndtset 2
acell 3*10.0 Angstrom
rprim  1.0 0.0 0.0
       0.0 1.0 0.0
       0.0 0.0 1.0
natom 3
ntypat 2
znucl 8.0 1.0
typat 1 2*2
xangst1  9.0    0.0    0.0
         9.958  0.0    0.0
         8.76   0.927  0.0
xangst2  0.0    0.0    0.0
         0.958  0.0    0.0
        -0.24   0.927  0.0
ecut 20
`;
  check('ABINIT input: recognised', sniff(AB_IN) === 'abinit-in', String(sniff(AB_IN)));
  const i = tryParse('ABINIT input', AB_IN);
  if (i) {
    water('ABINIT input', i, ' (the last dataset)');
    check('ABINIT input: typat with 2*2 repetition and real znucl give O H H', i.atoms.map(a => a.elem).join('') === 'OHH',
      i.atoms.map(a => a.elem).join(''));
    check('ABINIT input: acell with an Angstrom suffix gives a 10 A box', i.cell && near(cellParams(i.cell).a, 10, 1e-9) && /ABINIT/.test(i.periodic || ''),
      i.cell ? cellParams(i.cell).a.toFixed(4) + ' ' + i.periodic : 'no cell');
    check('ABINIT input: says which program', i.program === 'ABINIT input', i.program);
  }
  const XRED = `acell 10.0 10.0 10.0
natom 3
ntypat 2
znucl 8 1
typat 1 2 2
xred 0.0 0.0 0.0
     0.1810322 0.0 0.0
    -0.0453543 0.1751823 0.0
`;
  const x = tryParse('ABINIT input xred', XRED);
  check('ABINIT input: acell defaults to bohr and xred is placed in that cell', x && near(dist(x.atoms[0], x.atoms[1]), 0.958, 0.002),
    x ? dist(x.atoms[0], x.atoms[1]).toFixed(4) + ' A' : '');
  const ANG = `acell 5.0 5.0 5.0 Angstrom
angdeg 90 90 120
natom 1
ntypat 1
znucl 12
typat 1
xred 0.5 0.0 0.5
`;
  const g = tryParse('ABINIT input angdeg', ANG);
  check('ABINIT input: angdeg builds the cell (gamma = 120) and xred follows it',
    g && near(cellParams(g.cell).gamma, 120, 1e-6) && near(g.atoms[0].z, 2.5, 1e-9), g ? JSON.stringify(cellParams(g.cell)) + JSON.stringify(g.atoms[0]) : '');
  const RHOMB = `acell 3*5.0 Angstrom\nangdeg 3*60\nnatom 1\nntypat 1\nznucl 12\ntypat 1\nxred 0 0 0\n`;
  const rh = tryParse('ABINIT input rhombohedral', RHOMB);
  check('ABINIT input: three equal angdeg give a rhombohedral cell with every angle 60',
    rh && ['alpha', 'beta', 'gamma'].every(k => near(cellParams(rh.cell)[k], 60, 1e-6)) && near(cellParams(rh.cell).a, 5, 1e-9),
    rh ? JSON.stringify(cellParams(rh.cell)) : '');

  const AB_OUT = `.Version 9.6.2 of ABINIT
.(MPI version, prepared for a x86_64_linux_gnu9.3 computer)

.Copyright (C) 1998-2021 ABINIT group .

 -outvars: echo values of preprocessed input variables --------
            acell      1.8897261246E+01  1.8897261246E+01  1.8897261246E+01 Bohr
              amu      1.59994000E+01  1.00794000E+00
             ecut      2.00000000E+01 Hartree
-          fftalg         312
           ionmov           2
            natom           3
           ntypat           2
            rprim      1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
                       0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
            typat      1  2  2
           xangst      9.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       9.9580000000E+00  0.0000000000E+00  0.0000000000E+00
                       8.7600000000E+00  9.2700000000E-01  0.0000000000E+00
            xcart      1.7007535196E+01  0.0000000000E+00  0.0000000000E+00
                       1.8817857028E+01  0.0000000000E+00  0.0000000000E+00
                       1.6553991813E+01  1.7518225896E+00  0.0000000000E+00
             xred      9.0000000000E-01  0.0000000000E+00  0.0000000000E+00
                       9.9580000000E-01  0.0000000000E+00  0.0000000000E+00
                       8.7600000000E-01  9.2700000000E-02  0.0000000000E+00
            znucl        8.00000    1.00000

================================================================================

== END DATASET(S) ==============================================================
================================================================================

 -outvars: echo values of variables after computation  --------
            acell      1.8897261246E+01  1.8897261246E+01  1.8897261246E+01 Bohr
              amu      1.59994000E+01  1.00794000E+00
             ecut      2.00000000E+01 Hartree
           etotal     -1.7234567890E+01
            fcart     -0.0000000000E+00 -0.0000000000E+00 -0.0000000000E+00
                       0.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       0.0000000000E+00  0.0000000000E+00  0.0000000000E+00
-          fftalg         312
           ionmov           2
            natom           3
           ntypat           2
            rprim      1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
                       0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
            typat      1  2  2
           xangst      0.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       9.5800000000E-01  0.0000000000E+00  0.0000000000E+00
                      -2.4000000000E-01  9.2700000000E-01  0.0000000000E+00
            xcart      0.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       1.8103218317E+00  0.0000000000E+00  0.0000000000E+00
                      -4.5354338293E-01  1.7518225896E+00  0.0000000000E+00
             xred      0.0000000000E+00  0.0000000000E+00  0.0000000000E+00
                       9.5800000000E-02  0.0000000000E+00  0.0000000000E+00
                      -2.4000000000E-02  9.2700000000E-02  0.0000000000E+00
            znucl        8.00000    1.00000

================================================================================
`;
  check('ABINIT output: recognised', sniff(AB_OUT) === 'abinit-out', String(sniff(AB_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  check('ABINIT output: the echoed variables do not tie with the output', !sniff.lastTie, JSON.stringify(sniff.lastTie));
  const o = tryParse('ABINIT output', AB_OUT);
  if (o) {
    water('ABINIT output', o);
    check('ABINIT output: the cell is 10 A from acell in bohr', o.cell && near(cellParams(o.cell).a, 10, 1e-6) && /ABINIT/.test(o.periodic || ''),
      o.cell ? cellParams(o.cell).a.toFixed(5) + ' ' + o.periodic : 'no cell');
    check('ABINIT output: says which program', o.program === 'ABINIT', o.program);
  }
}

/* ---------------------------------------------------------------- ADF / AMS (SCM)
   No file of either in the corpus. The AMS "Atoms" table header is the one the coordinator
   quoted; the old ADF "Coordinates (Cartesian)" table with bohr AND angstrom columns is the
   classic trap (read the angstrom ones); ams.log prefixes every line with two timestamps. */
{
  const AMS_OUT = ` *******************************************************************************
 *                                                                             *
 *  -------------------------------------                                      *
 *   Amsterdam Modeling Suite (AMS)              2023.101                      *
 *  -------------------------------------                                      *
 *                                                                             *
 *******************************************************************************

 AMS 2023.101  RunTime: Sep12-2026 10:00:00  ShM Nodes: 1  Procs: 8

 --------
 Geometry
 --------
 Formula: H2O

 Atoms
       Index Symbol   x (angstrom)   y (angstrom)   z (angstrom)
           1      O     9.00000000     0.00000000     0.00000000
           2      H     9.95800000     0.00000000     0.00000000
           3      H     8.76000000     0.92700000     0.00000000

 Total System Charge             0.00000

 Geometry optimization started
 Optimization step 1
 Energy (hartree)          -0.36000000

 Geometry optimization converged

 Optimized geometry:
 Formula: H2O

 Atoms
       Index Symbol   x (angstrom)   y (angstrom)   z (angstrom)
           1      O     0.00000000     0.00000000     0.00000000
           2      H     0.95800000     0.00000000     0.00000000
           3    H.1    -0.24000000     0.92700000     0.00000000

 Total System Charge             0.00000

 Energy (hartree)          -0.36578990
`;
  check('AMS output: recognised', sniff(AMS_OUT) === 'adf-out', String(sniff(AMS_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  check('AMS output: the echoed input blocks do not tie with the output', !sniff.lastTie, JSON.stringify(sniff.lastTie));
  const r = tryParse('AMS output', AMS_OUT);
  if (r) {
    water('AMS output', r);
    check('AMS output: a symbol with a suffix (H.1) is still hydrogen', r.atoms[2].elem === 'H', r.atoms[2].elem);
    check('AMS output: the last energy goes into the note as text', /-0\.36578990/.test(r.note) && /hartree/i.test(r.note), r.note);
    check('AMS output: says which program', r.program === 'AMS/ADF', r.program);
    check('AMS output: a molecule is not periodic', !r.periodic && !r.cell, String(r.periodic));
  }
  /* ams.log: the same lines with "<date> <time>  " in front of every one */
  const log = AMS_OUT.split('\n').map(l => `<Sep12-2026> <10:00:02>  ${l}`).join('\n');
  const lg = tryParse('ams.log with timestamps', log);
  check('AMS ams.log: the timestamp prefix on every line is stepped over', lg && lg.atoms.length === 3 && Math.abs(lg.atoms[0].x) < 1e-9 && /-0\.36578990/.test(lg.note),
    lg ? lg.atoms.length + ' atoms, ' + lg.note : '');
  /* periodic: the driver prints the lattice next to the atoms */
  const slab = AMS_OUT.replace(/ Total System Charge             0\.00000\n\n Energy/, ` Lattice vectors (angstrom)
     1     2.50000000     0.00000000     0.00000000
     2     0.00000000     2.50000000     0.00000000
     3     0.00000000     0.00000000     2.50000000

 Total System Charge             0.00000

 Energy`);
  const p = tryParse('AMS periodic output', slab);
  check('AMS output: "Lattice vectors (angstrom)" give the cell and the structure is periodic',
    p && p.cell && near(cellParams(p.cell).a, 2.5, 1e-9) && /AMS|ADF/.test(p.periodic || ''), p ? JSON.stringify(p.cell) + ' ' + p.periodic : '');

  const ADF_OLD = ` *******************************************************************************
 *                                                                             *
 *  -------------------------------------                                      *
 *   Amsterdam Density Functional  (ADF)         2017.113                      *
 *  -------------------------------------                                      *
 *******************************************************************************

 Coordinates (Cartesian)
 =======================

   Atom                      bohr                                 angstrom                 Geometric Variables
                   X           Y           Z               X           Y           Z       (0):fixed, (1):free
 -------------------------------------------------------------------------------------------------------------
   1 O       17.007535    0.000000    0.000000        9.000000    0.000000    0.000000        1   1   1
   2 H       18.817857    0.000000    0.000000        9.958000    0.000000    0.000000        1   1   1
   3 H       16.553992    1.751823    0.000000        8.760000    0.927000    0.000000        1   1   1
 -------------------------------------------------------------------------------------------------------------

 Total Bonding Energy:            -0.36000000 a.u.       -9.7961 eV      -225.90 kcal/mol

 Coordinates (Cartesian)
 =======================

   Atom                      bohr                                 angstrom                 Geometric Variables
                   X           Y           Z               X           Y           Z       (0):fixed, (1):free
 -------------------------------------------------------------------------------------------------------------
   1 O        0.000000    0.000000    0.000000        0.000000    0.000000    0.000000        1   1   1
   2 H        1.810322    0.000000    0.000000        0.958000    0.000000    0.000000        1   1   1
   3 H       -0.453543    1.751823    0.000000       -0.240000    0.927000    0.000000        1   1   1
 -------------------------------------------------------------------------------------------------------------

 Total Bonding Energy:            -0.36578990 a.u.       -9.9536 eV      -229.54 kcal/mol
`;
  check('old ADF output: recognised', sniff(ADF_OLD) === 'adf-out', String(sniff(ADF_OLD)));
  const o = tryParse('old ADF output', ADF_OLD);
  if (o) {
    water('old ADF output', o);
    check('old ADF output: the ANGSTROM columns are read, not the bohr ones beside them',
      near(dist(o.atoms[0], o.atoms[1]), 0.958, 1e-6), dist(o.atoms[0], o.atoms[1]).toFixed(4) + ' A');
    check('old ADF output: Total Bonding Energy goes into the note', /-0\.36578990/.test(o.note), o.note);
  }
  /* the older ATOMS table: symbol, x y z in angstrom, then the nuclear CHARGE in a.u. — so a
     shouting label CO with charge 6 is carbon here too */
  const ATOMS = ` Amsterdam Density Functional  (ADF)

 ATOMS
 =====
                            X Y Z                    CHARGE
                        (Angstrom)                     (a.u.)
    1  CO           0.000000    0.000000    0.000000      6.00
    2  O            1.128000    0.000000    0.000000      8.00
`;
  const a = tryParse('old ADF ATOMS table', ATOMS);
  check('old ADF output: the ATOMS table is read in angstrom and CO with charge 6 is carbon',
    a && a.atoms.map(x => x.elem).join('') === 'CO' && near(a.atoms[1].x, 1.128, 1e-9), a ? a.atoms.map(x => x.elem).join('') : '');

  const AMS_IN = `Task GeometryOptimization

System
  Atoms
    O   9.0 0.0 0.0
    H   9.958 0.0 0.0
    H   8.76 0.927 0.0
  End
End

System
  Atoms [Bohr]
    O    0.00000000   0.00000000   0.00000000
    H    1.81032183   0.00000000   0.00000000  adf.f=frag1
    H.1 -0.45354338   1.75182259   0.00000000
  End
  Lattice [Bohr]
    18.897261 0.0 0.0
    0.0 18.897261 0.0
    0.0 0.0 18.897261
  End
End

Engine ADF
  Basis
    Type DZP
  End
EndEngine
`;
  check('AMS input: recognised', sniff(AMS_IN) === 'adf-in', String(sniff(AMS_IN)));
  const i = tryParse('AMS input', AMS_IN);
  if (i) {
    water('AMS input', i);
    check('AMS input: "Atoms [Bohr]" is honoured and said, a key=value after the coordinates is ignored', /bohr/.test(i.note), i.note);
    check('AMS input: the Lattice block gives a periodic cell, in bohr here', i.cell && near(cellParams(i.cell).a, 10, 1e-4) && /AMS|ADF/.test(i.periodic || ''),
      i.cell ? cellParams(i.cell).a.toFixed(4) + ' ' + i.periodic : 'no cell');
    check('AMS input: says which program', i.program === 'AMS/ADF input', i.program);
  }
  const ADF_RUN = `TITLE water
ATOMS
  1 O   0.0 0.0 0.0
  2 H   0.958 0.0 0.0
  3 H  -0.24 0.927 0.0
END
BASIS
  type DZP
END
`;
  const old = tryParse('old ADF .run input', ADF_RUN);
  check('old ADF input: an ATOMS block with an index column reads', old && old.atoms.length === 3 && old.atoms[1].x === 0.958, old ? old.atoms.length + ' atoms' : '');
  check('AMS input: a Z-matrix ATOMS block is refused with a plain message',
    /Z-matrix/i.test(thrown('ATOMS ZMatrix\n 1 O 0 0 0\n 2 H 1 0 0 0.96\n 3 H 1 2 0 0.96 104.5\nEND\n')),
    thrown('ATOMS ZMatrix\n 1 O 0 0 0\n 2 H 1 0 0 0.96\n 3 H 1 2 0 0.96 104.5\nEND\n'));
  /* no shadowing: a mention is a mention */
  const gIn = GAUSSIAN_IN.replace('water optimisation', 'ADF comparison, also run in Jaguar and AMS');
  check('a Gaussian input whose title mentions ADF, AMS and Jaguar is still a Gaussian input', sniff(gIn) === 'gaussian-in',
    String(sniff(gIn)) + ' ' + JSON.stringify(sniff.lastScores));
  const gOut = GAUSSIAN.replace('Normal termination', 'compare with ADF and Jaguar\n Normal termination');
  check('a Gaussian output that mentions ADF and Jaguar is still a Gaussian output', sniff(gOut) === 'gaussian-out' && !sniff.lastTie,
    String(sniff(gOut)) + ' ' + JSON.stringify(sniff.lastScores));
}

/* ---------------------------------------------------------------- Jaguar (Schrödinger)
   Written from memory of the format: geometry blocks headed "Input geometry:" / "new
   geometry:" / "final geometry:", a unit line, an "atom x y z" header, then rows whose atom
   label is the symbol plus a number (C1, H12, Fe1). The energy is on the SCFE line. */
{
  const JAG_OUT = `Job water started on node01 at Fri Sep 12 10:00:00 2026
 jobid: water

  Jaguar version 11.9, release 013
  Copyright (c) 2023 Schrodinger, LLC. All rights reserved.

  Input geometry:
  angstroms
  atom               x                 y                 z
  O1              9.0000000000      0.0000000000      0.0000000000
  H2              9.9580000000      0.0000000000      0.0000000000
  H3              8.7600000000      0.9270000000      0.0000000000

 SCFE:    SCF energy: DFT(b3lyp)      -76.4000000000 hartrees   iterations:  12

  new geometry:
  angstroms
  atom               x                 y                 z
  O1              0.1000000000      0.0000000000      0.0000000000
  H2              1.0580000000      0.0000000000      0.0000000000
  H3             -0.1400000000      0.9270000000      0.0000000000

 SCFE:    SCF energy: DFT(b3lyp)      -76.4100000000 hartrees   iterations:   9

  final geometry:
  angstroms
  atom               x                 y                 z
  O1              0.0000000000      0.0000000000      0.0000000000
  H2              0.9580000000      0.0000000000      0.0000000000
  H3             -0.2400000000      0.9270000000      0.0000000000

 SCFE:    SCF energy: DFT(b3lyp)      -76.4193587012 hartrees   iterations:   8
`;
  check('Jaguar output: recognised', sniff(JAG_OUT) === 'jaguar-out', String(sniff(JAG_OUT)) + ' ' + JSON.stringify(sniff.lastScores));
  const r = tryParse('Jaguar output', JAG_OUT);
  if (r) {
    water('Jaguar output', r);
    check('Jaguar output: labels O1 H2 H3 are typed from their leading letters', r.atoms.map(a => a.elem).join('') === 'OHH', r.atoms.map(a => a.elem).join(''));
    check('Jaguar output: the last SCFE energy goes into the note', /-76\.4193587012/.test(r.note) && /hartree/i.test(r.note), r.note);
    check('Jaguar output: says the final geometry was taken', /final/i.test(r.note), r.note);
    check('Jaguar output: says which program', r.program === 'Jaguar', r.program);
  }
  const fe = JAG_OUT.replace('  O1              0.0000000000      0.0000000000      0.0000000000\n  H2              0.9580000000',
                             '  Fe1             0.0000000000      0.0000000000      0.0000000000\n  CL2             0.9580000000');
  const f = tryParse('Jaguar output with Fe1 and CL2', fe);
  check('Jaguar output: Fe1 is iron (not fluorine) and CL2 is chlorine', f && f.atoms[0].elem === 'Fe' && f.atoms[1].elem === 'Cl',
    f ? f.atoms.map(a => a.elem).join(',') : '');
  const JAG_IN = `&gen
basis=6-31g**
dftname=b3lyp
igeopt=1
&
&zmat
O1   0.0000000000   0.0000000000   0.0000000000
H2   0.9580000000   0.0000000000   0.0000000000
H3  -0.2400000000   0.9270000000   0.0000000000
&
`;
  check('Jaguar input: recognised', sniff(JAG_IN) === 'jaguar-in', String(sniff(JAG_IN)));
  const i = tryParse('Jaguar input', JAG_IN);
  if (i) {
    water('Jaguar input', i);
    check('Jaguar input: &gen is ignored and says which program', i.program === 'Jaguar input', i.program);
  }
  const zm = '&gen\nbasis=6-31g**\n&\n&zmat\nO1\nH2  O1  0.96\nH3  O1  0.96  H2  104.5\n&\n';
  check('Jaguar input: a genuine Z-matrix with connectivity is refused with a plain message', /Z-matrix/i.test(thrown(zm)), thrown(zm));
  /* &zmat2 (the product of a QST search) is another block; the primary &zmat is the one shown */
  const qst = JAG_IN + '&zmat2\nO1  5.0 0.0 0.0\nH2  5.958 0.0 0.0\nH3  4.76 0.927 0.0\n&\n';
  const q = tryParse('Jaguar input with &zmat2', qst);
  check('Jaguar input: &zmat2 does not replace &zmat', q && Math.abs(q.atoms[0].x) < 1e-9, q ? 'x = ' + q.atoms[0].x : '');
}

/* ============================== TWO MORE WRITERS: pw.x and ABINIT inputs
   Round trip: written by the writer, read back by the reader above, same atoms and same
   cell to 1e-6. Frozen atoms become if_pos 0 0 0 in pw.x and natfix/iatfix in ABINIT. */
{
  const atoms = [{ elem: 'O', x: 0, y: 0, z: 0 }, { elem: 'H', x: 0.958, y: 0, z: 0 }, { elem: 'H', x: -0.24, y: 0.927, z: 0 },
                 { elem: 'Fe', x: 2.5, y: 2.5, z: 2.5 }];
  const cell = { a: [10, 0, 0], b: [1, 9, 0], c: [0.5, 0.5, 8] };
  const same = (r) => r.atoms.length === atoms.length &&
    atoms.every((a, i) => r.atoms[i].elem === a.elem && dist(r.atoms[i], a) < 1e-6) &&
    ['a', 'b', 'c'].every(k => r.cell[k].every((v, j) => Math.abs(v - cell[k][j]) < 1e-6));
  check('WRITERS has qe and abinit', typeof WRITERS.qe === 'function' && typeof WRITERS.abinit === 'function');

  const qe = WRITERS.qe(atoms, cell, { frozen: new Set([0, 3]), title: 'water+fe' });
  check('qe: the file is a pw.x input with every card', /&CONTROL/i.test(qe) && /&SYSTEM/i.test(qe) && /&ELECTRONS/i.test(qe) &&
    /ATOMIC_SPECIES/.test(qe) && /CELL_PARAMETERS angstrom/.test(qe) && /ATOMIC_POSITIONS angstrom/.test(qe) && /K_POINTS gamma/.test(qe), qe.slice(0, 200));
  check('qe: calculation is relax when atoms are frozen, ibrav 0, nat and ntyp counted',
    /calculation\s*=\s*'relax'/.test(qe) && /ibrav\s*=\s*0/.test(qe) && /nat\s*=\s*4/.test(qe) && /ntyp\s*=\s*3/.test(qe), qe.slice(0, 300));
  check('qe: frozen atoms carry if_pos 0 0 0 and the others 1 1 1',
    /^\s*O\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+\s+0 0 0\s*$/m.test(qe) && /^\s*H\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+\s+1 1 1\s*$/m.test(qe) &&
    /^\s*Fe\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+\s+0 0 0\s*$/m.test(qe), qe.split('ATOMIC_POSITIONS')[1]);
  check('qe: species lines carry a mass and a .UPF placeholder', /^\s*Fe\s+55\.845\s+Fe\.UPF/m.test(qe), (qe.match(/^\s*Fe\s.*UPF.*$/m) || [''])[0]);
  const rq = tryParse('qe round trip', qe);
  check('qe: reads back to the same atoms and cell', rq && same(rq), rq ? JSON.stringify(rq.cell) : '');
  const qeNoCell = WRITERS.qe(atoms.slice(0, 3), null, {});
  check('qe: without a cell a 15 A box is invented and the file says so',
    /calculation\s*=\s*'scf'/.test(qeNoCell) && /15\.0+\s+0\.0+\s+0\.0+/.test(qeNoCell) && /invented/i.test(qeNoCell), qeNoCell.slice(0, 300));
  const rn = tryParse('qe round trip without a cell', qeNoCell);
  check('qe: and that box reads back', rn && near(cellParams(rn.cell).a, 15, 1e-9) && rn.atoms.length === 3, rn ? JSON.stringify(rn.cell) : '');

  const ab = WRITERS.abinit(atoms, cell, { frozen: [1, 2] });
  check('abinit: acell 1 1 1 Angstrom, explicit rprim, natom, ntypat, znucl, typat, xangst, ecut placeholder',
    /^\s*acell\s+1(\.0+)?\s+1(\.0+)?\s+1(\.0+)?\s+Angstrom/m.test(ab) && /^\s*rprim\b/m.test(ab) && /^\s*natom\s+4\b/m.test(ab) &&
    /^\s*ntypat\s+3\b/m.test(ab) && /^\s*znucl\s+8\s+1\s+26\b/m.test(ab) && /^\s*typat\s+1\s+2\s+2\s+3\b/m.test(ab) &&
    /^\s*xangst\b/m.test(ab) && /^\s*ecut\s+20\b/m.test(ab), ab);
  check('abinit: frozen atoms become natfix and 1-based iatfix', /^\s*natfix\s+2\b/m.test(ab) && /^\s*iatfix\s+2\s+3\b/m.test(ab), ab);
  const ra = tryParse('abinit round trip', ab);
  check('abinit: reads back to the same atoms and cell', ra && same(ra), ra ? JSON.stringify(ra.cell) : '');
  const abNoCell = WRITERS.abinit(atoms.slice(0, 3), null, {});
  check('abinit: without a cell the same invented box, said so, and no natfix', /invented/i.test(abNoCell) && !/natfix/.test(abNoCell), abNoCell);
  const ran = tryParse('abinit round trip without a cell', abNoCell);
  check('abinit: and that box reads back', ran && near(cellParams(ran.cell).a, 15, 1e-9) && ran.atoms.length === 3, ran ? JSON.stringify(ran.cell) : '');
}

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
