#!/bin/sh
# Build the two archives for a release, from the working tree.
#
#   sh package.sh 0.7.4 13
#
# TWO archives, deliberately different, and they must never be confused:
#
#   2D-WORM_v<ver>_build<n>_server.zip   what goes on the web server. The application plus
#                                        the built Ketcher assets. No test suite, no build
#                                        sources, no repository files.
#   2DWORM_github_repo_v<ver>.zip        what goes in the repository. Sources, tests and the
#                                        Ketcher build project; the built assets are left out
#                                        because they are rebuilt from ketcher-build.
#
# NEITHER may contain: config.php (it holds the administrator's password hash), the live
# database, .admin-enabled, or the geo CSV. Those are the operator's, they live only on the
# server, and a secret that has been committed once has to be changed, not merely deleted.
# The check at the end fails the build rather than trusting this comment.
set -e
VER="$1"; BUILD="$2"
[ -n "$VER" ] && [ -n "$BUILD" ] || { echo "usage: sh package.sh <version> <build>"; exit 2; }
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${OUT:-/mnt/user-data/outputs}
WORK=$(mktemp -d)
# zip ADDS to an archive that already exists, so a file dropped from the build would still be
# in the zip from last time. Start from nothing.
rm -f "${OUT:-/mnt/user-data/outputs}/2D-WORM_v${VER}_build${BUILD}_server.zip" "${OUT:-/mnt/user-data/outputs}/2DWORM_github_repo_v${VER}.zip"
mkdir -p "$OUT"

SECRET='QRsharing/config.php QRsharing/data/*.sqlite* QRsharing/geo/*.csv .admin-enabled'

# ---------------------------------------------------------------- the server archive
mkdir -p "$WORK/server"
cp -a "$ROOT/2dworm" "$WORK/server/2dworm"
cd "$WORK/server/2dworm"
rm -f $SECRET .gitignore
rm -rf out test-results
find . -name '*.log' -delete
find . -name '.DS_Store' -delete
cd "$WORK/server"
zip -qr "$OUT/2D-WORM_v${VER}_build${BUILD}_server.zip" 2dworm

# ---------------------------------------------------------------- the repository archive
mkdir -p "$WORK/repo/2DWORM"
cp -a "$ROOT/2dworm" "$WORK/repo/2DWORM/2dworm"
cp -a "$ROOT/2dworm-test" "$WORK/repo/2DWORM/2dworm-test"
mkdir -p "$WORK/repo/2DWORM/ketcher-build"
for f in vite.config.js index.html package.json package-lock.json src public test; do
  [ -e "$ROOT/ketcher-build/$f" ] && cp -a "$ROOT/ketcher-build/$f" "$WORK/repo/2DWORM/ketcher-build/"
done
cd "$WORK/repo/2DWORM/2dworm"
rm -f $SECRET
# the built third-party bundles are attached to a release, not committed: Ketcher is 17 MB
# and Mol* is 5 MB, and both are reproducible from a pinned version.
rm -rf ketcher/assets ketcher/index.html molstar out test-results
find . -name '*.log' -delete
cd "$WORK/repo/2DWORM/2dworm-test"
rm -rf out figures node_modules test-results
find . -name '*.log' -delete
# one-off probes written while chasing a particular bug: they hold hard-coded paths and prove
# nothing to anybody else. The suites, the two runner scripts and the reference data go in.
KEEP='test qcgeom mdgeom qcresults crystal names sellang session fragments pmodel ppbc periodic frame cube geo reps fetchdb field lang admin settings counts edit notes vr server qcopen select build24 build25 build26 build27 build28 terms uff bench bigmol memory uff-cross figures perf make-coastlines strings'
for f in *.mjs; do
  base=${f%.mjs}; keep=0
  for k in $KEEP; do [ "$base" = "$k" ] && keep=1; done
  [ "$keep" = 1 ] || rm -f "$f"
done
rm -f ketcher-test.html
# the test corpus goes in, except the cube files: four of them are 103 MB of one research
# group's density grids, which the repository has no business carrying. The suites that use
# them say SKIP when a corpus file is absent.
find corpus -name '*.cub' -delete
find corpus -name '*.cube' -delete
cd "$WORK/repo"
zip -qr "$OUT/2DWORM_github_repo_v${VER}.zip" 2DWORM

# ---------------------------------------------------------------- refuse to ship a secret
fail=0
for z in "$OUT/2D-WORM_v${VER}_build${BUILD}_server.zip" "$OUT/2DWORM_github_repo_v${VER}.zip"; do
  bad=$(unzip -Z1 "$z" | grep -E 'config\.php$|\.sqlite|\.admin-enabled|geo/.*\.csv|node_modules/' || true)
  if [ -n "$bad" ]; then echo "REFUSED: $z contains"; echo "$bad"; fail=1; fi
done
[ "$fail" = 0 ] || { rm -f "$OUT/2D-WORM_v${VER}_build${BUILD}_server.zip" "$OUT/2DWORM_github_repo_v${VER}.zip"; exit 1; }

ls -l "$OUT/2D-WORM_v${VER}_build${BUILD}_server.zip" "$OUT/2DWORM_github_repo_v${VER}.zip"
rm -rf "$WORK"
