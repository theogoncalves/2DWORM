/* The sharing service: three stores, the enforced wait, and the admin gate.
   The security checks are the point of this file — a store that prunes badly is an
   annoyance, an admin page that opens without a password is a different matter. */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const ROOT = APP;
const PORT = 8781;
const BASE = `http://127.0.0.1:${PORT}`;
const API  = `${BASE}/QRsharing/share.php`;
const ADMIN = `${BASE}/QRsharing/admin.php`;
const DATA = path.join(ROOT, 'QRsharing/data');
const SWITCH = path.join(ROOT, 'QRsharing/.admin-enabled');
const CONFIG = path.join(ROOT, 'QRsharing/config.php');

let cookie = '';                       // the admin session, once there is one
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/* a clean slate — the shares database AND the featured one — and a config with a known
   password and a 2-second wait so the test can prove the wait is enforced without sitting
   here for twenty */
for (const f of fs.readdirSync(DATA)) if (/^(shares|featured)\.sqlite/.test(f)) fs.rmSync(path.join(DATA, f));
const PASSWORD = 'correct horse battery staple';
const hash = spawn('php', ['-r', `echo password_hash(${JSON.stringify(PASSWORD)}, PASSWORD_DEFAULT);`]);
let hashOut = '';
hash.stdout.on('data', d => { hashOut += d; });
await new Promise(r => hash.on('close', r));
const hadConfig = fs.existsSync(CONFIG);
const oldConfig = hadConfig ? fs.readFileSync(CONFIG, 'utf8') : null;
/* A bcrypt hash is full of $ signs. Written into a double-quoted PHP string they are
   interpolated as variables and the hash silently becomes rubbish — which is exactly what
   happened the first time this test ran. Single quotes, and escape what single quotes need. */
const phpStr = (v) => "'" + v.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";
fs.writeFileSync(CONFIG, `<?php return [
  'admin_hash' => ${phpStr(hashOut.trim())},
  'admin_max_tries' => 3,
  'small_max_bytes' => 2048,
  'large_max_bytes' => 20000,
  'large_wait' => 2,
  /* The shipped defaults are 10 s for an ordinary drawing and 60 s for a large one. Both are
     shortened here rather than switched off, so that every check goes through the real ticket
     path instead of a special case that only exists in the tests. */
  'small_wait' => 1,
  'small_max_rows' => 6,
  'large_per_hour' => 50,
];\n`);

const oldConfigForTest = fs.readFileSync(CONFIG, 'utf8');

/* PHP's own upload ceilings are raised for this server so that a 60 MB upload REACHES
   admin.php and it is keep_max_bytes that refuses it, which is the check being made; the
   shipped php.ini would throw the body away first and prove nothing about our code. A second
   server further down keeps the small ceiling, to check that case is explained too. */
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', ROOT, '-d', 'upload_max_filesize=128M', '-d', 'post_max_size=128M'],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const payload = (n, tag = 'a') => 'z=' + tag + 'A'.repeat(Math.max(8, n - 2 - tag.length));
/** exactly what the server said, with nothing done about it – for the wait checks themselves */
async function postRaw(body, headers = {}) {
  const r = await fetch(API, { method: 'POST', body, headers });
  let j = null; try { j = await r.json(); } catch {}
  return { status: r.status, json: j };
}
/** what the page does: take the ticket, sit out the wait, send it back. Every other check
    here is about storing and retrieving, so it should not have to know about the ticket. */
async function post(body, headers = {}) {
  let r = await postRaw(body, headers);
  if (r.status === 202 && r.json && r.json.error === 'wait' && r.json.ticket) {
    await sleep((r.json.wait | 0) * 1000 + 400);
    r = await postRaw(body, { ...headers, 'X-DW-Ticket': r.json.ticket });
  }
  return r;
}

/* ------------------------------------------------------------------- status */
{
  const r = await fetch(API + '?status');
  const j = await r.json();
  check('status reports the service and both size limits',
    j.service === '2dworm-qrsharing' && j.small_bytes === 2048 && j.max_bytes === 20000 && j.wait === 2 && j.small_wait === 1,
    JSON.stringify({ v: j.version, small: j.small_bytes, max: j.max_bytes, wait: j.wait, sw: j.small_wait }));
}

/* -------------------------------------------------------------- small store */
let smallKey = '';
{
  const asked = await postRaw(payload(500, 's1'));
  check('even an ordinary drawing is asked to wait, with a signed ticket',
    asked.status === 202 && asked.json.error === 'wait' && asked.json.wait === 1 && !!asked.json.ticket,
    JSON.stringify({ s: asked.status, w: asked.json && asked.json.wait }));
  const tooSoon = await postRaw(payload(500, 's1'), { 'X-DW-Ticket': asked.json.ticket });
  check('and sending it straight back is refused: the wait is real, not a countdown in the browser',
    tooSoon.status === 202 && /seconds have passed/.test(tooSoon.json.message), tooSoon.json && tooSoon.json.message);
  const r = await post(payload(500, 's1'));
  smallKey = r.json && r.json.key;
  check('after the wait it is stored, in the small store', r.status === 201 && r.json.store === 'small', JSON.stringify(r.json));
  const back = await (await fetch(API + '?k=' + smallKey)).json();
  check('and comes back unchanged', back.ok && back.payload === payload(500, 's1'));
  const again = await post(payload(500, 's1'));
  check('the same drawing keeps its key', again.json.key === smallKey && again.json.deduped === true);
}

/* ------------------------------------------------- large store: the 20 s wait */
{
  const big = payload(9000, 'L1');
  const first = await postRaw(big);
  check('a large drawing is not stored on the first try', first.status === 202 && first.json.error === 'wait',
    JSON.stringify({ s: first.status, e: first.json && first.json.error, w: first.json && first.json.wait }));
  check('it comes back with a ticket and the wait', !!first.json.ticket && first.json.wait === 2);

  const tooSoon = await postRaw(big, { 'X-DW-Ticket': first.json.ticket });
  check('sending it straight back is refused: the wait is real, not a countdown in the browser',
    tooSoon.status === 202 && /seconds have passed/.test(tooSoon.json.message), tooSoon.json && tooSoon.json.message);

  const forged = await postRaw(big, { 'X-DW-Ticket': (Math.floor(Date.now() / 1000) - 999) + '.' + 'f'.repeat(32) });
  check('a forged ticket is refused', forged.status === 202 && /not for this drawing|malformed/.test(forged.json.message),
    forged.json && forged.json.message);

  // a ticket issued for one drawing must not store another
  const other = payload(9000, 'L2');
  await sleep(2200);
  const wrongDrawing = await postRaw(other, { 'X-DW-Ticket': first.json.ticket });
  check('a ticket cannot be reused for a different drawing',
    wrongDrawing.status === 202 && /not for this drawing/.test(wrongDrawing.json.message),
    wrongDrawing.json && wrongDrawing.json.message);

  const ok = await postRaw(big, { 'X-DW-Ticket': first.json.ticket });
  check('after the wait it is stored, in the large store', ok.status === 201 && ok.json.store === 'large',
    JSON.stringify(ok.json));
}

/* -------------------------------------------------------------------- limits */
{
  const huge = payload(30000, 'X');
  const r = await post(huge);
  check('a drawing over the hard limit is refused', r.status === 413 && r.json.error === 'too_large', JSON.stringify(r.json));
  const junk = await post('not a 2dworm payload at all');
  check('something that is not a 2D-WORM payload is refused', junk.status === 400 && junk.json.error === 'bad_payload');
  const bad = await (await fetch(API + '?k=' + encodeURIComponent("' OR 1=1--"))).json();
  check('a malformed key is refused rather than reaching the database', bad.error === 'bad_key');
  const gone = await fetch(API + '?k=zzzzzzzz');
  check('an unknown key is a clean 404', gone.status === 404);
}

/* ------------------------------------------------------------------- pruning
   small_max_rows is 6 in this run. Pruning runs on one write in twenty by design, so the
   test asks for it directly through the admin page rather than writing until it happens. */
async function prunePlease() {
  const had = fs.existsSync(SWITCH);
  if (!had) fs.writeFileSync(SWITCH, '');
  const page = await (await fetch(ADMIN, { headers: cookie ? { Cookie: cookie } : {} })).text();
  const t = (page.match(/name="csrf" value="([0-9a-f]+)"/) || [])[1];
  if (t) {
    await fetch(ADMIN, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie }, body: 'do=prune&csrf=' + t });
  } else {
    // not logged in yet: prune through PHP directly, which is what the service does anyway
    await new Promise((res) => {
      const p = spawn('php', ['-r', `require ${JSON.stringify(ROOT + '/QRsharing/lib/core.php')}; $c=dw_config(); dw_prune(dw_db($c), $c);`]);
      p.on('close', res);
    });
  }
  if (!had) fs.rmSync(SWITCH, { force: true });
}
{
  for (let i = 0; i < 10; i++) await post(payload(300, 'p' + i));
  await fetch(API + '?status');
  const r = await post(payload(300, 'pz'));
  check('the small store prunes itself to its row limit', r.status === 201,
    JSON.stringify({ s: r.status, j: r.json }));
  await prunePlease();
  const count = await new Promise((res) => {
    const p = spawn('php', ['-r', `$d=new PDO('sqlite:${path.join(DATA, 'shares.sqlite')}');echo $d->query('SELECT COUNT(*) FROM shares WHERE store="small"')->fetchColumn();`]);
    let o = ''; p.stdout.on('data', d => { o += d; }); p.on('close', () => res(parseInt(o, 10)));
  });
  check('and the oldest went, not the newest', count <= 8, 'rows now ' + count);
  const large = await new Promise((res) => {
    const p = spawn('php', ['-r', `$d=new PDO('sqlite:${path.join(DATA, 'shares.sqlite')}');echo $d->query('SELECT COUNT(*) FROM shares WHERE store="large"')->fetchColumn();`]);
    let o = ''; p.stdout.on('data', d => { o += d; }); p.on('close', () => res(parseInt(o, 10)));
  });
  check('pruning the small store leaves the large one alone', large === 1, 'large rows ' + large);
}

/* --------------------------------------------------------------- admin gate */
fs.rmSync(SWITCH, { force: true });
{
  const r = await fetch(ADMIN);
  check('without .admin-enabled the admin page is a plain 404', r.status === 404, 'status ' + r.status);
  const body = await r.text();
  check('and it gives nothing away', !/password|2D-WORM sharing service —/i.test(body), body.slice(0, 60));
}
fs.writeFileSync(SWITCH, '');
{
  const r = await fetch(ADMIN);
  const body = await r.text();
  check('with the file present it asks for a password', r.status === 200 && /type="password"/.test(body));
  check('the page carries no password or hash anywhere in it', !/\$2y\$|correct horse/.test(body));
}

/* ----------------------------------------------------------- admin password */
async function login(pw) {
  const r = await fetch(ADMIN, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(cookie ? { Cookie: cookie } : {}) },
    body: 'do=login&pw=' + encodeURIComponent(pw),
  });
  const sc = r.headers.get('set-cookie');
  if (sc) cookie = sc.split(';')[0];
  return { status: r.status, body: await r.text() };
}
{
  const wrong = await login('hunter2');
  check('a wrong password is refused', /not the password/.test(wrong.body), wrong.body.match(/not the password[^<]*/)?.[0] || '');
  await login('hunter2');
  const third = await login('hunter2');
  check('after three failures the door shuts for the hour', /door is now shut|Too many failed/.test(third.body));
  const evenRight = await login(PASSWORD);
  check('and the right password does not open it while it is shut',
    !/administration/i.test(evenRight.body) || /Too many failed/.test(evenRight.body));
}
// clear the lock the way an hour would
await new Promise((res) => {
  const p = spawn('php', ['-r', `$d=new PDO('sqlite:${path.join(DATA, 'shares.sqlite')}');$d->exec("DELETE FROM meta WHERE k LIKE 'admin_tries_%'");`]);
  p.on('close', res);
});
{
  const good = await login(PASSWORD);
  // a real login redirects; the login form also contains the word "administration", so
  // matching on the text alone would pass while being logged out
  check('the right password logs in', good.status === 302, 'status ' + good.status);
  const page = await (await fetch(ADMIN, { headers: { Cookie: cookie } })).text();
  check('the admin page shows the three stores', /Small \(/.test(page) && /Large \(/.test(page) && /Permanent/.test(page));
  check('it says no address is stored', /No address is ever stored/.test(page));
  check('drawings are linked out, not rendered inside the page',
    /target="_blank"/.test(page) && !/<iframe/.test(page));
  const csrf = (page.match(/name="csrf" value="([0-9a-f]+)"/) || [])[1];
  check('every form carries a CSRF token', !!csrf);

  /* A fresh drawing for this part: the pruning test above deliberately trimmed the small
     store, and the very first drawing was its oldest, so it is gone by now. */
  const victim = await post(payload(500, 'vic'));
  const vkey = victim.json.key;

  // a state-changing action without the token must do nothing
  const noToken = await fetch(ADMIN, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: 'do=delete&key=' + vkey,
  });
  const t1 = await noToken.text();
  check('an action without the CSRF token changes nothing', /stale/.test(t1));
  const still = await fetch(API + '?k=' + vkey);
  check('and the drawing is still there', still.status === 200, 'status ' + still.status);

  // with the token it works
  await fetch(ADMIN, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: 'do=block&key=' + vkey + '&csrf=' + csrf + '&why=test',
  });
  const afterBlock = await fetch(API + '?k=' + vkey);
  check('Block deletes the drawing', afterBlock.status === 404, 'status ' + afterBlock.status);
  const reupload = await post(payload(500, 'vic'));
  check('and re-uploading the same drawing is refused', reupload.status === 403 && reupload.json.error === 'blocked',
    JSON.stringify(reupload.json));

  // the kill switch
  await fetch(ADMIN, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: 'do=offline&reason=' + encodeURIComponent('maintenance') + '&csrf=' + csrf,
  });
  const off = await post(payload(400, 'off'));
  check('the kill switch stops new drawings being stored', off.status === 503 && off.json.error === 'offline',
    JSON.stringify(off.json));
  const st = await (await fetch(API + '?status')).json();
  check('and the page is told why', st.offline === 'maintenance', JSON.stringify(st.offline));
  await fetch(ADMIN, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: 'do=offline&reason=&csrf=' + csrf,
  });
  const backOn = await post(payload(400, 'on'));
  check('and switching it back on works', backOn.status === 201);

  // backup
  const bk = await fetch(ADMIN + '?backup=1', { headers: { Cookie: cookie } });
  const buf = Buffer.from(await bk.arrayBuffer());
  check('the backup downloads a real SQLite file',
    bk.status === 200 && buf.slice(0, 15).toString() === 'SQLite format 3', `${buf.length} bytes`);
}
/* a session cookie from nowhere must not work */
{
  const r = await fetch(ADMIN, { headers: { Cookie: 'dworm_admin=made-up-session-id' } });
  const body = await r.text();
  check('an invented session cookie does not get in', /type="password"/.test(body));
}

/* ---------------------------------------------------------------- the geo table */
{
  const csv = path.join(ROOT, 'QRsharing/geo/ip2country.csv');
  fs.writeFileSync(csv, '1.0.0.0,1.0.0.255,AU\n127.0.0.0,127.255.255.255,SA\n2001:200::,2001:200:ffff:ffff:ffff:ffff:ffff:ffff,JP\n');
  const page = await (await fetch(ADMIN, { headers: { Cookie: cookie } })).text();
  const csrf = (page.match(/name="csrf" value="([0-9a-f]+)"/) || [])[1];
  const r = await fetch(ADMIN, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: 'do=geo&csrf=' + csrf,
  });
  const t = await r.text();
  check('the country table imports from a CSV', /Country table rebuilt: 3 ranges/.test(t),
    (t.match(/Country table rebuilt[^<]*/) || [])[0] || 'not rebuilt');
  await post(payload(400, 'geo1'));
  const after = await (await fetch(ADMIN, { headers: { Cookie: cookie } })).text();
  check('and a visit from 127.0.0.1 is counted against SA', /<td style="width:90px">SA<\/td>/.test(after) || /Other/.test(after),
    (after.match(/<td style="width:90px">[A-Z]{2}<\/td>/g) || []).join(','));
  fs.rmSync(csv, { force: true });
}

/* =============================== CLOSING THE STORE, WITHOUT BREAKING WHAT IS OUT THERE

   There was no way to turn the service off short of deleting the folder — and "set every
   limit to zero" does the opposite, because zero means NO LIMIT in three of them. `store_on`
   is that switch, and the whole point of it is what it does NOT stop: every QR code already
   printed on a poster goes on working, because a printed code cannot be recalled. */
{
  /* Stored through the DATABASE, the way the admin page stores it — a value saved there
     overrides config.php, so writing the file would be overridden by anything an earlier
     check happened to save and the test would pass or fail depending on its neighbours. */
  const setStore = (on) => new Promise((res) => {
    const php = `require ${JSON.stringify(ROOT + '/QRsharing/lib/core.php')}; $c=dw_config(); ` +
                `dw_set_setting(dw_db($c), 'store_on', ${on ? '1' : '0'});`;
    spawn('php', ['-r', php]).on('close', res);
  });
  const fresh = await post(payload(220, 'beforeclose'));
  const key = (fresh.json && fresh.json.key) || smallKey;
  await setStore(false);
  await sleep(300);
  const refused = await postRaw(payload(200, 'closed'));
  check('with the store closed, a new short link is refused rather than quietly failing',
    refused.status === 503 && refused.json && refused.json.error === 'store_closed',
    refused.status + ' ' + (refused.json ? refused.json.error : '?'));
  /* The message has to say what still works, or somebody reads "503" as "sharing is broken"
     and stops using the page altogether. A FULL LINK never touches this server at all. */
  check('and it says the full link still works, because that one never reaches the server',
    /FULL LINK/.test((refused.json || {}).message || ''), ((refused.json || {}).message || '').slice(0, 90));
  const still = await (await fetch(API + '?k=' + key)).json();
  check('while everything already stored still opens — a printed QR code cannot be recalled',
    still && still.ok === true, JSON.stringify(still && still.ok));
  await setStore(true);
  await sleep(300);
  const open2 = await post(payload(200, 'reopened'));
  check('and switching it back on stores again', open2.status === 201 || open2.status === 200,
    String(open2.status));
}

/* ======================================================= helpers for the last three parts
   The database is read directly, with PHP, because the endpoint's own answer is not
   evidence about what it wrote; a setting is stored the way the admin page stores it; and
   the sweep is run by hand with the clock moved, because a test that waits thirty days is
   not a test. dw_now() honours DW_FAKE_NOW only in a plain command-line PHP, so the web
   server's clock is never faked — only the sweep's. */
const php = (code, env = {}, args = []) => new Promise((res) => {
  const p = spawn('php', ['-r', code, '--', ...args], { env: { ...process.env, ...env } });
  let o = '', e = ''; p.stdout.on('data', d => { o += d; }); p.stderr.on('data', d => { e += d; });
  p.on('close', () => res((o + e).trim()));
});
const CORE = JSON.stringify(ROOT + '/QRsharing/lib/core.php');
const SHARES_DB = path.join(DATA, 'shares.sqlite');
const FEATURED_DB = path.join(DATA, 'featured.sqlite');
/* the query travels as an argument, never spliced into PHP source */
const sql = (q, db = SHARES_DB) => php(`$d=new PDO('sqlite:' . $argv[1]); foreach($d->query($argv[2]) as $r) { echo implode('|', array_slice($r, 0, count($r)/2)), "\\n"; }`, {}, [db, q]);
const setSetting = (k, v) => php(`require ${CORE}; $c=dw_config(); echo dw_set_setting(dw_db($c), ${JSON.stringify(k)}, ${JSON.stringify(v)});`);
const sweep = (at = 0) => php(`require ${CORE}; $c=dw_config(); dw_prune(dw_db($c), $c); echo 'swept';`, at ? { DW_FAKE_NOW: String(at) } : {});
const adminPage = async () => (await fetch(ADMIN, { headers: { Cookie: cookie } })).text();
const adminPost = async (fields) => {
  const csrf = ((await adminPage()).match(/name="csrf" value="([0-9a-f]+)"/) || [])[1];
  const r = await fetch(ADMIN, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ csrf, ...fields }).toString() });
  const t = await r.text();
  return { status: r.status, text: t, msg: (t.match(/class="msg [oe]">([^<]*)/) || [])[1] || '' };
};
/** the upload form, exactly as a browser posts it: multipart, with a file and its name */
const upload = async (fields, file, url = ADMIN) => {
  const csrf = ((await adminPage()).match(/name="csrf" value="([0-9a-f]+)"/) || [])[1];
  const fd = new FormData();
  fd.append('csrf', csrf);
  for (const [k, v] of Object.entries(fields)) fd.append(k, v);
  if (file) fd.append(file.field || 'file', new Blob([file.bytes]), file.name);
  const r = await fetch(url, { method: 'POST', headers: { Cookie: cookie }, body: fd });
  const t = await r.text();
  return { status: r.status, text: t, msg: (t.match(/class="msg [oe]">([^<]*)/) || [])[1] || '' };
};
const un = (s) => s.replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#039;/g, "'");
const FEATURED = `${BASE}/QRsharing/featured.php`;

/* ============================================================== THE QR SENTENCE
   The sentence the page shows beside a QR code — that a code is not permanent, who to write
   to, and the two alternatives that never expire. It is what makes the retirement rule
   below honest: it is said BEFORE the poster is printed. The exact text lives in one
   constant in core.php and is printed in TERMS.md; here the service is checked to hand it
   out, word for word, wherever a link is made. */
{
  const notice = await php(`require ${CORE}; echo DW_QR_NOTICE;`);
  const st = await (await fetch(API + '?status')).json();
  check('the status answer carries the QR sentence, word for word', st.notice === notice && notice.length > 300,
    (st.notice || '').slice(0, 60) + '…');
  check('it says a code is not permanent, gives the contact address, and names both alternatives',
    /not permanent/.test(notice) && /contact@dworm\.org/.test(notice) && /FULL LINK/.test(notice) && /SAVE SESSION/.test(notice));
  check('and it says nothing about the server or its capacity — that is never a user-facing sentence',
    !/server capacity|disk|storage|database|megabyte/i.test(notice.replace(/depend on this server/, '')));
  check('and the status says the retirement rule is off, in figures the page can show',
    st.retire_hits === 0 && st.retire_days === 0, `retire_hits ${st.retire_hits}, retire_days ${st.retire_days}`);
  const made = await post(payload(300, 'notice1'));
  check('a newly stored link carries the same sentence, so the page can show it beside the QR code',
    made.status === 201 && made.json.notice === notice, String(made.status));
  const again = await post(payload(300, 'notice1'));
  check('and so does the answer for a drawing that was already stored', again.json.deduped === true && again.json.notice === notice);
  const back = await (await fetch(API + '?k=' + made.json.key)).json();
  check('opening a drawing does not repeat it — that answer is for the reader, not the printer', back.ok === true && !('notice' in back));
}

/* ================================================================= RETIREMENT
   A code opened more than `retire_hits` times is a published resource rather than a drawing
   shared with a colleague, and the operator may decline to be its permanent host. The rule
   ships OFF. When it is on, reaching the count ARMS A TIMER and deletes nothing; the sweep
   removes the entry `retire_days` later; the permanent store is exempt at every step; and
   a retired code answers with a sentence and the contact address, never a bare 404. */
{
  /* config.php keeps the small store at 6 rows for the pruning check above; the sweeps run
     here must remove entries for their DATE and for nothing else, so the row limit is lifted
     for this part — in the database, the way the admin page would — and handed back after */
  await setSetting('small_max_rows', '1000');
  check('the rule is off unless the operator switches it on: a fresh service arms nothing',
    (await sql('SELECT COUNT(*) FROM shares WHERE retire_at IS NOT NULL')) === '0');
  check('retire_days cannot be zero — a code that goes the moment it is popular would need no timer',
    /between 1 and/.test(await setSetting('retire_days', '0')), await setSetting('retire_days', '0'));
  await setSetting('retire_hits', '3');
  await setSetting('retire_days', '1');
  const st = await (await fetch(API + '?status')).json();
  check('with the rule on, the status carries the two figures', st.retire_hits === 3 && st.retire_days === 1,
    `${st.retire_hits} opens, ${st.retire_days} days`);

  const r1 = await post(payload(300, 'retire1'));
  const k1 = r1.json.key;
  await fetch(API + '?k=' + k1); await fetch(API + '?k=' + k1);
  check('two opens of three arm nothing', (await sql(`SELECT retire_at FROM shares WHERE skey='${k1}'`)) === '',
    'retire_at = ' + (await sql(`SELECT COALESCE(retire_at,'NULL') FROM shares WHERE skey='${k1}'`)));
  const third = await fetch(API + '?k=' + k1);
  const tj = await third.json();
  const armedAt = Number(await sql(`SELECT retire_at FROM shares WHERE skey='${k1}'`));
  const now = Math.floor(Date.now() / 1000);
  check('the third open arms the timer: retire_at is now plus retire_days, and the drawing is still handed over',
    tj.ok === true && armedAt >= now + 86400 - 5 && armedAt <= now + 86400 + 5, `retire_at − now = ${armedAt - now} s`);
  check('and the answer says when, so the page can tell whoever opened it', tj.retire_at === armedAt, String(tj.retire_at));
  check('an armed drawing is no longer cached, or a cache could serve it past its date',
    /no-store/.test(third.headers.get('cache-control') || ''), third.headers.get('cache-control'));
  const page = await adminPage();
  check('the admin page says how many are scheduled to retire, and shows the date in a Retires column',
    /<b>1<\/b>\s*entry is scheduled to retire/.test(page) && /<th>Retires<\/th>/.test(page));
  await sweep();
  check('the sweep does nothing before the date', (await fetch(API + '?k=' + k1)).status === 200);
  await sweep(now + 2 * 86400);
  check('and removes the entry once the date has passed',
    (await sql(`SELECT COUNT(*) FROM shares WHERE skey='${k1}'`)) === '0' && (await sql(`SELECT skey FROM retired`)) === k1,
    'retired: ' + (await sql('SELECT skey FROM retired')));
  const gone = await fetch(API + '?k=' + k1);
  const gj = await gone.json();
  check('opening a retired code is not a bare 404: it says it was retired and who to write to',
    gone.status === 410 && gj.error === 'retired' && /retired/.test(gj.message) && /contact@dworm\.org/.test(gj.message),
    `${gone.status} ${gj.error}: ${(gj.message || '').slice(0, 70)}…`);
  check('while an unknown key is still a plain 404', (await fetch(API + '?k=neverwasakey')).status === 404);

  /* the read path honours a timer that has run out, without waiting for a sweep */
  const r2 = await post(payload(300, 'retire2'));
  const k2 = r2.json.key;
  for (let i = 0; i < 3; i++) await fetch(API + '?k=' + k2);
  await sql(`UPDATE shares SET retire_at = ${now - 60} WHERE skey='${k2}'`);
  const late = await fetch(API + '?k=' + k2);
  check('a timer that has run out is honoured by the next open itself, before any sweep',
    late.status === 410 && (await late.json()).error === 'retired' && (await sql(`SELECT COUNT(*) FROM retired WHERE skey='${k2}'`)) === '1');

  /* the permanent store is exempt: never armed, never removed */
  const r3 = await post(payload(300, 'retire3'));
  const k3 = r3.json.key;
  await adminPost({ do: 'keep', key: k3 });
  for (let i = 0; i < 5; i++) await fetch(API + '?k=' + k3);
  check('a permanent entry is never armed, however often it is opened',
    (await sql(`SELECT store || '|' || COALESCE(retire_at,'NULL') || '|' || hits FROM shares WHERE skey='${k3}'`)) === 'keep|NULL|5');
  await sweep(now + 3 * 86400);
  check('and the sweep leaves it alone', (await fetch(API + '?k=' + k3)).status === 200);
  const r4 = await post(payload(300, 'retire4'));
  const k4 = r4.json.key;
  for (let i = 0; i < 3; i++) await fetch(API + '?k=' + k4);
  check('(an entry armed for this next check)', (await sql(`SELECT retire_at FROM shares WHERE skey='${k4}'`)) !== '');
  const kept = await adminPost({ do: 'keep', key: k4 });
  check('KEEP on an armed entry cancels its timer — permanent means never retired either',
    (await sql(`SELECT COALESCE(retire_at,'NULL') FROM shares WHERE skey='${k4}'`)) === 'NULL' && /never be pruned or retired/.test(kept.msg), kept.msg);

  /* switching the rule off cancels every pending timer */
  const r5 = await post(payload(300, 'retire5'));
  const k5 = r5.json.key;
  for (let i = 0; i < 3; i++) await fetch(API + '?k=' + k5);
  check('(another one armed)', (await sql(`SELECT COUNT(*) FROM shares WHERE retire_at IS NOT NULL`)) === '1');
  const off = await adminPost({ do: 'settings', s_retire_hits: '0' });
  check('setting retire_hits back to zero cancels every pending retirement, and says so',
    (await sql('SELECT COUNT(*) FROM shares WHERE retire_at IS NOT NULL')) === '0' && /1 pending retirement was cancelled/.test(off.msg), off.msg);
  await sql(`UPDATE shares SET retire_at = ${now - 60} WHERE skey='${k5}'`);
  check('and with the rule off a leftover timer means nothing: the drawing opens', (await fetch(API + '?k=' + k5)).status === 200);
  await sweep();
  check('the sweep clears such leftovers rather than acting on them',
    (await sql(`SELECT COALESCE(retire_at,'NULL') FROM shares WHERE skey='${k5}'`)) === 'NULL' && (await sql(`SELECT COUNT(*) FROM shares WHERE skey='${k5}'`)) === '1');
  check('the retired table remembers a key and a time, and nothing else',
    (await sql("SELECT group_concat(name) FROM pragma_table_info('retired')")) === 'skey,t');
  await setSetting('retire_hits', ''); await setSetting('retire_days', ''); await setSetting('small_max_rows', '');
}

/* ============================================================ THE FEATURED LIST
   "Molecule of the day": a database of its own, filled only from the admin page, read by
   the public through featured.php. What is checked here is the public side and the two
   rules that make the upload safe: the server never opens what it is given, and the
   uploaded NAME is used for nothing — not even the attachment header. */
{
  check('(no featured database yet)', !fs.existsSync(FEATURED_DB));
  const empty = await fetch(FEATURED + '?list=1');
  const ej = await empty.json();
  check('with no featured database the list is empty, 200, and cacheable',
    empty.status === 200 && Array.isArray(ej) && ej.length === 0 && /public, max-age=300/.test(empty.headers.get('cache-control') || ''),
    empty.headers.get('cache-control'));
  check('and asking for it did not create the database: the public route never writes', !fs.existsSync(FEATURED_DB));
  check('it sets no cookie and starts no session', !empty.headers.get('set-cookie'));
  check('a key in an absent database is a 404', (await fetch(FEATURED + '?key=abcdefgh')).status === 404);
  const opensBefore = await sql("SELECT COALESCE(SUM(n),0) FROM usage_day WHERE action='open'");

  const core = fs.readFileSync(ROOT + '/QRsharing/lib/core.php', 'utf8');
  const featuredSrc = fs.readFileSync(ROOT + '/QRsharing/featured.php', 'utf8');
  check("the public reads open the file with SQLite's read-only flag, on a handle that never creates it",
    /'ro'\s*=>\s*PDO::SQLITE_OPEN_READONLY/.test(core) && (featuredSrc.match(/dw_featured_db\(\$CFG, 'ro'\)/g) || []).length === 2 &&
    !/SQLITE_OPEN_CREATE/.test(featuredSrc) && !/'admin'/.test(featuredSrc));
  check('and the hits bump is a separate read-write handle, best-effort, after the entry was read',
    (featuredSrc.match(/dw_featured_db\(\$CFG, 'rw'\)/g) || []).length === 1 && /hits = hits \+ 1/.test(featuredSrc));
  check('the server never opens an upload: no ZipArchive, no zip_open, no inflating, no parsing of the bytes',
    !/new ZipArchive|zip_open\(|gzdecode\(|gzinflate\(|simplexml|json_decode\(\$bytes/.test(fs.readFileSync(ROOT + '/QRsharing/admin.php', 'utf8')));

  /* the upload, with the worst filename that fits in a header */
  const session = Buffer.concat([Buffer.from('PK\x03\x04'), Buffer.from('a session file, as uploaded, byte for byte é')]);
  const up = await upload({ do: 'upload', dest: 'featured', title: 'Caffeine, arranged', credit: 'T. Goncalves' },
    { name: 'evil"; rm -rf.zip', bytes: session });
  check('an upload lands in the featured list under a generated key, and says so',
    /Featured as [A-Za-z0-9]{8,} — "Caffeine, arranged" \(\d+ B, session\)/.test(un(up.msg)), un(up.msg));
  const list = await (await fetch(FEATURED + '?list=1')).json();
  check('the list is a JSON array of {fkey, title, credit, kind, bytes} and nothing more',
    Array.isArray(list) && list.length === 1 && Object.keys(list[0]).sort().join(',') === 'bytes,credit,fkey,kind,title' &&
    list[0].title === 'Caffeine, arranged' && list[0].credit === 'T. Goncalves' && list[0].kind === 'session' && list[0].bytes === session.length,
    JSON.stringify(list));
  const fkey = list[0].fkey;
  check('the key is one the server made up, in its own alphabet (no 0, O, 1, l, I)',
    /^[23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ]{8}$/.test(fkey), fkey);
  const got = await fetch(FEATURED + '?key=' + fkey);
  const body = Buffer.from(await got.arrayBuffer());
  check('the entry comes back byte for byte', got.status === 200 && body.equals(session), `${body.length} bytes`);
  check('as an opaque download: application/octet-stream, nosniff, attachment',
    got.headers.get('content-type') === 'application/octet-stream' && got.headers.get('x-content-type-options') === 'nosniff' &&
    /^attachment;/.test(got.headers.get('content-disposition') || ''), got.headers.get('content-disposition'));
  const cd = got.headers.get('content-disposition') || '';
  check('the filename in the header is the KEY and the KIND — the uploaded name is not in it, not anywhere',
    cd === `attachment; filename="${fkey}.2dworm.zip"` && !/evil|rm -rf|%22/.test(cd) && !/evil/.test(await adminPage()) &&
    (await sql("SELECT COUNT(*) FROM featured WHERE title LIKE '%evil%' OR credit LIKE '%evil%'", FEATURED_DB)) === '0', cd);
  check('with its length, and cacheable for a while', got.headers.get('content-length') === String(session.length) && /max-age=300/.test(got.headers.get('cache-control') || ''));
  check('opening it bumps hits and seen in the featured database, and touches the shares database not at all',
    (await sql(`SELECT hits || '|' || (seen > 0) FROM featured WHERE fkey='${fkey}'`, FEATURED_DB)) === '1|1' &&
    (await sql(`SELECT COUNT(*) FROM shares WHERE skey='${fkey}'`)) === '0');
  await fetch(FEATURED + '?key=' + fkey);
  check('and again', (await sql(`SELECT hits FROM featured WHERE fkey='${fkey}'`, FEATURED_DB)) === '2');
  check('none of which is counted in the share statistics: the featured list is the operator\'s own material',
    (await sql("SELECT COALESCE(SUM(n),0) FROM usage_day WHERE action='open'")) === opensBefore, `opens still ${opensBefore}`);
  check('the featured database has exactly the ten columns the design names, and nothing about anybody',
    (await sql("SELECT group_concat(name) FROM pragma_table_info('featured')", FEATURED_DB)) === 'fkey,title,credit,blob,bytes,kind,created,hits,seen,enabled');

  /* a text file is text */
  const xyz = Buffer.from('2\nwater fragment\nO 0 0 0\nH 0.96 0 0\n');
  const up2 = await upload({ do: 'upload', dest: 'featured', title: 'A plain structure file' }, { name: 'frag.xyz', bytes: xyz });
  const fkey2 = (un(up2.msg).match(/Featured as ([A-Za-z0-9]+)/) || [])[1];
  const got2 = await fetch(FEATURED + '?key=' + fkey2);
  check('anything not starting with PK is kind "text", served as .txt, byte for byte',
    /\(\d+ B, text\)/.test(up2.msg) && got2.headers.get('content-disposition') === `attachment; filename="${fkey2}.txt"` &&
    Buffer.from(await got2.arrayBuffer()).equals(xyz), un(up2.msg));
  check('an upload with no title is refused for the featured list', /needs a title/.test((await upload({ do: 'upload', dest: 'featured', title: '' }, { name: 'x.xyz', bytes: xyz })).msg));
  check('and an empty file is refused', /empty/.test((await upload({ do: 'upload', dest: 'featured', title: 'nothing' }, { name: 'x.xyz', bytes: Buffer.alloc(0) })).msg));

  /* disabled entries are kept, not offered, and not enumerable */
  const tog = await adminPost({ do: 'f_toggle', fkey });
  const list2 = await (await fetch(FEATURED + '?list=1')).json();
  check('DISABLE keeps an entry but takes it off the list', /no longer offered/.test(tog.msg) && list2.length === 1 && list2[0].fkey === fkey2);
  check('and a disabled key answers exactly as a missing one', (await fetch(FEATURED + '?key=' + fkey)).status === 404);
  await adminPost({ do: 'f_toggle', fkey });
  check('ENABLE puts it back', (await (await fetch(FEATURED + '?list=1')).json()).length === 2);
  check('a malformed key is refused before it reaches the database', (await fetch(FEATURED + '?key=' + encodeURIComponent("' OR 1=1--"))).status === 400);
  check('POST is refused: nothing can be written through the public route', (await fetch(FEATURED + '?list=1', { method: 'POST', body: 'x' })).status === 405);

  /* the size limit: a 60 MB file against the shipped 50 MB, refused without being read */
  const big = Buffer.alloc(60 * 1024 * 1024, 0x78);
  const t0 = Date.now();
  const refused = await upload({ do: 'upload', dest: 'featured', title: 'too big' }, { name: 'big.2dworm.zip', bytes: big });
  check('a 60 MB upload is refused by keep_max_bytes (50 MB), before the file is read',
    refused.status === 200 && /60 MB, and the most this page stores is 50 MB/.test(refused.msg) && /was not read/.test(refused.msg),
    refused.msg.slice(0, 100) + ` (${Date.now() - t0} ms)`);
  check('and nothing was stored', (await sql('SELECT COUNT(*) FROM featured', FEATURED_DB)) === '2');

  /* PHP's own ceiling, on a server that still has it: explained, not "stale form" */
  const SMALLPORT = PORT + 1;
  const small = spawn('php', ['-S', '127.0.0.1:' + SMALLPORT, '-t', ROOT, '-d', 'post_max_size=1M', '-d', 'upload_max_filesize=1M'], { stdio: 'ignore' });
  await sleep(800);
  const dropped = await upload({ do: 'upload', dest: 'featured', title: 'two megabytes' }, { name: 'two.zip', bytes: Buffer.alloc(2 * 1024 * 1024, 0x79) },
    `http://127.0.0.1:${SMALLPORT}/QRsharing/admin.php`);
  small.kill();
  check("an upload PHP itself threw away is explained as PHP's ceiling, not as a stale form",
    /bigger than PHP on this server accepts: post_max_size is 1M/.test(dropped.msg) && !/stale/.test(dropped.msg), dropped.msg.slice(0, 90));

  /* the other destination: a permanent link, opened through share.php like any share */
  const perm = await upload({ do: 'upload', dest: 'keep', title: 'a lecture, as a file' }, { name: 'lecture.2dworm.zip', bytes: session });
  const pkey = (perm.msg.match(/Stored permanently as ([A-Za-z0-9]+)/) || [])[1];
  check('a PERMANENT upload answers with a key and a short link, as any share does',
    !!pkey && new RegExp('index\\.html\\?k=' + pkey).test(perm.msg), perm.msg.slice(0, 90));
  const pj = await (await fetch(API + '?k=' + pkey)).json();
  check('and share.php hands it back as f= plus base64, in the permanent store, saying what kind it is',
    pj.ok === true && pj.store === 'keep' && pj.kind === 'session' && pj.payload === 'f=' + session.toString('base64'),
    JSON.stringify({ store: pj.store, kind: pj.kind, head: (pj.payload || '').slice(0, 12) }));
  check('the same bytes uploaded twice are one row, promoted, not a second copy',
    /already stored as / .test((await upload({ do: 'upload', dest: 'keep', title: 'again' }, { name: 'x.zip', bytes: session })).msg) &&
    (await sql("SELECT COUNT(*) FROM shares WHERE payload LIKE 'f=%'")) === '1');
  const pub = await post('f=' + session.toString('base64'));
  check('the public endpoint refuses an f= payload: only the operator can put a file in the store',
    pub.status === 400 && pub.json.error === 'bad_payload', JSON.stringify(pub.json));
}

server.kill();
fs.rmSync(SWITCH, { force: true });
if (hadConfig) fs.writeFileSync(CONFIG, oldConfig); else fs.rmSync(CONFIG, { force: true });
for (const f of fs.readdirSync(DATA)) if (/^(shares|featured)\.sqlite/.test(f)) fs.rmSync(path.join(DATA, f));

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
