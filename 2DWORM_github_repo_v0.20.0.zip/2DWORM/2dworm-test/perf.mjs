/* Measure what actually makes a large structure slow in the 3D panel, so FAST mode
   turns off the expensive things rather than guessing. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8773;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));

function bigPdb(nRes) {
  let s = 'HEADER    TEST\n', serial = 1;
  const tpl = [['N', 'N', 0, 0, 0], ['CA', 'C', 1.45, 0, 0], ['C', 'C', 2.0, 1.4, 0], ['O', 'O', 3.2, 1.5, 0]];
  for (let r = 0; r < nRes; r++) {
    const a = r * 0.35, R = 3.5 + r * 0.02;      // a loose helix so it is not a straight line
    for (const [name, el, x, y, z] of tpl) {
      const X = x + R * Math.cos(a), Y = y + R * Math.sin(a), Z = z + r * 1.5;
      s += 'ATOM  ' + String(serial).padStart(5) + ' ' + name.padEnd(4) + ' GLY A' +
           String(r + 1).padStart(4) + '    ' + X.toFixed(3).padStart(8) + Y.toFixed(3).padStart(8) +
           Z.toFixed(3).padStart(8) + '  1.00  0.00          ' + el.padStart(2) + '\n';
      serial++;
    }
  }
  return s + 'END\n';
}

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

// time 20 renders after a small camera rotation, which is what dragging costs
await page.exposeFunction('noop', () => {});
async function timeRenders(setup) {
  return page.evaluate(async (js) => {
    eval(js);
    const v = dworm2d.viewer;
    dworm2d.applyStyle(v); v.render();
    await new Promise(r => setTimeout(r, 200));
    const t0 = performance.now();
    for (let i = 0; i < 20; i++) { v.rotate(2, 'y'); v.render(); }
    return Math.round(performance.now() - t0) / 20;
  }, setup);
}

for (const n of [250, 1000]) {
  const pdb = bigPdb(n);
  await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'perf.pdb'), pdb);
  const atoms = await page.evaluate(() => dworm2d.state3d.nAtoms);
  console.log(`\n=== ${atoms} atoms ===`);
  const cases = {
    'ball & stick, no outline, no labels': "dworm2d.opts.style='bs';dworm2d.opts.outline=0;dworm2d.opts.labels='none'",
    'ball & stick + outline 0.06':          "dworm2d.opts.style='bs';dworm2d.opts.outline=0.06;dworm2d.opts.labels='none'",
    'ball & stick + element labels':        "dworm2d.opts.style='bs';dworm2d.opts.outline=0;dworm2d.opts.labels='elem'",
    'space filling':                        "dworm2d.opts.style='cpk';dworm2d.opts.outline=0;dworm2d.opts.labels='none'",
    'wireframe (line)':                     "dworm2d.opts.style='wire';dworm2d.opts.outline=0;dworm2d.opts.labels='none'",
    'tubes':                                "dworm2d.opts.style='stick';dworm2d.opts.outline=0;dworm2d.opts.labels='none'",
  };
  for (const [name, js] of Object.entries(cases)) {
    const ms = await timeRenders(js);
    console.log(`  ${name.padEnd(38)} ${ms.toFixed(1)} ms/frame`);
  }
  // cost of applyStyle itself (per-element setStyle loop + full geometry rebuild)
  const applyMs = await page.evaluate(() => {
    dworm2d.opts.style = 'bs'; dworm2d.opts.outline = 0; dworm2d.opts.labels = 'none';
    const t0 = performance.now();
    for (let i = 0; i < 5; i++) { dworm2d.applyStyle(dworm2d.viewer); }
    return Math.round((performance.now() - t0) / 5);
  });
  console.log(`  applyStyle() (per-element loop + rebuild)   ${applyMs} ms`);
}

await browser.close(); server.kill();
