/* FIND: search a public database, bring the structure in, and share it by IDENTIFIER
   rather than by copying the coordinates.

   Two parts. The first drives lib/fetchdb.js on its own, in Node, with globalThis.fetch
   replaced per check by a function that answers the REAL urls with bodies in each service's
   own format and refuses anything else — so a wrong endpoint, a wrong query or a wrong
   parser fails here rather than in front of a user. The second drives the page in a browser
   with the same services stood in for by route interception.

   What neither part can prove is that the hosts send the CORS headers a browser needs; that
   is each server's business, and only a real browser on the open internet can check it. The
   container this runs in cannot reach any of them (its outbound proxy blocks every one), so
   every response body below is written from the service's documentation, not copied from a
   live answer — the report says so. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8786;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const failing = async (p) => { try { await p; return null; } catch (e) { return e; } };

/* ------------------------------------------------------------------ fixtures */
const CRAMBIN = `HEADER    PLANT PROTEIN                           30-APR-81   1CRN
TITLE     WATER STRUCTURE OF A HYDROPHOBIC PROTEIN AT ATOMIC RESOLUTION
ATOM      1  N   THR A   1      17.047  14.099   3.625  1.00 13.79           N
ATOM      2  CA  THR A   1      16.967  12.784   4.338  1.00 10.80           C
ATOM      3  C   THR A   1      15.685  12.755   5.133  1.00  9.19           C
ATOM      4  O   THR A   1      15.268  13.825   5.594  1.00  9.85           O
ATOM      5  H   THR A   1      17.130  14.925   4.219  1.00  0.00           H
ATOM      6  N   CYS A   2      15.115  11.555   5.265  1.00  7.81           N
ATOM      7  CA  CYS A   2      13.856  11.469   6.066  1.00  8.31           C
ATOM      8  C   CYS A   2      14.164  10.785   7.379  1.00  8.66           C
ATOM      9  O   CYS A   2      14.993   9.862   7.443  1.00  9.72           O
ATOM     10  SG  CYS A   2      12.685  10.531   5.109  1.00 11.29           S
END
`;
/* a real PubChem 3D SDF: molfile, then the data fields that must NOT reach Ketcher */
const CAFFEINE_SDF = `2519
  -OEChem-04012608563D

  6  5  0     0  0  0  0  0  0999 V2000
    0.0000    0.0000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0
    1.4000    0.1000    0.0500 C   0  0  0  0  0  0  0  0  0  0  0  0
    2.0000    1.3000   -0.2000 N   0  0  0  0  0  0  0  0  0  0  0  0
    1.9000   -1.1000    0.4000 O   0  0  0  0  0  0  0  0  0  0  0  0
   -0.5000    0.8000    0.3000 H   0  0  0  0  0  0  0  0  0  0  0  0
   -0.4000   -0.8500   -0.2000 H   0  0  0  0  0  0  0  0  0  0  0  0
  1  2  1  0  0  0  0
  2  3  1  0  0  0  0
  2  4  2  0  0  0  0
  1  5  1  0  0  0  0
  1  6  1  0  0  0  0
M  END
> <PUBCHEM_COMPOUND_CID>
2519

> <PUBCHEM_CONFORMER_RMSD>
0.4

$$$$
`;
const FLAT_SDF = CAFFEINE_SDF.replace(/(-?\d+\.\d+)\s*$/gm, '$1')   // untouched
  .split('\n').map((l, i) => (i >= 4 && i <= 9 ? l.slice(0, 20) + '    0.0000' + l.slice(30) : l)).join('\n');
const MINI_CIF = `data_9XXX
loop_
_atom_site.group_PDB
_atom_site.id
_atom_site.type_symbol
_atom_site.label_atom_id
_atom_site.label_comp_id
_atom_site.label_asym_id
_atom_site.label_seq_id
_atom_site.Cartn_x
_atom_site.Cartn_y
_atom_site.Cartn_z
ATOM 1 N N ALA A 1 0.000 0.000 0.000
ATOM 2 C CA ALA A 1 1.458 0.000 0.000
ATOM 3 C C ALA A 1 2.009 1.420 0.000
`;
/* A COD entry in the house style of the archive's own files: the SVN header, the
   public-domain statement, the journal block, the cell, `_cod_database_code`, symmetry as
   xyz strings and fractional coordinates. Halite, which is what 1000041 is. */
const COD_CIF = `#------------------------------------------------------------------------------
#$Date: 2016-02-13 21:28:24 +0200 (Sat, 13 Feb 2016) $
#$Revision: 176429 $
#$URL: svn://www.crystallography.net/cod/cif/1/00/00/1000041.cif $
#------------------------------------------------------------------------------
#
# This file is available in the Crystallography Open Database (COD),
# http://www.crystallography.net/
#
# All data on this site have been placed in the public domain by the
# contributors.
#
data_1000041
loop_
_publ_author_name
'Abrahams, S C'
'Bernstein, J L'
_publ_section_title
;
Accuracy of an automatic diffractometer. Measurement of the sodium
chloride structure factors
;
_journal_name_full               'Acta Crystallographica (1,1948-23,1967)'
_journal_page_first              926
_journal_volume                  18
_journal_year                    1965
_chemical_formula_structural     'Na Cl'
_chemical_formula_sum            'Cl Na'
_chemical_name_systematic        'Sodium chloride'
_space_group_IT_number           225
_symmetry_cell_setting           cubic
_symmetry_space_group_name_Hall  '-F 4 2 3'
_symmetry_space_group_name_H-M   'F m -3 m'
_cell_angle_alpha                90
_cell_angle_beta                 90
_cell_angle_gamma                90
_cell_formula_units_Z            4
_cell_length_a                   5.62
_cell_length_b                   5.62
_cell_length_c                   5.62
_cell_volume                     177.5
_cod_database_code               1000041
loop_
_symmetry_equiv_pos_as_xyz
x,y,z
x,y+1/2,z+1/2
x+1/2,y,z+1/2
x+1/2,y+1/2,z
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_symmetry_multiplicity
_atom_site_Wyckoff_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_occupancy
_atom_site_attached_hydrogens
_atom_site_calc_flag
Na1 Na1+ 4 a 0. 0. 0. 1. 0 d
Cl1 Cl1- 4 b 0.5 0.5 0.5 1. 0 d
`;
/* The COD REST answer (result?format=json): an array of rows with the search form's column
   names — `file` is the COD number, `formula` is stored between dashes. From the COD wiki's
   description of the interface; not copied from a live answer (see the header). */
const COD_ROWS = [
  { file: '2300212', a: '11.233', b: '6.544', c: '11.231', alpha: '90', beta: '95.89', gamma: '90', vol: '821.2',
    sg: 'P 1 21/c 1', formula: '- C9 H8 O4 -', calcformula: '- C9 H8 O4 -', Z: '4', commonname: 'Aspirin',
    chemname: '2-acetoxybenzoic acid', mineral: null, authors: 'Kim, Y.; Machida, K.; Taga, T.; Osaki, K.',
    title: 'Structure redetermination and packing analysis of aspirin crystal', journal: 'Chemical & Pharmaceutical Bulletin',
    year: '1985', volume: '33', firstpage: '2641', doi: '10.1248/cpb.33.2641', nel: '3' },
  { file: '2100205', a: '12.095', b: '6.491', c: '11.323', alpha: '90', beta: '111.5', gamma: '90', vol: '827.1',
    sg: 'P 1 21/c 1', formula: '- C9 H8 O4 -', calcformula: '- C9 H8 O4 -', Z: '4', commonname: null,
    chemname: 'aspirin form II', mineral: null, authors: 'Vishweshwar, P.; McMahon, J. A.; Oliveira, M.; Peterson, M. L.; Zaworotko, M. J.',
    title: 'The predictably elusive form II of aspirin', journal: 'Journal of the American Chemical Society',
    year: '2005', volume: '127', firstpage: '16802', doi: '10.1021/ja056455b', nel: '3' },
];
/* A SPARQL JSON answer with two bindings, in the W3C results format the endpoint returns for
   format=json: P274 formulas carry Unicode subscripts, the label binding carries xml:lang. */
const SPARQL_JSON = {
  head: { vars: ['item', 'itemLabel', 'can', 'iso', 'inchi', 'formula'] },
  results: { bindings: [
    { item: { type: 'uri', value: 'http://www.wikidata.org/entity/Q18216' },
      can: { type: 'literal', value: 'CC(=O)OC1=CC=CC=C1C(=O)O' },
      inchi: { type: 'literal', value: 'InChI=1S/C9H8O4/c1-6(10)13-8-5-3-2-4-7(8)9(11)12/h2-5H,1H3,(H,11,12)' },
      formula: { type: 'literal', value: 'C₉H₈O₄' },
      itemLabel: { 'xml:lang': 'en', type: 'literal', value: 'aspirin' } },
    { item: { type: 'uri', value: 'http://www.wikidata.org/entity/Q218642' },
      can: { type: 'literal', value: 'CC(C(=O)O)N' },
      iso: { type: 'literal', value: 'C[C@@H](C(=O)O)N' },
      inchi: { type: 'literal', value: 'InChI=1S/C3H7NO2/c1-2(4)3(5)6/h2H,4H2,1H3,(H,5,6)/t2-/m0/s1' },
      formula: { type: 'literal', value: 'C₃H₇NO₂' },
      itemLabel: { 'xml:lang': 'en', type: 'literal', value: 'L-alanine' } },
  ] },
};
const CIR_SDF = `50-78-2
  CACTVS  09122612343D

  3  2  0  0  0  0  0  0  0  0999 V2000
    0.0000    0.0000    0.1173 O   0  0  0  0  0  0  0  0  0  0  0  0
    0.0000    0.7572   -0.4692 H   0  0  0  0  0  0  0  0  0  0  0  0
    0.0000   -0.7572   -0.4692 H   0  0  0  0  0  0  0  0  0  0  0  0
  1  2  1  0  0  0  0
  1  3  1  0  0  0  0
M  END
$$$$
`;
/* A Zenodo record as /api/records/<id> returns it: the licence under metadata.license.id,
   each file with its key, size and links.self. From the Zenodo REST API documentation. */
const ZENODO_RECORD = (licence = 'cc-by-4.0') => ({
  created: '2023-07-03T09:12:44.113321+00:00', modified: '2023-07-03T10:01:02.000000+00:00',
  id: 8104385, conceptrecid: '8104384', doi: '10.5281/zenodo.8104385', conceptdoi: '10.5281/zenodo.8104384',
  doi_url: 'https://doi.org/10.5281/zenodo.8104385',
  metadata: {
    title: 'Crystal structure of a copper–organic framework, refined',
    doi: '10.5281/zenodo.8104385', publication_date: '2023-07-03',
    description: '<p>CIF and refinement log.</p>', access_right: 'open',
    creators: [{ name: 'Goncalves, Theo P.', affiliation: 'DWORM' }, { name: 'Example, Ada', affiliation: null }],
    keywords: ['crystal structure', 'MOF'], resource_type: { title: 'Dataset', type: 'dataset' },
    license: { id: licence }, version: '1.0',
  },
  title: 'Crystal structure of a copper–organic framework, refined',
  links: { self: 'https://zenodo.org/api/records/8104385', self_html: 'https://zenodo.org/records/8104385',
           doi: 'https://doi.org/10.5281/zenodo.8104385', files: 'https://zenodo.org/api/records/8104385/files' },
  files: [
    { id: '4f0c7c2e-9b0a-4e2b-9d2f-0f2f9c8b1a11', key: 'structure.cif', size: 41, checksum: 'md5:2f6f5a1e3b0d3b8e1a4c8d6c1e2f3a4b',
      links: { self: 'https://zenodo.org/api/records/8104385/files/structure.cif/content' } },
    { id: '9a1b2c3d-4e5f-4a6b-8c7d-0e1f2a3b4c5d', key: 'refinement.log', size: 20480, checksum: 'md5:0a1b2c3d4e5f60718293a4b5c6d7e8f9',
      links: { self: 'https://zenodo.org/api/records/8104385/files/refinement.log/content' } },
  ],
  owners: [12345], revision: 3, stats: { downloads: 12 }, state: 'done', submitted: true,
});
const ZENODO_CIF = 'data_zenodo\n_cell_length_a 10.0\n_cod_database_code 0\n';
/* the PDBe entry summary, keyed by the lower-case id, one object per entry */
const PDBE_SUMMARY = { '1crn': [{
  title: 'WATER STRUCTURE OF A HYDROPHOBIC PROTEIN AT ATOMIC RESOLUTION. PENTAGON RINGS OF WATER MOLECULES IN CRYSTALS OF CRAMBIN',
  experimental_method: ['X-ray diffraction'], release_date: '19810430', deposition_date: '19810430',
  number_of_entities: { polypeptide: 1, water: 1 }, processing_site: 'BNL', assemblies: [{ assembly_id: '1', form: 'homo', preferred: true, name: 'monomer' }],
}] };
const AF_API = [{ entryId: 'AF-P69905-F1', uniprotAccession: 'P69905', uniprotDescription: 'Hemoglobin subunit alpha',
  organismScientificName: 'Homo sapiens', latestVersion: 4, modelCreatedDate: '2022-06-01',
  pdbUrl: 'https://alphafold.ebi.ac.uk/files/AF-P69905-F1-model_v4.pdb', cifUrl: 'https://alphafold.ebi.ac.uk/files/AF-P69905-F1-model_v4.cif' }];
const AF_PDB = 'HEADER                                            01-JUN-22                     \nTITLE     ALPHAFOLD MONOMER V2.0 PREDICTION FOR HEMOGLOBIN SUBUNIT ALPHA (P69905)\n' +
  CRAMBIN.split('\n').filter(l => /^ATOM/.test(l)).join('\n') + '\nEND\n';

/* ======================================================================================
   Part 1 — the module on its own, in Node, every fetch mocked
   ====================================================================================== */
const PROVIDERS_JSON = readFileSync(new URL('../2dworm/lib/providers.json', import.meta.url), 'utf8');
const calls = [];                 // every url the module asked for: { method, url, body, signal }
let answer = () => undefined;     // the current check's stand-in for the services
const json = (obj, init = {}) => new Response(typeof obj === 'string' ? obj : JSON.stringify(obj),
  { status: 200, ...init, headers: { 'content-type': 'application/json', ...(init.headers || {}) } });
const text = (s, init = {}) => new Response(s, { status: 200, ...init });
const gone = () => new Response('Not Found', { status: 404 });
/** A body that arrives in pieces, with a pause between them — what a real download is. */
function streamed(chunks, { headers = {}, delay = 4, hang = false, onCancel = null } = {}) {
  const enc = new TextEncoder();
  const body = new ReadableStream({
    async start(c) {
      try { for (const ch of chunks) { await sleep(delay); c.enqueue(enc.encode(ch)); } if (!hang) c.close(); }
      catch (e) { /* cancelled under us: nothing to do */ }
    },
    cancel() { if (onCancel) onCancel(); },
  });
  return new Response(body, { status: 200, headers });
}
globalThis.fetch = async (url, init = {}) => {
  const u = String(url);
  calls.push({ method: init.method || 'GET', url: u, body: init.body || '', signal: init.signal || null });
  if (u.endsWith('/providers.json')) return json(PROVIDERS_JSON);
  const r = await answer(u, init);
  if (r === undefined) throw new Error('no stand-in for ' + u);      // a wrong url must fail loudly
  return r;
};
const urls = () => calls.map(c => c.url);
const reset = (fn) => { calls.length = 0; answer = fn || (() => undefined); };

const db = await import('../2dworm/lib/fetchdb.js');

/* ------------------------------------------------------- the list is data */
const pj = JSON.parse(PROVIDERS_JSON);
const ids = pj.providers.map(p => p.id);
check('providers.json is a list of sources with unique ids', Array.isArray(pj.providers) && new Set(ids).size === ids.length && ids.length >= 9, ids.join(' '));
check('every source names a licence and says whether attribution is owed',
  pj.providers.every(p => typeof p.licence === 'string' && p.licence && (p.attribution === null || typeof p.attribution === 'string')));
check('every ENABLED source is one that owes nothing: attribution null (or a string it chooses to show)',
  pj.providers.filter(p => p.enabled).every(p => p.attribution === null || typeof p.attribution === 'string'));
check('every DISABLED source carries the credit line it would owe, so switching it on is complete',
  pj.providers.filter(p => !p.enabled).every(p => typeof p.attribution === 'string' && p.attribution.length > 5),
  pj.providers.filter(p => !p.enabled).map(p => p.id + ': ' + p.attribution).join(' | '));
check('the public-domain sources are on and the CC-BY one is off',
  ['rcsb', 'pubchem', 'cod', 'tcod', 'pdbe', 'wikidata', 'cactus', 'zenodo'].every(id => pj.providers.find(p => p.id === id)?.enabled === true) &&
  pj.providers.find(p => p.id === 'alphafold')?.enabled === false);
check('every idPattern is a regular expression that accepts the example identifier',
  pj.providers.every(p => { try { return new RegExp(p.idPattern).test(p.idExample); } catch (e) { return false; } }),
  pj.providers.map(p => p.id + ':' + p.idExample).join(' '));
check('every source says what it can be asked for, and has at least one https url template for the code to fill',
  pj.providers.every(p => Array.isArray(p.kinds) && p.kinds.every(k => ['id', 'name', 'doi'].includes(k)) && Object.values(p.urls).some(u => /^https:\/\//.test(u))));
check('the module fetched the list relative to itself, once, at import',
  calls.filter(c => c.url.endsWith('/providers.json')).length === 1 && calls[0].url.endsWith('/lib/providers.json'), calls[0]?.url);
const listed = db.listProviders();
check('listProviders() gives the same sources, in the file\'s order, with the effective on/off',
  listed.map(p => p.id).join() === ids.join() && listed.every(p => typeof p.enabled === 'boolean' && p.label && p.licence),
  listed.map(p => p.id + (p.enabled ? '' : '(off)')).join(' '));
check('SOURCES, which the page reads synchronously, is filled from the same list',
  ids.every(id => db.SOURCES[id] && db.SOURCES[id].label === pj.providers.find(p => p.id === id).label));
db.setEnabled('alphafold', true);
check('the page can switch a source on, and the list says so', db.isEnabled('alphafold') && db.listProviders().find(p => p.id === 'alphafold').enabled === true);
db.setEnabled('alphafold', false);
check('and off again', !db.isEnabled('alphafold'));

/* --------------------------------------------------- fetchWithProgress */
{
  reset(() => streamed(['abc', 'def', 'gh'], { headers: { 'content-length': '8' } }));
  const seen = [];
  const r = await db.fetchWithProgress('https://example.org/a.txt', { onProgress: (l, t) => seen.push([l, t]) });
  check('a streamed body arrives whole', r.text === 'abcdefgh' && r.loaded === 8 && r.total === 8, JSON.stringify(r));
  check('and progress was reported as the bytes arrived, with the total from Content-Length',
    JSON.stringify(seen) === '[[0,8],[3,8],[6,8],[8,8]]', JSON.stringify(seen));
}
{
  reset(() => streamed(['abc', 'def', 'gh']));
  const seen = [];
  const r = await db.fetchWithProgress('https://example.org/b.txt', { onProgress: (l, t) => seen.push([l, t]) });
  check('with no Content-Length the total is null every time — the caller must not invent a percentage',
    r.text === 'abcdefgh' && r.total === null && seen.length === 4 && seen.every(s => s[1] === null), JSON.stringify(seen));
}
{
  reset(() => streamed(['abcdef', 'ghijkl'], { headers: { 'content-length': '8' } }));
  const seen = [];
  await db.fetchWithProgress('https://example.org/c.gz', { onProgress: (l, t) => seen.push([l, t]) });
  check('a compressed answer (more bytes than it declared) drops the total rather than reporting 150 %',
    JSON.stringify(seen) === '[[0,8],[6,8],[12,null]]', JSON.stringify(seen));
}
{
  let cancelled = false;
  reset(() => streamed(['abc', 'def'], { hang: true, onCancel: () => { cancelled = true; } }));
  const ac = new AbortController();
  const seen = [];
  const p = db.fetchWithProgress('https://example.org/d.txt', { signal: ac.signal, onProgress: (l) => { seen.push(l); if (l >= 6) ac.abort(); } });
  const e = await failing(p);
  check('an aborted stream rejects with kind "aborted", even though the stream itself never ended',
    e && e.kind === 'aborted' && seen.includes(6), e && (e.kind + ': ' + e.message));
  await sleep(10);
  check('and the reader was cancelled, so the connection is released, and fetch\'s own signal was aborted',
    cancelled && calls[0].signal && calls[0].signal.aborted);
}
{
  reset(() => streamed(['abc'], { hang: true }));
  const outer = new AbortController();
  db.setAbortSignal(outer.signal);
  const p = db.fetchWithProgress('https://example.org/e.txt', { onProgress: (l) => { if (l) outer.abort(); } });
  const e = await failing(p);
  db.setAbortSignal(null);
  check('the page\'s STOP signal (setAbortSignal) aborts a download in the middle of its body', e && e.kind === 'aborted', e && e.message);
}
{
  reset(() => { throw new TypeError('Failed to fetch'); });
  const e = await failing(db.fetchWithProgress('https://blocked.example/x.cif'));
  check('a TypeError from fetch — a CORS refusal or a dead host — is named as both, since a browser cannot tell them apart',
    e && e.kind === 'unreachable' && /does not allow other sites to read its files/.test(e.message) && /or is unreachable/.test(e.message) && /blocked\.example/.test(e.message),
    e && e.message);
}
{
  reset(() => gone());
  const e = await failing(db.fetchWithProgress('https://example.org/missing.cif'));
  check('a 404 is worded differently: the server answered, it has no such file',
    e && e.kind === 'http' && e.status === 404 && /HTTP 404/.test(e.message) && !/other sites/.test(e.message), e && e.message);
}
{
  reset(() => streamed(['abc'], { hang: true }));
  const e = await failing(db.fetchWithProgress('https://slow.example/x', { timeoutMs: 60 }));
  check('a server that stops talking is given up on after the idle timeout, with a sentence', e && e.kind === 'timeout' && /did not answer within/.test(e.message), e && e.message);
}
{
  reset(() => streamed(['0123456789', '0123456789']));
  const e = await failing(db.fetchWithProgress('https://example.org/big', { maxBytes: 12 }));
  check('a file past the size the page will hold is refused as such, not downloaded to the end', e && e.kind === 'toolarge' && /larger than/.test(e.message), e && e.message);
}

/* --------------------------------------------------------- identifyFile */
{
  const cif8yax = readFileSync(new URL('./corpus/8yax.fw2.cif', import.meta.url), 'utf8');
  check('identifyFile: a real mmCIF names its PDB entry from _entry.id', JSON.stringify(db.identifyFile(cif8yax)) === '{"source":"rcsb","id":"8YAX","ref":"rcsb:8YAX"}', JSON.stringify(db.identifyFile(cif8yax)));
  check('a PDB file, from the id code on its HEADER record', db.identifyFile(CRAMBIN)?.id === '1CRN');
  check('an mmCIF with only a data_ block, provided it carries PDBx atom sites', db.identifyFile(MINI_CIF)?.id === '9XXX');
  check('a COD file, from _cod_database_code', JSON.stringify(db.identifyFile(COD_CIF)) === '{"source":"cod","id":"1000041","ref":"cod:1000041"}', JSON.stringify(db.identifyFile(COD_CIF)));
  check('a plain xyz names nothing', db.identifyFile('3\nwater\nO 0 0 0\nH 0.96 0 0\nH -0.24 0.93 0\n') === null);
  const urea = readFileSync(new URL('./corpus/Urea.cif', import.meta.url), 'utf8');
  check('nor does a CIF written by a modelling program', db.identifyFile(urea) === null && db.identifyFile(null) === null);
}

/* ------------------------------------------------------------- parseRef */
{
  const P = (r) => JSON.stringify(db.parseRef(r));
  const cases = [
    ['cod:1000041', '{"src":"cod","id":"1000041"}'], ['tcod:10000001', '{"src":"tcod","id":"10000001"}'],
    ['pdbe:1crn', '{"src":"pdbe","id":"1crn"}'], ['rcsb:1CRN', '{"src":"rcsb","id":"1CRN"}'],
    ['pubchem:2244', '{"src":"pubchem","id":"2244"}'], ['wd:Q2270', '{"src":"wikidata","id":"Q2270"}'],
    ['wikidata:q2270', '{"src":"wikidata","id":"Q2270"}'], ['zenodo:8104385', '{"src":"zenodo","id":"8104385"}'],
    ['zenodo:8104385/structure.cif', '{"src":"zenodo","id":"8104385/structure.cif"}'],
    ['10.5281/zenodo.8104385', '{"src":"zenodo","id":"8104385"}'], ['doi:10.5281/zenodo.8104385', '{"src":"zenodo","id":"8104385"}'],
    ['https://doi.org/10.5281/zenodo.8104385', '{"src":"zenodo","id":"8104385"}'],
    ['https://zenodo.org/records/8104385/files/structure.cif?download=1', '{"src":"zenodo","id":"8104385/structure.cif"}'],
    ['cactus:acetylsalicylic acid', '{"src":"cactus","id":"acetylsalicylic acid"}'], ['alphafold:P69905', '{"src":"alphafold","id":"P69905"}'],
  ];
  const bad = cases.filter(([r, want]) => P(r) !== want);
  check('parseRef reads every kind of reference a link can carry', bad.length === 0, bad.map(([r]) => r + ' → ' + P(r)).join(' | '));
  const refused = ['file:///etc/passwd', 'javascript:alert(1)', 'cod:12', 'rcsb:../x', 'https://evil.example/x', '', 'nosuch:1', 'wd:18216'];
  check('and refuses what names nothing this build fetches', refused.every(r => db.parseRef(r) === null), refused.filter(r => db.parseRef(r) !== null).join(' | '));
  check('refOf is its inverse', db.refOf('cod', '1000041') === 'cod:1000041');
}

/* ------------------------------------------------------------------ COD */
{
  reset((u) => u === 'https://www.crystallography.net/cod/1000041.cif' ? text(COD_CIF) : undefined);
  const r = await db.fetchOne('cod', '1000041');
  check('COD: an entry is fetched as the CIF at its documented url', urls()[0] === 'https://www.crystallography.net/cod/1000041.cif' && r.text === COD_CIF && r.format === 'cif');
  check('and comes back with its source, licence and (no) attribution, the fields every fetch has',
    r.src === 'cod' && r.source === 'COD' && /public domain/.test(r.licence) && r.attribution === null && r.ref === 'cod:1000041' && r.fileName === '1000041.cif' && r.toDrawing === false,
    JSON.stringify({ ...r, text: undefined }));
  reset(() => gone());
  const e = await failing(db.fetchOne('cod', '1000041'));
  check('an entry COD does not have is said to be missing, not unreachable', e && e.kind === 'notfound' && /COD has no entry 1000041/.test(e.message), e && e.message);
  const e2 = await failing(db.fetchOne('cod', '12'));
  check('and an identifier of the wrong shape is refused before any request', e2 && /not a COD identifier/.test(e2.message) && calls.length === 1, e2 && e2.message);

  reset((u) => /crystallography\.net\/cod\/result\?/.test(u) ? json(COD_ROWS) : undefined);
  let s = await db.search('aspirin', 'cod');
  check('a COD name search goes to the REST interface as format=json with text=', urls()[0] === 'https://www.crystallography.net/cod/result?format=json&text=aspirin', urls()[0]);
  check('and each row becomes a hit in the page\'s shape, tagged with its COD number',
    s.hits.length === 2 && s.hits[0].src === 'cod' && s.hits[0].id === '2300212' && s.hits[0].tag === 'COD 2300212' && s.hits[0].title === 'Aspirin' &&
    /C9 H8 O4/.test(s.hits[0].sub) && /P 1 21\/c 1/.test(s.hits[0].sub) && s.hits[0].attribution === null && s.hits[0].label === 'COD' && s.hits[0].ref === 'cod:2300212',
    JSON.stringify(s.hits[0]));
  check('a row with no common name falls back to its chemical name', s.hits[1].title === 'aspirin form II' && s.hits[1].id === '2100205');
  reset((u) => /result\?/.test(u) ? json([]) : undefined);
  await db.search('C9H8O4', 'cod');
  check('a formula is sent as formula= in Hill order with spaces', /[?&]formula=C9%20H8%20O4$/.test(urls()[0]) && !/text=/.test(urls()[0]), urls()[0]);
  await db.search('NaCl', 'cod');
  check('with no carbon, the elements go alphabetically', /formula=Cl%20Na$/.test(urls()[1]), urls()[1]);
  reset((u) => /result\?format=json&id=1000041$/.test(u) ? json([{ file: '1000041', formula: '- Cl Na -', sg: 'F m -3 m', chemname: 'Sodium chloride', journal: 'Acta Crystallographica (1,1948-23,1967)', year: '1965' }]) : undefined);
  s = await db.search('1000041', 'cod');
  check('a COD number typed on its own is looked up as one', s.hits.length === 1 && s.hits[0].id === '1000041' && /Sodium chloride/.test(s.hits[0].title) && /COD identifier/.test(s.notes[0]), JSON.stringify(s));
}

/* ------------------------------------------------------------------ TCOD */
{
  reset((u) => u === 'https://www.crystallography.net/tcod/10000001.cif' ? text(COD_CIF.replace(/1000041/g, '10000001')) : undefined);
  const r = await db.fetchOne('tcod', '10000001');
  check('TCOD: the same shape of adapter at its own url', urls()[0] === 'https://www.crystallography.net/tcod/10000001.cif' && r.src === 'tcod' && r.format === 'cif' && r.ref === 'tcod:10000001' && r.attribution === null);
  reset();
  const s = await db.search('10000001', 'tcod');
  check('a TCOD number typed with TCOD chosen is offered without a request (there is no verified search interface)',
    s.hits.length === 1 && s.hits[0].src === 'tcod' && s.hits[0].tag === 'TCOD 10000001' && calls.length === 0, JSON.stringify(s.hits));
}

/* ------------------------------------------------------------------ PDBe */
{
  reset((u) => u === 'https://www.ebi.ac.uk/pdbe/entry-files/download/1crn.cif' ? text(MINI_CIF.replace('9XXX', '1CRN')) : undefined);
  const r = await db.fetchOne('pdbe', '1crn');
  check('PDBe: an entry is fetched as mmCIF with the identifier in lower case',
    urls()[0] === 'https://www.ebi.ac.uk/pdbe/entry-files/download/1crn.cif' && r.format === 'cif' && r.id === '1CRN' && r.ref === 'pdbe:1CRN' && r.source === 'PDBe' && r.attribution === null);
  reset((u) => u === 'https://www.ebi.ac.uk/pdbe/api/pdb/entry/summary/1crn' ? json(PDBE_SUMMARY) : undefined);
  const s = await db.search('1CRN', 'pdbe');
  check('a PDB code with PDBe chosen is looked up in the PDBe summary API for its title',
    s.hits.length === 1 && s.hits[0].src === 'pdbe' && s.hits[0].id === '1CRN' && /CRAMBIN/.test(s.hits[0].title) && /X-ray/.test(s.hits[0].sub), JSON.stringify(s.hits));
  reset((u) => /pdbe/.test(u) ? json(PDBE_SUMMARY) : undefined);
  const s2 = await db.search('haemoglobin', 'pdbe');
  check('and a name with PDBe chosen says what PDBe takes instead of searching nothing',
    s2.hits.length === 0 && /PDBe takes a PDB identifier/.test(s2.notes[0]) && calls.length === 0, JSON.stringify(s2.notes));

  /* the fallback: the same wwPDB archive from EMBL-EBI when RCSB's file server cannot be reached */
  reset((u) => {
    if (/files\.rcsb\.org/.test(u)) throw new TypeError('Failed to fetch');
    if (u === 'https://www.ebi.ac.uk/pdbe/entry-files/download/1crn.cif') return text(MINI_CIF.replace('9XXX', '1CRN'));
  });
  const f = await db.fetchOne('rcsb', '1CRN');
  check('rcsb: when files.rcsb.org cannot be reached the entry is fetched from PDBe instead',
    urls()[0] === 'https://files.rcsb.org/download/1CRN.pdb' && urls().includes('https://www.ebi.ac.uk/pdbe/entry-files/download/1crn.cif') && f.text.includes('1CRN'), urls().join(' | '));
  check('and the result still belongs to rcsb:1CRN, says PDBe served it, and carries a note saying why',
    f.src === 'rcsb' && f.ref === 'rcsb:1CRN' && f.via === 'pdbe' && f.source === 'PDBe' && /RCSB PDB could not be reached, so the same entry was fetched from PDBe/.test(f.note) && f.format === 'cif',
    JSON.stringify({ ...f, text: undefined }));
  reset((u) => /files\.rcsb\.org/.test(u) ? gone() : undefined);
  const e = await failing(db.fetchOne('rcsb', '9ZZZ'));
  check('but an entry RCSB answers 404 for (both .pdb and .cif) is missing, and PDBe is not asked',
    e && e.kind === 'notfound' && /RCSB PDB has no entry 9ZZZ/.test(e.message) && urls().length === 2 && !urls().some(u => /ebi/.test(u)), (e && e.message) + ' ' + urls().join(' | '));
  reset(() => { throw new TypeError('Failed to fetch'); });
  const e2 = await failing(db.fetchOne('rcsb', '1CRN'));
  check('and when neither host answers, the sentence names both and says what to do instead',
    e2 && /^RCSB PDB could not be reached/.test(e2.message) && /PDBe .*could not be reached either/.test(e2.message) && /use OPEN with a file you already have/.test(e2.message) && e2.kind === 'unreachable',
    e2 && e2.message);
}

/* -------------------------------------------------------------- Wikidata */
{
  reset((u) => /query\.wikidata\.org\/sparql\?/.test(u) ? json(SPARQL_JSON) : undefined);
  const s = await db.search('aspirin', 'wikidata');
  const q = decodeURIComponent(new URL(urls()[0]).searchParams.get('query'));
  check('Wikidata: a name search is one GET to the SPARQL endpoint with format=json',
    urls()[0].startsWith('https://query.wikidata.org/sparql?format=json&query=') && calls.length === 1, urls()[0].slice(0, 80));
  check('the query matches labels AND aliases, in English, in the typed case and the others chemical names are written in',
    /rdfs:label\|skos:altLabel/.test(q) && /"aspirin"@en/.test(q) && /"Aspirin"@en/.test(q) && /"ASPIRIN"@en/.test(q), q.replace(/\s+/g, ' ').slice(0, 200));
  check('and asks only for items with an InChI and a SMILES, canonical or isomeric',
    /wdt:P234 \?inchi/.test(q) && /wdt:P233 \?can/.test(q) && /wdt:P2017 \?iso/.test(q) && /BOUND\(\?can\) \|\| BOUND\(\?iso\)/.test(q) && /LIMIT 8/.test(q));
  check('two bindings become two hits with SMILES, label and QID, CC0 so no attribution',
    s.hits.length === 2 && s.hits[0].src === 'wikidata' && s.hits[0].id === 'Q18216' && s.hits[0].title === 'aspirin' && s.hits[0].smiles === 'CC(=O)OC1=CC=CC=C1C(=O)O' &&
    /C₉H₈O₄/.test(s.hits[0].sub) && s.hits[0].attribution === null && /CC0/.test(s.hits[0].licence) && s.hits[0].ref === 'wikidata:Q18216' && s.hits[0].inchi.startsWith('InChI='),
    JSON.stringify(s.hits[0]));
  check('the isomeric SMILES is preferred when there is one — it carries the stereochemistry', s.hits[1].id === 'Q218642' && s.hits[1].smiles === 'C[C@@H](C(=O)O)N');
  reset((u) => /sparql/.test(u) ? json(SPARQL_JSON) : undefined);
  await db.search('a"b\\c', 'wikidata');
  const q2 = decodeURIComponent(new URL(urls()[0]).searchParams.get('query'));
  check('quotes and backslashes in the typed text are escaped inside the query', /"a\\"b\\\\c"@en/.test(q2), q2.match(/VALUES[^}]*\}/)?.[0]);
  reset((u) => /sparql/.test(u) ? json({ head: { vars: [] }, results: { bindings: [SPARQL_JSON.results.bindings[0]] } }) : undefined);
  const f = await db.fetchOne('wikidata', 'Q18216');
  const q3 = decodeURIComponent(new URL(urls()[0]).searchParams.get('query'));
  check('fetching an item asks for that QID and hands the SMILES to the drawing, flat',
    /VALUES \?item \{ wd:Q18216 \}/.test(q3) && f.text === 'CC(=O)OC1=CC=CC=C1C(=O)O' && f.format === 'smiles' && f.toDrawing === true && f.flat === true &&
    f.title === 'aspirin' && f.ref === 'wikidata:Q18216' && f.source === 'Wikidata' && f.attribution === null, JSON.stringify(f));
  const s3 = await db.search('wd:Q18216', 'auto');
  check('a QID typed as wd:Q18216 goes straight to that item', s3.hits.length === 1 && s3.hits[0].id === 'Q18216' && /Wikidata item/.test(s3.notes[0]), JSON.stringify(s3.notes));
  reset((u) => /sparql/.test(u) ? json({ head: { vars: [] }, results: { bindings: [] } }) : undefined);
  const e = await failing(db.fetchOne('wikidata', 'Q42'));
  check('an item with no SMILES says so', e && /Q42 has no SMILES/.test(e.message), e && e.message);
}

/* ---------------------------------------------------------------- CACTUS */
{
  reset((u) => u === 'https://cactus.nci.nih.gov/chemical/structure/aspirin/smiles' ? text('CC(=O)Oc1ccccc1C(O)=O\n') : undefined);
  const s = await db.search('aspirin', 'cactus');
  check('CACTUS: a name is resolved to one SMILES, one hit', s.hits.length === 1 && s.hits[0].src === 'cactus' && s.hits[0].id === 'aspirin' && s.hits[0].smiles === 'CC(=O)Oc1ccccc1C(O)=O' && s.hits[0].sub === 'CC(=O)Oc1ccccc1C(O)=O' && s.hits[0].attribution === null,
    JSON.stringify(s.hits));
  reset((u) => /cactus/.test(u) ? gone() : undefined);
  const s2 = await db.search('zzzzqq', 'cactus');
  check('a 404 from the resolver is "not found", quietly', s2.hits.length === 0 && s2.notes.length === 0, JSON.stringify(s2));
  reset((u) => u === 'https://cactus.nci.nih.gov/chemical/structure/50-78-2/file?format=sdf&get3d=true' ? text(CIR_SDF) : undefined);
  const f = await db.fetchOne('cactus', '50-78-2');
  check('fetching asks for the 3D SDF first, and a CAS number resolves like a name',
    calls.length === 1 && f.format === 'sdf' && f.flat === false && f.toDrawing === true && f.text === CIR_SDF && f.ref === 'cactus:50-78-2' && f.source === 'NCI/CADD CIR', JSON.stringify({ ...f, text: undefined }));
  reset((u) => /get3d/.test(u) ? gone() : u === 'https://cactus.nci.nih.gov/chemical/structure/acetylsalicylic%20acid/sdf' ? text(CIR_SDF) : undefined);
  const f2 = await db.fetchOne('cactus', 'acetylsalicylic acid');
  check('when there is no 3D the plain SDF is taken, flat, and the identifier is url-encoded', f2.flat === true && urls()[1] === 'https://cactus.nci.nih.gov/chemical/structure/acetylsalicylic%20acid/sdf', urls().join(' | '));
  reset((u) => /InChI%3D1S%2FC2H6O/.test(u) ? text(CIR_SDF) : undefined);
  await db.fetchOne('cactus', 'InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3');
  check('an InChI, slashes and all, survives the url', /structure\/InChI%3D1S%2FC2H6O%2Fc1-2-3%2Fh3H%2C2H2%2C1H3\/file/.test(urls()[0]), urls()[0]);
  reset(() => gone());
  const e = await failing(db.fetchOne('cactus', 'nosuchthing'));
  check('both routes 404: the resolver could not resolve it', e && e.kind === 'notfound' && /could not resolve “nosuchthing”/.test(e.message), e && e.message);
  reset(() => streamed(['x'], { hang: true }));
  const t0 = Date.now();
  const e2 = await failing(db.fetchOne('cactus', 'aspirin', { timeoutMs: 80 }));
  check('a resolver that hangs (it has outages) ends in a sentence, not a spinner',
    e2 && /NCI\/CADD CIR could not be reached — it did not answer in time/.test(e2.message) && Date.now() - t0 < 2000, e2 && e2.message);
  reset(() => undefined);
  await db.search('aspirin', 'auto');
  check('and the resolver is not asked by an "all databases" search — only when chosen', !urls().some(u => /cactus/.test(u)), urls().join(' | '));
}

/* ---------------------------------------------------------------- Zenodo */
{
  const CIF_URL = 'https://zenodo.org/api/records/8104385/files/structure.cif/content';
  reset((u) => u === 'https://zenodo.org/api/records/8104385' ? json(ZENODO_RECORD()) : undefined);
  let s = await db.search('10.5281/zenodo.8104385', 'auto');
  check('Zenodo: a DOI typed anywhere fetches the record from the API', urls()[0] === 'https://zenodo.org/api/records/8104385' && calls.length === 1, urls().join(' | '));
  check('and each file of the record is one hit, with its size, the record title and its licence',
    s.hits.length === 2 && s.hits[0].src === 'zenodo' && s.hits[0].id === '8104385/structure.cif' && s.hits[0].title === 'structure.cif' && s.hits[0].tag === 'Zenodo 8104385' &&
    /1 kB · Crystal structure of a copper–organic framework, refined · CC-BY-4.0/.test(s.hits[0].sub) && s.hits[0].url === CIF_URL && s.hits[1].id === '8104385/refinement.log',
    JSON.stringify(s.hits[0]));
  check('a CC-BY record comes with a credit line built from its creators, title and DOI',
    s.hits[0].licence === 'CC-BY-4.0' && s.hits[0].attribution === 'Goncalves, Theo P., Example, Ada (2023). Crystal structure of a copper–organic framework, refined. Zenodo. https://doi.org/10.5281/zenodo.8104385 — licence CC-BY-4.0',
    s.hits[0].attribution);
  check('the note says what it looked like', /Zenodo record/.test(s.notes[0]), s.notes[0]);
  reset((u) => /api\/records\/8104385$/.test(u) ? json(ZENODO_RECORD()) : undefined);
  s = await db.search('https://zenodo.org/records/8104385', 'pubchem');
  check('a zenodo.org url as well, whatever database is selected', s.hits.length === 2 && urls().length === 1);
  reset((u) => /zenodo/.test(u) ? json(ZENODO_RECORD()) : json([]));
  s = await db.search('8104385', 'auto');
  check('but a bare number is a CID or a COD entry before it is a record: Zenodo is not asked unless chosen', !urls().some(u => /zenodo/.test(u)), urls().join(' | '));
  reset((u) => /zenodo/.test(u) ? json(ZENODO_RECORD()) : undefined);
  s = await db.search('8104385', 'zenodo');
  check('with Zenodo chosen, it is', s.hits.length === 2 && urls()[0] === 'https://zenodo.org/api/records/8104385');

  const seen = [];
  reset((u) => u === 'https://zenodo.org/api/records/8104385' ? json(ZENODO_RECORD())
             : u === CIF_URL ? streamed([ZENODO_CIF.slice(0, 20), ZENODO_CIF.slice(20)], { headers: { 'content-length': String(ZENODO_CIF.length) } }) : undefined);
  const f = await db.fetchOne('zenodo', '8104385/structure.cif', { onProgress: (l, t) => seen.push([l, t]) });
  check('fetching one file reads the record, then streams the file from links.self with progress',
    urls()[1] === CIF_URL && f.text === ZENODO_CIF && seen.length >= 3 && seen[seen.length - 1][0] === ZENODO_CIF.length && seen[0][1] === ZENODO_CIF.length, JSON.stringify(seen));
  check('and the result carries the file name as its format, and the record\'s licence and credit line',
    f.format === 'cif' && f.fileName === 'structure.cif' && f.licence === 'CC-BY-4.0' && /Goncalves/.test(f.attribution) && f.record.doi === '10.5281/zenodo.8104385' &&
    f.ref === 'zenodo:8104385/structure.cif' && f.source === 'Zenodo' && f.toDrawing === false, JSON.stringify({ ...f, text: undefined }));
  reset((u) => u === 'https://zenodo.org/api/records/8104385' ? json(ZENODO_RECORD('cc0-1.0')) : u === CIF_URL ? text(ZENODO_CIF) : undefined);
  const f0 = await db.fetchOne('zenodo', '8104385/structure.cif');
  check('a CC0 record owes nothing: attribution null, licence still named', f0.attribution === null && f0.licence === 'CC0-1.0', JSON.stringify({ a: f0.attribution, l: f0.licence }));
  reset((u) => /api\/records\/8104385$/.test(u) ? json(ZENODO_RECORD()) : undefined);
  const e = await failing(db.fetchOne('zenodo', '8104385'));
  check('a record with several files, asked for without saying which, lists them instead of guessing',
    e && e.kind === 'choose' && /2 files — say which: structure\.cif, refinement\.log/.test(e.message), e && e.message);
  const one = ZENODO_RECORD(); one.files = one.files.slice(0, 1);
  reset((u) => /api\/records\/8104385$/.test(u) ? json(one) : u === CIF_URL ? text(ZENODO_CIF) : undefined);
  const f1 = await db.fetchOne('zenodo', '10.5281/zenodo.8104385');
  check('a record with one file needs no choosing, and a DOI fetches as well as a number', f1.fileName === 'structure.cif' && f1.text === ZENODO_CIF);
  reset((u) => /api\/records\/8104385$/.test(u) ? json(ZENODO_RECORD()) : undefined);
  const e2 = await failing(db.fetchOne('zenodo', '8104385/nosuch.cif'));
  check('a file the record does not have is named as missing', e2 && e2.kind === 'notfound' && /no file called “nosuch\.cif”/.test(e2.message), e2 && e2.message);
  reset((u) => /api\/records\/100$/.test(u) ? gone() : undefined);
  const e3 = await failing(db.fetchOne('zenodo', '100'));
  check('and so is a record that does not exist', e3 && e3.kind === 'notfound' && /Zenodo has no entry 100/.test(e3.message), e3 && e3.message);
  const e4 = await failing(db.fetchZenodoFile('https://evil.example/records/1/files/x.cif'));
  check('fetchZenodoFile only ever reads from zenodo.org, whatever url a link carries', e4 && /Only files on zenodo\.org/.test(e4.message), e4 && e4.message);
  reset((u) => u === CIF_URL ? streamed(['ab', 'cd']) : undefined);
  const z = await db.fetchZenodoFile(CIF_URL, { onProgress: () => {} });
  check('and streams the body the same way as everything else', z.text === 'abcd' && z.loaded === 4 && z.total === null);
}

/* ------------------------------------------------------------- AlphaFold */
{
  reset(() => text(AF_PDB));
  const e = await failing(db.fetchOne('alphafold', 'P69905'));
  check('AlphaFold: switched off by default, a fetch is refused with the reason and the credit it would owe, and no request is made',
    e && e.kind === 'disabled' && /AlphaFold DB is switched off/.test(e.message) && /CC-BY-4.0/.test(e.message) && /AlphaFold DB, EMBL-EBI, CC-BY-4.0/.test(e.message) && calls.length === 0, e && e.message);
  const e2 = await failing(db.search('P69905', 'alphafold'));
  check('and so is a search with it chosen', e2 && e2.kind === 'disabled', e2 && e2.message);
  reset(() => undefined);
  const s0 = await db.search('P69905', 'auto');
  check('an accession typed with "all databases" does not reach it either', !urls().some(u => /alphafold/.test(u)), urls().join(' | '));
  db.setEnabled('alphafold', true);
  reset((u) => u === 'https://alphafold.ebi.ac.uk/files/AF-P69905-F1-model_v4.pdb' ? text(AF_PDB) : undefined);
  const f = await db.fetchOne('alphafold', 'p69905');
  check('switched on, the v4 model file is fetched by UniProt accession',
    urls()[0] === 'https://alphafold.ebi.ac.uk/files/AF-P69905-F1-model_v4.pdb' && f.format === 'pdb' && f.id === 'P69905' && f.ref === 'alphafold:P69905' && f.fileName === 'AF-P69905-F1-model_v4.pdb', JSON.stringify({ ...f, text: undefined }));
  check('and the structure carries the attribution the licence asks for', f.attribution === 'AlphaFold DB, EMBL-EBI, CC-BY-4.0' && f.licence === 'CC-BY-4.0' && f.source === 'AlphaFold DB');
  reset((u) => u === 'https://alphafold.ebi.ac.uk/api/prediction/P69905' ? json(AF_API) : undefined);
  const s = await db.search('P69905', 'alphafold');
  check('an accession typed with it chosen is looked up in the prediction API for the protein\'s name, and the hit carries the credit too',
    s.hits.length === 1 && s.hits[0].src === 'alphafold' && s.hits[0].title === 'Hemoglobin subunit alpha' && /Homo sapiens/.test(s.hits[0].sub) && s.hits[0].tag === 'AF-P69905' &&
    s.hits[0].attribution === 'AlphaFold DB, EMBL-EBI, CC-BY-4.0' && /UniProt accession/.test(s.notes[0]), JSON.stringify(s));
  reset(() => gone());
  const e3 = await failing(db.fetchOne('alphafold', 'P69905'));
  check('no model for an accession is "missing", named as the model file', e3 && e3.kind === 'notfound' && /AF-P69905-F1/.test(e3.message), e3 && e3.message);
  db.setEnabled('alphafold', false);
}

/* --------------------------------------------- search, across the sources */
{
  const RCSB_ENTRY = (id, title) => ({ rcsb_id: id, struct: { title }, rcsb_entry_info: { deposited_atom_count: 327, polymer_composition: 'protein (only)' }, exptl: [{ method: 'X-RAY DIFFRACTION' }] });
  reset((u) => {
    if (/data\.rcsb\.org\/graphql/.test(u)) return json({ data: { entries: /1CRN/.test(decodeURIComponent(u)) ? [RCSB_ENTRY('1CRN', 'WATER STRUCTURE OF A HYDROPHOBIC PROTEIN')] : [] } });
    if (/pubchem.*\/cid\/2244\/property/.test(u)) return json({ PropertyTable: { Properties: [{ CID: 2244, Title: 'Aspirin', MolecularFormula: 'C9H8O4', MolecularWeight: '180.16' }] } });
    if (/pubchem.*\/property/.test(u)) return gone();
    if (/crystallography\.net\/cod\/result/.test(u)) return json([]);
  });
  let s = await db.search('1CRN', 'auto');
  check('a PDB code typed on its own goes straight to that entry, in one GraphQL request, and says so',
    s.hits.length === 1 && s.hits[0].src === 'rcsb' && s.hits[0].id === '1CRN' && s.hits[0].tag === '1CRN' && s.hits[0].label === 'RCSB PDB' && s.hits[0].attribution === null &&
    /Looks like a PDB identifier\./.test(s.notes[0]) && calls.length === 1, JSON.stringify(s));
  s = await db.search('2244', 'auto');
  check('a number fits several sources (a PDB code, a CID) and all are asked at once; the ones that answer name the note',
    s.hits.length === 1 && s.hits[0].src === 'pubchem' && s.hits[0].tag === 'CID 2244' && s.hits[0].title === 'Aspirin' && /180\.16 g\/mol/.test(s.hits[0].sub) &&
    s.notes[0] === 'Looks like a PubChem CID.' && urls().some(u => /graphql/.test(u)) && urls().some(u => /cid\/2244\/property/.test(u)), JSON.stringify(s));
  reset((u) => {
    if (/search\.rcsb\.org/.test(u)) return new Response(null, { status: 204 });   // RCSB's "no hits"
    if (/pubchem.*\/cids\/JSON/.test(u)) return gone();
    if (/crystallography\.net\/cod\/result/.test(u)) return json([]);
    if (/query\.wikidata\.org/.test(u)) return json({ head: { vars: [] }, results: { bindings: [] } });
  });
  s = await db.search('nothing at all', 'auto');
  const hosts = [...new Set(urls().map(u => new URL(u).host))].sort();
  check('an "all databases" name search asks exactly the sources marked auto: RCSB, PubChem, COD and Wikidata — not the resolver, PDBe, TCOD, Zenodo or AlphaFold',
    hosts.join() === 'pubchem.ncbi.nlm.nih.gov,query.wikidata.org,search.rcsb.org,www.crystallography.net' && s.hits.length === 0 && s.notes.length === 0, hosts.join() + ' ' + JSON.stringify(s.notes));
  reset(() => { throw new TypeError('Failed to fetch'); });
  s = await db.search('1000041', 'auto');
  check('a host that is down is said to be down once, though it was asked by identifier and by name',
    s.hits.length === 0 && s.notes.filter(n => /^COD could not be reached/.test(n)).length === 1 && s.notes.filter(n => /^PubChem/.test(n)).length === 1, JSON.stringify(s.notes));
  const e = await failing(db.search('x', 'auto'));
  check('one character is not a search', e && /at least two characters/.test(e.message));
  const e2 = await failing(db.fetchOne('nosuch', '1'));
  check('an unknown source is refused by name', e2 && /Unknown source: nosuch/.test(e2.message), e2 && e2.message);
}

/* ======================================================================================
   Part 2 — the page, in a browser, the services stood in for by route interception
   ====================================================================================== */
delete globalThis.fetch;   // the browser has its own; nothing below goes through the stand-in above
await sleep(300);
const asked = [];   // every outbound url the page tried, in order

async function install(page, opt = {}) {
  asked.length = 0;
  await page.unrouteAll({ behavior: 'ignoreErrors' }).catch(() => {});
  await page.route('**://search.rcsb.org/**', async (route) => {
    const req = route.request();
    asked.push(req.method() + ' ' + req.url() + ' ' + (req.postData() || ''));
    if (opt.rcsbDown) return route.abort('failed');
    const body = JSON.parse(req.postData() || '{}');
    const term = String(body.query?.parameters?.value || '').toLowerCase();
    if (term.includes('zzzz')) return route.fulfill({ status: 204, body: '' });
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({ total_count: 2, result_set: ['1CRN', '4HHB'] }),
    });
  });
  const ENTRY = {
    '1CRN': { title: 'WATER STRUCTURE OF A HYDROPHOBIC PROTEIN', n: 327 },
    '4HHB': { title: 'THE CRYSTAL STRUCTURE OF HUMAN DEOXYHAEMOGLOBIN', n: 4779 },
  };
  await page.route('**://data.rcsb.org/**', async (route) => {
    const url = route.request().url();
    asked.push('GET ' + url);
    // answer for exactly the entries that were asked for, so "1CRN alone" means 1CRN alone
    const ids = Object.keys(ENTRY).filter(id => decodeURIComponent(url).includes('"' + id + '"'));
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({ data: { entries: ids.map(id => ({
        rcsb_id: id, struct: { title: ENTRY[id].title },
        rcsb_entry_info: { deposited_atom_count: ENTRY[id].n, polymer_composition: 'protein (only)' },
        exptl: [{ method: 'X-RAY DIFFRACTION' }],
      })) } }),
    });
  });
  await page.route('**://files.rcsb.org/**', async (route) => {
    const url = route.request().url();
    asked.push('GET ' + url);
    if (opt.filesDown) return route.abort('failed');
    if (/9XXX\.pdb$/.test(url)) return route.fulfill({ status: 404, body: 'not found' });
    if (/9XXX\.cif$/.test(url)) return route.fulfill({ contentType: 'text/plain', body: MINI_CIF });
    await route.fulfill({ contentType: 'text/plain', body: CRAMBIN });
  });
  await page.route('**://pubchem.ncbi.nlm.nih.gov/**', async (route) => {
    const url = route.request().url();
    asked.push('GET ' + url);
    if (opt.pubchemDown) return route.abort('failed');
    if (/\/name\/[^/]*zzzz/i.test(url)) return route.fulfill({ status: 404, contentType: 'application/json', body: '{"Fault":{}}' });
    if (/\/cids\/JSON/.test(url)) {
      // the word-search fallback must only be reached when the exact name found nothing
      if (/name_type=word/.test(url) && !opt.wordOnly) return route.fulfill({ status: 404, body: '{}' });
      if (!/name_type=word/.test(url) && opt.wordOnly) return route.fulfill({ status: 404, body: '{}' });
      return route.fulfill({ contentType: 'application/json', body: JSON.stringify({ IdentifierList: { CID: [2519, 2244] } }) });
    }
    if (/\/property\//.test(url)) {
      return route.fulfill({ contentType: 'application/json', body: JSON.stringify({ PropertyTable: { Properties: [
        { CID: 2519, Title: 'Caffeine', MolecularFormula: 'C8H10N4O2', MolecularWeight: '194.19' },
        { CID: 2244, Title: 'Aspirin', MolecularFormula: 'C9H8O4', MolecularWeight: '180.16' },
      ] } }) });
    }
    if (/\/SDF/.test(url)) {
      if (/record_type=3d/.test(url) && opt.no3d) return route.fulfill({ status: 404, body: '' });
      return route.fulfill({ contentType: 'chemical/x-mdl-sdfile', body: opt.no3d ? FLAT_SDF : CAFFEINE_SDF });
    }
    await route.fulfill({ status: 404, body: '' });
  });
  /* the sources added in build 24 — mocked so that an "all databases" search never leaves
     the machine; they answer nothing for the names the checks above search for */
  await page.route('**://www.crystallography.net/**', async (route) => {
    const url = route.request().url();
    asked.push('GET ' + url);
    if (/\/cod\/1000041\.cif$/.test(url)) return route.fulfill({ contentType: 'text/plain', body: COD_CIF });
    if (/\/result\?/.test(url)) return route.fulfill({ contentType: 'application/json', body: '[]' });
    await route.fulfill({ status: 404, body: 'not found' });
  });
  await page.route('**://query.wikidata.org/**', async (route) => {
    const url = route.request().url();
    asked.push('GET ' + url);
    const q = decodeURIComponent(url);
    const bindings = /wd:Q18216/.test(q) ? [SPARQL_JSON.results.bindings[0]] : [];
    await route.fulfill({ contentType: 'application/sparql-results+json', body: JSON.stringify({ head: { vars: [] }, results: { bindings } }) });
  });
  await page.route('**://www.ebi.ac.uk/**', async (route) => {
    const url = route.request().url();
    asked.push('GET ' + url);
    if (opt.pdbeDown) return route.abort('failed');
    if (/entry-files\/download\/1crn\.cif$/.test(url)) return route.fulfill({ contentType: 'text/plain', body: MINI_CIF.replace('9XXX', '1CRN') });
    await route.fulfill({ status: 404, body: 'not found' });
  });
  for (const host of ['cactus.nci.nih.gov', 'zenodo.org', 'alphafold.ebi.ac.uk']) {
    await page.route(`**://${host}/**`, async (route) => { asked.push('GET ' + route.request().url()); await route.fulfill({ status: 404, body: '' }); });
  }
}

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await install(page);
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

const hits = () => page.$$eval('#findHits .hit', els => els.map(e => e.textContent));
const findMsg = () => page.textContent('#findMsg');
const settle = (p = page) =>
  p.waitForFunction(() => !/^Searching/.test(document.getElementById('findMsg').textContent), null, { timeout: 20000 });
/** Changing the database re-runs the search by itself, which is the point of it — so set
    that first, let whatever it starts finish, and only then time the search being measured. */
async function search(text, where = 'auto') {
  await page.selectOption('#findWhere', where);
  await settle();
  await page.fill('#findInput', text);
  asked.length = 0;
  await page.click('#btnFindGo');
  await settle();
}

/* ------------------------------------------------------------ the dialog opens */
await page.click('#btnFind');
check('FIND opens a dialog', await page.isVisible('#findDlg.open'));
check('and it says what a search sends where, before anything is typed',
  /sends what you type.*network address/i.test(await page.textContent('#findDlg .warn')));
check('and that what you bring in is not copied into the link',
  /link carries the identifier/i.test(await page.textContent('#findDlg .warn')));

/* ------------------------------------------------------------------- searching */
await search('haemoglobin');
const h1 = await hits();
check('a search finds entries in both databases', h1.length === 4, h1.length + ' hits');
check('a PDB hit shows its code, title and method',
  h1.some(t => /1CRN/.test(t) && /HYDROPHOBIC PROTEIN/.test(t) && /X-RAY/.test(t) && /RCSB PDB/.test(t)),
  h1.find(t => /1CRN/.test(t)) || '(none)');
check('a PubChem hit shows its CID, name and formula',
  h1.some(t => /CID 2519/.test(t) && /Caffeine/.test(t) && /C8H10N4O2/.test(t) && /194\.19/.test(t)),
  h1.find(t => /2519/.test(t)) || '(none)');
check('the RCSB search went to the documented endpoint, as a POST full-text query',
  asked.some(a => /^POST https:\/\/search\.rcsb\.org\/rcsbsearch\/v2\/query/.test(a) && /full_text/.test(a) && /haemoglobin/.test(a)),
  asked.find(a => a.startsWith('POST')) || '(none)');
check('titles came back in ONE graphql request, not one per hit',
  asked.filter(a => a.includes('data.rcsb.org')).length === 1,
  asked.filter(a => a.includes('data.rcsb.org')).length + ' requests');
check('PubChem was asked for the exact name first',
  /\/name\/haemoglobin\/cids\/JSON$/.test((asked.find(a => a.includes('/cids/JSON')) || '').replace('GET ', '')),
  asked.find(a => a.includes('/cids/JSON')) || '(none)');
check('and, that name having resolved, not asked for a word search on top of it',
  !asked.some(a => /name_type=word/.test(a)), asked.filter(a => a.includes('cids')).join(' | '));
check('the "all databases" search also asked COD and Wikidata — and nothing left the machine unmocked',
  asked.some(a => /crystallography\.net\/cod\/result\?format=json&text=haemoglobin/.test(a)) && asked.some(a => /query\.wikidata\.org\/sparql/.test(a)),
  asked.map(a => a.slice(0, 70)).join(' | '));

await install(page, { wordOnly: true });
await search('sulfa', 'pubchem');
check('a name that matches nothing exactly falls back to a word search',
  (await hits()).length === 2 && asked.some(a => /name_type=word/.test(a)),
  asked.filter(a => a.includes('cids')).join(' | '));
await install(page);

await search('1CRN');
const h2 = await hits();
check('a PDB code typed on its own goes straight to that entry and nothing else',
  h2.length === 1 && /1CRN/.test(h2[0]), h2.join(' | '));
check('and says so', /PDB identifier/i.test(await findMsg()));

await page.fill('#findInput', 'caffeine');
await page.click('#btnFindGo');
await settle();
asked.length = 0;
await page.selectOption('#findWhere', 'pubchem');
await settle();
check('changing the database re-runs the search by itself', (await hits()).filter(h => !/^NAME/.test(h)).length === 2, (await hits()).join(' | '));
check('and a name the page knows itself is offered too, last, as an offline result', (await hits()).some(h => /^NAME/.test(h) && /offline/.test(h)));
check('and restricting to PubChem does not ask RCSB at all',
  !asked.some(a => a.includes('rcsb.org')), asked.join(' | ').slice(0, 160));

await search('zzzzqq');
check('nothing found says so plainly, and is not an error',
  /Nothing found/i.test(await findMsg()) && (await hits()).length === 0, await findMsg());

/* --------------------------------------------------- one service being down */
await install(page, { rcsbDown: true });
await search('haemoglobin');
check('when one service cannot be reached, the other still answers',
  (await hits()).length === 2 && /RCSB PDB could not be reached/i.test(await findMsg()), await findMsg());
check('and the message says what to do instead', /use OPEN with a file you already have/i.test(await findMsg()));
check('and says that a refusal and a dead server look the same from here', /does not allow other sites to read its files \(or is unreachable\)/.test(await findMsg()), await findMsg());

/* ------------------------------------------------------------------ importing */
await install(page);
await search('haemoglobin');
await page.click('#findHits .hit:has-text("1CRN")');
await page.waitForFunction(() => !document.getElementById('findDlg').classList.contains('open'), null, { timeout: 20000 });
const st = () => page.evaluate(() => ({ ...window.dworm2d.state3d, data: null, molblock: null }));
let s = await st();
check('the entry is in the 3D view, with its hydrogens', s.nAtoms === 10, s.nAtoms + ' atoms');
check('and it is marked as coming from RCSB', s.remote && s.remote.ref === 'rcsb:1CRN', JSON.stringify(s.remote));
check('the page says where it came from and what that means for a link',
  /rcsb:1CRN/.test(await page.textContent('#msg')) && /identifier, not the coordinates/.test(await page.textContent('#msg')),
  await page.textContent('#msg'));
check('the coordinates were fetched from files.rcsb.org',
  asked.some(a => a === 'GET https://files.rcsb.org/download/1CRN.pdb'), asked.slice(-2).join(' | '));

/* ------------------------------------------- the link carries the identifier */
let state = await page.evaluate(() => window.dworm2d.buildState('full'));
check('a shared link carries the identifier, not the structure', state.rf === 'rcsb:1CRN' && !state.m3, JSON.stringify({ rf: state.rf, m3: !!state.m3 }));
check('and the entry title, so the recipient sees a name while it loads', /HYDROPHOBIC/.test(state.rn || ''), state.rn || '(none)');
/* measured against the same link carrying the same structure's coordinates, not against a
   number: the rest of the state grows with every build and has nothing to do with FIND */
const lens = await page.evaluate(async () => {
  const st = await window.dworm2d.buildState('full');
  const ref = (await window.dworm2d.encodeState(st)).length;
  const withCoords = { ...st }; delete withCoords.rf; delete withCoords.rn;
  withCoords.m3 = window.dworm2d.state3d.data; withCoords.m3f = window.dworm2d.state3d.format; withCoords.m3n = '1CRN.pdb';
  return { ref, coords: (await window.dworm2d.encodeState(withCoords)).length };
});
check('which makes the link far shorter than the coordinates would', lens.ref < lens.coords / 2, `${lens.ref} characters against ${lens.coords} with the coordinates — for a ten-atom fixture`);

await page.click('#btnShare');
await page.waitForFunction(() => document.getElementById('shareUrl').value.length > 0, null, { timeout: 20000 });
check('the share dialog explains that the structure is fetched, not carried',
  /identifier rcsb:1CRN/.test(await page.textContent('#shareModeNote')) && /need to be online/.test(await page.textContent('#shareModeNote')),
  await page.textContent('#shareModeNote'));
const shareUrl = await page.inputValue('#shareUrl');
await page.click('#shareDlg [data-close]');

/* ------------------------------ changing the structure gives up the provenance */
await page.evaluate(() => window.dworm2d.minimizeCurrent());
await page.waitForFunction(() => !document.getElementById('btnMinimize').classList.contains('running'), null, { timeout: 120000 });
s = await st();
check('minimising it makes it your own work again — the provenance is dropped', s.remote === null, JSON.stringify(s.remote));
state = await page.evaluate(() => window.dworm2d.buildState('full'));
check('so the changed structure travels as coordinates, as before', !state.rf && !!state.m3,
  JSON.stringify({ rf: state.rf, m3: state.m3 ? state.m3.length + ' chars' : null }));

/* ----------------------------------------------------- opening a shared link */
const page2 = await ctx.newPage();
const errors2 = [];
page2.on('pageerror', e => errors2.push(e.message));
await install(page2);
await page2.goto(shareUrl.replace('http://localhost', 'http://127.0.0.1'));
await page2.waitForFunction(() => /Shared structure loaded/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
const s2 = await page2.evaluate(() => ({ ...window.dworm2d.state3d, data: null, molblock: null }));
check('opening the link fetches the entry again rather than reading it from the link',
  s2.nAtoms === 10 && s2.remote && s2.remote.ref === 'rcsb:1CRN', JSON.stringify({ n: s2.nAtoms, r: s2.remote }));
check('and the fetch really went out to RCSB', asked.some(a => a.includes('files.rcsb.org/download/1CRN.pdb')));
check('the recipient is told the structure was fetched, not carried',
  /fetched from rcsb:1CRN/.test(await page2.textContent('#msg')), await page2.textContent('#msg'));
check('and they can share it on by identifier too',
  (await page2.evaluate(() => window.dworm2d.buildState('full'))).rf === 'rcsb:1CRN');

/* the honest failure: no coordinates were stored, so there is nothing to fall back on —
   with RCSB's files AND the PDBe mirror both unreachable, since the mirror is tried first */
const page3 = await ctx.newPage();
await install(page3, { filesDown: true, pdbeDown: true });
await page3.goto(shareUrl.replace('http://localhost', 'http://127.0.0.1'));
await page3.waitForFunction(() => /could not be fetched/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
const m3 = await page3.textContent('#msg');
check('if the database cannot be reached, the link says so instead of showing an empty panel',
  /could not be fetched/.test(m3) && /Nothing was stored with the link/.test(m3), m3);
check('and names the mirror it also tried', /PDBe/.test(m3) && asked.some(a => /ebi\.ac\.uk\/pdbe\/entry-files\/download\/1crn\.cif/.test(a)), m3);
check('and the drawing that travelled with it still arrives',
  (await page3.evaluate(() => window.dworm2d.state3d.nAtoms)) === 0);
await page3.close();

/* the mirror doing its job: RCSB's file server down, PDBe up */
const page4 = await ctx.newPage();
await install(page4, { filesDown: true });
await page4.goto(shareUrl.replace('http://localhost', 'http://127.0.0.1'));
await page4.waitForFunction(() => /Shared structure loaded/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
const s4 = await page4.evaluate(() => ({ ...window.dworm2d.state3d, data: null, molblock: null }));
check('when only RCSB\'s file server is down, the link still opens — the entry came from PDBe',
  s4.nAtoms === 3 && s4.format === 'cif' && s4.remote && s4.remote.ref === 'rcsb:1CRN' &&
  asked.some(a => /files\.rcsb\.org\/download\/1CRN\.pdb/.test(a)) && asked.some(a => /ebi\.ac\.uk\/pdbe\/entry-files\/download\/1crn\.cif/.test(a)),
  JSON.stringify({ n: s4.nAtoms, f: s4.format, r: s4.remote }) + ' ' + asked.filter(a => /rcsb\.org\/download|ebi/.test(a)).join(' | '));
await page4.close();
await page2.close();

/* ------------------------------------------------- a small molecule from PubChem */
await install(page);
await page.evaluate(() => document.getElementById('btnClear3d').click());
await page.click('#btnFind');
await search('caffeine', 'pubchem');
await page.click('#findHits .hit:has-text("Caffeine")');
await page.waitForFunction(() => !document.getElementById('findDlg').classList.contains('open'), null, { timeout: 20000 });
s = await st();
check('a PubChem compound arrives in the 3D view', s.nAtoms === 6, s.nAtoms + ' atoms');
check('marked as coming from PubChem', s.remote && s.remote.ref === 'pubchem:2519', JSON.stringify(s.remote));
check('the 3D conformer was asked for first', asked.some(a => /cid\/2519\/SDF\?record_type=3d/.test(a)));
const ket = await page.evaluate(async () => (await window.dworm2d.whenKetcher()).getMolfile());
check('and it is in the drawing as well', /V2000/.test(ket) && (ket.match(/\n/g) || []).length > 8);
check('the SDF data fields did not follow it into Ketcher', !/PUBCHEM_COMPOUND_CID/.test(ket));
check('nor into the structure the force field is given',
  !/PUBCHEM_COMPOUND_CID/.test(await page.evaluate(() => window.dworm2d.state3d.molblock || '')));

/* a compound with no computed conformer belongs in the drawing, not in the 3D panel */
await install(page, { no3d: true });
await page.evaluate(() => document.getElementById('btnClear3d').click());
await page.click('#btnFind');
await search('caffeine', 'pubchem');
await page.click('#findHits .hit:has-text("Caffeine")');
await page.waitForFunction(() => /MAKE 3D/.test(document.getElementById('msg').textContent), null, { timeout: 20000 });
check('a compound PubChem has no 3D conformer for goes to the drawing and says so',
  (await st()).nAtoms === 0 && /no computed 3D (conformer|structure)/.test(await page.textContent('#msg')),
  await page.textContent('#msg'));
check('after trying for a 3D record first', asked.some(a => /record_type=3d/.test(a)) && asked.some(a => /record_type=2d/.test(a)));

/* --------------------------------------------- an entry published only as mmCIF */
await install(page);
await page.evaluate(() => window.dworm2d.importHit({ src: 'rcsb', id: '9XXX', title: 'ONLY AS CIF' }));
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 20000 });
s = await st();
check('an entry with no PDB file falls back to mmCIF', s.nAtoms === 3 && s.format === 'cif', JSON.stringify({ n: s.nAtoms, f: s.format }));
check('after asking for the PDB first', asked.some(a => /9XXX\.pdb$/.test(a)) && asked.some(a => /9XXX\.cif$/.test(a)));

/* ---------------------------------------- the new sources, through the page's importHit */
await install(page);
await page.evaluate(() => document.getElementById('btnClear3d').click());
await page.evaluate(() => window.dworm2d.importHit({ src: 'cod', id: '1000041', title: 'Sodium chloride' }));
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 20000 });
s = await st();
/* since build 24 a CIF is expanded by its symmetry on the OPEN path, so the rock-salt entry
   (Fm-3m, two atoms in the asymmetric unit) arrives as the eight atoms of its cell */
check('a COD entry arrives in the 3D view through the page\'s existing OPEN path, expanded by its symmetry',
  s.nAtoms === 8 && s.remote && s.remote.ref === 'cod:1000041' && asked.some(a => a === 'GET https://www.crystallography.net/cod/1000041.cif'),
  JSON.stringify({ n: s.nAtoms, f: s.format, r: s.remote }));
check('and the page names the source from the list, not from code',
  /from COD \(cod:1000041\)/.test(await page.textContent('#msg')), await page.textContent('#msg'));
check('and a link made now carries cod:1000041', (await page.evaluate(() => window.dworm2d.buildState('full'))).rf === 'cod:1000041');

await page.evaluate(() => document.getElementById('btnClear3d').click());
await page.evaluate(() => window.dworm2d.importHit({ src: 'wikidata', id: 'Q18216', title: 'aspirin' }));
await page.waitForFunction(() => /MAKE 3D/.test(document.getElementById('msg').textContent), null, { timeout: 20000 });
const ketWd = await page.evaluate(async () => (await window.dworm2d.whenKetcher()).getMolfile());
check('a Wikidata SMILES lands in the drawing, flat, waiting for MAKE 3D',
  (await st()).nAtoms === 0 && /^ *13 *13 /m.test(ketWd) && asked.some(a => /query\.wikidata\.org\/sparql/.test(a)),
  (ketWd.split('\n')[3] || '').trim());

/* ------------------------------------------------------------------- hygiene */
check('a bad identifier in a link is refused, not fetched', await page.evaluate(async () => {
  await window.dworm2d.applyState({ v: 2, rf: 'file:///etc/passwd' });
  return /does not know how to fetch/.test(document.getElementById('msg').textContent);
}));
check('CLEAR forgets the provenance too', await page.evaluate(() => {
  document.getElementById('btnClear3d').click();
  return window.dworm2d.state3d.remote === null;
}));
const noisy = [...errors, ...errors2].filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
