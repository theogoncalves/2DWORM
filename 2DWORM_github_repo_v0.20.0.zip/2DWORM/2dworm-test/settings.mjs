/* The settings the administrator can change from the page, and the read limits.
 *
 * Two kinds of thing are worth testing here and they are not the same. One is that a saved
 * value actually GOVERNS — that turning a limit down really does make the endpoint refuse
 * what it used to accept, rather than merely showing a different number in a box. The other,
 * and the more important, is what the page must NOT be able to reach: the administrator
 * password, the database path, the country-table path and the two URL settings, because
 * anyone who got into the admin page could otherwise change the password, point the service
 * at another database, or send every link anybody shares to a site of their own.
 *
 * The read side gets its own attention. A ceiling on opens per address is what stops somebody
 * copying the whole store by walking the key space; a wait would be paid by the colleague who
 * was sent the link, so it ships off, and both of those are asserted rather than assumed.
 */
import { spawn, spawnSync } from 'node:child_process';
import { readdirSync, existsSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const APP    = fileURLToPath(new URL('../2dworm/', import.meta.url));
const DATA   = join(APP, 'QRsharing/data');
const DB     = join(DATA, 'shares.sqlite');
const CONFIG = join(APP, 'QRsharing/config.php');
const SWITCH = join(APP, 'QRsharing/.admin-enabled');
const PORT   = 8798;
const BASE   = `http://127.0.0.1:${PORT}`;
const API    = `${BASE}/QRsharing/share.php`;
const ADMIN  = `${BASE}/QRsharing/admin.php`;

for (const f of existsSync(DATA) ? readdirSync(DATA) : []) { if (/sqlite/.test(f)) { rmSync(join(DATA, f)); } }
const hadConfig = existsSync(CONFIG);
const oldConfig = hadConfig ? readFileSync(CONFIG, 'utf8') : null;

const PASSWORD = 'a-password-for-the-suite';
const hash = spawnSync('php', ['-r', `echo password_hash(${JSON.stringify(PASSWORD)}, PASSWORD_DEFAULT);`], { encoding: 'utf8' }).stdout.trim();
/* small_wait 1, so this suite spends its time on the settings rather than on proving the
   ten-second wait again — server.mjs does that where it belongs. */
writeFileSync(CONFIG, `<?php return [\n  'admin_hash' => '${hash}',\n  'small_wait' => 1,\n  'large_per_hour' => 40,\n];\n`);
writeFileSync(SWITCH, '');

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const cleanup = () => {
  server.kill();
  rmSync(SWITCH, { force: true });
  if (hadConfig) { writeFileSync(CONFIG, oldConfig); } else { rmSync(CONFIG, { force: true }); }
};
process.on('exit', cleanup);

const q = (sql) => (spawnSync('php', ['-r',
  `$d=new PDO('sqlite:' . $argv[1]); foreach($d->query($argv[2]) as $r) { echo implode('|', array_slice($r, 0, count($r)/2)), "\\n"; }`,
  '--', DB, sql], { encoding: 'utf8' }).stdout || '').trim();

let cookie = '';
const get = async (url) => {
  const r = await fetch(url, { headers: cookie ? { Cookie: cookie } : {}, redirect: 'manual' });
  const sc = r.headers.get('set-cookie'); if (sc) { cookie = sc.split(';')[0]; }
  return { status: r.status, text: await r.text() };
};
const post = async (fields) => {
  const body = new URLSearchParams(fields).toString();
  const r = await fetch(ADMIN, { method: 'POST', body, redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(cookie ? { Cookie: cookie } : {}) } });
  const sc = r.headers.get('set-cookie'); if (sc) { cookie = sc.split(';')[0]; }
  return { status: r.status, text: await r.text() };
};
const csrfOf = (html) => (html.match(/name="csrf" value="([^"]+)"/) || [])[1] || '';
/** Store a drawing, doing the ticket dance so the wait does not have to be waited out twice. */
const share = async (payload) => {
  for (let i = 0, ticket = null; i < 3; i++) {
    const r = await fetch(API, { method: 'POST', body: payload,
      headers: ticket ? { 'X-DW-Ticket': ticket } : {} });
    const j = await r.json();
    if (j.ok) { return j; }
    if (j.error === 'wait' && j.ticket) { ticket = j.ticket; await new Promise(s => setTimeout(s, (j.wait + 1) * 1000)); continue; }
    return j;
  }
  return { ok: false, error: 'gave up' };
};
const payload = (tag, n = 30) => 'z=' + tag + 'A'.repeat(n);

/* -------------------------------------------------------------------- logging in */
let page = (await get(ADMIN)).text;
await post({ do: 'login', csrf: csrfOf(page), pw: PASSWORD });   // the field is `pw`
page = (await get(ADMIN)).text;
check('the settings section is on the page', /<h2>Settings<\/h2>/.test(page));
check('and it says where each value comes from',
  /config\.php/.test(page) && /the shipped default/.test(page) &&
  /small_max_bytes/.test(page) && /read_per_hour/.test(page));
const creditFor = (k) => {
  const row = (page.match(new RegExp('<code class="muted">' + k + '</code>[\\s\\S]*?</tr>')) || [''])[0];
  return /set here/.test(row) ? 'set here' : /config\.php/.test(row) ? 'config.php' : 'default';
};
check('a value set in config.php is credited to config.php, not claimed by the page',
  creditFor('small_wait') === 'config.php' && creditFor('large_per_hour') === 'config.php' &&
  creditFor('read_per_hour') === 'default',
  `small_wait ${creditFor('small_wait')}, large_per_hour ${creditFor('large_per_hour')}, read_per_hour ${creditFor('read_per_hour')}`);

/* ------------------------------------------------- the five that must not be reachable */
const forbidden = ['admin_hash', 'db_path', 'geo_csv', 'page_url', 'short_base'];
check('the password, the database, the geo file and the two URLs have no box on the page',
  forbidden.every(k => !new RegExp(`name="s_${k}"`).test(page)), forbidden.join(', '));
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_admin_hash: 'nonsense', s_db_path: '/tmp/elsewhere.sqlite',
             s_page_url: 'https://example.invalid/', s_small_max_bytes: '20480' });
check('and posting them anyway writes nothing: the form is not the list of what may be changed',
  q("SELECT COUNT(*) FROM meta WHERE k IN ('set.admin_hash','set.db_path','set.page_url')") === '0');
check('the password in config.php is untouched, so the door still opens',
  (await get(ADMIN)).text.includes('<h2>Settings</h2>'));

/* ------------------------------------------------------ a saved value really governs */
check('a 30-byte drawing is accepted at the shipped limit', (await share(payload('a'))).ok === true);
page = (await get(ADMIN)).text;
let r = await post({ do: 'settings', csrf: csrfOf(page), s_small_max_bytes: '1024', s_large_max_bytes: '2048' });
check('lowering the size limits is accepted', /Settings saved/.test(r.text), (r.text.match(/class="msg[^"]*">([^<]*)/) || [])[1]);
const big = await share(payload('b', 4000));
check('and the endpoint refuses at the NEW limit, not the one it shipped with',
  big.ok === false && big.error === 'too_large', JSON.stringify(big).slice(0, 90));
check('while something inside the new limit still goes through', (await share(payload('c'))).ok === true);
const status = await (await fetch(`${API}?status`)).json();
check('the page is told the new limits too, so it stops offering what will be refused',
  status.max_bytes === 2048 && status.small_bytes === 1024, `max ${status.max_bytes}, small ${status.small_bytes}`);

/* ------------------------------------------------------------- clearing hands it back */
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_small_max_bytes: '', s_large_max_bytes: '' });
const back = await (await fetch(`${API}?status`)).json();
check('clearing a box hands the setting back to the shipped default',
  back.small_bytes === 20480 && back.max_bytes === 512000, `small ${back.small_bytes}, max ${back.max_bytes}`);
check('and nothing is left behind in the database for it',
  q("SELECT COUNT(*) FROM meta WHERE k IN ('set.small_max_bytes','set.large_max_bytes')") === '0');
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_small_wait: '1', s_small_max_rows: '100000' });
check('saving a value that equals config.php does not quietly take config.php out of the loop',
  q("SELECT COUNT(*) FROM meta WHERE k = 'set.small_wait'") === '0' &&
  q("SELECT COUNT(*) FROM meta WHERE k = 'set.small_max_rows'") === '0');

/* -------------------------------------------------------------------- what is refused */
page = (await get(ADMIN)).text;
r = await post({ do: 'settings', csrf: csrfOf(page), s_max_age_days: '999999' });
check('a figure outside the allowed range is refused and says the range',
  /Not saved/.test(r.text) && /between/.test(r.text),
  ((r.text.match(/class="msg[^"]*">([^<]*)/) || [])[1] || '').slice(0, 100));
r = await post({ do: 'settings', csrf: csrfOf((await get(ADMIN)).text), s_read_per_hour: 'lots' });
check('and so is something that is not a number', /Not saved/.test(r.text));
check('nothing of either was stored', q("SELECT COUNT(*) FROM meta WHERE k IN ('set.max_age_days','set.read_per_hour')") === '0');

/* ------------------------------------------- the three added in 2.1 govern as well
   Retirement (off by default) and the operator's own upload ceiling. Saved here, they must
   reach the status the page reads and the form the operator uses — not merely a box. */
page = (await get(ADMIN)).text;
r = await post({ do: 'settings', csrf: csrfOf(page), s_retire_hits: '200', s_retire_days: '45', s_keep_max_bytes: '2048' });
const st2 = await (await fetch(`${API}?status`)).json();
check('retire_hits and retire_days saved on the page reach the status the app reads',
  /Settings saved/.test(r.text) && st2.retire_hits === 200 && st2.retire_days === 45, `${st2.retire_hits} opens, ${st2.retire_days} days`);
page = (await get(ADMIN)).text;
check('and keep_max_bytes reaches the upload form, in the unit a person reads', /Up to 2 kB/.test(page),
  (page.match(/Up to [^<(]+/) || [''])[0]);
check('the page now says the retirement rule is on, with the figures in force',
  /rule is on: a code opened more than\s*<b>200<\/b> times is retired\s*<b>45 days<\/b>/.test(page));
r = await post({ do: 'settings', csrf: csrfOf(page), s_retire_days: '0' });
check('zero days of notice is refused — the count must never be the thing that deletes',
  /Not saved/.test(r.text) && /between 1 and 3,650/.test(r.text) && q("SELECT v FROM meta WHERE k = 'set.retire_days'") === '45');
r = await post({ do: 'settings', csrf: csrfOf(page), s_keep_max_bytes: '999999999999' });
check('and so is an upload ceiling above 500 MB', /Not saved/.test(r.text) && /between 1,024 and 524,288,000/.test(r.text));
await post({ do: 'settings', csrf: csrfOf(page), s_retire_hits: '', s_retire_days: '', s_keep_max_bytes: '' });
const st3 = await (await fetch(`${API}?status`)).json();
check('clearing the three hands them back: the rule is off again and the status says so',
  st3.retire_hits === 0 && st3.retire_days === 0 && q("SELECT COUNT(*) FROM meta WHERE k IN ('set.retire_hits','set.retire_days','set.keep_max_bytes')") === '0');

/* --------------------------------------------------------------- the read ceiling */
const one = await share(payload('read-me'));
check('there is a drawing to read', one.ok === true, one.key);
const readIt = () => fetch(`${API}?k=${one.key}`, { cache: 'no-store' });
check('reading it is not delayed by default: no wait, first try', (await (await readIt()).json()).ok === true);
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_read_per_hour: '3' });
let codes = [];
for (let i = 0; i < 6; i++) { codes.push((await readIt()).status); }
check('a ceiling on opens per address bites, and says so with 429 rather than pretending',
  codes.filter(c => c === 200).length <= 3 && codes.includes(429), codes.join(','));
check('and no address was stored to do it — only a salted hourly hash',
  q("SELECT COUNT(*) FROM rl") !== '0' &&
  q("SELECT COUNT(*) FROM rl WHERE bucket LIKE '%127.0.0.1%' OR bucket LIKE '%::1%'") === '0');
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_read_per_hour: '0' });
check('setting the ceiling to zero means no ceiling, which is what 0 usually means',
  (await (await readIt()).status) === 200);

/* ------------------------------------------------------------------ the read wait */
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_read_wait: '2' });
const first = await readIt();
const fj = await first.json();
check('with a wait set, the first read is answered with a ticket instead of the drawing',
  first.status === 202 && fj.error === 'wait' && typeof fj.ticket === 'string' && fj.wait === 2,
  JSON.stringify(fj).slice(0, 110));
check('and the drawing is NOT in that answer — a wait that hands the thing over is not a wait',
  !('payload' in fj));
const tooSoon = await fetch(`${API}?k=${one.key}`, { headers: { 'X-DW-Ticket': fj.ticket } });
check('coming back too soon is refused, by the server and not by the page',
  tooSoon.status === 202, 'HTTP ' + tooSoon.status);
await new Promise(s => setTimeout(s, 2200));
const late = await fetch(`${API}?k=${one.key}`, { headers: { 'X-DW-Ticket': fj.ticket } });
const lj = await late.json();
check('and the same ticket works once the time has really passed', late.status === 200 && lj.ok === true);
const forged = await fetch(`${API}?k=${one.key}`, { headers: { 'X-DW-Ticket': '1000000000.' + 'a'.repeat(32) } });
check('a made-up ticket does not', forged.status === 202, 'HTTP ' + forged.status);
check('a waited read is not cached, or the wait would be served once and skipped for ever',
  /no-store/.test(late.headers.get('cache-control') || ''), late.headers.get('cache-control'));
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_read_wait: '0' });
check('and with the wait back at zero the drawing comes straight back, cached again',
  (await (await readIt()).json()).ok === true);

/* ------------------------------------------------- the policy warning, and PRUNE NOW */
page = (await get(ADMIN)).text;
/* This installation's config.php sets small_wait to 1 so the suite is not spent waiting, which
   is itself a departure from what TERMS.md says — and the warning is right to mention it. So
   the checks are about WHICH sentences it names, not about whether any warning is showing:
   that is the more useful property anyway. */
const drift = () => (page.match(/class="warn"[\s\S]*?<\/p>/) || [''])[0].replace(/<[^>]+>/g, ' ');
check('the warning names the sentence that is untrue and no others',
  /waits a few seconds/.test(drift()) && !/two years/.test(drift()) && !/OPENING/.test(drift()),
  drift().replace(/\s+/g, ' ').trim().slice(0, 120));
await post({ do: 'settings', csrf: csrfOf(page), s_max_age_days: '30', s_read_wait: '5' });
page = (await get(ADMIN)).text;
check('changing another makes it name that one too, with the figure that is now in force',
  /two years/.test(drift()) && /30 days/.test(drift()) && /now makes them wait 5 seconds/.test(drift()),
  drift().replace(/\s+/g, ' ').trim().slice(0, 160));
check('and it tells the operator to fix one or the other rather than just noting it',
  /edit .{0,40}TERMS\.md.{0,60}so the policy is true again/s.test(page.replace(/<[^>]+>/g, '')));
page = (await get(ADMIN)).text;
await post({ do: 'settings_reset', csrf: csrfOf(page) });
page = (await get(ADMIN)).text;
check('FORGET ALL OF THESE clears every one of them, and the warnings they caused',
  !/two years/.test(drift()) && !/OPENING/.test(drift()) &&
  q("SELECT COUNT(*) FROM meta WHERE k LIKE 'set.%'") === '0',
  drift().replace(/\s+/g, ' ').trim().slice(0, 120));
/* the checkbox marker: a form that posts only some fields must not switch counting off */
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_read_per_hour: '500' });
check('a partial save does not silently switch the counters off — an unticked box sends nothing',
  q("SELECT COUNT(*) FROM meta WHERE k = 'set.count_usage'") === '0' &&
  /name="s_count_usage_sent"/.test(page));

for (let i = 0; i < 8; i++) { await share(payload('p' + i)); }
const rowsBefore = Number(q('SELECT COUNT(*) FROM shares'));
page = (await get(ADMIN)).text;
await post({ do: 'settings', csrf: csrfOf(page), s_small_max_rows: '10' });
page = (await get(ADMIN)).text;
check('lowering a row limit does not delete anything by itself',
  Number(q('SELECT COUNT(*) FROM shares')) === rowsBefore, rowsBefore + ' rows still there');
const preview = (page.match(/Would remove ([\d,]+) entries and ([^<]+)</) || []);
check('and PRUNE NOW says what it would remove before it removes it',
  !!preview[1] && Number(preview[1].replace(/,/g, '')) > 0, preview[0] || 'no preview shown');
r = await post({ do: 'prune', csrf: csrfOf(page) });
const rowsAfter = Number(q('SELECT COUNT(*) FROM shares'));
check('pressing it removes what it said, and reports the same figure back',
  rowsAfter === rowsBefore - Number(preview[1].replace(/,/g, '')) &&
  new RegExp('Pruned: ' + preview[1] + ' entries').test(r.text),
  `${rowsBefore} -> ${rowsAfter}; ` + ((r.text.match(/Pruned:[^<]*/) || [])[0] || ''));

cleanup();
process.removeAllListeners('exit');
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
