/* The feature counters: count.php, the tally table, and the page that feeds them.
 *
 * These numbers exist so that one person can see which parts of 2D-WORM are worth keeping.
 * That is a small benefit, and it is only worth having if the counting cannot turn into a
 * record of who did what — so most of this suite is about what must NOT end up in the
 * database, and reads the database directly rather than believing the endpoint's reply.
 *
 * The one invariant everything else rests on: a row is a day, a kind, a key and a number,
 * and no two rows can be joined into a description of a person.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn, spawnSync } from 'node:child_process';
import { readdirSync, existsSync, rmSync, mkdtempSync, writeFileSync, cpSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const APP  = fileURLToPath(new URL('../2dworm/', import.meta.url));
const DATA = join(APP, 'QRsharing/data');
const DB   = join(DATA, 'shares.sqlite');
const PORT = 8794, OFFPORT = 8795;

/* a database left over from another suite would make every figure below meaningless */
for (const f of existsSync(DATA) ? readdirSync(DATA) : []) {
  if (/sqlite/.test(f)) { rmSync(join(DATA, f)); }
}

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });

/* The same service with counting switched off, in a copy of its own — rewriting a config
   under a running PHP and hoping it is re-read is how this test flaked the first time. */
const off = mkdtempSync(join(tmpdir(), 'dw-off-'));
cpSync(join(APP, 'QRsharing'), join(off, 'QRsharing'), { recursive: true });
rmSync(join(off, 'QRsharing/data'), { recursive: true, force: true });
writeFileSync(join(off, 'QRsharing/config.php'),
  "<?php return ['count_usage' => false, 'db_path' => '" + join(off, 'QRsharing/data/shares.sqlite') + "'];\n");
const offServer = spawn('php', ['-S', '127.0.0.1:' + OFFPORT, '-t', off], { stdio: 'ignore' });

await new Promise(r => setTimeout(r, 1000));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/** Read the database itself. The endpoint's own answer is not evidence about what it wrote. */
const q = (sql, db = DB) => {
  const r = spawnSync('php', ['-r',
    `$d=new PDO('sqlite:' . $argv[1]); foreach($d->query($argv[2]) as $row) { echo implode('|', array_slice($row, 0, count($row) / 2)), "\\n"; }`,
    '--', db, sql], { encoding: 'utf8' });
  return (r.stdout || '').trim();
};

const post = async (body, ua, port = PORT) => {
  const r = await fetch(`http://127.0.0.1:${port}/QRsharing/count.php`, {
    method: 'POST', body: typeof body === 'string' ? body : JSON.stringify(body),
    headers: { 'Content-Type': 'application/json', ...(ua ? { 'User-Agent': ua } : {}) },
  });
  let json = null; try { json = await r.json(); } catch { /* not every answer is JSON */ }
  return { status: r.status, json, cookie: r.headers.get('set-cookie') };
};

const QUEST = 'Mozilla/5.0 (X11; Linux x86_64) OculusBrowser/34.0 Quest 3 SamsungBrowser/4.0 Chrome/130 Safari/537.36';
const PICO  = 'Mozilla/5.0 (Linux; Android 10; Pico 4) AppleWebKit/537.36 PicoBrowser/4.7 Chrome/126 Safari/537.36';
const WIN   = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130 Safari/537.36';
const MAC   = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15';

/* ------------------------------------------------------------- what it accepts */

const a = await post({ f: { make3d: 3, minimize: 1, nonsense: 9 }, first: true }, WIN);
check('the endpoint takes a batch of features and says it is counting',
  a.status === 200 && a.json && a.json.ok === true && a.json.counting === true, JSON.stringify(a.json));
const b = await post({ f: { vr_launch: 1 }, xr: true, first: true }, QUEST);
check('and a VR launch from a headset', b.json && b.json.ok === true);
await post({ f: { make3d: 2 } }, WIN);
await post({ f: { vr_launch: 1, vr_return: 1 }, xr: true, first: true }, PICO);
await post({ first: true }, MAC);

check('features are added up across visits, and a name nobody offered is ignored',
  q("SELECT key||'='||n FROM usage_tally WHERE kind='feature' ORDER BY key") ===
    'make3d=5\nminimize=1\nvr_launch=2\nvr_return=1',
  q("SELECT key||'='||n FROM usage_tally WHERE kind='feature' ORDER BY key"));

check('the headset is a bucket out of a short list, never the user agent',
  q("SELECT key||'='||n FROM usage_tally WHERE kind='headset' ORDER BY key") === 'Meta Quest=1\nPICO=1',
  q("SELECT key||'='||n FROM usage_tally WHERE kind='headset' ORDER BY key"));

check('so is the platform, and a headset is told apart from a phone',
  q("SELECT key||'='||n FROM usage_tally WHERE kind='platform' ORDER BY key") ===
    'Android (headset)=2\nMac=1\nWindows=1',
  q("SELECT key||'='||n FROM usage_tally WHERE kind='platform' ORDER BY key"));

/* --------------------------------------------- and, at length, what it must not keep */

check('a tally row is a day, a kind, a key and a number — there is nowhere to put anything else',
  q("SELECT name FROM pragma_table_info('usage_tally')").split('\n').join(',') === 'day,kind,key,n',
  q("SELECT name FROM pragma_table_info('usage_tally')").split('\n').join(','));

check('no user-agent string reaches the database, in any column',
  q("SELECT COUNT(*) FROM usage_tally WHERE key LIKE '%Mozilla%' OR key LIKE '%Chrome%' OR key LIKE '%WebKit%'") === '0');

check('nothing joins a device to a country: the country table was never touched',
  q('SELECT COUNT(*) FROM usage_day') === '0', q('SELECT COUNT(*) FROM usage_day') + ' rows');

check('and the tally table has no column a country could be written into',
  !/country/.test(q("SELECT name FROM pragma_table_info('usage_tally')")));

check('the endpoint sets no cookie and starts no session', !a.cookie, a.cookie || 'none');

check('one visit cannot be told from two: nothing identifies who sent what',
  q("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND (name LIKE '%visit%' OR name LIKE '%session%')") === '0');

/* -------------------------------------------------------------- and what it refuses */

const bad = await post({ f: { make3d: 999999 } }, WIN);
check('an absurd count is clamped rather than believed',
  bad.json && bad.json.ok && Number(q("SELECT n FROM usage_tally WHERE kind='feature' AND key='make3d'")) <= 505,
  'make3d = ' + q("SELECT n FROM usage_tally WHERE kind='feature' AND key='make3d'"));

const many = {}; for (let i = 0; i < 60; i++) { many['k' + i] = 1; } many.best = 1;
const flood = await post({ f: many }, WIN);
check('a request naming sixty things is cut off rather than walked through',
  flood.json && flood.json.ok && q("SELECT COUNT(*) FROM usage_tally WHERE kind='feature'") === '4',
  q("SELECT key FROM usage_tally WHERE kind='feature' ORDER BY key").split('\n').join(','));

const junk = await post('not json at all', WIN);
check('a body that is not JSON is refused', junk.status === 400 && junk.json.error === 'bad_json', String(junk.status));

const g = await fetch(`http://127.0.0.1:${PORT}/QRsharing/count.php`);
check('GET is refused: this is a write endpoint and nothing can be read back out of it',
  g.status === 405, 'HTTP ' + g.status);

const before = q("SELECT COALESCE(SUM(n),0) FROM usage_tally");
await post({ f: {} }, WIN);
check('a visit that used nothing writes nothing',
  q("SELECT COALESCE(SUM(n),0) FROM usage_tally") === before, before + ' -> ' + q("SELECT COALESCE(SUM(n),0) FROM usage_tally"));

/* --------------------------------------------------------------- the off switch */

const offDB = join(off, 'QRsharing/data/shares.sqlite');
const o1 = await post({ f: { make3d: 5 }, first: true, xr: true }, QUEST, OFFPORT);
check('with counting off the endpoint says so plainly instead of pretending',
  o1.status === 200 && o1.json && o1.json.ok === true && o1.json.counting === false, JSON.stringify(o1.json));
check('and stores nothing at all — not even an empty tally table full of zeros',
  !existsSync(offDB) || q('SELECT COALESCE(SUM(n),0) FROM usage_tally', offDB) === '0',
  existsSync(offDB) ? 'sum ' + q('SELECT COALESCE(SUM(n),0) FROM usage_tally', offDB) : 'no database was even created');

/* ------------------------------------------------------------------- the page */

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1200, height: 800 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
const posts = []; page.on('request', r => { if (/count\.php/.test(r.url())) { posts.push(r.url()); } });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });

check('loading the page sends nothing by itself', posts.length === 0, posts.length + ' requests');
await page.evaluate(() => { for (let i = 0; i < 6; i++) { window.dworm2d.used('style'); } });
await page.waitForTimeout(800);
check('and six actions in a row still cost no requests — this is a batch, not a beacon per click',
  posts.length === 0, posts.length + ' requests');

await page.evaluate(() => window.dworm2d.flushTally());
await page.waitForTimeout(800);
check('one request when it is flushed', posts.length === 1, posts.length + ' requests');
check('carrying all six, so the numbers survive the batching',
  q("SELECT n FROM usage_tally WHERE kind='feature' AND key='style'") === '6',
  'style = ' + q("SELECT n FROM usage_tally WHERE kind='feature' AND key='style'"));

check('the counts went to the server that served the page, and to no other host',
  posts.length > 0 && posts.every(u => u === `http://127.0.0.1:${PORT}/QRsharing/count.php`),
  posts.join(', '));

const after = q("SELECT COALESCE(SUM(n),0) FROM usage_tally");
await page.evaluate(() => window.dworm2d.flushTally());
await page.waitForTimeout(600);
check('flushing an empty tally sends nothing, so a quiet tab is silent',
  posts.length === 1 && q("SELECT COALESCE(SUM(n),0) FROM usage_tally") === after,
  posts.length + ' requests');

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close();
server.kill(); offServer.kill();
rmSync(off, { recursive: true, force: true });
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
