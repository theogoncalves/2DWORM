"""Build a UFF test system for every element and record RDKit's UFF energy and minimised
geometry. Nothing is copied: RDKit is asked only for numbers, which a Node script then
compares against our own implementation. RDKit is BSD-3, so even consulting it is safe."""
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit import RDLogger; RDLogger.DisableLog('rdApp.*')
import json, math, sys

def build(symbols, coords, bonds):
    m = Chem.RWMol()
    for s in symbols:
        a = Chem.Atom(s); a.SetNoImplicit(True); m.AddAtom(a)
    for i, j in bonds: m.AddBond(i, j, Chem.BondType.SINGLE)
    conf = Chem.Conformer(len(symbols))
    for k, (x, y, z) in enumerate(coords): conf.SetAtomPosition(k, Chem.rdGeometry.Point3D(x, y, z))
    mol = m.GetMol(); mol.AddConformer(conf)
    try: Chem.SanitizeMol(mol, Chem.SanitizeFlags.SANITIZE_ALL ^ Chem.SanitizeFlags.SANITIZE_PROPERTIES)
    except Exception: pass
    return mol

OCT = [(2.05,0,0),(-2.05,0,0),(0,2.05,0),(0,-2.05,0),(0,0,2.05),(0,0,-2.05)]

def case(el, ligand, n=6):
    """el at the origin with n ligands around it."""
    pos = OCT[:n]
    syms = [el] + [ligand]*n
    coords = [(0,0,0)] + list(pos)
    bonds = [(0, i+1) for i in range(n)]
    return syms, coords, bonds

ELEMENTS = sys.argv[1].split(',')
out = []
for el in ELEMENTS:
    for ligand, n in (('F', 6), ('Cl', 6), ('F', 4), ('F', 2)):
        syms, coords, bonds = case(el, ligand, n)
        mol = build(syms, coords, bonds)
        if not AllChem.UFFHasAllMoleculeParams(mol): continue
        try:
            ff = AllChem.UFFGetMoleculeForceField(mol, ignoreInterfragInteractions=False)
            if ff is None: continue
            e0 = ff.CalcEnergy()
            ff.Minimize(maxIts=8000)
            e1 = ff.CalcEnergy()
        except Exception: continue
        c = mol.GetConformer()
        final = [[round(c.GetAtomPosition(k).x,6), round(c.GetAtomPosition(k).y,6), round(c.GetAtomPosition(k).z,6)] for k in range(len(syms))]
        d = math.dist(final[0], final[1])
        out.append({'el': el, 'ligand': ligand, 'n': n, 'symbols': syms,
                    'start': coords, 'bonds': bonds, 'e0': e0, 'e1': e1,
                    'final': final, 'bond': d})
        break                       # one usable case per element is enough
print(json.dumps(out))
