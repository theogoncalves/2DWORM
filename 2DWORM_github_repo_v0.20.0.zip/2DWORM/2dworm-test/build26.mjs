/* BUILD 26 — what it added, checked in a real browser.
   The EXPERT bar as two rows with short names; REPLACE on a whole group (a methyl, an OH,
   a tert-butyl, the ring of a biphenyl) and the marks that survive a rewrite that removed
   atoms; residues, chains and atom names kept through +H / REPLACE / DELETE / REORDER on a
   protein; a PDB without element columns read with the right elements; the ENERGY slider that
   scrubs between before and after an edit; perspective back as the default camera; the amber
   warning for a crowded hydrogen; GROW's 0 button; the reviewer sheet. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8826;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP], { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await ctx.newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
const D = (fn, arg) => page.evaluate(fn, arg);
const status = () => page.$eval('#status3d', e => e.textContent);
const build = async (smiles, n) => {
  await D(async (s) => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule(s); }, smiles);
  await page.click('#btnMake3d');
  await page.waitForFunction((n) => window.dworm2d.state3d.nAtoms === n && !document.getElementById('btnMake3d').classList.contains('running'), n, { timeout: 120000 });
  await page.waitForTimeout(300);
};
const atoms = () => D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => ({ elem: a.elem, resn: a.resn, resi: a.resi, chain: a.chain, name: a.atom, x: a.x, y: a.y, z: a.z })));
const dist = (p, q) => Math.hypot(p.x - q.x, p.y - q.y, p.z - q.z);

check('it is build 26 or later', (parseInt((await page.$eval('#buildTag', e => e.textContent)).match(/build (\d+)/)[1], 10) >= 26), await page.$eval('#buildTag', e => e.textContent));

/* ------------------------------------------------------------ the EXPERT bar: two rows */
await build('CC(=O)Oc1ccccc1C(=O)O', 21);
await page.click('#btnEdit'); await page.waitForTimeout(300);
const rows = await D(() => [...document.querySelectorAll('#editBar .editrow')].map(e => Math.round(e.getBoundingClientRect().height)));
check('the EXPERT bar is two rows by construction', rows.length === 2 && rows.every(h => h > 0), rows.join(' + ') + ' px');
check('and each is one line in a half-width panel, nothing armed', rows.every(h => h <= 36), rows.join(', ') + ' px');
const labels = await D(() => [...document.querySelectorAll('#toolSeg button')].map(b => b.textContent.trim()));
check('the tools carry the short names', labels.join('|') === 'VIEW|DRAG ATOM|ANGLE PAN|DRAG MOL.|BOND|+H|REPLACE|DEL', labels.join('|'));
check('and the long names are in the tooltips', (await page.getAttribute('#toolSeg button[data-tool="angle"]', 'title')).startsWith('ANGLE PANNING') && (await page.getAttribute('#toolSeg button[data-tool="move"]', 'title')).startsWith('DRAG MOLECULES') && (await page.getAttribute('#toolSeg button[data-tool="del"]', 'title')).startsWith('DELETE'));
await page.click('#toolSeg button[data-tool="bond"]'); await page.waitForTimeout(200);
const rowsBond = await D(() => [...document.querySelectorAll('#editBar .editrow')].map(e => Math.round(e.getBoundingClientRect().height)));
check('with BOND armed the bond orders fit on the first row', rowsBond[0] <= 36, rowsBond.join(', ') + ' px');
check('the hint sits on the second row, one line, cut with an ellipsis rather than growing the bar', await D(() => document.getElementById('editHint').closest('.editrow') === document.querySelectorAll('#editBar .editrow')[1]) && (await D(() => getComputedStyle(document.getElementById('editHint')).textOverflow)) === 'ellipsis' && (await D(() => document.querySelectorAll('#editBar .editrow').length)) === 2);
/* the bar must not change height while a tool is used: a hint that wrapped moved the 3D view */
const viewerTop0 = await D(() => document.getElementById('viewer3d').getBoundingClientRect().y);
await D(() => window.dworm2d.editHint('C1 swung 5° about C2 (4 atoms) — the arrows keep going; UNDO takes each step back. And a longer sentence still, to be sure.'));
await page.waitForTimeout(100);
check('a long hint does not move the 3D view: the bar keeps its height', Math.abs((await D(() => document.getElementById('viewer3d').getBoundingClientRect().y)) - viewerTop0) < 0.5 && /swung/.test(await page.getAttribute('#editHint', 'title')));
await D(() => window.dworm2d.editHint(''));
check('the language files carry the short keys, in every language', (() => {
  const langs = ['en', 'ar', 'zh', 'pt', 'es', 'pl', 'de', 'it', 'hi', 'ur'];
  return langs.every(l => { const d = JSON.parse(fs.readFileSync(APP + 'lang/' + l + '.json', 'utf8')); return 'ANGLE PAN' in d && 'DRAG MOL.' in d && !('ANGLE PANNING' in d) && !('DRAG MOLECULES' in d); });
})());
await page.click('#toolSeg button[data-tool=""]');

/* ------------------------------------------------------------ REPLACE takes a group */
await build('CC(C)(C)c1ccccc1', 24);                             // tert-butylbenzene
await page.click('#btnEdit').catch(() => {});
if (!(await page.isVisible('#editBar'))) { await page.click('#btnEdit'); }
await page.waitForTimeout(200);
await page.click('#toolSeg button[data-tool="subst"]'); await page.waitForTimeout(400);
check('REPLACE arms and the substituent menu appears', await page.isVisible('#selFrag'));
await page.selectOption('#selFrag', 'CH3');
/* keep a mark on the ring so the remap can be checked */
await D(() => { window.dworm2d.state3d.sel = [4, 5, 6, 7, 8, 9]; window.dworm2d.saySelection(); });
await page.click('#btnMark'); await page.waitForTimeout(200);
const markBefore = await D(() => window.dworm2d.state3d.marks[0].idx.slice());
check('a mark on the six ring carbons is kept', markBefore.length === 6, markBefore.join(','));
const tbuC = await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).findIndex((a, i, all) => a.elem === 'C' && (a.bonds || []).length === 4 && a.bonds.every(j => all[j].elem === 'C')));
check('the quaternary carbon of the tert-butyl is found', tbuC >= 0, 'atom ' + (tbuC + 1));
await D(i => window.dworm2d.builderClick('subst', i), tbuC);
await page.waitForTimeout(1200);
const afterTbu = await atoms();
check('clicking the quaternary carbon replaces the WHOLE tert-butyl: toluene, 15 atoms', afterTbu.length === 15, afterTbu.length + ' atoms');
check('the footer names the group by formula and says how many atoms are left', /group of atom \d+ \(C4H9, 13 atoms\)/.test(await status()) && /15 atoms now/.test(await status()), (await status()).slice(0, 120));
const markAfter = await D(() => (window.dworm2d.state3d.marks[0] || { idx: [] }).idx.slice());
check('the mark followed the ring through the renumbering: six atoms, all carbon', markAfter.length === 6 && markAfter.every(i => afterTbu[i] && afterTbu[i].elem === 'C'), markAfter.join(','));
check('the new methyl is picked, and it is a methyl (one C, three H)', await D(() => { const s = window.dworm2d.state3d.sel, a = window.dworm2d.viewer.getModel().selectedAtoms({}); return s.length === 4 && s.filter(i => a[i].elem === 'C').length === 1 && s.filter(i => a[i].elem === 'H').length === 3; }));
await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(600);
check('UNDO brings the tert-butyl back, 24 atoms, and the mark with it', (await atoms()).length === 24 && (await D(() => window.dworm2d.state3d.marks[0].idx.length)) === 6);
/* a ring carbon is refused with the reason */
await D(() => window.dworm2d.builderClick('subst', 5)); await page.waitForTimeout(400);
check('a ring carbon is refused: "every bond in a ring", and nothing changed', /in a ring/.test(await page.$eval('#editHint', e => e.textContent)) && (await atoms()).length === 24, (await page.$eval('#editHint', e => e.textContent)).slice(0, 80));
/* the middle carbon of propane: two sides of one size */
await build('CCC', 11);
await page.click('#toolSeg button[data-tool="subst"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('subst', 1)); await page.waitForTimeout(400);
check('the middle carbon of propane is refused: two groups of the same size', /same size/.test(await page.$eval('#editHint', e => e.textContent)) && (await atoms()).length === 11, (await page.$eval('#editHint', e => e.textContent)).slice(0, 80));
/* the OH of ethanol: the oxygen takes its hydrogen with it */
await build('CCO', 9);
await page.click('#toolSeg button[data-tool="subst"]'); await page.waitForTimeout(300);
await page.selectOption('#selFrag', 'CH3');
await D(() => window.dworm2d.builderClick('subst', 2)); await page.waitForTimeout(800);
check('ethanol, click the oxygen, CH3: propane (11 atoms), the OH gone as a group', (await atoms()).length === 11 && (await atoms()).every(a => a.elem !== 'O'), (await atoms()).length + ' atoms');

/* ------------------------------------------------------------ +H: the crowd warning */
await build('C', 5);
await page.click('#toolSeg button[data-tool="addh"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('addh', 0)); await page.waitForTimeout(800);
check('a fifth hydrogen on methane is added anyway (asked for), 6 atoms', (await atoms()).length === 6);
check('and the footer turns the distance amber with a warning sign, because it is closer than a bond', await D(() => !!document.querySelector('#status3d .crowd')) && /⚠/.test(await status()), (await status()).slice(0, 100));
await build('CC', 8);
await page.click('#toolSeg button[data-tool="del"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('del', 2)); await page.waitForTimeout(600);      // an H of ethane → CH2 radical? no: deleting an H caps nothing
await page.click('#toolSeg button[data-tool="addh"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('addh', 0)); await page.waitForTimeout(800);
check('a hydrogen put back where one was removed is not crowded: no warning', !(await D(() => !!document.querySelector('#status3d .crowd'))), (await status()).slice(0, 100));

/* ------------------------------------------------------------ residues through the builder */
const dna = fs.readFileSync(fileURLToPath(new URL('./corpus/DNA.pdb', import.meta.url)), 'utf8');
await D(p => window.dworm2d.show3d(p, 'pdb', 'file', 'DNA.pdb'), dna);
await page.waitForTimeout(800);
check('DNA.pdb has no element columns, and the elements come from the names all the same: 234 hydrogens, no element "1"', /C200H234N70O116P18/.test(await status()) && (await atoms()).every(a => /^[A-Z][a-z]?$/.test(a.elem)), (await status()).slice(0, 60));
const before = await atoms();
await page.click('#toolSeg button[data-tool="addh"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('addh', 2)); await page.waitForTimeout(1200);
let now = await atoms();
check('+H on a nucleotide carbon: the structure is still a PDB with its residues', (await D(() => window.dworm2d.state3d.format)) === 'pdb' && now[0].resn === 'DA5' && now[0].name === 'H5T' && now[now.length - 2].resn === 'DT3', now[0].resn + ' ' + now[0].name);
check('the new hydrogen is in the residue of the carbon it hangs from, with a name of its own', now[now.length - 1].resn === 'DA5' && now[now.length - 1].resi === 1 && /^H\d+$/.test(now[now.length - 1].name) && !before.some(a => a.resn === 'DA5' && a.resi === 1 && a.name === now[now.length - 1].name), JSON.stringify(now[now.length - 1]));
check('every other atom kept its residue, number and name', before.every((a, i) => now[i].resn === a.resn && now[i].resi === a.resi && now[i].name === a.name));
const c7 = now.findIndex(a => a.name === 'C7');
await page.click('#toolSeg button[data-tool="subst"]'); await page.waitForTimeout(300);
await page.selectOption('#selFrag', 'Ph');
await D(i => window.dworm2d.builderClick('subst', i), c7); await page.waitForTimeout(1500);
now = await atoms();
check('REPLACE thymine\'s methyl by a phenyl: 639 − 3 H + 10 = 646 atoms, all in thymine 11', now.length === 646 && now.slice(-10).every(a => a.resn === 'DT5' && a.resi === 11), now.length + ' atoms, last in ' + now[now.length - 1].resn + ' ' + now[now.length - 1].resi);
check('the ipso carbon kept the methyl carbon\'s number and residue', now[c7].elem === 'C' && now[c7].resn === 'DT5' && now[c7].resi === 11);
check('the phenyl\'s atom names are unique within the residue', (() => { const names = now.filter(a => a.resn === 'DT5' && a.resi === 11).map(a => a.name); return new Set(names).size === names.length; })());
await page.click('#toolSeg button[data-tool="del"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('del', 0)); await page.waitForTimeout(1200);
now = await atoms();
check('DELETE the first atom (H5T): 645 atoms, residues intact, the first atom is now O5* of DA5 1', now.length === 645 && now[0].name === 'O5*' && now[0].resn === 'DA5', now[0].name + ' ' + now[0].resn);
await D(() => { window.dworm2d.state3d.sel = [10, 11, 12]; });
await D(() => window.dworm2d.reorderPickedFirst([10, 11, 12])); await page.waitForTimeout(1200);
now = await atoms();
check('REORDER on a protein keeps residues and says so', /residues and chains kept/.test(await status()) && now.length === 645 && now.every(a => a.resn), (await status()).slice(0, 100));
for (let k = 0; k < 4; k++) { await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(500); }
now = await atoms();
check('four UNDOs bring DNA.pdb back exactly', now.length === 638 && now.every((a, i) => a.name === before[i].name && a.resn === before[i].resn), now.length + ' atoms');
/* the PDB the page writes reads back with the right elements everywhere */
const pdbOut = await D(() => window.dworm2d.toPDB(window.dworm2d.viewerStruct()));
check('the PDB written by the page has ATOM records, element columns and the original names', /^ATOM  .{6} H5T DA5/.test(pdbOut.split('\n')[2]) && pdbOut.split('\n').filter(l => /^ATOM|^HETATM/.test(l)).every(l => l.length >= 78 && l.slice(76, 78).trim()), pdbOut.split('\n')[2]);

/* ------------------------------------------------------------ a drawn molecule is still a molfile */
await build('CCO', 9);
await page.click('#toolSeg button[data-tool="addh"]'); await page.waitForTimeout(300);
await D(() => window.dworm2d.builderClick('addh', 0)); await page.waitForTimeout(800);
check('a drawn molecule without residues is rebuilt as a molfile, as before', (await D(() => window.dworm2d.state3d.format)) === 'mol');

/* ------------------------------------------------------------ the ENERGY slider (§7) */
await build('CC(=O)Oc1ccccc1C(=O)O', 21);
await page.click('#btnEdit').catch(() => {});
if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
await page.waitForTimeout(200);
const row = () => D(() => ({ dis: document.getElementById('energyR').disabled, val: document.getElementById('energyR').value, before: document.getElementById('energyBefore').textContent, after: document.getElementById('energyAfter').textContent, v: document.getElementById('energyV').textContent }));
let r = await row();
check('the ENERGY row is there and disabled until something has been edited', r.dis && /make an edit first/.test(r.v), r.v);
await page.selectOption('#selField', 'uff');
await page.click('#btnMinimize');
await page.waitForFunction(() => !document.getElementById('btnMinimize').classList.contains('running') && /kcal\/mol/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
await page.waitForTimeout(1200);
r = await row();
check('after MINIMIZE the row is armed at AFTER, with both energies', !r.dis && r.val === '100' && /^-?\d+\.\d$/.test(r.before) && /^-?\d+\.\d$/.test(r.after) && /MINIMIZE/.test(r.v) && /UFF/.test(r.v), `${r.before} → ${r.after} · ${r.v}`);
check('and the minimisation lowered the energy', parseFloat(r.after) < parseFloat(r.before), `${r.before} → ${r.after}`);
const cc = () => D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({}); return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y, a[0].z - a[1].z); });
const pos = () => D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
const ccAfter = await cc(), pAfter = await pos(), dataAfter = await D(() => window.dworm2d.state3d.data);
await D(() => { const s = document.getElementById('energyR'); s.value = '0'; s.dispatchEvent(new Event('input', { bubbles: true })); });
await page.waitForTimeout(500);
r = await row();
const ccBefore = await cc(), pBefore = await pos();
check('scrubbing to 0 shows the structure BEFORE the minimisation, and its energy', /before/.test(r.v) && Math.abs(parseFloat(r.v.match(/(-?\d+\.\d) kcal/)[1]) - parseFloat(r.before)) < 0.05 && Math.abs(ccBefore - ccAfter) > 1e-3, `${r.v} · C–C ${ccBefore.toFixed(3)} vs ${ccAfter.toFixed(3)}`);
await D(() => { const s = document.getElementById('energyR'); s.value = '50'; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); });
await page.waitForTimeout(600);
r = await row();
const pHalf = await pos();
const halfOff = Math.max(...pHalf.map((p, i) => Math.max(...p.map((x, k) => Math.abs(x - (pBefore[i][k] + pAfter[i][k]) / 2)))));
const eHalf = parseFloat((r.v.match(/(-?\d+\.\d) kcal/) || [])[1]);
check('halfway is halfway: every coordinate is the mean of the two, and the energy is printed for it', halfOff < 1e-4 && /50 %/.test(r.v) && Number.isFinite(eHalf), `largest deviation ${halfOff.toExponential(1)} Å · ${r.v}`);
check('releasing the slider is not an undo step of its own', (await D(() => window.dworm2d.undoDepth)) === 1);
check('and the structure the page holds (what a link or a file gets) is the scrubbed one', (await D(() => window.dworm2d.state3d.data)) !== dataAfter && (await D(() => window.dworm2d.state3d.source)) === 'edited');
await page.click('#energyEnd'); await page.waitForTimeout(500);
check('AFTER puts the minimised structure back', Math.abs((await cc()) - ccAfter) < 1e-6 && (await row()).val === '100');
await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(600);
r = await row();
check('UNDO takes the whole edit back and clears the row', r.dis && /make an edit first/.test(r.v) && Math.abs((await cc()) - ccBefore) < 1e-6);
/* a drag arms it too, with the tool's name */
await page.click('#toolSeg button[data-tool="atom"]'); await page.waitForTimeout(200);
await D(() => { window.dworm2d.state3d.sel = [0, 1]; window.dworm2d.saySelection(); }); await page.waitForTimeout(200);
await D(() => { const s = document.getElementById('geoBondR'); s.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); s.value = '20'; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); s.dispatchEvent(new PointerEvent('pointerup', { bubbles: true })); });
await page.waitForTimeout(800);
r = await row();
check('a slider edit arms the row under the name SLIDER, and stretching a bond costs energy', !r.dis && /SLIDER/.test(r.v) && parseFloat(r.after) > parseFloat(r.before), `${r.before} → ${r.after} · ${r.v}`);
/* pPBC makes it periodic: the energies go into the brackets */
await page.click('#btnPPBC'); await page.waitForTimeout(1500);
await page.click('#toolSeg button[data-tool=""]');
await D(() => { window.dworm2d.state3d.sel = [0, 1]; window.dworm2d.saySelection(); }); await page.waitForTimeout(200);
await D(() => { const s = document.getElementById('geoBondR'); s.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); s.value = '10'; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); s.dispatchEvent(new PointerEvent('pointerup', { bubbles: true })); });
await page.waitForTimeout(800);
r = await row();
check('in a periodic box the energies are printed in the approximation brackets and say the images are not counted', /⟦.*⟧/.test(r.before) && /isolated/.test(r.v), `${r.before} · ${r.v.slice(0, 90)}`);
await D(() => window.dworm2d.editUndo()); await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(400);

/* ------------------------------------------------------------ GROW's 0 button */
await build('CC(=O)Oc1ccccc1C(=O)O', 21);
await D(() => { window.dworm2d.state3d.sel = [0]; window.dworm2d.saySelection(); }); await page.waitForTimeout(200);
await D(() => { const s = document.getElementById('growR'); s.value = '2'; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); });
await page.waitForTimeout(300);
const grown = await D(() => window.dworm2d.state3d.sel.length);
await page.click('#growZero'); await page.waitForTimeout(300);
check('GROW to two bonds and back with its 0 button (whose handler a generic one had replaced)', grown > 1 && (await D(() => window.dworm2d.state3d.sel.length)) === 1 && (await D(() => document.getElementById('growR').value)) === '0', grown + ' → ' + (await D(() => window.dworm2d.state3d.sel.length)));

/* ------------------------------------------------------------ the camera: perspective by default */
check('the camera is perspective by default, orthographic an OPTIONS choice', (await D(() => window.dworm2d.optGet('cam'))) === 'persp' && (await D(() => window.dworm2d.viewer.camera.ortho !== true)));
const ext = () => D(() => { const all = window.dworm2d.viewer.getModel().selectedAtoms({}).map((a, i) => i); return window.dworm2d.screenExtentOf(all); });
const e0 = await ext();
await page.selectOption('#selLabels', 'elem'); await page.waitForTimeout(400);
const e1 = await ext();
await page.selectOption('#selLabels', 'none'); await page.waitForTimeout(400);
check('and labels on or off move the picture by nothing under it either (B5 holds for both cameras)', Math.abs(e1.w - e0.w) < 0.5 && Math.abs(e1.cx - e0.cx) < 0.5, `${e0.w.toFixed(1)} → ${e1.w.toFixed(1)} px`);
await D(() => window.dworm2d.optSet('cam', 'ortho')); await page.waitForTimeout(400);
check('OPTIONS switches to orthographic', await D(() => window.dworm2d.viewer.camera.ortho === true));
await D(() => window.dworm2d.optSet('cam', 'persp')); await page.waitForTimeout(400);
check('and back', await D(() => window.dworm2d.viewer.camera.ortho !== true));
check('the OPTIONS window marks perspective as the default', /perspective.*\(default\)/.test(await page.$eval('#optCam option[value=persp]', e => e.textContent)));

/* ------------------------------------------------------------ the reviewer sheet */
const sheet = fs.readFileSync(APP + 'lang/STRINGS_TO_REVIEW.md', 'utf8');
check('lang/STRINGS_TO_REVIEW.md exists with the Hindi and Urdu columns and a few hundred rows', /हिन्दी/.test(sheet) && /اردو/.test(sheet) && sheet.split('\n').filter(l => l.startsWith('| ')).length > 200, sheet.split('\n').filter(l => l.startsWith('| ')).length + ' rows');
check('and it is for this build', new RegExp('build ' + (await D(() => window.dworm2d.APP.build))).test(sheet.split('\n')[0]), sheet.split('\n')[0]);
const csv = fs.readFileSync(APP + 'lang/strings_to_review.csv', 'utf8');
check('with a CSV twin for a spreadsheet', csv.startsWith('﻿English,where,Hindi,Urdu'));

/* ------------------------------------------------------------ SAVE ▸ 2DWORM session, first */
const saveItems = await D(() => [...document.querySelectorAll('#saveMenu > *')].filter(e => !e.hidden).map(e => e.tagName + ':' + e.textContent.trim().replace(/\s+/g, ' ')));
check('the SAVE menu opens with "2DWORM session" under its own heading, above every format (Dante, mid-build)', saveItems[0] === 'H4:2DWORM session' && /^BUTTON:2DWORM session \.2dworm\.zip$/.test(saveItems[1]) && saveItems[2] === 'H4:Drawing (Ketcher)', saveItems.slice(0, 3).join(' | '));
check('and the session is not listed among the other programs any more', !saveItems.slice(3).some(s => /session/i.test(s)));

check('no page errors', errors.filter(e => !/favicon|ResizeObserver|WebGL|swiftshader|Could not create/i.test(e)).length === 0, errors.slice(0, 3).join(' | '));
await browser.close(); server.kill();
const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
