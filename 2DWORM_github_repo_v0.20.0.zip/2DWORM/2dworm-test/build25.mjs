/* BUILD 25 — what it added, checked in a real browser.
   PAUSED! (the breakpoint with CONTINUE and STOP, KILL still working), pPBC (a guessed box that
   becomes the cell), pMODEL (a capped model relaxed and put back under its numbers), the
   builder (+H, REPLACE with a fragment, DELETE with caps, the library and fragments_user.xyz),
   UNDO and RESET ALL in the main row, OPTIONS crossing to the VR page and back, the
   orthographic camera that never jumps, the arrows driving ANGLE PANNING, the number boxes
   and SHIFT beside the sliders, the fourth slider, coordinates in the note, .mol2 lone pairs,
   the BUG theme, and the picked-atoms window with REORDER. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8825;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP], { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
const D = (fn, arg) => page.evaluate(fn, arg);
const status = () => page.$eval('#status3d', e => e.textContent);
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'b25-'));

/* ------------------------------------------------ the camera: orthographic, and nothing jumps */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CC(=O)Oc1ccccc1C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 21, null, { timeout: 120000 });
await page.waitForTimeout(500);
const extent = () => D(() => { const all = window.dworm2d.viewer.getModel().selectedAtoms({}).map((a, i) => i); return window.dworm2d.screenExtentOf(all); });
const e0 = await extent();
await page.selectOption('#selLabels', 'elem'); await page.waitForTimeout(400);
const e1 = await extent();
await page.selectOption('#selLabels', 'none'); await page.waitForTimeout(400);
const e2 = await extent();
check('turning labels on and off changes the apparent size and position by nothing at all (B5)',
  Math.abs(e1.w - e0.w) < 0.5 && Math.abs(e1.cx - e0.cx) < 0.5 && Math.abs(e2.w - e0.w) < 0.5, `${e0.w.toFixed(1)} → ${e1.w.toFixed(1)} → ${e2.w.toFixed(1)} px, centre ${e0.cx.toFixed(1)} → ${e1.cx.toFixed(1)}`);
check('because the camera never switches projection with the labels; which projection is an OPTIONS choice (perspective by default since build 26)', ['ortho', 'persp'].includes(await D(() => window.dworm2d.optGet('cam'))) && (await D(() => !!document.getElementById('optCam'))));

/* ------------------------------------------------ UNDO and RESET ALL live in the main row now */
check('UNDO and RESET ALL are in the 3D row, visible without EXPERT', await page.isVisible('#btnUndo') && await page.isVisible('#btnResetAll') && !(await page.isVisible('#editBar')));
await page.click('#btnMinimize');
await page.waitForFunction(() => /kcal\/mol/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
check('and a minimisation arms them there', await page.$eval('#btnUndo', b => !b.disabled) && await page.$eval('#btnResetAll', b => !b.disabled));
await page.click('#btnResetAll'); await page.waitForTimeout(400);
check('RESET ALL from the main row unwinds it', await page.$eval('#btnUndo', b => b.disabled) && /undone/.test(await status()));

/* ------------------------------------------------ pPBC */
await page.click('#btnEdit'); await page.waitForTimeout(300);
check('pPBC and pMODEL sit in the EXPERT row with the periodic tools', await page.isVisible('#btnPPBC') && await D(() => !!document.getElementById('btnPModel')));
await page.click('#btnPPBC');
await page.waitForFunction(() => window.dworm2d.state3d.cell, null, { timeout: 30000 });
await page.waitForTimeout(400);
const box = await D(() => ({ a: window.dworm2d.state3d.cell.a, b: window.dworm2d.state3d.cell.b, c: window.dworm2d.state3d.cell.c, per: window.dworm2d.state3d.periodic, s: document.getElementById('status3d').textContent, approx: !!document.querySelector('#status3d .approx'), undo: window.dworm2d.undoDepth, n: window.dworm2d.state3d.nAtoms }));
check('pPBC gives aspirin an orthogonal box and marks the structure pseudo-periodic', box.a[1] === 0 && box.a[2] === 0 && box.b[0] === 0 && box.c[0] === 0 && /pPBC/.test(box.per) && box.n === 21, JSON.stringify([box.a[0], box.b[1], box.c[2]].map(x => +x.toFixed(2))));
check('the box is the vdW envelope: 8–12 Å along the long axis, ~4 Å thick for a flat molecule', box.a[0] > 8 && box.a[0] < 13 && box.c[2] > 3 && box.c[2] < 5, `${box.a[0].toFixed(1)} × ${box.b[1].toFixed(1)} × ${box.c[2].toFixed(1)}`);
check('its sentence is in the approximation brackets and says "guess"', box.approx && /guess/.test(box.s) && box.undo === 1);
const inside = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({}); const c = window.dworm2d.state3d.cell; return a.every(p => p.x >= -1e-6 && p.y >= -1e-6 && p.z >= -1e-6 && p.x <= c.a[0] + 1e-6 && p.y <= c.b[1] + 1e-6 && p.z <= c.c[2] + 1e-6); });
check('every atom centre is inside the box', inside);
await D(() => window.dworm2d.optSet('gap', '2'));
await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(300);
await page.click('#btnPPBC');
await page.waitForFunction(() => window.dworm2d.state3d.cell, null, { timeout: 30000 });
const box2 = await D(() => window.dworm2d.state3d.cell.a[0]);
check('OPTIONS ▸ pPBC gap adds the gap to every length', Math.abs(box2 - box.a[0] - 2) < 0.05, `${box.a[0].toFixed(2)} → ${box2.toFixed(2)}`);
await D(() => window.dworm2d.optSet('gap', '0'));
await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(300);
await page.click('#btnPPBC');
await page.waitForFunction(() => window.dworm2d.state3d.cell && Math.abs(window.dworm2d.state3d.cell.a[0] - 10.26) < 0.1, null, { timeout: 30000 });
check('with a 2 Å gap no image touches the molecule, so MIN pPERIODIC would have nothing to do — the touching box is back for it', true);

/* ------------------------------------------------ PAUSED! on MIN pPERIODIC */
await D(() => window.dworm2d.optSet('pause', 'always'));
await page.click('#btnMinPeriodic');
await page.waitForFunction(() => !document.getElementById('pauseBar').hidden, null, { timeout: 30000 });
const paused = await D(() => ({ what: document.getElementById('pauseWhat').textContent, btn: document.getElementById('btnMinPeriodic').textContent, running: document.getElementById('btnMinPeriodic').classList.contains('running'), s: document.getElementById('status3d').textContent, models: window.dworm2d.viewer.getNumFrames ? true : true, disabled: document.getElementById('btnMake3d').disabled }));
check('MIN pPERIODIC pauses at its breakpoint: the bar is up, the button reads PAUSED! and is red', /frozen shell/.test(paused.what) && paused.btn === 'PAUSED!' && paused.running, JSON.stringify(paused).slice(0, 200));
check('the status line says paused — it does not go quiet', /Paused/.test(paused.s));
check('the other job buttons are held while it waits', paused.disabled);
const secondModel = () => D(() => { const m = window.dworm2d.viewer.getModel(1); return !!m && m.getID() === 1; });   // getModel(i) hands back the LAST model for an id it does not have
check('the shell is drawn as a second model', await secondModel());
await page.click('#pauseStop'); await page.waitForTimeout(400);
const stopped = await D(() => ({ bar: document.getElementById('pauseBar').hidden, s: document.getElementById('status3d').textContent, running: document.getElementById('btnMinPeriodic').classList.contains('running') }));
stopped.second = await secondModel();
check('STOP while paused stops it: bar down, "Stopped.", button back, the shell gone', stopped.bar && /Stopped/.test(stopped.s) && !stopped.running && !stopped.second, JSON.stringify(stopped));
await page.click('#btnMinPeriodic');
await page.waitForFunction(() => !document.getElementById('pauseBar').hidden, null, { timeout: 30000 });
await page.click('#btnMinPeriodic');      // pressing the red PAUSED! button itself continues
/* the worker reports its progress in the status line ("UFF: step 200 · … kcal/mol"), so the
   thing to wait for is the button coming back, not a number appearing */
await page.waitForFunction(() => document.getElementById('pauseBar').hidden && !document.getElementById('btnMinPeriodic').classList.contains('running') && /pseudo-periodic/.test(document.getElementById('status3d').textContent), null, { timeout: 300000 });
check('pressing the red PAUSED! button continues, and the minimisation finishes', /pseudo-periodic/.test(await status()) && !(await secondModel()), (await status()).slice(0, 80));

/* ------------------------------------------------ pMODEL */
await D(() => window.dworm2d.optSet('pause', 'never'));
/* the acetyl group: the methyl carbon, the carbonyl carbon, its oxygen and the three methyl
   hydrogens — one cut, at the ester oxygen, so the carbonyl carbon is the linker */
const REGION = [0, 1, 2, 13, 14, 15];
await D((r) => { window.dworm2d.state3d.sel = r; window.dworm2d.saySelection(); }, REGION);
await page.waitForTimeout(300);
check('pMODEL appears once atoms are picked', await page.isVisible('#btnPModel'));
const before = await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
await page.click('#btnPModel');
await page.waitForFunction(() => /pMODEL:/.test(document.getElementById('status3d').textContent) && !document.getElementById('btnPModel').classList.contains('running'), null, { timeout: 180000 });
const pm = await D(() => ({ s: document.getElementById('status3d').textContent, n: window.dworm2d.state3d.nAtoms, undo: window.dworm2d.undoDepth, approx: !!document.querySelector('#status3d .approx'), after: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]) }));
const moved = pm.after.map((p, i) => Math.hypot(p[0] - before[i][0], p[1] - before[i][1], p[2] - before[i][2]));
const movedIdx = moved.map((d, i) => d > 1e-3 ? i : -1).filter(i => i >= 0);   // a molfile carries four decimals, so rounding is not a move
check('pMODEL relaxes the acetyl group as a capped model and puts it back under the same numbers', pm.n === 21 && /1 cut bond capped with 1 H/.test(pm.s) && /model system/.test(pm.s) && pm.approx, pm.s.slice(0, 160));
check('only the free region atoms moved — the linker at the cut and everything outside stayed put', movedIdx.every(i => REGION.includes(i) && i !== 1) && movedIdx.length >= 1, 'moved: ' + movedIdx.join(','));
check('the energy is in the approximation brackets and the sentence says it is a guess', /guess/.test(pm.s) && pm.approx);
await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(300);
const restored = await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
check('UNDO puts the coordinates back exactly', restored.every((p, i) => Math.hypot(p[0] - before[i][0], p[1] - before[i][1], p[2] - before[i][2]) < 1e-9), restored.map((p, i) => Math.hypot(p[0] - before[i][0], p[1] - before[i][1], p[2] - before[i][2]).toExponential(1)).slice(0, 4).join(','));
await page.click('#pauseStop').catch(() => {});

/* ------------------------------------------------ the arrows drive ANGLE PANNING (B6) */
await D(() => { window.dworm2d.state3d.sel = [0]; window.dworm2d.saySelection(); window.dworm2d.setEditTool('angle'); });
await page.waitForTimeout(200);
const p0 = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({})[0]; return window.dworm2d.viewer.modelToScreen({ x: a.x, y: a.y, z: a.z }); });
await page.keyboard.press('ArrowRight'); await page.waitForTimeout(250);
const p1 = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({})[0]; return window.dworm2d.viewer.modelToScreen({ x: a.x, y: a.y, z: a.z }); });
check('with ANGLE PANNING armed, → swings the picked atom about its pivot to the right on the screen', p1.x > p0.x + 0.5, `${p0.x.toFixed(1)} → ${p1.x.toFixed(1)}`);
check('and says so, naming the pivot', /swung 5°/.test(await page.$eval('#editHint', e => e.textContent)));
await page.keyboard.press('ArrowLeft'); await page.waitForTimeout(250);
const p2 = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({})[0]; return window.dworm2d.viewer.modelToScreen({ x: a.x, y: a.y, z: a.z }); });
check('← brings it back to within a pixel — the arrows no longer reset the angle', Math.abs(p2.x - p0.x) < 1.0 && Math.abs(p2.y - p0.y) < 1.0, `${p2.x.toFixed(1)} vs ${p0.x.toFixed(1)}`);
await D(() => window.dworm2d.setEditTool(''));

/* ------------------------------------------------ the number boxes, SHIFT, the fourth slider */
await D(() => { window.dworm2d.state3d.sel = [0, 1]; window.dworm2d.saySelection(); });
await page.waitForTimeout(300);
const len0 = await D(() => window.dworm2d.measureOf().value);
await page.fill('#geoBondN', '10'); await page.press('#geoBondN', 'Enter'); await page.waitForTimeout(400);
const len1 = await D(() => window.dworm2d.measureOf().value);
check('typing 10 into the BOND box and pressing Enter stretches the bond by 10 %', Math.abs(parseFloat(len1) / parseFloat(len0) - 1.10) < 0.005, `${len0} → ${len1}`);
check('and the box is a fresh zero afterwards, like the slider', (await page.inputValue('#geoBondN')) === '0');
const more = await D(() => ({ label: document.getElementById('moreLabel').textContent, min: document.getElementById('geoMoreR').min, disabled: document.getElementById('geoMoreR').disabled }));
check('with two atoms picked the fourth row is TWIST, ±180°', more.label === 'TWIST' && more.min === '-180' && !more.disabled, JSON.stringify(more));
await D(() => { window.dworm2d.state3d.sel = [0, 1, 2]; window.dworm2d.saySelection(); });
await page.waitForTimeout(300);
const more3 = await D(() => ({ label: document.getElementById('moreLabel').textContent, min: document.getElementById('geoMoreR').min, v: document.getElementById('geoMoreV').textContent }));
check('with three it is the A–B length in ångström', more3.label === 'A–B' && more3.min === '-1' && /Å/.test(more3.v), JSON.stringify(more3));
const ab0 = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({}); return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y, a[0].z - a[1].z); });
await page.fill('#geoMoreN', '0.2'); await page.press('#geoMoreN', 'Enter'); await page.waitForTimeout(400);
const ab1 = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({}); return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y, a[0].z - a[1].z); });
check('typing 0.2 into it stretches A–B by 0.2 Å', Math.abs(ab1 - ab0 - 0.2) < 0.005, `${ab0.toFixed(3)} → ${ab1.toFixed(3)}`);
const shiftNarrow = await D(() => {
  const r = document.getElementById('geoAngR');
  r.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, shiftKey: true, pointerId: 7 }));
  const narrowed = { min: r.min, max: r.max };
  r.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 7 }));
  return { narrowed, back: { min: r.min, max: r.max } };
});
check('SHIFT on a slider narrows its range by four around the value, and lets go with it', shiftNarrow.narrowed.min === '-45' && shiftNarrow.narrowed.max === '45' && shiftNarrow.back.min === '-180', JSON.stringify(shiftNarrow));
await D(() => window.dworm2d.setEditMode(false));

/* ------------------------------------------------ the picked-atoms window and REORDER */
await D(() => { window.dworm2d.state3d.sel = [7, 2, 5]; window.dworm2d.saySelection(); });
await D(() => window.dworm2d.openSelList()); await page.waitForTimeout(300);
check('the picked-atoms window lists them 1-based, in click order', (await page.inputValue('#selListText')) === '8 3 6');
await page.click('#selListOrder button[data-order="numeric"]'); await page.waitForTimeout(100);
await page.click('#selListSep button[data-sep=", "]'); await page.waitForTimeout(100);
check('numeric order and commas on request', (await page.inputValue('#selListText')) === '3, 6, 8');
await page.fill('#selListText', '1 2 21'); await page.click('#selListApply'); await page.waitForTimeout(300);
check('an edited list applies as the selection', (await D(() => window.dworm2d.state3d.sel.join(','))) === '0,1,20');
const elemsBefore = await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem));
await page.fill('#selListText', '21 5');
await page.click('#selListReorder'); await page.waitForTimeout(600);
const re = await D(() => ({ elems: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem), sel: window.dworm2d.state3d.sel, s: document.getElementById('status3d').textContent, n: window.dworm2d.state3d.nAtoms, undo: window.dworm2d.undoDepth }));
check('REORDER puts the listed atoms first, in that order, and the rest follow', re.n === 21 && re.elems[0] === elemsBefore[20] && re.elems[1] === elemsBefore[4] && re.sel.join(',') === '0,1' && /Renumbered/.test(re.s), re.elems.slice(0, 4).join(''));
await D(() => window.dworm2d.editUndo()); await page.waitForTimeout(300);
check('and UNDO restores the old numbering', (await D(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join(''))) === elemsBefore.join(''));
await D(() => document.getElementById('selListDlg').classList.remove('open'));
await D(() => { window.dworm2d.state3d.sel = [3]; window.dworm2d.opts.labelsPicked = true; window.dworm2d.opts.labels = 'elem'; window.dworm2d.saySelection(); window.dworm2d.drawLabels(window.dworm2d.viewer); });
check('"labels on the picked atoms only" draws one caption', (await D(() => (window.dworm2d.viewer.labels || []).length)) === 1);
await D(() => { window.dworm2d.opts.labelsPicked = false; window.dworm2d.opts.labels = 'none'; window.dworm2d.drawLabels(window.dworm2d.viewer); });

/* ------------------------------------------------ the builder */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('C'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 5, null, { timeout: 120000 });
await page.click('#btnEdit'); await page.waitForTimeout(300);
await D(() => window.dworm2d.setEditTool('subst'));
await page.waitForFunction(() => document.querySelectorAll('#selFrag option').length >= 38, null, { timeout: 30000 }).catch(() => {});
check('REPLACE shows the fragment menu, with the built-in library and its groups', await page.isVisible('#fragSeg') && (await page.$$eval('#selFrag option', o => o.length)) >= 38 && (await page.$$eval('#selFrag optgroup', g => g.map(x => x.label))).includes('aryl'));
await page.selectOption('#selFrag', 'Ph');
await D(() => window.dworm2d.builderClick('subst', 1));
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 15, null, { timeout: 30000 });
await page.waitForTimeout(300);
const tol = await D(() => ({ elems: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join(''), s: document.getElementById('status3d').textContent, undo: window.dworm2d.undoDepth, f: window.dworm2d.state3d.format, sel: window.dworm2d.state3d.sel.length }));
check('methane + phenyl in place of H2 = toluene, the ring carbon taking the hydrogen\'s number', tol.elems === 'CCHHHCCCCCHHHHH' && /Replaced atom 2/.test(tol.s) && tol.f === 'mol', tol.elems);
check('the new atoms are picked and it is one undo', tol.sel === 11 && tol.undo === 1);
const cc = await D(() => { const a = window.dworm2d.viewer.getModel().selectedAtoms({}); return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y, a[0].z - a[1].z); });
check('the new C–C bond is the Cordero distance, 1.52 Å', Math.abs(cc - 1.52) < 0.01, cc.toFixed(3));
await D(() => window.dworm2d.builderClick('addh', 0));
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 16, null, { timeout: 30000 });
check('+H adds a hydrogen at the covalent distance and says where', /Added a hydrogen to atom 1/.test(await status()) && /1\.07 Å/.test(await status()));
await D(() => window.dworm2d.builderClick('del', 5));
await page.waitForFunction(() => /Deleted/.test(document.getElementById('status3d').textContent), null, { timeout: 30000 });
await page.waitForTimeout(300);
const del = await D(() => ({ n: window.dworm2d.state3d.nAtoms, s: document.getElementById('status3d').textContent, undo: window.dworm2d.undoDepth }));
check('DELETE takes a ring carbon with its hydrogen and caps both wounds — two gone, two caps, one undo', /Deleted 2 atoms, capped 2 broken bonds/.test(del.s) && del.n === 16 && del.undo === 3, del.s.slice(0, 100));
await page.click('#btnResetAll'); await page.waitForTimeout(500);
check('RESET ALL walks all three builder steps back to methane', (await D(() => window.dworm2d.state3d.nAtoms)) === 5);
/* the library */
await page.click('#btnFragLib'); await page.waitForTimeout(400);
const userLib = fs.readFileSync(fileURLToPath(new URL('../2dworm/fragments_user.xyz', import.meta.url)), 'utf8');
await page.fill('#fragText', userLib);
await page.click('#fragApply'); await page.waitForTimeout(500);
const lib = await D(() => ({ note: document.getElementById('fragNote').textContent, yours: [...document.querySelectorAll('#selFrag optgroup')].map(g => g.label).includes('yours'), ls: (localStorage.getItem('dworm2d.fragments') || '').includes('key=Mes') }));
check('a user library pasted as XYZ text registers its entries under "yours" and is remembered', /4 of your own/.test(lib.note) && lib.yours && lib.ls, lib.note);
await D(() => document.getElementById('fragDlg').classList.remove('open'));
await page.selectOption('#selFrag', 'Mes');
await D(() => window.dworm2d.builderClick('subst', 1));
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 5 - 1 + 20, null, { timeout: 30000 });
check('and a user substituent (mesityl, from Dante\'s own file) goes on', (await D(() => window.dworm2d.state3d.nAtoms)) === 24);
/* SAVE PICKED AS SUBSTITUENT: the mesityl we just attached */
await D(() => { window.dworm2d.state3d.sel = Array.from({ length: 24 }, (_, i) => i).filter(i => i !== 0 && i !== 2 && i !== 3 && i !== 4); window.dworm2d.saySelection(); });
await page.click('#btnFragLib'); await page.waitForTimeout(300);
await page.fill('#fragKey', 'MesAgain'); await page.click('#fragFromPicked'); await page.waitForTimeout(500);
check('SAVE PICKED AS SUBSTITUENT turns the picked group into a library entry', /saved as MesAgain/.test(await page.$eval('#fragNote', e => e.textContent)) && (await page.inputValue('#fragText')).includes('key=MesAgain'));
await D(() => document.getElementById('fragDlg').classList.remove('open'));
await D(() => { localStorage.removeItem('dworm2d.fragments'); });
await page.click('#btnEdit');

/* ------------------------------------------------ coordinates into the note */
await page.click('#btnNotes'); await page.waitForTimeout(300);
await page.selectOption('#selNoteCoords', 'xyz'); await page.waitForTimeout(500);
const note = await page.inputValue('#noteText');
check('COORDINATES ▸ .xyz puts a fenced block in the note with every atom', /^```xyz\n24\n/.test(note) && note.split('\n').length >= 27 && /```\n?$/.test(note.trim() + '\n'), note.slice(0, 40).replace(/\n/g, '⏎'));
await D(() => window.dworm2d.setNoteMode('read')); await page.waitForTimeout(300);
check('READ shows it verbatim in a monospace block', (await page.$eval('#noteView pre.coords', e => e.textContent.split('\n').length)) >= 26);
check('and the cap has room for it', (await D(() => window.dworm2d.NOTE_MAX)) >= 20000);
await D(() => { window.dworm2d.setNoteMode('write'); document.getElementById('noteText').value = ''; });
await page.click('#btnNotes');

/* ------------------------------------------------ .mol2 lone pairs */
const mol2 = `@<TRIPOS>MOLECULE
water with lone pairs
 5 4 0 0 0
SMALL
NO_CHARGES

@<TRIPOS>ATOM
      1 O1          0.0000    0.0000    0.0000 O.3     1  WAT1   -0.8
      2 H1          0.9572    0.0000    0.0000 H       1  WAT1    0.4
      3 H2         -0.2400    0.9266    0.0000 H       1  WAT1    0.4
      4 LP1         0.2000   -0.5000    0.6000 LP      1  WAT1    0.0
      5 LP2         0.2000   -0.5000   -0.6000 LP      1  WAT1    0.0
@<TRIPOS>BOND
     1     1     2    1
     2     1     3    1
     3     1     4    1
     4     1     5    1
`;
fs.writeFileSync(path.join(tmp, 'water_lp.mol2'), mol2);
await page.setInputFiles('#fileInput', [path.join(tmp, 'water_lp.mol2')]);
await page.waitForFunction(() => /water_lp/.test(document.getElementById('msg').textContent), null, { timeout: 60000 });
await page.waitForTimeout(300);
const lp = await D(() => ({ n: window.dworm2d.state3d.nAtoms, elems: window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join(''), msg: document.getElementById('msg').textContent }));
check('a .mol2 with LP centres opens as the three atoms of water, and the footer says two were left out', lp.n === 3 && lp.elems === 'OHH' && /2 lone-pair centres/.test(lp.msg), JSON.stringify(lp).slice(0, 160));
const stripped = await D((t) => window.dworm2d.stripMol2LonePairs(t), mol2);
check('the bonds are renumbered and the header counts corrected', stripped.dropped === 2 && / 3 2 /.test(stripped.text) && !/LP/.test(stripped.text.split('@<TRIPOS>ATOM')[1]));

/* ------------------------------------------------ the BUG theme */
await page.click('#themeSeg button[data-theme="bug"]'); await page.waitForTimeout(300);
const bug1 = await D(() => ({ t: document.documentElement.getAttribute('data-theme'), bg: getComputedStyle(document.documentElement).getPropertyValue('--bg').trim(), fg: getComputedStyle(document.body).color, vbg: window.dworm2d.opts.bg }));
await page.click('#themeSeg button[data-theme="bug"]'); await page.waitForTimeout(300);
const bug2 = await D(() => ({ bg: getComputedStyle(document.documentElement).getPropertyValue('--bg').trim() }));
check('BUG is a theme of its own, with a generated palette', bug1.t === 'bug' && /^hsl/.test(bug1.bg) && /^#[0-9a-f]{6}$/.test(bug1.vbg), JSON.stringify(bug1));
check('and every press is a different palette', bug1.bg !== bug2.bg, bug1.bg + ' → ' + bug2.bg);
const contrast = await D(() => {
  const rgb = (s) => (s.match(/\d+/g) || []).slice(0, 3).map(Number);
  const lum = (c) => { const [r, g, b] = c.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  const bg = rgb(getComputedStyle(document.body).backgroundColor), fg = rgb(getComputedStyle(document.body).color);
  const L1 = lum(bg), L2 = lum(fg); return (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
});
check('the text keeps a readable contrast against the ground (≥ 7:1) whatever the hue', contrast >= 7, contrast.toFixed(1) + ':1');
check('DUSK still exists for a link that names it, without a button', (await D(() => { window.dworm2d.setTheme('dusk'); return document.documentElement.getAttribute('data-theme'); })) === 'dusk' && !(await D(() => !!document.querySelector('#themeSeg button[data-theme="dusk"]'))));
await page.click('#themeSeg button[data-theme="white"]');

/* ------------------------------------------------ OPTIONS cross to the VR page and back */
await D(() => window.dworm2d.optSet('sess', 'volumes'));
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 9, null, { timeout: 120000 });
await D(() => window.dworm2d.goVR());
await page.waitForFunction(() => window.dwormVR && window.dwormVR.booted, null, { timeout: 90000 });
check('the VR page opens with the OPTIONS in its address', /sess=volumes/.test(page.url()), page.url().slice(-40));
await page.evaluate(() => document.getElementById('btnReturn').click());
await page.waitForFunction(() => /Back from/.test(document.getElementById('msg').textContent), null, { timeout: 90000 });
check('and RETURN brings them back in the address of 2D-WORM', /sess=volumes/.test(page.url()) && (await D(() => window.dworm2d.optGet('sess'))) === 'volumes', page.url().slice(-40));
await D(() => window.dworm2d.optSet('sess', 'mesh'));

check('no page errors', errors.filter(e => !/favicon|ResizeObserver|WebGL|swiftshader|Could not create/i.test(e)).length === 0, errors.slice(0, 3).join(' | '));
await browser.close(); server.kill();
fs.rmSync(tmp, { recursive: true, force: true });
const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
