/* Crystal machinery: CIF reading, the 230 space groups, asymmetric-unit expansion, supercells.
   The real files are in corpus/: Urea.cif (Materials Studio, P-421m with its 8 operators listed)
   against Urea_crystal.pdb — which, inspected, is NOT a P1 cell but a cluster of 11 complete urea
   molecules in a frame rotated 45 degrees about c, with no CRYST1, so the check below finds that
   rigid transformation from the central molecule and then demands every one of the 88 atoms sit
   on a crystal atom; zeolite.cif and COF_12000N2.cif (P1, expanded unchanged); and 8yax.fw2.cif,
   a 4 MB cryo-EM mmCIF with a 1 A placeholder cell, which must be read but refused.

   The 230-group table is checked two ways: the ORDER of every group (from the point group and
   the centring, written out below from crystallography, not from any program) and a FINGERPRINT
   of every operator set taken from spglib 2.7.0 (BSD-3, A. Togo): FNV-1a over the sorted
   canonical operators. The fingerprints were produced once by a script and pasted here; the
   suite recomputes them from crystal.js and needs no spglib. */
import { parseCIF, cifBlocks, symopFromXyz, symopToXyz, symopsForGroup, symopsFromHall, findSpaceGroup, closeGroup, hallGenerators,
         expandAsymmetricUnit, fracToCart, cartToFrac, buildSupercell, wrapIntoCell, crystalToStructure,
         LATTICE_SYSTEMS, cellForSystem, latticeSystemFor, crystalSystem, SPACE_GROUPS, UNVERIFIED,
         cellFromParams, cellParams, elemFromCIF } from '../2dworm/lib/crystal.js';
import { readFileSync } from 'node:fs';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const near = (a, b, t = 1e-4) => Math.abs(a - b) <= t;
const corpus = (f) => readFileSync(new URL('./corpus/' + f, import.meta.url), 'utf8');
const canonOp = (s) => { const o = symopFromXyz(s); return o.R.flat().join(',') + '|' + o.t.map(v => Math.round(v * 24) % 24).join(','); };
const canonGroup = (ops) => ops.map(canonOp).sort().join(';');
const sameSet = (A, B) => { const a = A.map(canonOp).sort(), b = B.map(canonOp).sort(); return a.length === b.length && a.every((v, i) => v === b[i]); };
const fnv = (s) => { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, '0'); };
const tryCall = (f) => { try { return { v: f() }; } catch (e) { return { e }; } };

/* ------------------------------------------------------------ symmetry operators as text */
{
  const rt = (s) => symopToXyz(symopFromXyz(s));
  check('symop: x,y,z is the identity', rt('x,y,z') === 'x,y,z' && JSON.stringify(symopFromXyz('x,y,z').R) === '[[1,0,0],[0,1,0],[0,0,1]]');
  const o = symopFromXyz('-x, y+1/2, -z+1/2');
  check('symop: "-x, y+1/2, -z+1/2" gives the matrix and the halves', JSON.stringify(o.R) === '[[-1,0,0],[0,1,0],[0,0,-1]]' && o.t[0] === 0 && o.t[1] === 0.5 && o.t[2] === 0.5, JSON.stringify(o));
  check('symop: spaces, capitals, 1/2-x, 0.5+x, x-y, y+2/3 all read', rt(' 1/2 - X , 0.5+Y, x-y ') === '-x+1/2,y+1/2,x-y' && rt('y+2/3,-x+y,z+1/3') === 'y+2/3,-x+y,z+1/3', rt(' 1/2 - X , 0.5+Y, x-y ') + ' / ' + rt('y+2/3,-x+y,z+1/3'));
  check('symop: a decimal third is snapped to the exact fraction', near(symopFromXyz('x,y,z+0.3333').t[2], 1 / 3, 1e-12) && rt('x,y,z+0.6667') === 'x,y,z+2/3');
  check('symop: a negative translation wraps into the cell', rt('-x-1/2,y,z') === '-x+1/2,y,z' && rt('x,y,z-1/4') === 'x,y,z+3/4');
  check('symop: round trip of every P-421m operator in the urea file', ['x,y,z', '-x,-y,z', 'y,-x,-z', '-y,x,-z', '-x+1/2,y+1/2,-z', 'x+1/2,-y+1/2,-z', '-y+1/2,-x+1/2,z', 'y+1/2,x+1/2,z'].every(s => rt(s) === s));
  check('symop: a coefficient is tolerated', JSON.stringify(symopFromXyz('2x,y,z').R[0]) === '[2,0,0]');
  check('symop: two components, or letters that are no axis, are refused', !!tryCall(() => symopFromXyz('x,y')).e && !!tryCall(() => symopFromXyz('a,b,c')).e);
  check('symop: an eighth survives (Fd-3m needs quarters, nothing needs less than 1/24)', rt('x+1/8,y,z') === 'x+1/8,y,z');
}

/* ------------------------------------------------------------ the Hall decoder and closure */
{
  const g = hallGenerators('-P 2ybc');
  check('hall: -P 2ybc has centring, inversion and the 2_1 with c glide', g.length === 3 && symopToXyz(g[2]) === '-x,y+1/2,-z+1/2', g.map(symopToXyz).join(' ; '));
  check('hall: P 31 2 (0 0 4) shifts the 2-fold to z = 1/3 (P3112 of the Tables)', sameSet(symopsFromHall('P 31 2 (0 0 4)'),
    ['x,y,z', '-y,x-y,z+1/3', '-x+y,-x,z+2/3', '-y,-x,-z+2/3', '-x+y,y,-z+1/3', 'x,x-y,-z']));
  check('hall: F 4d 2 3 -1d is Fd-3m with the inversion at 1/8 (origin choice 1)', symopsFromHall('F 4d 2 3 -1d').includes('-x+1/4,-y+1/4,-z+1/4') && symopsFromHall('F 4d 2 3 -1d').length === 192);
  check('hall: garbage is refused', !!tryCall(() => symopsFromHall('Q 2 2')).e && !!tryCall(() => symopsFromHall('P 5')).e);
  check('closure: a translation that is no fraction of the cell does not close, and says so', /close/.test((tryCall(() => closeGroup(['x+0.1357,y,z'])).e || {}).message || ''));
  check('closure: a decimal within 0.001 of a 24th is that fraction, further off it is what it says', near(symopFromXyz('x+0.1246,y,z').t[0], 0.125, 1e-12) && symopFromXyz('x+0.123456,y,z').t[0] === 0.123456);
  check('closure: a fifth closes to five', closeGroup(['x+1/5,y,z']).length === 5);
  check('closure: generators of P21/c give exactly the four operators of the Tables', sameSet(closeGroup(['-x,y+1/2,-z+1/2', '-x,-y,-z']).map(symopToXyz),
    ['x,y,z', '-x,y+1/2,-z+1/2', '-x,-y,-z', 'x,-y+1/2,z+1/2']));
}

/* ------------------------------------------------------------ the 230 groups: orders and fingerprints */
{
  /* Order of each group modulo lattice translations = |point group| x lattice points per cell.
     Written from the point groups and centrings, as ranges: [first, last, order]. */
  const ORDER_RANGES = [
    [1, 1, 1], [2, 4, 2], [5, 5, 4], [6, 7, 2], [8, 11, 4], [12, 12, 8], [13, 14, 4], [15, 15, 8],
    [16, 19, 4], [20, 21, 8], [22, 22, 16], [23, 24, 8], [25, 34, 4], [35, 41, 8], [42, 43, 16], [44, 46, 8],
    [47, 62, 8], [63, 68, 16], [69, 70, 32], [71, 74, 16],
    [75, 78, 4], [79, 80, 8], [81, 81, 4], [82, 82, 8], [83, 86, 8], [87, 88, 16], [89, 96, 8], [97, 98, 16],
    [99, 106, 8], [107, 110, 16], [111, 118, 8], [119, 122, 16], [123, 138, 16], [139, 142, 32],
    [143, 145, 3], [146, 146, 9], [147, 147, 6], [148, 148, 18], [149, 154, 6], [155, 155, 18], [156, 159, 6],
    [160, 161, 18], [162, 165, 12], [166, 167, 36],
    [168, 174, 6], [175, 176, 12], [177, 190, 12], [191, 194, 24],
    [195, 195, 12], [196, 196, 48], [197, 197, 24], [198, 198, 12], [199, 201, 24], [202, 203, 96], [204, 204, 48],
    [205, 205, 24], [206, 206, 48], [207, 208, 24], [209, 210, 96], [211, 211, 48], [212, 213, 24], [214, 214, 48],
    [215, 215, 24], [216, 216, 96], [217, 217, 48], [218, 218, 24], [219, 219, 96], [220, 220, 48],
    [221, 224, 48], [225, 228, 192], [229, 230, 96]];
  const ORDER = [];
  for (const [a, b, o] of ORDER_RANGES) for (let n = a; n <= b; n++) ORDER[n] = o;
  check('table: the order ranges cover 1..230 once', ORDER.filter(Boolean).length === 230 && ORDER_RANGES.every(([a, b], i) => i === 0 || a === ORDER_RANGES[i - 1][1] + 1));
  const NAMED = { 'P1': 1, 'P-1': 2, 'P21/c': 4, 'C2/c': 8, 'P212121': 4, 'Pnma': 8, 'Cmcm': 16, 'I4/mmm': 32, 'P-421m': 8, 'P63/mmc': 24,
                  'R-3c': 36, 'Fm-3m': 192, 'Pm-3m': 48, 'Fd-3m': 192, 'Ia-3d': 96, 'P3121': 6, 'Pbca': 8, 'P4/mmm': 16, 'I41/amd': 32, 'F-43m': 96 };
  const badNamed = Object.entries(NAMED).filter(([hm, o]) => symopsForGroup(hm).length !== o).map(([hm, o]) => hm + ' ' + symopsForGroup(hm).length + '!=' + o);
  check('table: the 20 named groups close to their orders (P1 1 ... F-43m 96, #113 urea 8)', !badNamed.length, badNamed.join(' '));
  const badOrder = [];
  for (let n = 1; n <= 230; n++) if (symopsForGroup(n).length !== ORDER[n]) badOrder.push(n + ':' + symopsForGroup(n).length + '!=' + ORDER[n]);
  check('table: all 230 groups close to the order of their point group x centring', !badOrder.length, badOrder.join(' '));
  check('table: every group has the identity and each operator once', SPACE_GROUPS.every(g => { const ops = symopsForGroup(g.number); return ops[0] === 'x,y,z' && new Set(ops.map(canonOp)).size === ops.length; }));
  check('table: UNVERIFIED is empty (every entry was checked against spglib)', UNVERIFIED.size === 0, [...UNVERIFIED].join(' '));

  /* spglib 2.7.0 fingerprints: key:fnv1a:order, where the key is the number, or number:1 for
     origin choice 1, number:R for rhombohedral axes. Standard = unique axis b cell choice 1,
     abc, origin choice 2, hexagonal axes. */
  const FP = ('1:1c3060d0:1 2:3ce98f1b:2 3:ce83d41e:2 4:0c670b31:2 5:c58e3528:4 6:3ac3ddb5:2 7:3480364c:2 8:a691064e:4' +
    ' 9:d6faa270:4 10:c1b64182:4 11:b7aba450:4 12:40cdd3e0:8 13:e9a3cf30:4 14:9d55f2a6:4 15:2e4be24c:8' +
    ' 16:f33435da:4 17:8bc744ac:4 18:f17decfa:4 19:0162b414:4 20:9c95154c:8 21:b65e67bc:8 22:d5393f84:16' +
    ' 23:ec3f37a0:8 24:690572f4:8 25:133e8fb4:4 26:dd48534a:4 27:ba870b42:4 28:9cfec042:4 29:4169e8ec:4' +
    ' 30:eebd7340:4 31:58b87140:4 32:773d94a0:4 33:6920deba:4 34:d593936e:4 35:c64d3250:8 36:1a61ef10:8' +
    ' 37:2adbbdc8:8 38:0462a618:8 39:6c0f9f64:8 40:d646d480:8 41:88e80fb4:8 42:afd089fc:16 43:c6e5473c:16' +
    ' 44:a24659bc:8 45:915df1c8:8 46:0d4c62c4:8 47:16c6a408:8 48:2dd1532c:8 48:1:ee1fb984:8 49:34dd017c:8' +
    ' 50:42639d00:8 50:1:9d6914b8:8 51:0d9ce5f4:8 52:7e64d700:8 53:f9586b64:8 54:dc3c77b8:8 55:e2602f88:8' +
    ' 56:617e6614:8 57:18a41c7c:8 58:b8d48dcc:8 59:beea4570:8 59:1:4cc26358:8 60:0e90c164:8 61:3a826024:8' +
    ' 62:c80adf78:8 63:3e1f2d44:16 64:f43d7ed4:16 65:09f7231c:16 66:152294b4:16 67:22b8f80c:16 68:fc890470:16' +
    ' 68:1:5ca08554:16 69:f17e337c:32 70:7f72fe7c:32 70:1:ab62c2ac:32 71:94543e34:16 72:e749d674:16 73:3dd6f1b4:16' +
    ' 74:90cb1478:16 75:02342fc4:4 76:96900cb6:4 77:99ebdf32:4 78:6052dd12:4 79:6aab773c:8 80:12a06700:8' +
    ' 81:13ae52ea:4 82:06c82b48:8 83:c57c8750:8 84:fca51fcc:8 85:2accb110:8 85:1:99fc9800:8 86:856305e4:8' +
    ' 86:1:79006c34:8 87:82dbc76c:16 88:be002bc8:16 88:1:25ffa6ac:16 89:31d00604:8 90:644c6210:8 91:fed2fe70:8' +
    ' 92:1409262c:8 93:76e0b650:8 94:ff570590:8 95:0f71ad48:8 96:418705f8:8 97:880129cc:16 98:aa95e04c:16' +
    ' 99:5b739a50:8 100:d6b316dc:8 101:aec2805c:8 102:7bda88f4:8 103:ccda4a88:8 104:b326604c:8 105:67b730a4:8' +
    ' 106:63e682c0:8 107:4bcd593c:16 108:a10d73ac:16 109:960e117c:16 110:c9d24a48:16 111:d44eec58:8 112:fd6570a4:8' +
    ' 113:8f519dd0:8 114:60de736c:8 115:23ca7ebc:8 116:5eb5cfe4:8 117:da1d78b4:8 118:8867c6c4:8 119:72acd91c:16' +
    ' 120:83f08410:16 121:6151fffc:16 122:7be7ecf4:16 123:4d2e186c:16 124:ba8709c4:16 125:d669ee84:16' +
    ' 125:1:417eaac4:16 126:61eb6ffc:16 126:1:598df168:16 127:1564608c:16 128:a66978f4:16 129:a619ba24:16' +
    ' 129:1:94dbf024:16 130:2a1d608c:16 130:1:286cc134:16 131:51ffd074:16 132:1d26e3dc:16 133:d910129c:16' +
    ' 133:1:f269e3b0:16 134:106c7bfc:16 134:1:d3e01d8c:16 135:564c1894:16 136:e1f2caec:16 137:2f2ce534:16' +
    ' 137:1:352be820:16 138:eec6ff44:16 138:1:de7eb4f4:16 139:aa11e494:32 140:6b742fec:32 141:dcd17328:32' +
    ' 141:1:d9806224:32 142:47403000:32 142:1:770b124c:32 143:b20346ac:3 144:7af80745:3 145:070c16eb:3' +
    ' 146:32bead6d:9 146:R:2f5cbce0:3 147:ddc49e0b:6 148:63cb1247:18 148:R:1f2be28d:6 149:992a53fb:6 150:1c0714d9:6' +
    ' 151:7a151bbb:6 152:73066f97:6 153:1ff85147:6 154:df304b6b:6 155:d648c5b3:18 155:R:8918313d:6 156:e120b0fe:6' +
    ' 157:8eff9f88:6 158:b06a999b:6 159:95e60f6d:6 160:e05870e6:18 160:R:bbb8c80c:6 161:88eef070:18' +
    ' 161:R:c370ee0f:6 162:725ab9fe:12 163:e8e29900:12 164:1a469d7a:12 165:8d53078c:12 166:828ff2ba:36' +
    ' 166:R:e8696cae:12 167:bb141bb6:36 167:R:c9c9f46c:12 168:8b1620ec:6 169:2ef0ccde:6 170:6684ba34:6' +
    ' 171:e33697ec:6 172:a62602dc:6 173:414c0777:6 174:9f60236d:6 175:720de1fe:12 176:f3bb5760:12 177:89c2c6f8:12' +
    ' 178:6599674c:12 179:7c9c9250:12 180:abc25c72:12 181:2106fda0:12 182:1a804408:12 183:4ef1156e:12' +
    ' 184:dae14098:12 185:892541ce:12 186:7d016452:12 187:f11a21ea:12 188:56b98914:12 189:1f7b53a2:12' +
    ' 190:e28102f4:12 191:715e0c44:24 192:86aa73d8:24 193:1252b2a0:24 194:d9be3b60:24 195:ad01d916:12' +
    ' 196:544a0c54:48 197:4850d6c0:24 198:c0035c14:12 199:a0e2f9bc:24 200:14814580:24 201:1f459de4:24' +
    ' 201:1:33148524:24 202:8b3e036c:96 203:9276e76c:96 203:1:c4b7fadc:96 204:02977a84:48 205:d2104d04:24' +
    ' 206:e69f3f94:48 207:518ae008:24 208:a1fb1610:24 209:3589c53c:96 210:73e59dfc:96 211:bdf8441c:48' +
    ' 212:eeeddb0c:24 213:f35cdb1c:24 214:a1aac478:48 215:9b34707c:24 216:02e6846c:96 217:3217526c:48' +
    ' 218:faa66c28:24 219:5fc071a4:96 220:09354d78:48 221:6ea73ec4:48 222:f4043e4c:48 222:1:5405a0f8:48' +
    ' 223:3c0a73cc:48 224:12c8aedc:48 224:1:c142fabc:48 225:2771c92c:192 226:2c78655c:192 227:0a9433ec:192' +
    ' 227:1:6cdef22c:192 228:7bfa6f7c:192 228:1:b437754c:192 229:a58c41ac:96 230:f1564ea0:96').trim().split(/\s+/);
  const badFp = [];
  let nStd = 0, nOne = 0, nR = 0;
  for (const item of FP) {
    const m = item.match(/^(\d+)(?::([1R]))?:([0-9a-f]{8}):(\d+)$/);
    const key = m[1] + (m[2] ? ':' + m[2] : '');
    const ops = symopsForGroup(key);
    if (fnv(canonGroup(ops)) !== m[3] || ops.length !== +m[4]) badFp.push(key);
    if (!m[2]) nStd++; else if (m[2] === '1') nOne++; else nR++;
  }
  check(`table: operator sets equal spglib's for ${nStd} standard settings, ${nOne} origin-choice-1 and ${nR} rhombohedral-axes settings`, !badFp.length && nStd === 230 && nOne === 24 && nR === 7, badFp.join(' '));
  check('table: SPACE_GROUPS lists 230 entries with number, symbol, Hall symbol and system', SPACE_GROUPS.length === 230 && SPACE_GROUPS[13].hm === 'P 21/c' && SPACE_GROUPS[13].hall === '-P 2ybc' && SPACE_GROUPS[13].system === 'monoclinic' && SPACE_GROUPS[229].number === 230);
}

/* ------------------------------------------------------------ names, as CIFs spell them */
{
  const same = (a, b) => sameSet(symopsForGroup(a), symopsForGroup(b));
  const spellings = [['P 21/c', 14], ['P21/c', 14], ['P2(1)/c', 14], ['P 1 21/c 1', 14], ['P 2_1/c', 14], ['p21/c', 14], ['P-1', 2], ['P 1', 1], ['P -1', 2],
    ['Fm-3m', 225], ['F m -3 m', 225], ['Fm3m', 225], ['P 63/m m c', 194], ['P63/mmc', 194], ['P 6_3/m m c', 194], ['R-3c', 167], ['R -3 c', 167], ['R-3c:H', 167],
    ['P-421M', 113], ['P -4 21 m', 113], ['P-42(1)m', 113], ['P212121', 19], ['P 21 21 21', 19], ['Pnma', 62], ['P n m a', 62], ['C 1 2/c 1', 15], ['C2/c', 15],
    ['Abm2', 39], ['Aem2', 39], ['Cmca', 64], ['Cmce', 64], ['Ccca', 68], ['Ia3d', 230], ['Pn3m', 224], ['F43m', 216], ['P 3 m 1', 156], ['P-3m1', 164], ['P 3 1 m', 157],
    ['I 41/a m d', 141], ['I41/amd:2', 141], ['Fd-3m:1', 227], ['Fd-3m :1', 227], ['P 4/n m m :2', 129], ['14', 14], ['227:1', 227]];
  const bad = spellings.filter(([s, n]) => { const g = findSpaceGroup(s); return !g || g.number !== n; }).map(([s]) => s);
  check('names: every spelling CIFs use finds its group', !bad.length, bad.join(' | '));
  /* full symbols, as _space_group_name_H-M_full and the ICSD write them; spglib's international_full column was the source of the spellings */
  const full = [['P 21/n 21/m 21/a', 62], ['P 2/m 2/m 2/m', 47], ['P 21/b 21/c 21/a', 61], ['C 2/m 2/c 21/m', 63], ['F 4/m -3 2/m', 225], ['F 41/d -3 2/m', 227], ['P 2/m -3', 200],
    ['I 21/a -3', 206], ['P 42/m -3 2/n', 223], ['P 4/m 2/m 2/m', 123], ['I 41/a 2/m 2/d', 141], ['P 4/n 21/m m', 129], ['P 42/m 21/n 2/m', 136], ['P -3 2/m 1', 164], ['P -3 1 2/m', 162],
    ['R -3 2/c', 167], ['P 6/m 2/m 2/m', 191], ['P 63/m 2/m 2/c', 194], ['P 1 2/m 1', 10], ['P 2/n 2/n 2/n', 48], ['P 4/m 2_1/b m', 127], ['P 2 2 2', 16], ['P 2 3', 195]];
  const badFull = full.filter(([s, n]) => { const g = findSpaceGroup(s); return !g || g.number !== n; }).map(([s]) => s);
  check('names: full Hermann-Mauguin symbols reduce to the short ones', !badFull.length, badFull.join(' | '));
  check("names: the PDB's trailing Z and S pick the origin", findSpaceGroup('P 4/n m m Z').setting === 'origin choice 2' && findSpaceGroup('P 4/n m m S').setting === 'origin choice 1' && findSpaceGroup('F d -3 m S').hall === 'F 4d 2 3 -1d');
  check('names: the two origin choices differ, and :1 is chosen by the suffix', !same('Fd-3m', 'Fd-3m:1') && findSpaceGroup('Fd-3m').setting === 'origin choice 2' && findSpaceGroup('Fd-3m:1').setting === 'origin choice 1');
  check('names: the number and the symbol agree for every group', SPACE_GROUPS.every(g => same(g.number, g.hm)));
  check('names: P21/n, P21/a, I2/a, P2/n are the monoclinic cells CIFs name most', same('P21/n', '-P 2yn') && same('P 1 21/n 1', '-P 2yn') && same('P21/a', '-P 2yab') && same('I2/a', '-I 2ya') && same('P 2/n', '-P 2yac') && findSpaceGroup('P21/n').number === 14);
  check('names: P21/n is not P21/c (the n glide is the point)', !same('P21/n', 'P21/c') && symopsForGroup('P21/n').includes('-x+1/2,y+1/2,-z+1/2'));
  check('names: a Hall symbol is accepted directly', same('-P 2ybc', 14) && same('-F 4vw 2vw 3', 227) && same('P 3* 2', '155:R'));
  check('names: a symbol nobody knows is null, not a guess (P 21 2 2 is a non-standard P2221, not a Hall symbol)', findSpaceGroup('P 21 2 2') === null && findSpaceGroup('Xyz') === null && findSpaceGroup(231) === null && findSpaceGroup('P 1 1 21/b') === null);
  check('names: symopsForGroup throws for an unknown group', !!tryCall(() => symopsForGroup('P 21 2 2')).e);
  const r = findSpaceGroup('R-3c');
  check('names: R-3c on hexagonal axes has 36 operators and a note pointing at :R', symopsForGroup('R-3c').length === 36 && r.setting === 'hexagonal axes' && /rhombohedral/.test(r.note) && /R-3c:R/.test(r.note), r.note);
  const rr = findSpaceGroup('R-3c:R');
  check('names: R-3c:R is the primitive rhombohedral cell with 12 operators, and says which cell it needs', symopsForGroup('R-3c:R').length === 12 && rr.setting === 'rhombohedral axes' && /a = b = c/.test(rr.note) && latticeSystemFor(rr) === 'rhombohedral' && latticeSystemFor(r) === 'hexagonal');
  check('names: the R centring is the obverse one', symopsForGroup('R3').includes('x+2/3,y+1/3,z+1/3') && symopsForGroup('R3').includes('x+1/3,y+2/3,z+2/3'));
  check('names: crystalSystem by number', crystalSystem(1) === 'triclinic' && crystalSystem(15) === 'monoclinic' && crystalSystem(74) === 'orthorhombic' && crystalSystem(142) === 'tetragonal' && crystalSystem(167) === 'trigonal' && crystalSystem(194) === 'hexagonal' && crystalSystem(230) === 'cubic' && crystalSystem(0) === null);
}

/* ------------------------------------------------------------ elements as CIFs write them */
check('elements: type symbols with charges, capitals, labels with digits, D for hydrogen',
  elemFromCIF('Fe3+') === 'Fe' && elemFromCIF('O2-') === 'O' && elemFromCIF('CL') === 'Cl' && elemFromCIF('Ca1') === 'Ca' && elemFromCIF('C12A') === 'C' &&
  elemFromCIF('Ow') === 'O' && elemFromCIF('D') === 'H' && elemFromCIF('Si4+') === 'Si' && elemFromCIF('Cu2+') === 'Cu' && elemFromCIF('X') === null && elemFromCIF('?') === null && elemFromCIF('Q1') === null);

/* ------------------------------------------------------------ the cell */
{
  const V = cellFromParams(6.1, 7.2, 8.3, 81, 97, 112);
  const p = cellParams(V);
  check('cell: six numbers to vectors and back (triclinic)', near(p.a, 6.1, 1e-9) && near(p.b, 7.2, 1e-9) && near(p.c, 8.3, 1e-9) && near(p.alpha, 81, 1e-9) && near(p.beta, 97, 1e-9) && near(p.gamma, 112, 1e-9), JSON.stringify(p));
  const f = [0.13, 0.77, 0.41], c = fracToCart(f, V), back = cartToFrac(c, V);
  check('cell: fracToCart / cartToFrac round trip on a triclinic cell', back.every((v, i) => near(v, f[i], 1e-10)), JSON.stringify(back));
  check('cell: fracToCart is f0 a + f1 b + f2 c', near(c[0], 0.13 * V.a[0] + 0.77 * V.b[0] + 0.41 * V.c[0], 1e-12) && near(fracToCart([1, 0, 0], V)[0], 6.1, 1e-12));
  check('cell: wrapIntoCell lands in [0,1) and 1 - epsilon is 0', JSON.stringify(wrapIntoCell([1.25, -0.3, 1 - 1e-12])) === '[0.25,0.7,0]');
  check('cell: cartToFrac refuses a flat cell', !!tryCall(() => cartToFrac([1, 1, 1], { a: [1, 0, 0], b: [2, 0, 0], c: [0, 0, 1] })).e);
}

/* ------------------------------------------------------------ the seven lattice systems */
{
  check('systems: the seven are there, with trigonal an alias of hexagonal', ['triclinic', 'monoclinic', 'orthorhombic', 'tetragonal', 'rhombohedral', 'hexagonal', 'cubic'].every(s => LATTICE_SYSTEMS[s]) && LATTICE_SYSTEMS.trigonal === LATTICE_SYSTEMS.hexagonal);
  const cub = cellForSystem('cubic', { a: 5.64, b: 1, c: 2, alpha: 80 });
  check('systems: cubic ties b and c to a and fixes the angles at 90', cub.a === 5.64 && cub.b === 5.64 && cub.c === 5.64 && cub.alpha === 90 && cub.beta === 90 && cub.gamma === 90, JSON.stringify(cub));
  const hex = cellForSystem('hexagonal', { a: 4.76, c: 12.99 });
  check('systems: hexagonal ties b to a and sets gamma 120', hex.b === 4.76 && hex.c === 12.99 && hex.gamma === 120 && hex.alpha === 90, JSON.stringify(hex));
  const rh = cellForSystem('rhombohedral', { a: 5.13, alpha: 55.3 });
  check('systems: rhombohedral ties everything to a and alpha', rh.b === 5.13 && rh.c === 5.13 && rh.beta === 55.3 && rh.gamma === 55.3 && LATTICE_SYSTEMS.rhombohedral.free.join() === 'a,alpha');
  const mono = cellForSystem('monoclinic', { a: 5, b: 6, c: 7, beta: 101 });
  check('systems: monoclinic (unique axis b) leaves beta free and fixes alpha and gamma', mono.beta === 101 && mono.alpha === 90 && mono.gamma === 90 && LATTICE_SYSTEMS.monoclinic.free.includes('beta'));
  check('systems: triclinic fixes nothing, and missing angles default to 90', LATTICE_SYSTEMS.triclinic.free.length === 6 && cellForSystem('triclinic', { a: 1, b: 2, c: 3 }).alpha === 90);
  check('systems: an unknown system throws', !!tryCall(() => cellForSystem('rhombic', {})).e);
  check('systems: the system a group needs, for the builder to grey out fields', latticeSystemFor(findSpaceGroup('Fm-3m')) === 'cubic' && latticeSystemFor(findSpaceGroup('P63/mmc')) === 'hexagonal' && latticeSystemFor(findSpaceGroup('P3121')) === 'hexagonal' && latticeSystemFor(findSpaceGroup(14)) === 'monoclinic');
}

/* ------------------------------------------------------------ expansion on textbook crystals */
{
  const nacl = { a: [5.64, 0, 0], b: [0, 5.64, 0], c: [0, 0, 5.64] };
  const ex = expandAsymmetricUnit([{ label: 'Na1', elem: 'Na', frac: [0, 0, 0] }, { label: 'Cl1', elem: 'Cl', frac: [0.5, 0.5, 0.5] }], symopsForGroup('Fm-3m'), { vectors: nacl });
  check('NaCl: two atoms in Fm-3m give the eight of the rock-salt cell, multiplicity 4 and 4', ex.atoms.length === 8 && ex.multiplicity.join() === '4,4' && ex.atoms.filter(a => a.elem === 'Na').length === 4 && ex.dropped === 0, ex.atoms.length + ' ' + ex.multiplicity.join());
  check('NaCl: the images are the face centres, in angstrom too', ex.atoms.some(a => a.elem === 'Na' && a.frac.join() === '0,0.5,0.5' && near(a.cart[1], 2.82, 1e-9)) && ex.atoms.some(a => a.elem === 'Cl' && a.frac.join() === '0.5,0,0'));
  const sc = buildSupercell(ex.atoms, nacl, [2, 2, 2]);
  check('NaCl: a 2x2x2 supercell has 64 atoms and the vectors doubled', sc.atoms.length === 64 && sc.vectors.a[0] === 11.28 && sc.vectors.b[1] === 11.28 && sc.vectors.c[2] === 11.28 && sc.atoms.filter(a => a.elem === 'Cl').length === 32);
  check('NaCl: supercell atoms carry angstrom coordinates inside the big box and fractions of it', sc.atoms.every(a => a.x >= 0 && a.x < 11.28 && a.frac.every(v => v >= 0 && v < 1)) && sc.atoms.some(a => near(a.x, 8.46, 1e-9) && near(a.y, 8.46, 1e-9) && near(a.z, 8.46, 1e-9) && a.elem === 'Cl'));
  check('NaCl: the first 8 supercell atoms are the original cell', sc.atoms.slice(0, 8).every((a, i) => a.cellIndex.join() === '0,0,0' && a.label === ex.atoms[i].label));
  const again = expandAsymmetricUnit(ex.atoms, symopsForGroup('Fm-3m'));
  check('NaCl: expanding the expanded cell again changes nothing (8 atoms x 4 images, 8 kept, 24 dropped)', again.atoms.length === 8 && again.dropped === 24 && again.atoms.every((a, i) => a.frac.join() === ex.atoms[i].frac.join()));

  /* corundum, R-3c on hexagonal axes: Al on 12c (0,0,z), O on 18e (x,0,1/4) — 30 atoms per hexagonal cell */
  const cor = expandAsymmetricUnit([{ label: 'Al1', elem: 'Al', frac: [0, 0, 0.35216] }, { label: 'O1', elem: 'O', frac: [0.3064, 0, 0.25] }], symopsForGroup('R-3c'));
  check('corundum: R-3c on hexagonal axes gives 12 Al + 18 O = 30 atoms', cor.atoms.length === 30 && cor.multiplicity.join() === '12,18', cor.atoms.length + ' ' + cor.multiplicity.join());
  /* the same crystal on rhombohedral axes: Al on 4c (x,x,x), O on 6e (x,-x+1/2,1/4) — 10 atoms in the primitive cell */
  const corR = expandAsymmetricUnit([{ label: 'Al1', elem: 'Al', frac: [0.352, 0.352, 0.352] }, { label: 'O1', elem: 'O', frac: [0.556, -0.056, 0.25] }], symopsForGroup('R-3c:R'));
  check('corundum: R-3c:R gives 4 Al + 6 O = 10 atoms, a third of the hexagonal cell', corR.atoms.length === 10 && corR.multiplicity.join() === '4,6', corR.atoms.length + ' ' + corR.multiplicity.join());
  /* a general position in P1 is untouched; an atom given twice is kept once */
  const p1 = expandAsymmetricUnit([{ label: 'C1', elem: 'C', frac: [0.1, 0.2, 0.3] }, { label: 'C1b', elem: 'C', frac: [1.1, 0.2, -0.7] }, { label: 'N1', elem: 'N', frac: [0.1, 0.2, 0.3] }], ['x,y,z']);
  check('expansion: a duplicate of the same element is dropped (label of the first kept), a different element at the same site is disorder and kept', p1.atoms.length === 2 && p1.atoms[0].label === 'C1' && p1.atoms[1].elem === 'N' && p1.dropped === 1);
  check('expansion: the identity is added when the list lacks it', expandAsymmetricUnit([{ elem: 'C', frac: [0.1, 0.2, 0.3] }], ['-x,-y,-z']).atoms.length === 2);
  check('expansion: an atom without fractional coordinates is an error', !!tryCall(() => expandAsymmetricUnit([{ elem: 'C', cart: [1, 2, 3] }], ['x,y,z'])).e);
}

/* ------------------------------------------------------------ Urea.cif — the real thing */
{
  const cif = parseCIF(corpus('Urea.cif'));
  check('urea: cell 5.589 5.589 4.6947 90 90 90', cif.cell && near(cif.cell.a, 5.589) && near(cif.cell.b, 5.589) && near(cif.cell.c, 4.6947) && cif.cell.gamma === 90, JSON.stringify(cif.cell));
  check('urea: vectors follow (a along x, b along y, c along z)', !!cif.vectors && near(cif.vectors.a[0], 5.589) && near(cif.vectors.c[2], 4.6947) && near(cif.vectors.b[0], 0, 1e-12) && near(cif.vectors.b[1], 5.589));
  check("urea: space group 'P-421M' #113, tetragonal, 8 operators listed", cif.spaceGroup.hm === 'P-421M' && cif.spaceGroup.number === 113 && cif.spaceGroup.crystalSystem === 'tetragonal' && cif.symops.length === 8 && cif.symops[4] === '-x+1/2,y+1/2,-z', JSON.stringify(cif.spaceGroup) + ' ' + cif.symops.length);
  check('urea: 5 atoms C O N H1 H2 with fractions, occupancy and Uiso', cif.atoms.length === 5 && cif.atoms.map(a => a.elem).join() === 'C,O,N,H,H' && cif.atoms[3].label === 'H1' && near(cif.atoms[2].frac[0], 0.1447) && near(cif.atoms[4].frac[2], -0.0339) && cif.atoms[0].occ === 1 && cif.atoms[0].uiso === 0, JSON.stringify(cif.atoms[2]));
  check('urea: kind cif, block name, note', cif.kind === 'cif' && cif.block === 'Urea_crystal' && /5 atoms, 8 operators listed, P-421M \(#113\)/.test(cif.note), cif.note);
  check("urea: the file's 8 operators are exactly the table's P-421m (#113) — one real-world check of the table", sameSet(cif.symops, symopsForGroup('P-421m')) && sameSet(cif.symops, symopsForGroup(113)));
  const ex = expandAsymmetricUnit(cif.atoms, cif.symops, { vectors: cif.vectors });
  check('urea: expansion gives 16 atoms (Z = 2), C and O on the 2-fold axis with multiplicity 2, N and H with 4', ex.atoms.length === 16 && ex.multiplicity.join() === '2,2,4,4,4' && ex.dropped === 0, ex.atoms.length + ' ' + ex.multiplicity.join());
  check('urea: C=O 1.258 A and C-N 1.343 A in the expanded cell (the file says 1.258 and 1.343)', (() => {
    const C = ex.atoms.find(a => a.elem === 'C'), O = ex.atoms.filter(a => a.elem === 'O'), N = ex.atoms.filter(a => a.elem === 'N');
    const d = (p, q) => { const f = p.frac.map((v, i) => { const x = v - q.frac[i]; return x - Math.round(x); }); const c = fracToCart(f, cif.vectors); return Math.hypot(...c); };
    return O.some(o => near(d(C, o), 1.258, 0.002)) && N.filter(n => near(d(C, n), 1.343, 0.002)).length === 2;
  })());
  const S = crystalToStructure(corpus('Urea.cif'));
  check('urea: crystalToStructure gives the same 16 atoms in angstrom, using the file\'s operators', S.nAsym === 5 && S.nExpanded === 16 && S.nAtoms === 16 && S.spaceGroup.source === 'file' && S.spaceGroup.number === 113 && S.spaceGroup.standardHm === 'P -4 21 m' && S.atoms.every(a => Number.isFinite(a.x) && a.elem) && near(S.cell.a[0], 5.589), S.note);
  check('urea: expanding the P1 result again with the full group changes nothing (same 16 sites, as a set)', (() => {
    const again = expandAsymmetricUnit(ex.atoms, symopsForGroup(113));
    const key = (a) => a.elem + ':' + a.frac.map(v => v.toFixed(4)).join(',');
    /* C, C', O, O' each give 2 images and the 12 others 4: 56 images, 16 kept, 40 dropped */
    return again.atoms.length === 16 && again.dropped === 40 &&
           again.atoms.map(key).sort().join('|') === ex.atoms.map(key).sort().join('|');
  })());

  /* Urea_crystal.pdb: 88 atoms = 11 complete urea molecules, no CRYST1, the REMARK naming the
     central molecule's atoms. Its frame is not the CIF's (the [110] direction of the cell lies
     along x), so the rigid motion is found from the central molecule — the angle from the N...N
     vector, the shift from the carbon — and then every atom of the cluster must sit on an atom of
     the expanded crystal, periodic images included, within 0.05 A. */
  const pdb = corpus('Urea_crystal.pdb');
  const P = pdb.split('\n').filter(l => /^(HETATM|ATOM)/.test(l)).map(l => ({ serial: +l.slice(6, 11), elem: l.slice(76, 78).trim(), x: +l.slice(30, 38), y: +l.slice(38, 46), z: +l.slice(46, 54) }));
  check('urea pdb: 88 atoms, 11 molecules, no CRYST1 — a cluster, not a P1 cell (so the comparison below is by rigid motion)', P.length === 88 && P.filter(a => a.elem === 'C').length === 11 && !/^CRYST1/m.test(pdb));
  const central = (pdb.match(/central urea:\s*([\d,\s]+)/) || [])[1].split(',').map(Number);
  const cen = central.map(s => P.find(a => a.serial === s));
  const pC = cen.find(a => a.elem === 'C'), pN = cen.filter(a => a.elem === 'N');
  const cryst = ex.atoms.map(a => ({ ...a, cart: fracToCart(a.frac, cif.vectors) }));
  const cC = cryst.find(a => a.elem === 'C');
  const bonded = (a, b, r) => Math.hypot(a.cart[0] - b.cart[0], a.cart[1] - b.cart[1], a.cart[2] - b.cart[2]) < r;
  /* the two N of the crystal's first carbon, from the periodic images within a bond length */
  const shifts = []; for (const i of [-1, 0, 1]) for (const j of [-1, 0, 1]) for (const k of [-1, 0, 1]) shifts.push([i, j, k]);
  const cN = [];
  for (const a of cryst.filter(x => x.elem === 'N')) for (const s of shifts) { const img = { cart: fracToCart(a.frac.map((v, q) => v + s[q]), cif.vectors) }; if (bonded(img, cC, 1.5)) cN.push(img); }
  check('urea pdb: the central carbon of the cluster and the first carbon of the crystal each have two nitrogens', pN.length === 2 && cN.length === 2, pN.length + ' ' + cN.length);
  const ang = (u) => Math.atan2(u[1], u[0]);
  const vP = [pN[1].x - pN[0].x, pN[1].y - pN[0].y], vC = [cN[1].cart[0] - cN[0].cart[0], cN[1].cart[1] - cN[0].cart[1]];
  const matchAll = (theta) => {
    const cs = Math.cos(theta), sn = Math.sin(theta);
    const rot = (p) => [cs * p.x - sn * p.y, sn * p.x + cs * p.y, p.z];
    const rc = rot(pC), t = [cC.cart[0] - rc[0], cC.cart[1] - rc[1], cC.cart[2] - rc[2]];
    let worst = 0, misses = 0;
    for (const p of P) {
      const r = rot(p).map((v, i) => v + t[i]);
      const f = cartToFrac(r, cif.vectors);
      let best = Infinity;
      for (const a of cryst) {
        if (a.elem !== p.elem) continue;
        const d = f.map((v, i) => { const x = v - a.frac[i]; return x - Math.round(x); });
        const c = fracToCart(d, cif.vectors);
        best = Math.min(best, Math.hypot(c[0], c[1], c[2]));
      }
      worst = Math.max(worst, best);
      if (best > 0.05) misses++;
    }
    return { worst, misses };
  };
  const th = ang(vC) - ang(vP);
  let m = matchAll(th);
  if (m.misses) m = matchAll(th + Math.PI);
  check('urea pdb: after the rigid motion every one of the 88 atoms lies on an expanded crystal atom within 0.05 A', m.misses === 0 && m.worst < 0.05, 'worst ' + m.worst.toFixed(4) + ' A, misses ' + m.misses + ', rotation ' + (th * 180 / Math.PI).toFixed(1) + ' deg');
  check('urea pdb: and the motion really is a 45 degree turn about c (the cluster has [110] along x)', near(Math.abs(((th * 180 / Math.PI) % 90 + 90) % 90), 45, 0.5), (th * 180 / Math.PI).toFixed(2));
}

/* ------------------------------------------------------------ zeolite.cif and COF_12000N2.cif (P1) */
{
  const z = parseCIF(corpus('zeolite.cif'));
  check('zeolite: monoclinic cell 17.523 17.644 14.802 beta 116.104, P1 with x,y,z listed, no name, 216 atoms (labels only, no type symbols)',
    z.cell && near(z.cell.beta, 116.104) && z.symops.join() === 'x,y,z' && !z.spaceGroup.hm && z.atoms.length === 216 && z.atoms.every(a => a.elem === 'O' || a.elem === 'Si'), z.note);
  const ez = expandAsymmetricUnit(z.atoms, z.symops);
  check('zeolite: expansion keeps all 216, every atom unique, multiplicity 1', ez.atoms.length === 216 && ez.dropped === 0 && ez.multiplicity.every(m => m === 1));
  const zz = expandAsymmetricUnit(ez.atoms, ['x,y,z']);
  check('zeolite: re-expanding the P1 result changes nothing', zz.atoms.length === 216 && zz.atoms.every((a, i) => a.frac.every((v, k) => near(v, ez.atoms[i].frac[k], 1e-12))));
  const Sz = crystalToStructure(corpus('zeolite.cif'));
  check('zeolite: crystalToStructure 216 atoms in angstrom, cell vectors with the monoclinic tilt', Sz.nAtoms === 216 && Sz.nAsym === 216 && near(Sz.cell.c[0], 14.802 * Math.cos(116.104 * Math.PI / 180), 1e-3) && Sz.spaceGroup.source === 'file', Sz.note);
  const negative = z.atoms.find(a => a.frac.some(v => v < 0));
  check('zeolite: a negative fraction in the file is wrapped into the cell on expansion', negative && ez.atoms.every(a => a.frac.every(v => v >= 0 && v < 1)));

  const c = parseCIF(corpus('COF_12000N2.cif'));
  check("COF: hexagonal cell 22.556 22.556 6.8 gamma 120, Hall 'P 1', H-M 'P 1', operator in quotes, 144 atoms with type symbols",
    c.cell && c.cell.gamma === 120 && c.spaceGroup.hall === 'P 1' && c.spaceGroup.hm === 'P 1' && c.symops.join() === 'x,y,z' && c.atoms.length === 144, c.note);
  const ec = expandAsymmetricUnit(c.atoms, c.symops);
  check('COF: 144 unique atoms, unchanged by expansion, and unchanged again', ec.atoms.length === 144 && ec.dropped === 0 && expandAsymmetricUnit(ec.atoms, ['x,y,z']).atoms.length === 144);
  const Sc = crystalToStructure(corpus('COF_12000N2.cif'), { supercell: [2, 2, 1] });
  check('COF: a 2x2x1 supercell has 576 atoms, a and b doubled, c not, and b at 120 degrees from a', Sc.nAtoms === 576 && Sc.nExpanded === 144 && near(Sc.cell.a[0], 45.112, 1e-9) && near(Sc.cell.c[2], 6.8, 1e-9) && near(Sc.cell.b[0], -22.556, 1e-6), JSON.stringify(Sc.cell));
}

/* ------------------------------------------------------------ 8yax.fw2.cif — an mmCIF is not a crystal to expand */
{
  const t0 = Date.now();
  const m = parseCIF(corpus('8yax.fw2.cif'));
  check('mmCIF: read in reasonable time (4 MB)', Date.now() - t0 < 15000, (Date.now() - t0) + ' ms');
  check('mmCIF: kind mmcif, the placeholder cell 1 1 1 90 90 90 is still read, P 1 #1, one operator', m.kind === 'mmcif' && m.cell && m.cell.a === 1 && m.cell.alpha === 90 && m.spaceGroup.hm === 'P 1' && m.spaceGroup.number === 1 && m.symops.join() === 'x,y,z', m.note);
  check('mmCIF: 40738 Cartesian atoms with elements, no fractions', m.atoms.length === 40738 && m.atoms[0].elem === 'N' && m.atoms[0].cart && near(m.atoms[0].cart[0], 179.98438) && !m.atoms[0].frac);
  const r = tryCall(() => crystalToStructure(m));
  check('mmCIF: crystalToStructure refuses, with code mmcif and a message that says why', r.e && r.e.code === 'mmcif' && /macromolecular/.test(r.e.message) && /label_asym_id/.test(r.e.message), r.e && r.e.message);
  check('mmCIF: the refusal is not for want of a cell (small-molecule CIFs without one get nocell)', tryCall(() => crystalToStructure('data_x\nloop_\n_atom_site_label\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z\nC1 0 0 0\n')).e.code === 'nocell');
}

/* ------------------------------------------------------------ CIF syntax, from the awkward corners of real files */
{
  const QUIRKY = `#------------------------------------------------------------------------------
data_empty_first_block
_journal_name_full 'Acta Crystallographica'
_publ_section_title
;
 A structure with everything a reader must survive: esds, quotes, a text field,
 an id column, unknowns and a dummy atom
;
data_real
_symmetry_space_group_name_H-M   'P 1 21/c 1'      # a comment after the value
_symmetry_Int_Tables_number       14
_space_group_name_Hall           '-P 2ybc'
_cell_length_a                    10.123(4)
_cell_length_b                    7.456(3)
_cell_length_c                    12.789(5)
_cell_angle_alpha                 90
_cell_angle_beta                  98.76(2)
_cell_angle_gamma                 90
_cell_volume                      ?
loop_
_space_group_symop_id
_space_group_symop_operation_xyz
1 'x, y, z'
2 '-x, y+1/2, -z+1/2'
3 '-x, -y, -z'
4 'x, -y+1/2, z+1/2'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_U_iso_or_equiv
_atom_site_occupancy
_atom_site_calc_flag
Fe1  Fe3+  0.0000       0.0000      0.0000       0.0123(3)  1.0   .
O1   O2-   0.1234(5)    0.2345(6)   0.3456(7)    0.0234(4)  1.0   .
Cl1  CL    0.4321(5)   -0.1234(6)   0.7654(7)    ?          0.5   .
H1   H     0.1111       0.2222      0.3333       .          1.0   calc
X1   X     0.5000       0.5000      0.5000       .          1.0   dum
C1   C     ?            ?           ?            .          1.0   .
`;
  const q = parseCIF(QUIRKY);
  check('cif: the first block with atoms is chosen, not the empty first block', q.block === 'real');
  check('cif: esds are stripped from cell and coordinates, ? is unknown', q.cell && near(q.cell.a, 10.123) && near(q.cell.beta, 98.76) && q.atoms[1] && near(q.atoms[1].frac[0], 0.1234) && near(q.atoms[1].uiso, 0.0234) && q.atoms[2].uiso === undefined);
  check("cif: quoted H-M with the monoclinic padding, the number, the Hall symbol, and a comment after a value", q.spaceGroup.hm === 'P 1 21/c 1' && q.spaceGroup.number === 14 && q.spaceGroup.hall === '-P 2ybc');
  check('cif: the symop loop with an id column, quoted operators with spaces', q.symops.length === 4 && q.symops[1] === '-x, y+1/2, -z+1/2');
  check('cif: elements from type symbols with charges and capitals; a dummy atom and an atom without coordinates are skipped', q.atoms.length === 4 && q.atoms.map(a => a.elem).join() === 'Fe,O,Cl,H' && /2 atom rows skipped/.test(q.note), q.note);
  check('cif: occupancy read, label kept', q.atoms[2].occ === 0.5 && q.atoms[2].label === 'Cl1' && q.atoms[0].occ === 1);
  const S = crystalToStructure(QUIRKY);
  check('cif: P21/c file expands 4 atoms to 14 (Fe on the inversion centre counts 2) with the listed operators, on a monoclinic cell',
    S.nAsym === 4 && S.nExpanded === 14 && S.multiplicity.join() === '2,4,4,4' && S.spaceGroup.source === 'file' && near(cellParams(S.cell).beta, 98.76, 1e-6), S.nExpanded + ' ' + S.multiplicity.join());
  check('cif: a lone symop as a non-loop item is read too', parseCIF("data_a\n_symmetry_equiv_pos_as_xyz 'x,y,z'\n").symops.join() === 'x,y,z');
  const blocks = cifBlocks(QUIRKY).blocks;
  const title = blocks[0].items.get('_publ_section_title');
  check('cif: a text field keeps its lines and is not mistaken for values (cifBlocks exposes the raw items)', blocks.length === 2 && blocks[0].name === 'empty_first_block' && /^ A structure with everything.*\n.*dummy atom$/s.test(title) && blocks[0].loops.length === 0 && blocks[1].loops.length === 2, JSON.stringify(title));
  check('cif: CRLF line ends and tabs are fine', parseCIF(QUIRKY.replace(/\n/g, '\r\n').replace(/  +/g, '\t')).atoms.length === 4);
  check('cif: mmCIF dotted tags are read through the same names', parseCIF("data_x\n_cell.length_a 3\n_cell.length_b 4\n_cell.length_c 5\n_cell.angle_alpha 90\n_cell.angle_beta 90\n_cell.angle_gamma 90\n_symmetry.space_group_name_H-M 'P 1'\n").cell.b === 4);
  check('cif: no data block at all gives an empty result with a note, not an exception', parseCIF('').atoms.length === 0 && parseCIF('').note === 'no data block' && parseCIF('just words').atoms.length === 0);
  check('cif: an apostrophe inside a quoted string does not end it (CIF 1.1: a quote ends only before a blank)', parseCIF("data_x\n_chemical_name_common 'it's urea'\n_cell_length_a 1\n").cell === null && parseCIF("data_x\n_a 'it's here' _cell_length_a 2 _cell_length_b 2 _cell_length_c 2 _cell_angle_alpha 90 _cell_angle_beta 90 _cell_angle_gamma 90\n").cell.a === 2);
}

/* ------------------------------------------------------------ crystalToStructure: which operators */
{
  const NACL = `data_NaCl
_cell_length_a 5.64
_cell_length_b 5.64
_cell_length_c 5.64
_cell_angle_alpha 90
_cell_angle_beta 90
_cell_angle_gamma 90
_symmetry_space_group_name_H-M 'F m -3 m'
_symmetry_Int_Tables_number 225
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
Na1 Na 0 0 0
Cl1 Cl 0.5 0.5 0.5
`;
  const S = crystalToStructure(NACL);
  check('structure: a CIF naming Fm-3m without operators is expanded from the table: 8 atoms, 192 operators, source table', S.nAtoms === 8 && S.symops.length === 192 && S.spaceGroup.source === 'table' && S.spaceGroup.number === 225 && /operators from the table/.test(S.note), S.note);
  const S2 = crystalToStructure(NACL, { supercell: [2, 2, 2] });
  check('structure: 2x2x2 NaCl is 64 atoms with an 11.28 A box', S2.nAtoms === 64 && S2.nExpanded === 8 && near(S2.cell.a[0], 11.28, 1e-9) && S2.supercell.join() === '2,2,2');
  const S3 = crystalToStructure(NACL, { expand: false });
  check('structure: expand:false leaves the asymmetric unit', S3.nAtoms === 2 && S3.spaceGroup.source === 'not expanded');
  const byNumber = crystalToStructure(NACL.replace("_symmetry_space_group_name_H-M 'F m -3 m'\n", ''));
  check('structure: the number alone is enough', byNumber.nAtoms === 8);
  const byHall = crystalToStructure(NACL.replace("_symmetry_space_group_name_H-M 'F m -3 m'\n", "_symmetry_space_group_name_Hall '-F 4 2 3'\n"));
  check('structure: the Hall symbol alone is enough, and is preferred (it fixes the setting)', byHall.nAtoms === 8 && /Hall symbol from the file/.test(byHall.spaceGroup.setting));
  const asP1 = crystalToStructure(NACL.replace(/_symmetry.*\n/g, ''));
  check('structure: nothing named at all is P1 and the note says so', asP1.nAtoms === 2 && /taken as P1/.test(asP1.note));
  const rescued = crystalToStructure(NACL.replace('F m -3 m', 'Q q q'));
  check('structure: an unknown name is rescued by the number when the file gives one', rescued.nAtoms === 8 && rescued.spaceGroup.number === 225);
  const bad = tryCall(() => crystalToStructure(NACL.replace('F m -3 m', 'Q q q').replace('_symmetry_Int_Tables_number 225\n', '')));
  check('structure: an unknown name with no number and no operators is refused with code nogroup', bad.e && bad.e.code === 'nogroup' && /Q q q/.test(bad.e.message), bad.e && bad.e.message);
  const noAtoms = tryCall(() => crystalToStructure('data_x\n_cell_length_a 5\n_cell_length_b 5\n_cell_length_c 5\n_cell_angle_alpha 90\n_cell_angle_beta 90\n_cell_angle_gamma 90\n'));
  check('structure: no atoms is refused with code noatoms', noAtoms.e && noAtoms.e.code === 'noatoms');
  /* the listed operators win over the name, even when they disagree */
  const listed = crystalToStructure(NACL + "loop_\n_symmetry_equiv_pos_as_xyz\n'x,y,z'\n'-x,-y,-z'\n");
  check("structure: a listed operator set wins over the name, whatever the name says", listed.nAtoms === 2 && listed.spaceGroup.source === 'file' && listed.symops.length === 2);
  const broken = crystalToStructure(NACL + "loop_\n_symmetry_equiv_pos_as_xyz\n'x,y,z'\n'-y,x,z'\n");
  check('structure: a listed set that is not a group is used as given but the note says so', broken.symops.length === 2 && /do not form a group \(their closure has 4\)/.test(broken.note), broken.note);
  /* a rhombohedral cell with an R group named and no operators: expanded on rhombohedral axes */
  const CORR = `data_corundum_R
_cell_length_a 5.128
_cell_length_b 5.128
_cell_length_c 5.128
_cell_angle_alpha 55.28
_cell_angle_beta 55.28
_cell_angle_gamma 55.28
_symmetry_space_group_name_H-M 'R -3 c'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
Al1 Al 0.352 0.352 0.352
O1 O 0.556 -0.056 0.25
`;
  const R = crystalToStructure(CORR);
  check('structure: R-3c with a rhombohedral cell and no operators is expanded on rhombohedral axes: 10 atoms, 12 operators, said in the note', R.nAtoms === 10 && R.symops.length === 12 && /rhombohedral axes/.test(R.note) && /rhombohedral cell/.test(R.note), R.note);
  const CORH = CORR.replace(/_cell_length_a 5.128\n_cell_length_b 5.128\n_cell_length_c 5.128\n_cell_angle_alpha 55.28\n_cell_angle_beta 55.28\n_cell_angle_gamma 55.28/,
    '_cell_length_a 4.7589\n_cell_length_b 4.7589\n_cell_length_c 12.991\n_cell_angle_alpha 90\n_cell_angle_beta 90\n_cell_angle_gamma 120')
    .replace('Al1 Al 0.352 0.352 0.352\nO1 O 0.556 -0.056 0.25', 'Al1 Al 0 0 0.35216\nO1 O 0.3064 0 0.25');
  const H = crystalToStructure(CORH);
  check('structure: the same group with a hexagonal cell stays on hexagonal axes: 30 atoms, 36 operators', H.nAtoms === 30 && H.symops.length === 36 && /hexagonal axes/.test(H.note), H.note);
  /* Cartesian atom sites, as a few programs write them, are converted with the cell */
  const CART = NACL.replace(/_atom_site_fract_(.)/g, '_atom_site_Cartn_$1').replace('Cl1 Cl 0.5 0.5 0.5', 'Cl1 Cl 2.82 2.82 2.82');
  check('structure: _atom_site_Cartn_* (angstrom) is converted to fractions with the cell', crystalToStructure(CART).nAtoms === 8 && parseCIF(CART).atoms[1].frac.every(v => near(v, 0.5, 1e-9)));
  /* a file that states multiplicities lets the reader check its own setting */
  const MULT = NACL.replace('_atom_site_fract_z\n', '_atom_site_fract_z\n_atom_site_symmetry_multiplicity\n').replace('Na1 Na 0 0 0\n', 'Na1 Na 0 0 0 4\n').replace('Cl1 Cl 0.5 0.5 0.5\n', 'Cl1 Cl 0.5 0.5 0.5 4\n');
  check('structure: multiplicities that agree with the file pass in silence', parseCIF(MULT).atoms[0].multiplicity === 4 && !/multiplicities disagree/.test(crystalToStructure(MULT).note));
  const wrongSetting = crystalToStructure(MULT.replace('Cl1 Cl 0.5 0.5 0.5 4', 'Cl1 Cl 0.5 0.5 0.5 8'));
  check('structure: multiplicities that disagree are reported as a sign of a wrong setting', /multiplicities disagree.*Cl1 4 \(file says 8\)/.test(wrongSetting.note), wrongSetting.note);
  /* the atoms come out in angstrom with everything the page needs */
  check('structure: atoms carry elem, x, y, z, label, frac, asym', S.atoms.every(a => a.elem && [a.x, a.y, a.z].every(Number.isFinite) && a.label && a.frac.length === 3 && Number.isInteger(a.asym)) && S.atoms.filter(a => a.asym === 1).length === 4);
}

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
