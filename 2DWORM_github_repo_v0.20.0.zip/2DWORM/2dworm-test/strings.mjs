/* The strings a translator has to see — and does not have.
   Walks the page exactly the way i18nCollect() does (every text node and every title,
   placeholder and data-idle outside data-i18n-skip), adds the literal messages the script
   writes (say / say3d / editHint / tr with a plain string), and lists whatever is NOT yet a
   key in lang/en.json. Writes lang/STRINGS_TO_REVIEW.md (a table with empty columns for the
   reviewers) and lang/strings_to_review.csv. Run it before sending a build to a reviewer:

     node ../2dworm-test/strings.mjs            # from 2dworm/
     node strings.mjs --check                   # only count; exit 1 when new strings exist

   Nothing here touches the language files: a key is added to them when a translation
   arrives, not before, so that lang.mjs's "left untranslated by accident" check keeps its
   meaning. */
import { chromium } from '/home/claude/ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));
const APP = join(HERE, '..', '2dworm') + '/';
const checkOnly = process.argv.includes('--check');
const PORT = 8877;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP], { stdio: 'ignore' });
await new Promise(r => setTimeout(r, 900));

const en = JSON.parse(readFileSync(APP + 'lang/en.json', 'utf8'));
const have = new Set(Object.keys(en).filter(k => !k.startsWith('//')));
const src = readFileSync(APP + 'index.html', 'utf8');
const version = (src.match(/version:\s*'([\d.]+)'/) || [])[1] || '?';
const build = (src.match(/build:\s*(\d+)/) || [])[1] || '?';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
/* the same walk as the page's own i18nCollect(), on the page as it is at rest */
const dom = await page.evaluate(() => {
  const out = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      const p = n.parentElement;
      if (!p || /^(SCRIPT|STYLE|IFRAME|TEXTAREA)$/.test(p.nodeName)) return NodeFilter.FILTER_REJECT;
      if (p.closest('[data-i18n-skip]')) return NodeFilter.FILTER_REJECT;
      return n.nodeValue.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    },
  });
  const where = (el) => { const id = el.closest('[id]'); return (id ? '#' + id.id : el.tagName.toLowerCase()); };
  for (let n; (n = w.nextNode());) out.push({ s: n.nodeValue.trim(), kind: 'text', where: where(n.parentElement) });
  for (const a of ['title', 'placeholder', 'data-idle']) {
    document.querySelectorAll('[' + a + ']').forEach(el => {
      if (!el.closest('[data-i18n-skip]')) out.push({ s: el.getAttribute(a), kind: a, where: where(el) });
    });
  }
  return out;
});
await browser.close(); server.kill();

/* literal messages in the script: say('…'), say3d('…'), editHint('…'), tr('…') */
const lit = [];
const re = /\b(say3d|say|editHint|tr|ask|waitBox)\(\s*'((?:[^'\\]|\\.)*)'/g;
let m;
while ((m = re.exec(src))) lit.push({ s: m[2].replace(/\\'/g, "'"), kind: m[1] + '()', where: 'script' });

const seen = new Map();
for (const e of dom.concat(lit)) {
  const s = e.s.trim();
  if (!s || s.length < 2) continue;
  if (!/[A-Za-z]/.test(s)) continue;                      // numbers, symbols, formulae
  if (/^https?:\/\//.test(s)) continue;
  if (have.has(s)) continue;
  if (!seen.has(s)) seen.set(s, e);
}
const list = [...seen.entries()].sort((a, b) => a[1].kind.localeCompare(b[1].kind) || a[0].localeCompare(b[0]));
const short = list.filter(([s]) => s.length <= 40), long = list.filter(([s]) => s.length > 40);
console.log(`${list.length} strings in the page are not in lang/en.json (${short.length} labels, ${long.length} sentences); ${have.size} keys exist`);
if (checkOnly) process.exit(list.length ? 1 : 0);

const esc = (s) => s.replace(/\|/g, '\\|').replace(/\n/g, ' ');
let md = `# 2D-WORM — strings for review (v${version}, build ${build})\n\n`;
md += `Every English string in the page that is not yet in the language files: ${list.length} of them, `;
md += `${short.length} short labels and ${long.length} sentences. Fill the two columns (or one of them) and send the file back; `;
md += `the keys go into \`lang/hi.json\` and \`lang/ur.json\` exactly as written here. A string may stay in English — leave the cell empty and it will. `;
md += `Do not change the *English* column: it is the key the page looks up.\n\n`;
md += `Made by \`2dworm-test/strings.mjs\`; the \`where\` column says which control the text belongs to (a tooltip is a \`title\`).\n\n`;
const table = (rows) => '| English | where | हिन्दी | اردو |\n|---|---|---|---|\n' + rows.map(([s, e]) => `| ${esc(s)} | ${e.kind}${e.where && e.where !== 'script' ? ' ' + e.where : ''} |  |  |`).join('\n') + '\n';
md += '## Labels and short strings\n\n' + table(short) + '\n## Sentences (tooltips, messages)\n\n' + table(long);
writeFileSync(APP + 'lang/STRINGS_TO_REVIEW.md', md);
const csv = 'English,where,Hindi,Urdu\n' + list.map(([s, e]) => `"${s.replace(/"/g, '""')}","${e.kind} ${e.where}",,`).join('\n') + '\n';
writeFileSync(APP + 'lang/strings_to_review.csv', '﻿' + csv);
console.log('written lang/STRINGS_TO_REVIEW.md and lang/strings_to_review.csv');
