/* The same files, opened through the real page: lazy module load, drag-and-drop routing,
   .gro and POSCAR through 3Dmol's own parsers, and the status line that reports them. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8779;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const ORCA = `
                                 * O   R   C   A *
           Program Version 5.0.4 -  RELEASE  -

---------------------------------
CARTESIAN COORDINATES (ANGSTROEM)
---------------------------------
  O      9.000000    0.000000    0.000000
  H      9.900000    0.000000    0.000000
  H      8.760000    0.930000    0.000000

----------------------------
CARTESIAN COORDINATES (A.U.)
----------------------------
  NO LB      ZA    FRAG     MASS         X           Y           Z
   0 O     8.0000    0    15.999   17.007535    0.000000    0.000000

---------------------------------
CARTESIAN COORDINATES (ANGSTROEM)
---------------------------------
  O      0.000000    0.000000    0.000000
  H      0.958000    0.000000    0.000000
  H     -0.240000    0.927000    0.000000

----------------------------
CARTESIAN COORDINATES (A.U.)
----------------------------
   0 O     8.0000    0    15.999    0.000000    0.000000    0.000000
`;

const GAUSSIAN = ` Entering Gaussian System, Link 0=g16
 Gaussian 16:  ES64L-G16RevC.01

                          Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        5.000000    0.000000    0.000000
      2          1           0        5.900000    0.000000    0.000000
      3          1           0        4.760000    0.930000    0.000000
 ---------------------------------------------------------------------

                          Standard orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        0.000000    0.000000    0.000000
      2          1           0        0.958000    0.000000    0.000000
      3          1           0       -0.240000    0.927000    0.000000
 ---------------------------------------------------------------------
 Normal termination of Gaussian 16.
`;

const GAUSSIAN_GHOST = ` Entering Gaussian System, Link 0=g16
                          Input orientation:
 ---------------------------------------------------------------------
 Center     Atomic      Atomic             Coordinates (Angstroms)
 Number     Number       Type             X           Y           Z
 ---------------------------------------------------------------------
      1          8           0        0.000000    0.000000    0.000000
      2          1           0        0.958000    0.000000    0.000000
      3          1           0       -0.240000    0.927000    0.000000
      4          0           0        3.000000    3.000000    3.000000
 ---------------------------------------------------------------------
`;

const CP2K = ` DBCSR| Multiplication driver
 CP2K| version string:                            CP2K version 2023.1
 PROGRAM STARTED AT              2026-09-09 06:00:00.000

 MODULE QUICKSTEP:  ATOMIC COORDINATES IN angstrom

  Atom  Kind  Element       X           Y           Z          Z(eff)       Mass

       1     1      O    8    0.000000    0.000000    0.000000      6.0000   15.9994
       2     2      H    1    0.958000    0.000000    0.000000      1.0000    1.0079
       3     2      H    1   -0.240000    0.927000    0.000000      1.0000    1.0079
`;

const MOPAC_OUT = `                        MOPAC v22.0.6 for Windows
                     PM7 CALCULATION RESULTS

          CARTESIAN COORDINATES

   NO.       ATOM         X         Y         Z

    1         O        0.0000    0.0000    0.0000
    2         H        0.9580    0.0000    0.0000
    3         H       -0.2400    0.9270    0.0000
`;

const MOPAC_ARC = `          FINAL GEOMETRY OBTAINED                                    CHARGE
PM7 EF PRECISE
 water

  O     0.00000000 +1   0.00000000 +1   0.00000000 +1
  H     0.95800000 +1   0.00000000 +1   0.00000000 +1
  H    -0.24000000 +1   0.92700000 +1   0.00000000 +1
`;

// xtb writes its final structure in Turbomole coord format, IN BOHR
const XTB = `      -----------------------------------------------------------
     |                   =====================                   |
     |                           x T B                           |
      -----------------------------------------------------------
   * xtb version 6.6.1 (8d0f1dd) compiled by 'ci@ci'

 final structure:
================
$coord
        0.00000000000000        0.00000000000000        0.00000000000000      o
        1.81032183167855        0.00000000000000        0.00000000000000      h
       -0.45354338293264        1.75182258959268        0.00000000000000      h
$end
`;

const VASP = ` vasp.6.3.2 complex
 POTCAR:    PAW_PBE O 08Apr2002
 POTCAR:    PAW_PBE H 15Jun2001
 POTCAR:    PAW_PBE O 08Apr2002
 POTCAR:    PAW_PBE H 15Jun2001

   ions per type =               1   2

 POSITION                                       TOTAL-FORCE (eV/Angst)
 -----------------------------------------------------------------------------------
      5.00000      0.00000      0.00000         0.100000      0.000000      0.000000
      5.95800      0.00000      0.00000         0.000000      0.000000      0.000000
      4.76000      0.93000      0.00000         0.000000      0.000000      0.000000
 -----------------------------------------------------------------------------------

 POSITION                                       TOTAL-FORCE (eV/Angst)
 -----------------------------------------------------------------------------------
      0.00000      0.00000      0.00000         0.000000      0.000000      0.000000
      0.95800      0.00000      0.00000         0.000000      0.000000      0.000000
     -0.24000      0.93000      0.00000         0.000000      0.000000      0.000000
 -----------------------------------------------------------------------------------
`;

const ORCA_IN = `! B3LYP def2-SVP Opt
%pal nprocs 8 end

* xyz 0 1
O   0.000000   0.000000   0.000000
H   0.958000   0.000000   0.000000
H  -0.240000   0.927000   0.000000
*
`;

const GAUSSIAN_IN = `%nprocshared=8
%mem=8GB
#p B3LYP/6-31G(d) Opt

water optimisation

0 1
O   0.000000   0.000000   0.000000
H   0.958000   0.000000   0.000000
H  -0.240000   0.927000   0.000000

`;

const CP2K_IN = `&FORCE_EVAL
  &SUBSYS
    &COORD
      O   0.000000   0.000000   0.000000
      H   0.958000   0.000000   0.000000
      H  -0.240000   0.927000   0.000000
    &END COORD
  &END SUBSYS
&END FORCE_EVAL
`;

const CP2K_IN_BOHR = `&FORCE_EVAL
  &SUBSYS
    &COORD
      UNIT bohr
      O   0.000000   0.000000   0.000000
      H   1.810322   0.000000   0.000000
      H  -0.453543   1.751823   0.000000
    &END COORD
  &END SUBSYS
&END FORCE_EVAL
`;


const GRO = `MD of water, t= 0.0
    3
    1SOL     OW    1   0.000   0.000   0.000
    1SOL    HW1    2   0.096   0.000   0.000
    1SOL    HW2    3  -0.024   0.093   0.000
   2.00000   2.00000   2.00000
`;
const POSCAR = `water
1.0
  10.0000000000   0.0000000000   0.0000000000
   0.0000000000  10.0000000000   0.0000000000
   0.0000000000   0.0000000000  10.0000000000
O H
1 2
Cartesian
   0.0000000000   0.0000000000   0.0000000000
   0.9580000000   0.0000000000   0.0000000000
  -0.2400000000   0.9270000000   0.0000000000
`;

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

// a drawing in Ketcher throughout: opening a geometry file must never disturb it
await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('c1ccccc1O'); });

async function open(name, text) {
  await page.evaluate(async ([n, t]) => { await dworm2d.openFile(new File([t], n, { type: 'text/plain' })); }, [name, text]);
  await page.waitForTimeout(400);
  return page.evaluate(() => ({
    msg: document.getElementById('msg').textContent,
    cls: document.getElementById('msg').className,
    n: dworm2d.viewer.getModel() ? dworm2d.viewer.getModel().selectedAtoms({}).length : 0,
    elems: dworm2d.viewer.getModel() ? dworm2d.viewer.getModel().selectedAtoms({}).map(a => a.elem).join('') : '',
    name: dworm2d.state3d.fileName,
    periodic: dworm2d.state3d.periodic,
  }));
}

const files = [
  ['orca.out', ORCA, 'ORCA'], ['g16.log', GAUSSIAN, 'Gaussian'], ['cp2k.out', CP2K, 'CP2K'],
  ['job.arc', MOPAC_ARC, 'MOPAC'], ['xtb.out', XTB, 'xTB'], ['OUTCAR', VASP, 'VASP'],
  ['job.inp', ORCA_IN, 'ORCA input'], ['job.gjf', GAUSSIAN_IN, 'Gaussian input'],
];
for (const [name, text, program] of files) {
  const r = await open(name, text);
  check(`${name} opens and reports ${program}`, r.n === 3 && r.elems === 'OHH' && r.msg.includes(program),
    `${r.n} atoms ${r.elems} — ${r.msg.slice(0, 110)}`);
}
// formats 3Dmol reads itself
{
  const r = await open('conf.gro', GRO);
  check('a GROMACS .gro opens (3Dmol converts nm to A itself)', r.n === 3, `${r.n} atoms — ${r.msg.slice(0, 80)}`);
  const d = await page.evaluate(() => {
    const a = dworm2d.viewer.getModel().selectedAtoms({});
    return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y, a[0].z - a[1].z);
  });
  check('and its nanometres became angstrom', Math.abs(d - 0.96) < 0.05, d.toFixed(3) + ' A');
}
{
  const r = await open('POSCAR', POSCAR);
  check('a VASP POSCAR opens by its name alone', r.n === 3, `${r.n} atoms — ${r.msg.slice(0, 80)}`);
}
// the drawing is still there
/* ------------------------------------------------- periodic structures are not minimised
   A crystal is not a big molecule. Its atoms at a face of the cell are bonded to their own
   periodic images, and neither force field here can see those, so relaxing one moves every
   surface atom inwards against vacuum and returns something tidy and meaningless. The danger
   is precisely that nothing looks wrong, so the refusal has to happen in the program.
   Equally important is what must NOT be blocked: a deposited protein carries a CRYST1 record
   and an mmCIF carries a cell, but those coordinates are whole molecules — 1CRN, 4HHB and
   1AON are minimised in the ordinary way and the paper reports it. */
const CP2K_MOLECULAR = `&FORCE_EVAL
  &SUBSYS
    &CELL
      ABC 20.0 20.0 20.0
      PERIODIC NONE
    &END CELL
    &COORD
      O   0.000000   0.000000   0.000000
      H   0.958000   0.000000   0.000000
      H  -0.240000   0.927000   0.000000
    &END COORD
  &END SUBSYS
&END FORCE_EVAL
`;
const CIF_CRYSTAL = `data_ice
_cell_length_a     4.5181
_cell_length_b     4.5181
_cell_length_c     7.3560
_cell_angle_alpha  90.0
_cell_angle_beta   90.0
_cell_angle_gamma  120.0
_symmetry_space_group_name_H-M   'P 63/m m c'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
O1 O 0.3333 0.6667 0.0629
H1 H 0.3333 0.6667 0.1989
H2 H 0.4551 0.9102 0.0182
`;
const MMCIF_PROTEIN = `data_1XYZ
_cell.length_a      40.960
_cell.length_b      18.650
_cell.length_c      22.520
loop_
_atom_site.group_PDB
_atom_site.id
_atom_site.type_symbol
_atom_site.label_atom_id
_atom_site.label_comp_id
_atom_site.label_asym_id
_atom_site.label_seq_id
_atom_site.Cartn_x
_atom_site.Cartn_y
_atom_site.Cartn_z
ATOM 1 N N THR A 1 17.047 14.099 3.625
ATOM 2 C CA THR A 1 16.967 12.784 4.338
ATOM 3 C C THR A 1 15.685 12.755 5.133
ATOM 4 O O THR A 1 15.268 13.825 5.594
`;
const PDB_WITH_CRYST = `CRYST1   40.960   18.650   22.520  90.00  90.77  90.00 P 21          2
ATOM      1  N   THR A   1      17.047  14.099   3.625  1.00 13.79           N
ATOM      2  CA  THR A   1      16.967  12.784   4.338  1.00 10.80           C
ATOM      3  C   THR A   1      15.685  12.755   5.133  1.00  9.19           C
ATOM      4  O   THR A   1      15.268  13.825   5.594  1.00  9.85           O
END
`;
{
  const cases = [
    ['POSCAR', POSCAR, 'a VASP cell', true],
    ['OUTCAR', VASP, 'a VASP cell', true],
    ['box.gro', GRO, 'a GROMACS box', true],
    ['cp2k.out', CP2K, 'a CP2K cell', true],
    ['ice.cif', CIF_CRYSTAL, 'a crystallographic cell', true],
    ['molecular.inp', CP2K_MOLECULAR, null, false],
    ['1xyz.cif', MMCIF_PROTEIN, null, false],
    ['prot.pdb', PDB_WITH_CRYST, null, false],
    ['job.gjf', GAUSSIAN_IN, null, false],
  ];
  for (const [name, text, expect, isPeriodic] of cases) {
    const r = await open(name, text);
    check(`${name} is ${isPeriodic ? 'recognised as periodic' : 'treated as an isolated molecule'}`,
      r.periodic === expect, `periodic = ${JSON.stringify(r.periodic)}`);
  }

  await open('POSCAR', POSCAR);
  check('the status line says so before anything is pressed',
    /VASP cell/.test(await page.textContent('#status3d')) && /not minimisation/.test(await page.textContent('#status3d')),
    await page.textContent('#status3d'));
  await page.evaluate(() => dworm2d.minimizeCurrent());
  await page.waitForTimeout(500);
  const refused = await page.textContent('#status3d');
  check('MINIMIZE refuses a periodic structure and says why',
    /cannot do that/.test(refused) && /periodic boundary conditions/.test(refused) &&
    /relaxed against vacuum/.test(refused), refused.slice(0, 110));
  check('and tells you the honest way to relax it as a cluster instead',
    /save it with SAVE ▸ Coordinates \.xyz/.test(refused));
  check('nothing was touched — the structure is still on screen',
    (await page.evaluate(() => dworm2d.state3d.nAtoms)) === 3 &&
    (await page.evaluate(() => dworm2d.state3d.source)) === 'file');
  await page.evaluate(() => dworm2d.bestConformation());
  await page.waitForTimeout(400);
  check('BEST CONFORMATION refuses it too',
    /periodic boundary conditions/.test(await page.textContent('#status3d')));

  const st = await page.evaluate(() => dworm2d.buildState('full'));
  check('the cell travels in a shared link, so the recipient cannot relax it either',
    st.per === 'a VASP cell', JSON.stringify(st.per));
  await page.evaluate(async (s) => { await dworm2d.applyState(s); }, st);
  await page.waitForTimeout(400);
  check('and it arrives marked periodic', (await page.evaluate(() => dworm2d.state3d.periodic)) === 'a VASP cell');

  // a structure built from the drawing is the user's own molecule, whatever was open before
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.source === 'drawing', null, { timeout: 60000 });
  check('MAKE 3D forgets the cell — a molecule from the drawing is never periodic',
    (await page.evaluate(() => dworm2d.state3d.periodic)) === null);
  await page.evaluate(() => dworm2d.minimizeCurrent());
  await page.waitForFunction(() => /E .*→/.test(document.getElementById('status3d').textContent), null, { timeout: 60000 });
  check('and it minimises normally afterwards', /kcal\/mol/.test(await page.textContent('#status3d')));
}

const smi = await page.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles());
check('the Ketcher drawing was never touched by any of it', /c1|C1/.test(smi), smi);
// an unrecognised file explains itself instead of failing silently
{
  const r = await open('notes.log', 'hello, this is a log file but not a calculation\n');
  check('an unrecognised .log says what is supported', r.cls === 'err' && /not one 2D-WORM recognises/.test(r.msg),
    r.msg.slice(0, 130));
}
// the parser is fetched only when needed
{
  const p2 = await (await browser.newContext()).newPage();
  const asked = [];
  p2.on('request', q => { if (/qcgeom/.test(q.url())) asked.push(q.url()); });
  await p2.goto(`http://127.0.0.1:${PORT}/index.html`);
  await p2.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });
  check('qcgeom.js is NOT fetched on a first visit', asked.length === 0, asked.join(','));
  await p2.evaluate(async (t) => { await dworm2d.openFile(new File([t], 'a.out', { type: 'text/plain' })); }, ORCA);
  await p2.waitForTimeout(600);
  check('it is fetched once a geometry file is opened, with the build stamp',
    asked.length === 1 && /qcgeom\.js\?v=\d/.test(asked[0]), asked.join(','));
  await p2.close();
}

const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
