/* THE THREE SLIDERS — setting a geometry by number rather than by eye.
 *
 * The drag tools put an atom where the mouse is. These put a bond at 1.47 A and a torsion at
 * 60 degrees, which is what building a starting geometry actually needs.
 *
 * What is asserted here is mostly ARITHMETIC, because that is where this can be wrong in a
 * way nobody sees: the value the slider claims must be the value the atoms actually have,
 * the side that is frozen must not move by so much as a thousandth of an angstrom, and
 * dragging out and back must land exactly where it started — which is the property that
 * fails silently if the code applies increments instead of rebuilding from a reference.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8803;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));

await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });

/** n-butane: a four-carbon chain, so one selection gives a bond, an angle and a torsion,
    each with a real branch on both sides. */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCCC'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 120000 });
await page.waitForTimeout(400);
if (!(await page.isVisible('#editBar'))) await page.click('#btnEdit');
await page.waitForSelector('#geoBar', { state: 'visible', timeout: 15000 });

/** the four carbons, in chain order, as the page indexes them */
const chain = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  const C = a.map((x, i) => [x, i]).filter(([x]) => x.elem === 'C').map(([, i]) => i);
  /* walk the carbon skeleton from an end */
  const nb = (i) => (a[i].bonds || []).filter(j => a[j].elem === 'C');
  const end = C.find(i => nb(i).length === 1);
  const out = [end]; let prev = -1, cur = end;
  while (out.length < 4) { const nx = nb(cur).find(j => j !== prev); if (nx === undefined) break; out.push(nx); prev = cur; cur = nx; }
  return out;
});
check('n-butane gives a four-carbon chain to work on', chain.length === 4, chain.join('-'));

const pick = (idx) => page.evaluate((ids) => {
  window.dworm2d.state3d.sel = ids.slice();
  window.dworm2d.saySelection();
  window.dworm2d.applyStyle(window.dworm2d.viewer); window.dworm2d.viewer.render();
}, idx);
const row = (kind) => ({ bond: 'geoBond', angle: 'geoAng', dihedral: 'geoDih' })[kind];
const slide = async (kind, v) => page.evaluate(([k, val]) => {
  const r = document.getElementById(({ bond: 'geoBond', angle: 'geoAng', dihedral: 'geoDih' })[k] + 'R');
  r.value = String(val);
  r.dispatchEvent(new Event('input', { bubbles: true }));
  return { val: r.value, text: document.getElementById(({ bond: 'geoBond', angle: 'geoAng', dihedral: 'geoDih' })[k] + 'V').textContent };
}, [kind, v]);
const release = (kind) => page.evaluate((k) => {
  const r = document.getElementById(({ bond: 'geoBond', angle: 'geoAng', dihedral: 'geoDih' })[k] + 'R');
  r.dispatchEvent(new Event('change', { bubbles: true }));
}, kind);
const xyz = () => page.evaluate(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
const value = (kind, idx) => page.evaluate(([k, ids]) =>
  window.dworm2d.geoValue(k, ids, window.dworm2d.viewer.getModel().selectedAtoms({})), [kind, idx]);
const setMode = (kind, mode) => page.click(`.geomode[data-for="${kind}"] button[data-mode="${mode}"]`);
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

/* ------------------------------------------------------------------ nothing picked */
const idle = await page.evaluate(() => ({
  bond: document.getElementById('geoBondR').disabled,
  ang: document.getElementById('geoAngR').disabled,
  dih: document.getElementById('geoDihR').disabled,
  say: document.getElementById('geoBondV').textContent }));
/* A control that vanishes is one nobody finds twice. All three stay, and each says what it
   is waiting for. */
check('with nothing picked all three sliders are there, disabled, and say what they want',
  idle.bond && idle.ang && idle.dih && /pick 2 atoms/.test(idle.say), idle.say);

/* ------------------------------------------------------------------ BOND */
await pick([chain[1], chain[2]]);
const armed = await page.evaluate(() => ({
  bond: document.getElementById('geoBondR').disabled,
  ang: document.getElementById('geoAngR').disabled,
  say: document.getElementById('geoBondV').textContent }));
check('picking two atoms arms the bond slider and only the bond slider',
  armed.bond === false && armed.ang === true, armed.say);

const L0 = await value('bond', [chain[1], chain[2]]);
await setMode('bond', 'a');
await slide('bond', 50);
const L50 = await value('bond', [chain[1], chain[2]]);
/* The number on the slider is a percentage of what the bond was when it was picked, so +50
   is one and a half times. Asserted against the atoms, not against the readout — a readout
   that agrees with itself proves nothing. */
check('the bond slider is a percentage of the length it had when it was picked',
  Math.abs(L50 - L0 * 1.5) < 1e-6, `${L0.toFixed(3)} A → ${L50.toFixed(3)} A at +50%`);
const after50 = await xyz();
const before = await page.evaluate(() => window.dworm2d.geoRef.xyz0);
/* FREEZE A means the first atom's whole side does not move. Not "moves less" — does not
   move, to the last decimal, or the thing you were holding still has drifted. */
const frozenMoved = await page.evaluate(([a, b]) => {
  const D = window.dworm2d, nb = D.viewer.getModel().selectedAtoms({}).map(x => (x.bonds || []).slice());
  const sides = D.geoSides(a, b, nb);
  const now = D.viewer.getModel().selectedAtoms({});
  let worst = 0;
  for (const i of sides.A) {
    const r = D.geoRef.xyz0[i];
    worst = Math.max(worst, Math.hypot(now[i].x - r[0], now[i].y - r[1], now[i].z - r[2]));
  }
  return { worst, nA: sides.A.size, nB: sides.B.size, whole: sides.whole };
}, [chain[1], chain[2]]);
check('FREEZE A holds the first atom’s whole side exactly still, not approximately',
  frozenMoved.worst < 1e-9 && frozenMoved.nA > 1 && frozenMoved.whole,
  `${frozenMoved.nA} atoms held, worst drift ${frozenMoved.worst.toExponential(1)} A`);

await setMode('bond', 'uniform');
const uni = await page.evaluate(([a, b]) => {
  const D = window.dworm2d, now = D.viewer.getModel().selectedAtoms({});
  const mid0 = D.geoRef.xyz0[a].map((v, k) => (v + D.geoRef.xyz0[b][k]) / 2);
  const midNow = [(now[a].x + now[b].x) / 2, (now[a].y + now[b].y) / 2, (now[a].z + now[b].z) / 2];
  return Math.hypot(midNow[0] - mid0[0], midNow[1] - mid0[1], midNow[2] - mid0[2]);
}, [chain[1], chain[2]]);
check('UNIFORM moves both halves apart about the midpoint, which stays where it was',
  uni < 1e-9, 'midpoint moved ' + uni.toExponential(1) + ' A');

/* BACK TO ZERO, EXACTLY. This is the property that fails silently when a slider applies
   increments instead of rebuilding from a reference: a hundred small moves out and back do
   not compose to the identity, so the molecule ends subtly displaced with the slider
   reading zero and nothing on screen to say so. */
for (const v of [10, -40, 120, -200, 7, 0]) await slide('bond', v);
const backHome = await xyz();
const worstHome = Math.max(...backHome.map((p, i) => dist(p, before[i])));
check('dragging out and back lands exactly where it started, not nearly',
  worstHome < 1e-9, 'worst atom off by ' + worstHome.toExponential(1) + ' A');

/* Past -100% the atom goes through and out the other side, which is a real thing to want
   when you are building — and is why the slider goes to -300 rather than stopping at -100. */
await slide('bond', -200);
const through = await page.evaluate(([a, b]) => {
  const D = window.dworm2d, now = D.viewer.getModel().selectedAtoms({});
  const u0 = D.geoRef.xyz0[b].map((v, k) => v - D.geoRef.xyz0[a][k]);
  const u1 = [now[b].x - now[a].x, now[b].y - now[a].y, now[b].z - now[a].z];
  return u0[0] * u1[0] + u0[1] * u1[1] + u0[2] * u1[2];
}, [chain[1], chain[2]]);
check('below −100% the bond turns through itself rather than stopping dead',
  through < 0, 'direction reversed');
await slide('bond', 0);
await release('bond');

/* ------------------------------------------------------------------ ANGLE */
await pick([chain[0], chain[1], chain[2]]);
const A0 = await value('angle', [chain[0], chain[1], chain[2]]);
await setMode('angle', 'a');
await slide('angle', -20);
const A1 = await value('angle', [chain[0], chain[1], chain[2]]);
check('the angle slider is a change in degrees from the angle it had when it was picked',
  Math.abs((A1 - A0) - -20) < 1e-4, `${A0.toFixed(1)}° → ${A1.toFixed(1)}° for −20°`);
const armHeld = await page.evaluate(([i, j]) => {
  const D = window.dworm2d, nb = D.viewer.getModel().selectedAtoms({}).map(x => (x.bonds || []).slice());
  const sides = D.geoSides(i, j, nb), now = D.viewer.getModel().selectedAtoms({});
  let worst = 0;
  for (const k of sides.A) { const r = D.geoRef.xyz0[k]; worst = Math.max(worst, Math.hypot(now[k].x - r[0], now[k].y - r[1], now[k].z - r[2])); }
  return { worst, n: sides.A.size };
}, [chain[0], chain[1]]);
check('and FREEZE A holds the first arm still while the other one swings',
  armHeld.worst < 1e-9, `${armHeld.n} atoms held, worst ${armHeld.worst.toExponential(1)} A`);
/* The bond lengths at the vertex must not change: an angle is an angle, and a slider that
   quietly stretched the bonds would be a different tool. */
const lensKept = await page.evaluate(([i, j, k]) => {
  const D = window.dworm2d, now = D.viewer.getModel().selectedAtoms({}), r = D.geoRef.xyz0;
  const d = (a, b) => Math.hypot(now[a].x - now[b].x, now[a].y - now[b].y, now[a].z - now[b].z);
  const d0 = (a, b) => Math.hypot(r[a][0] - r[b][0], r[a][1] - r[b][1], r[a][2] - r[b][2]);
  return Math.max(Math.abs(d(i, j) - d0(i, j)), Math.abs(d(k, j) - d0(k, j)));
}, [chain[0], chain[1], chain[2]]);
check('the two bonds at the vertex keep their length — only the angle changes',
  lensKept < 1e-9, 'largest change ' + lensKept.toExponential(1) + ' A');
await slide('angle', 0);
await release('angle');

/* ------------------------------------------------------------------ DIHEDRAL */
await pick(chain);
const D0 = await value('dihedral', chain);
await setMode('dihedral', 'a');
await slide('dihedral', 60);
const D1 = await value('dihedral', chain);
const wrap = (d) => { let x = d; while (x > 180) x -= 360; while (x < -180) x += 360; return x; };
check('the dihedral slider turns the torsion by the degrees asked for',
  Math.abs(wrap(D1 - D0 - 60)) < 1e-4, `${D0.toFixed(1)}° → ${D1.toFixed(1)}° for +60°`);
/* Every bond length and every angle is unchanged by a torsion: that is what makes it a
   torsion rather than a general distortion. */
const rigid = await page.evaluate(() => {
  const D = window.dworm2d, now = D.viewer.getModel().selectedAtoms({}), r = D.geoRef.xyz0;
  let worst = 0;
  now.forEach((a, i) => (a.bonds || []).forEach(j => {
    if (j <= i) return;
    const d = Math.hypot(a.x - now[j].x, a.y - now[j].y, a.z - now[j].z);
    const d0 = Math.hypot(r[i][0] - r[j][0], r[i][1] - r[j][1], r[i][2] - r[j][2]);
    worst = Math.max(worst, Math.abs(d - d0));
  }));
  return worst;
});
check('and it changes no bond length anywhere in the molecule, which is what a torsion is',
  rigid < 1e-9, 'largest bond change ' + rigid.toExponential(1) + ' A');
await setMode('dihedral', 'uniform');
const split = await value('dihedral', chain);
check('UNIFORM turns both ends, so the torsion still lands on the same number',
  Math.abs(wrap(split - D0 - 60)) < 1e-4, `${split.toFixed(1)}°`);
await slide('dihedral', 0);
await release('dihedral');

/* =============================== THE ARROW KEYS — the same three changes, one press at a time

   Two picked atoms is the case the sliders do NOT cover, and it is the one that was asked
   for: LEFT and RIGHT turn one side about the bond. That is a dihedral whose axis is named
   by two atoms instead of four, so it is the same arithmetic and the same reference — and
   the same undo. */
await pick([chain[1], chain[2]]);
const key = async (k, shift = false) => {
  await page.evaluate(([kk, sh]) => {
    document.dispatchEvent(new KeyboardEvent('keydown', { key: kk, shiftKey: sh, bubbles: true, cancelable: true }));
  }, [k, shift]);
  await page.waitForTimeout(120);
};
const tors = () => page.evaluate((ids) =>
  window.dworm2d.geoValue('dihedral', ids, window.dworm2d.viewer.getModel().selectedAtoms({})), chain);
const t0 = await tors();
await key('ArrowRight');
const t1 = await tors();
const wrapD = (d) => { let x = d; while (x > 180) x -= 360; while (x < -180) x += 360; return x; };
check('RIGHT turns one side about the picked bond, five degrees a press',
  Math.abs(Math.abs(wrapD(t1 - t0)) - 5) < 1e-3, `${t0.toFixed(2)}° → ${t1.toFixed(2)}°`);
await key('ArrowRight', true);
const t2 = await tors();
check('and SHIFT makes it one degree, for the last bit',
  Math.abs(Math.abs(wrapD(t2 - t1)) - 1) < 1e-3, `${t1.toFixed(2)}° → ${t2.toFixed(2)}°`);
/* Turning about a bond must not change its length, or it is not a twist. */
const lenKept = await page.evaluate(([a, b]) => {
  const n = window.dworm2d.viewer.getModel().selectedAtoms({}), r = window.dworm2d.geoRef.xyz0;
  const d = Math.hypot(n[a].x - n[b].x, n[a].y - n[b].y, n[a].z - n[b].z);
  const d0 = Math.hypot(r[a][0] - r[b][0], r[a][1] - r[b][1], r[a][2] - r[b][2]);
  return Math.abs(d - d0);
}, [chain[1], chain[2]]);
check('and the bond it turns about keeps its length', lenKept < 1e-9, lenKept.toExponential(1) + ' A');
const twistSaid = await page.evaluate(() => document.getElementById('geoBondV').textContent);
check('the readout says how far it has been turned', /twist/.test(twistSaid), twistSaid);
await key('ArrowLeft'); await key('ArrowLeft', true);
const t3 = await tors();
check('LEFT turns it back, and the presses either way cancel',
  Math.abs(wrapD(t3 - t0)) < 1e-6, wrapD(t3 - t0).toExponential(1) + '°');

/* UP and DOWN stretch it — as a percentage of the reference, so one press is the same
   visible step on a C–H and on a metal–metal contact. */
const lenNow = () => value('bond', [chain[1], chain[2]]);
const l0 = await lenNow();
await key('ArrowUp');
const l1 = await lenNow();
check('UP stretches the bond and DOWN shortens it', l1 > l0 + 1e-6, `${l0.toFixed(3)} → ${l1.toFixed(3)} A`);
await key('ArrowDown');
check('and they cancel exactly', Math.abs((await lenNow()) - l0) < 1e-9);

/* With three or four picked the keys drive the slider itself, so there is one value and not
   two — a key that moved the atoms without moving the slider would leave `0` meaning
   something other than "untouched". */
await pick(chain);
const dd0 = await tors();
await key('ArrowRight');
const dd1 = await tors();
check('with four picked the keys turn the torsion, five degrees a press',
  Math.abs(Math.abs(wrapD(dd1 - dd0)) - 5) < 1e-3, `${dd0.toFixed(2)}° → ${dd1.toFixed(2)}°`);
/* Every press commits and takes a fresh reference, so the slider always reads zero — it
   means "as it is now", which is the only reading that stays true after a key press. */
check('and the slider comes back to zero after each press, because zero means "as it is now"',
  await page.evaluate(() => parseFloat(document.getElementById('geoDihR').value)) === 0);
check('while the readout keeps the running total from where you picked',
  /from where you picked/.test(await page.evaluate(() => document.getElementById('geoDihV').textContent)),
  await page.evaluate(() => document.getElementById('geoDihV').textContent));
await key('ArrowLeft');
check('and turning back cancels it', Math.abs(wrapD((await tors()) - dd0)) < 1e-6);

/* A key press inside a text box is typing, not geometry. */
const typing = await page.evaluate(async () => {
  const D = window.dworm2d;
  D.state3d.sel = [0, 1]; D.saySelection();
  await new Promise(r => setTimeout(r, 200));
  const before = D.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]);
  const box = document.createElement('input');
  document.body.appendChild(box); box.focus();
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true }));
  await new Promise(r => setTimeout(r, 200));
  const after = D.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]);
  box.remove();
  return Math.max(...after.map((p, i) => Math.hypot(p[0] - before[i][0], p[1] - before[i][1], p[2] - before[i][2])));
});
check('an arrow key pressed in a text box is typing, and moves no atoms', typing < 1e-12);

/* ------------------------------------------------------------------ a ring has no sides */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('C1CCCCC1'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms >= 18, null, { timeout: 120000 });
await page.waitForTimeout(400);
const ring = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  const C = a.map((x, i) => [x, i]).filter(([x]) => x.elem === 'C').map(([, i]) => i);
  return [C[0], (a[C[0]].bonds || []).find(j => a[j].elem === 'C')];
});
await pick(ring);
await slide('bond', 30);
const ringSay = await page.evaluate(() => document.getElementById('geoBondV').textContent);
const ringMoved = await page.evaluate(() => {
  const D = window.dworm2d, now = D.viewer.getModel().selectedAtoms({}), r = D.geoRef.xyz0;
  let n = 0;
  now.forEach((a, i) => { if (Math.hypot(a.x - r[i][0], a.y - r[i][1], a.z - r[i][2]) > 1e-6) n++; });
  return n;
});
/* Two atoms in the same ring cannot be pulled apart by branches: every branch comes back
   round. The honest answer is to move the two ends and say so, rather than to tear the ring
   or to do nothing without explaining. */
check('two atoms in a ring move as ends only, and the readout says so',
  /ends only/.test(ringSay) && ringMoved <= 2 && ringMoved >= 1, ringSay);
await slide('bond', 0);
await release('bond');

/* ------------------------------------------------------------------ undo */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCCC'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 120000 });
await page.waitForTimeout(400);
const chain2 = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  const C = a.map((x, i) => [x, i]).filter(([x]) => x.elem === 'C').map(([, i]) => i);
  const nb = (i) => (a[i].bonds || []).filter(j => a[j].elem === 'C');
  const end = C.find(i => nb(i).length === 1);
  const out = [end]; let prev = -1, cur = end;
  while (out.length < 4) { const nx = nb(cur).find(j => j !== prev); if (nx === undefined) break; out.push(nx); prev = cur; cur = nx; }
  return out;
});
await pick([chain2[1], chain2[2]]);
const pre = await xyz();
await slide('bond', 80);
await release('bond');
const moved = await xyz();
check('letting go writes the change down, so it can be exported and shared',
  Math.max(...moved.map((p, i) => dist(p, pre[i]))) > 0.1 &&
  await page.evaluate(() => window.dworm2d.state3d.source) === 'edited');
await page.click('#btnUndo');
await page.waitForTimeout(400);
const undone = await xyz();
/* ONE undo for the whole drag, not one per pixel: the stack is pushed when the drag starts
   and not again until it ends. */
check('and UNDO puts it back in one press, not in a hundred',
  Math.max(...undone.map((p, i) => dist(p, pre[i]))) < 1e-9,
  'worst ' + Math.max(...undone.map((p, i) => dist(p, pre[i]))).toExponential(1) + ' A');

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
