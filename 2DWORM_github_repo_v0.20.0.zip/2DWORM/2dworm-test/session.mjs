/* The .2dworm.zip session file — build it, read it back, and refuse the bad ones.
   The checks that matter most are the ones about being LIED TO by the container: a member
   that is not the size the manifest says, an original file whose hash no longer matches, a
   member name that would climb out of a folder, a zip that is not ours at all. The happy path
   is one test; the refusals are most of the file, because a session file is something people
   will mail each other and open years later. */
import { buildSession, readSession, isSessionFile, sha256Hex, sha256HexJs,
         SESSION_EXT, SESSION_FORMAT, SESSION_VERSION, SURFACE_LAYOUT } from '../2dworm/lib/session.js';
import { zipSync, unzipSync } from '../2dworm/lib/fflate/fflate-0.8.3.esm.js';
import { readFileSync } from 'node:fs';
import { createHash, randomBytes } from 'node:crypto';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const enc = new TextEncoder(), dec = new TextDecoder();
const nodeSha = (u8) => createHash('sha256').update(u8).digest('hex');
const sameArray = (a, b) => !!a && !!b && a.length === b.length && a.every((v, i) => v === b[i]);
const sameJson = (a, b) => JSON.stringify(a) === JSON.stringify(b);
async function throwsWith(fn, re) {
  try { await fn(); return { threw: false, msg: '(no error)' }; }
  catch (e) { return { threw: true, ok: re.test(String(e && e.message)), msg: String(e && e.message) }; }
}

/* A central-directory walker for the tests only: the module must not be trusted to describe
   its own compression choices, so the test reads the method bytes straight out of the zip. */
function centralDirectory(zip) {
  const b2 = (i) => zip[i] | (zip[i + 1] << 8);
  const b4 = (i) => (zip[i] | (zip[i + 1] << 8) | (zip[i + 2] << 16)) + zip[i + 3] * 0x1000000;
  let e = zip.length - 22;
  while (e >= 0 && b4(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error('no end-of-central-directory record');
  const count = b2(e + 10);
  let o = b4(e + 16);
  const out = [];
  for (let i = 0; i < count; i++) {
    if (b4(o) !== 0x02014b50) throw new Error('bad central directory entry');
    const flags = b2(o + 8), method = b2(o + 10), crc = b4(o + 16), csize = b4(o + 20), usize = b4(o + 24);
    const nlen = b2(o + 28), xlen = b2(o + 30), clen = b2(o + 32);
    out.push({ name: dec.decode(zip.subarray(o + 46, o + 46 + nlen)), flags, method, crc, csize, usize });
    o += 46 + nlen + xlen + clen;
  }
  return out;
}

/* ------------------------------------------------------------------ fixtures */
const APP = { name: '2D-WORM', version: '0.16.0', build: 24 };
const STATE = {
  v: 2, o: { theme: 'dark', rep: 'stick', halo: true, iso: 0.02 }, t: 'light',
  view: [1.5, -2.25, 0, 0.7071, 0, 0, 0.7071, 0],
  labels: ['Fe–N 2.01 Å', 'naïve résumé ☕ 日本語 — 🧪'],
  marks: [{ name: 'ligand', colour: '#ff00ff', atoms: [1, 2, 3] }, { name: 'active site', colour: '#ffd700', atoms: [40, 41] }],
  sel: { name: 'haem', expr: 'Fe(<2.4A)', atoms: [12, 13, 14, 15, 16] },
  nested: { deep: { deeper: [null, true, 3.14159, 'x'] } },
};
/* The drawing member is Ketcher's own JSON; this is the shape Ketcher writes for water. */
const KET = JSON.stringify({ root: { nodes: [{ $ref: 'mol0' }] },
  mol0: { type: 'molecule', atoms: [{ label: 'O', location: [0, 0, 0] }, { label: 'H', location: [0.96, 0, 0] }, { label: 'H', location: [-0.24, 0.93, 0] }],
          bonds: [{ type: 1, atoms: [0, 1] }, { type: 1, atoms: [0, 2] }] } });
const PDB = readFileSync(new URL('./corpus/DNA.pdb', import.meta.url), 'utf8');
/* The real 7 MB ORCA cube is not in the repository (the cubes stay with the research group);
   without it a synthetic cube of the same order of magnitude stands in, so the size checks
   below still mean something. */
const CUBE = (() => {
  try { return readFileSync(new URL('./corpus/FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube', import.meta.url), 'utf8'); }
  catch (e) {
    console.log('SKIP the real ORCA cube is absent — a synthetic 7 MB cube stands in');
    const L = [' synthetic cube', ' stand-in', '    1    0.000000    0.000000    0.000000', '   90    0.100000    0.000000    0.000000',
      '   90    0.000000    0.100000    0.000000', '   90    0.000000    0.000000    0.100000', '    8    8.000000    0.000000    0.000000    0.000000'];
    let n = 0; const rows = [];
    for (let i = 0; i < 90 * 90 * 90; i++) { rows.push((Math.sin(i * 0.001) * 1e-3).toExponential(5)); if (++n === 6) { L.push('  ' + rows.join('  ')); rows.length = 0; n = 0; } }
    if (rows.length) L.push('  ' + rows.join('  '));
    return L.join('\n') + '\n';
  }
})();
const ORIGINAL = new Uint8Array(randomBytes(200 * 1024));
/* The PNG signature, an IHDR and an IEND — enough to be a PNG to any sniffer, and nothing
   the module should be inspecting beyond the first eight bytes. */
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0, 0x1f, 0x15, 0xc4, 0x89,
  0, 0, 0, 0, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82]);

/* A small closed-ish mesh: a fan of triangles around a ring, with normals that are not what
   any recomputation from the triangles would give (that is the whole reason they are stored). */
function makeSurface(nRing, withColours) {
  const nVerts = nRing + 1, nTris = nRing;
  const positions = new Float32Array(nVerts * 3), normals = new Float32Array(nVerts * 3);
  const indices = new Uint32Array(nTris * 3);
  for (let i = 0; i < nRing; i++) {
    const a = 2 * Math.PI * i / nRing;
    positions.set([Math.cos(a) * 2.5, Math.sin(a) * 2.5, 0.1 * i], 3 * (i + 1));
    normals.set([Math.cos(a) * 0.6, Math.sin(a) * 0.6, 0.8], 3 * (i + 1));
    indices.set([0, i + 1, ((i + 1) % nRing) + 1], 3 * i);
  }
  normals.set([0, 0, 1], 0);
  const colours = withColours ? Uint8Array.from({ length: nVerts * 3 }, (_, k) => (k * 37) & 255) : undefined;
  return { positions, normals, indices, colours };
}
const SURF_A = { name: 'ESP on density', iso: 0.002, colour: null, ...makeSurface(64, true), meta: { range: [-0.05, 0.05], source: 'Jumanah-ESP-dens.cube', opacity: 0.85 } };
const SURF_B = { name: 'HOMO −', iso: -0.02, colour: '#d04020', ...makeSurface(40, false) };

const FULL = {
  app: APP, state: STATE, drawingKet: KET,
  structure: { text: PDB, format: 'pdb' },
  original: { name: 'DNA (Dante).pdb', bytes: ORIGINAL, format: 'pdb' },
  surfaces: [SURF_A, SURF_B],
  volumes: [{ name: 'FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube', text: CUBE }],
  notes: '# Notes\n\nThe **haem** iron, five-coordinate. Résumé: 日本語 ☕\n',
  thumbPng: PNG,
  references: [{ url: 'https://zenodo.org/records/1234567/files/Jumanah-HOMO.cub', kind: 'volume', bytes: 31882910, sha256: 'a'.repeat(64), name: 'Jumanah-HOMO.cub' }],
  created: '2026-09-12T10:00:00.000Z',
};

/* ------------------------------------------------------------------ constants */
check('SESSION_EXT is .2dworm.zip, format and version are what the manifest says', SESSION_EXT === '.2dworm.zip' && SESSION_FORMAT === '2dworm-session' && SESSION_VERSION === 1);
check('the surface layout string is the documented one', SURFACE_LAYOUT === 'pos:f32x3,norm:f32x3,idx:u32x3,col:u8x3');

/* ------------------------------------------------------------------ sha256 */
{
  const cases = [new Uint8Array(0), enc.encode('abc'), new Uint8Array(55).fill(0x61), new Uint8Array(56).fill(0x62), new Uint8Array(63).fill(0x63),
                 new Uint8Array(64).fill(0x64), new Uint8Array(65).fill(0x65), ORIGINAL, enc.encode(CUBE.slice(0, 1000000))];
  let okWeb = true, okJs = true;
  for (const c of cases) {
    const want = nodeSha(c);
    if (await sha256Hex(c) !== want) okWeb = false;
    if (sha256HexJs(c) !== want) okJs = false;
  }
  check('sha256Hex agrees with node:crypto on the block-boundary cases and 200 kB of noise', okWeb);
  check('the pure-JS sha256 fallback (for pages served without a secure context) agrees too', okJs);
  check('sha256Hex takes an ArrayBuffer and a subarray with a byteOffset', await sha256Hex(ORIGINAL.buffer) === nodeSha(ORIGINAL) &&
    await sha256Hex(ORIGINAL.subarray(1000, 2000)) === nodeSha(ORIGINAL.subarray(1000, 2000)));
}

/* ------------------------------------------------------------------ the full round trip */
let ZIP = null;
{
  ZIP = await buildSession(FULL);
  check('buildSession returns a Uint8Array that starts with the zip signature', ZIP instanceof Uint8Array && ZIP[0] === 0x50 && ZIP[1] === 0x4b && ZIP[2] === 3 && ZIP[3] === 4, `${ZIP.length} bytes`);
  const r = await readSession(ZIP);
  check('manifest: format, version 1, app, created as given, references kept', r.manifest.format === '2dworm-session' && r.manifest.version === 1 &&
    sameJson(r.manifest.app, APP) && r.manifest.created === FULL.created && r.app.build === 24 && r.created === FULL.created, JSON.stringify(r.manifest.app));
  check('state comes back equal, nested objects and unicode intact', sameJson(r.state, STATE) && r.state.labels[1] === STATE.labels[1]);
  check('the state is a fresh object, not the one handed in', r.state !== STATE);
  check('drawing.ket comes back byte for byte', r.drawingKet === KET);
  check('structure comes back with its text and format', r.structure && r.structure.text === PDB && r.structure.format === 'pdb');
  check('original: basename kept, bytes equal element-wise, sha256 in the manifest equals node\'s',
    r.original && r.original.name === 'DNA (Dante).pdb' && sameArray(r.original.bytes, ORIGINAL) && r.original.sha256 === nodeSha(ORIGINAL) && r.original.format === 'pdb',
    r.original ? r.original.name + ' ' + r.original.sha256.slice(0, 12) : 'no original');
  check('two surfaces, in order, with names, iso and colour', r.surfaces.length === 2 && r.surfaces[0].name === 'ESP on density' && r.surfaces[1].name === 'HOMO −' &&
    r.surfaces[0].iso === 0.002 && r.surfaces[1].iso === -0.02 && r.surfaces[0].colour === null && r.surfaces[1].colour === '#d04020');
  const sa = r.surfaces[0], sb = r.surfaces[1];
  check('surface A: positions, normals, indices, colours equal element-wise as typed arrays',
    sa.positions instanceof Float32Array && sa.normals instanceof Float32Array && sa.indices instanceof Uint32Array && sa.colours instanceof Uint8Array &&
    sameArray(sa.positions, SURF_A.positions) && sameArray(sa.normals, SURF_A.normals) && sameArray(sa.indices, SURF_A.indices) && sameArray(sa.colours, SURF_A.colours));
  check('surface B: no colours → colours is null, everything else equal', sb.colours === null && sameArray(sb.positions, SURF_B.positions) && sameArray(sb.normals, SURF_B.normals) && sameArray(sb.indices, SURF_B.indices));
  check('surface counts and the meta passthrough (colour range, source cube, opacity)', sa.nVerts === 65 && sa.nTris === 64 && sb.nVerts === 41 && sb.nTris === 40 &&
    sameJson(sa.meta, SURF_A.meta) && sameJson(sb.meta, {}));
  check('each surface array owns its buffer (safe to transfer to a worker one at a time)', sa.positions.buffer !== sa.normals.buffer && sa.positions.byteOffset === 0);
  const me = r.manifest.members.find(m => m.path === 'surfaces/1.bin');
  check('the surface manifest entry documents the binary layout', me && me.kind === 'surface' && me.nVerts === 65 && me.nTris === 64 && me.hasNormals === true && me.hasColours === true &&
    me.layout === SURFACE_LAYOUT && me.bytes === 65 * 12 * 2 + 64 * 12 + 65 * 3, JSON.stringify(me));
  check('the volume comes back verbatim (7 MB real ORCA cube) with its sha256', r.volumes.length === 1 && r.volumes[0].text === CUBE &&
    r.volumes[0].name === 'FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube' && r.volumes[0].sha256 === nodeSha(enc.encode(CUBE)));
  check('notes and the thumbnail come back', r.notes === FULL.notes && sameArray(r.thumbPng, PNG));
  check('references come back with url, kind, bytes, sha256, name', sameJson(r.references, FULL.references));
  check('no warnings on a file we wrote ourselves', Array.isArray(r.warnings) && r.warnings.length === 0, r.warnings.join(' | '));
  const paths = r.manifest.members.map(m => m.path);
  check('member paths are the documented ones', sameJson(paths, ['state.json', 'drawing.ket', 'structure.pdb', 'notes.md', 'thumb.png', 'original/DNA (Dante).pdb',
    'surfaces/1.bin', 'surfaces/2.bin', 'volumes/FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube']), paths.join(', '));
  check('every manifest entry states the member size and every entry carries a sha256', r.manifest.members.every(m => Number.isInteger(m.bytes) && /^[0-9a-f]{64}$/.test(m.sha256)));
  check('the whole file is smaller than the cube alone (text members are deflated)', ZIP.length < CUBE.length, `${ZIP.length} vs ${CUBE.length}`);

  /* the compression choice, read from the zip itself */
  const cd = centralDirectory(ZIP);
  const method = (n) => (cd.find(e => e.name === n) || {}).method;
  check('the central directory lists every member, manifest.json first', cd.length === 10 && cd[0].name === 'manifest.json', cd.map(e => e.name).join(','));
  check('surfaces/*.bin and thumb.png are STORED (method 0), byte for byte', method('surfaces/1.bin') === 0 && method('surfaces/2.bin') === 0 && method('thumb.png') === 0 &&
    cd.every(e => e.method !== 0 || e.csize === e.usize));
  check('text members are DEFLATED (method 8): manifest, state, drawing, structure, original, volume, notes',
    ['manifest.json', 'state.json', 'drawing.ket', 'structure.pdb', 'original/DNA (Dante).pdb', 'volumes/FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube', 'notes.md'].every(n => method(n) === 8));
  /* Measured, not assumed: this ORCA cube deflates 2.93× at level 6 (the mantissas are five
     digits of noise; only the exponents and the layout repeat). A ratio below 2.5 would mean
     the member was not really deflated. */
  check('the volume member deflates by the measured ~2.9× for a real cube', (() => { const e = cd.find(x => x.name.startsWith('volumes/')); return e && e.usize / e.csize > 2.5; })(),
    (() => { const e = cd.find(x => x.name.startsWith('volumes/')); return e ? (e.usize / e.csize).toFixed(2) + 'x' : ''; })());
  check('the same input with the same created time gives the same bytes (reproducible for Zenodo)', sameArray(await buildSession(FULL), ZIP));
  check('readSession accepts an ArrayBuffer and a Buffer', (await readSession(ZIP.buffer.slice(ZIP.byteOffset, ZIP.byteOffset + ZIP.byteLength))).drawingKet === KET &&
    (await readSession(Buffer.from(ZIP))).drawingKet === KET);
}

/* ------------------------------------------------------------------ the smallest session */
{
  const z = await buildSession({ app: APP, state: { v: 2, o: {} } });
  const r = await readSession(z);
  check('a state-only session is a zip with a manifest and state.json only, and reads back', z.length < 1024 && sameJson(r.manifest.members.map(m => m.path), ['state.json']) &&
    r.drawingKet === null && r.structure === null && r.original === null && r.surfaces.length === 0 && r.volumes.length === 0 && r.notes === null && r.thumbPng === null && r.references.length === 0,
    `${z.length} bytes`);
  check('isSessionFile is true for it', isSessionFile(z));
}

/* ------------------------------------------------------------------ builder refusals */
{
  const base = { app: APP, state: STATE };
  const noNormals = await throwsWith(() => buildSession({ ...base, surfaces: [{ name: 'x', iso: 0.02, colour: '#fff', positions: SURF_B.positions, normals: null, indices: SURF_B.indices }] }), /normals/i);
  check('a surface without normals is refused with a sentence about why', noNormals.ok, noNormals.msg);
  const shortNormals = await throwsWith(() => buildSession({ ...base, surfaces: [{ ...SURF_B, normals: SURF_B.normals.subarray(0, 30) }] }), /normals/i);
  check('normals of the wrong length are refused', shortNormals.ok, shortNormals.msg);
  const badIdx = await throwsWith(() => buildSession({ ...base, surfaces: [{ ...SURF_B, indices: Uint32Array.from([0, 1, 41]) }] }), /index|indices/i);
  check('an index past the last vertex is refused, naming the surface', badIdx.ok && /HOMO/.test(badIdx.msg), badIdx.msg);
  const badPos = await throwsWith(() => buildSession({ ...base, surfaces: [{ ...SURF_B, positions: new Float32Array(10), normals: new Float32Array(10) }] }), /positions/i);
  check('positions not a multiple of three are refused', badPos.ok, badPos.msg);
  const badCol = await throwsWith(() => buildSession({ ...base, surfaces: [{ ...SURF_B, colours: new Uint8Array(7) }] }), /colours/i);
  check('colours of the wrong length are refused', badCol.ok, badCol.msg);
  const u16 = await buildSession({ ...base, surfaces: [{ ...SURF_B, indices: Uint16Array.from(SURF_B.indices), colors: Uint8Array.from({ length: 41 * 3 }, (_, k) => k & 255) }] });
  const ru16 = await readSession(u16);
  check('Uint16 indices (3Dmol\'s faceArray) are widened to Uint32 and the "colors" spelling is accepted',
    ru16.surfaces[0].indices instanceof Uint32Array && sameArray(ru16.surfaces[0].indices, SURF_B.indices) && ru16.surfaces[0].colours && ru16.surfaces[0].colours.length === 41 * 3);
  const noState = await throwsWith(() => buildSession({ app: APP }), /state/i);
  check('no state → refused', noState.ok, noState.msg);
  const noApp = await throwsWith(() => buildSession({ state: STATE }), /app/i);
  check('no app → refused', noApp.ok, noApp.msg);
  const circular = {}; circular.self = circular;
  const circ = await throwsWith(() => buildSession({ ...base, state: circular }), /state/i);
  check('a state that cannot be JSON → refused with a message about the state', circ.ok, circ.msg);
  const badFmt = await throwsWith(() => buildSession({ ...base, structure: { text: 'x', format: '../pdb' } }), /format/i);
  check('a structure format that is not a plain extension is refused', badFmt.ok, badFmt.msg);
  const badPng = await throwsWith(() => buildSession({ ...base, thumbPng: new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8, 9]) }), /PNG/);
  check('a thumbnail that is not a PNG is refused', badPng.ok, badPng.msg);
  const badRef = await throwsWith(() => buildSession({ ...base, references: [{ url: 'javascript:alert(1)', kind: 'volume' }] }), /reference|url/i);
  check('a reference whose url is not http(s) or a DOI is refused', badRef.ok, badRef.msg);
  const badSha = await throwsWith(() => buildSession({ ...base, references: [{ url: 'https://zenodo.org/x', kind: 'volume', sha256: 'nope' }] }), /sha256/i);
  check('a reference with a malformed sha256 is refused', badSha.ok, badSha.msg);
  const badCreated = await throwsWith(() => buildSession({ ...base, created: 'yesterday' }), /created/i);
  check('a created value that is not a date is refused', badCreated.ok, badCreated.msg);
  const doi = await readSession(await buildSession({ ...base, references: [{ url: 'doi:10.5281/zenodo.1234567', kind: 'session' }] }));
  check('a DOI reference is accepted and bytes/sha256 stay optional', doi.references.length === 1 && doi.references[0].url === 'doi:10.5281/zenodo.1234567');
}

/* ------------------------------------------------------------------ names */
{
  const z = await buildSession({ app: APP, state: STATE, original: { name: 'C:\\Users\\dante\\Desktop\\ätzend µ.cube', bytes: enc.encode('cube text') },
    volumes: [{ name: '/tmp/a.cube', text: 'A' }, { name: 'a.cube', text: 'B' }, { name: 'orbital 12', text: 'C' }] });
  const r = await readSession(z);
  check('the original keeps its basename only (no user path leaks into a shared file), unicode intact', r.original.name === 'ätzend µ.cube' &&
    r.manifest.members.some(m => m.path === 'original/ätzend µ.cube'), r.original.name);
  check('volume names are basenames, deduplicated, and end in .cube', sameJson(r.volumes.map(v => v.name), ['a.cube', 'a-2.cube', 'orbital 12.cube']) &&
    sameJson(r.volumes.map(v => v.text), ['A', 'B', 'C']), r.volumes.map(v => v.name).join(', '));
  const cd = centralDirectory(z);
  check('a non-ASCII member name is flagged UTF-8 in the zip (bit 11)', (cd.find(e => e.name === 'original/ätzend µ.cube') || {}).flags & 0x800);
  const dots = await readSession(await buildSession({ app: APP, state: STATE, original: { name: '..', bytes: enc.encode('x') } }));
  check('a name that is only dots falls back to a safe one', dots.original.name === 'original.bin', dots.original.name);
}

/* ------------------------------------------------------------------ tolerance: the future and other people's zips */
const rezip = (mutate) => {
  const files = unzipSync(ZIP);
  const manifest = JSON.parse(dec.decode(files['manifest.json']));
  const out = mutate(files, manifest) || files;
  if (!out.__keepManifest) out['manifest.json'] = enc.encode(JSON.stringify(manifest, null, 2));
  delete out.__keepManifest;
  return zipSync(out);
};
{
  const z = rezip((files, m) => { m.version = 2; m.hologram = { enabled: true }; m.members.forEach(e => { e.future = 'field'; });
    m.members.push({ path: 'extra/thing.dat', kind: 'hologram', bytes: 3 }); files['extra/thing.dat'] = new Uint8Array([1, 2, 3]); });
  const r = await readSession(z);
  check('a version-2 manifest with unknown fields and an unknown member kind still opens', sameJson(r.state, STATE) && r.surfaces.length === 2 && r.volumes[0].text === CUBE);
  check('…and says so in warnings (newer version, ignored member)', r.warnings.some(w => /version 2|newer/i.test(w)) && r.warnings.some(w => /hologram|extra\/thing\.dat/.test(w)), r.warnings.join(' | '));
  check('isSessionFile is true for the version-2 file', isSessionFile(z));
  const rz = rezip((files) => { /* surfaces deflated by a re-zip: the reader must not care about the method */ });
  const rr = await readSession(rz);
  check('a re-zipped session (every member deflated by another tool) reads identically', sameArray(rr.surfaces[0].positions, SURF_A.positions) && sameArray(rr.original.bytes, ORIGINAL));
  const inFolder = (() => { const files = unzipSync(ZIP); const out = {}; for (const k of Object.keys(files)) out['my session/' + k] = files[k];
    out['my session/'] = new Uint8Array(0); out['__MACOSX/my session/._manifest.json'] = new Uint8Array([0, 5, 22, 7]); return zipSync(out); })();
  const rf = await readSession(inFolder);
  check('a session re-zipped inside a folder by Finder (with __MACOSX junk and a directory entry) still opens', sameJson(rf.state, STATE) && rf.surfaces.length === 2, rf.warnings.join(' | '));
  check('isSessionFile is true for that one too', isSessionFile(inFolder));
  const z3 = rezip((files, m) => { m.members.push({ path: 'surfaces/3.bin', kind: 'surface', name: 'from the future', iso: 0.1, colour: '#fff', nVerts: 1, nTris: 1,
    hasNormals: true, hasColours: false, layout: 'pos:f16x3,norm:oct16,idx:u32x3', bytes: 4 }); files['surfaces/3.bin'] = new Uint8Array(4); });
  const r3 = await readSession(z3);
  check('a surface in a layout this build does not know is skipped with a warning, the rest opens', r3.surfaces.length === 2 && r3.warnings.some(w => /surfaces\/3\.bin/.test(w) && /layout/.test(w)), r3.warnings.join(' | '));
  const lax = rezip((files, m) => { files['notes.md'] = new Uint8Array([0x63, 0x61, 0x66, 0xe9]); m.members.find(e => e.path === 'notes.md').bytes = 4; delete m.members.find(e => e.path === 'notes.md').sha256; });
  const rl = await readSession(lax);
  check('a free-text member that is not UTF-8 (a Latin-1 "café") is decoded leniently with a warning', rl.notes === 'caf\ufffd' && rl.warnings.some(w => /notes\.md/.test(w) && /UTF-8/.test(w)), rl.warnings.join(' | '));
  /* Another writer might omit the normals; we never do, but the layout string spells the
     sections so the reader can still take the mesh and say what it will look like. */
  const noNorm = rezip((files, m) => {
    const e = m.members.find(x => x.path === 'surfaces/2.bin');
    const nV = e.nVerts, b = files['surfaces/2.bin'];
    const stripped = new Uint8Array(b.length - nV * 12);
    stripped.set(b.subarray(0, nV * 12), 0); stripped.set(b.subarray(nV * 24), nV * 12);
    files['surfaces/2.bin'] = stripped; e.hasNormals = false; e.bytes = stripped.length; delete e.sha256;
  });
  const rn = await readSession(noNorm);
  check('a surface stored without normals by another writer reads with normals null and a warning',
    rn.surfaces.length === 2 && rn.surfaces[1].normals === null && sameArray(rn.surfaces[1].positions, SURF_B.positions) && sameArray(rn.surfaces[1].indices, SURF_B.indices) &&
    rn.warnings.some(w => /surfaces\/2\.bin/.test(w) && /normals/.test(w)), rn.warnings.join(' | '));
  const unlisted = await readSession(rezip((files) => { files['stray.txt'] = enc.encode('x'); }));
  check('a member the manifest does not list is ignored with a warning naming it', unlisted.warnings.some(w => /stray\.txt/.test(w)), unlisted.warnings.join(' | '));
  const isoString = await readSession(await buildSession({ app: APP, state: STATE, surfaces: [{ ...SURF_B, iso: '0.03' }] }));
  check('an isovalue given as a numeric string is stored as a number', isoString.surfaces[0].iso === 0.03);
}

/* ------------------------------------------------------------------ refusals */
{
  const noManifest = await throwsWith(() => readSession(zipSync({ 'a.txt': enc.encode('hello'), 'state.json': enc.encode('{}') })), /2D-WORM session/);
  check('a zip with no manifest → error mentioning "2D-WORM session"', noManifest.ok, noManifest.msg);
  const wrongFormat = await throwsWith(() => readSession(zipSync({ 'manifest.json': enc.encode(JSON.stringify({ format: 'someone-elses-app', version: 1, members: [] })) })), /2D-WORM session/);
  check('a manifest with the wrong format → error mentioning "2D-WORM session"', wrongFormat.ok, wrongFormat.msg);
  const notJson = await throwsWith(() => readSession(zipSync({ 'manifest.json': enc.encode('{ not json') })), /manifest\.json/);
  check('a manifest that is not JSON → error naming manifest.json', notJson.ok, notJson.msg);
  const notZip = await throwsWith(() => readSession(enc.encode('ATOM      1  N   ALA A   1')), /zip/i);
  check('a text file → error saying it is not a zip', notZip.ok, notZip.msg);
  const truncated = await throwsWith(() => readSession(ZIP.subarray(0, 5000)), /zip|read/i);
  check('a truncated zip → a clear error, not a crash', truncated.ok, truncated.msg);
  const noState = await throwsWith(() => readSession(zipSync({ 'manifest.json': enc.encode(JSON.stringify({ format: '2dworm-session', version: 1, members: [] })) })), /state\.json/);
  check('a manifest without a state member → error naming state.json', noState.ok, noState.msg);
  const missing = await throwsWith(() => readSession(rezip((files, m) => { m.members.push({ path: 'surfaces/9.bin', kind: 'surface', nVerts: 3, nTris: 1, bytes: 84 }); })), /surfaces\/9\.bin/);
  check('a member the manifest lists but the zip lacks → error naming it', missing.ok, missing.msg);

  for (const bad of ['../evil.json', '/etc/passwd', 'C:/evil.json', 'a\\b.json', 'surfaces/../../x.bin']) {
    const z = rezip((files, m) => { files[bad] = enc.encode('{}'); m.members.push({ path: bad, kind: 'notes', bytes: 2 }); });
    const t = await throwsWith(() => readSession(z), /refus|member name/i);
    check(`zip-slip member name ${JSON.stringify(bad)} is rejected, and named`, t.ok && t.msg.includes(bad), t.msg);
  }
  const slipUnlisted = await throwsWith(() => readSession(rezip((files) => { files['../unlisted.txt'] = enc.encode('x'); })), /\.\.\/unlisted\.txt/);
  check('a zip-slip name is rejected even when the manifest does not list it', slipUnlisted.ok, slipUnlisted.msg);
  const slipManifest = await throwsWith(() => readSession(rezip((files, m) => { m.members.push({ path: '../only-in-manifest', kind: 'notes', bytes: 1 }); })), /only-in-manifest/);
  check('a zip-slip path in the manifest alone is rejected too', slipManifest.ok, slipManifest.msg);

  const tampered = rezip((files) => { const o = files['original/DNA (Dante).pdb']; o[12345] ^= 0x40; });
  const t1 = await throwsWith(() => readSession(tampered), /sha256/i);
  check('an original with one flipped byte → sha256 error naming original/DNA (Dante).pdb', t1.ok && t1.msg.includes('original/DNA (Dante).pdb'), t1.msg);
  const tamperedVol = rezip((files) => { const o = files['volumes/FOD_Ni-H_fromGeom_wB97XD6311Gdp.eldens.cube']; o[o.length - 3] = o[o.length - 3] === 0x30 ? 0x31 : 0x30; });
  const t2 = await throwsWith(() => readSession(tamperedVol), /sha256/i);
  check('a volume with one changed digit → sha256 error naming the volume', t2.ok && t2.msg.includes('volumes/FOD'), t2.msg);
  const tamperedSurf = rezip((files) => { files['surfaces/2.bin'][40] ^= 1; });
  const t3 = await throwsWith(() => readSession(tamperedSurf), /sha256/i);
  check('a surface with one flipped byte → sha256 error naming surfaces/2.bin', t3.ok && t3.msg.includes('surfaces/2.bin'), t3.msg);
  const shortState = rezip((files) => { files['state.json'] = files['state.json'].subarray(0, files['state.json'].length - 1); });
  const t4 = await throwsWith(() => readSession(shortState), /bytes/);
  check('a member whose size disagrees with the manifest → error naming state.json and both sizes', t4.ok && t4.msg.includes('state.json') && /\d+ bytes/.test(t4.msg), t4.msg);
  const badCounts = rezip((files, m) => { const e = m.members.find(x => x.path === 'surfaces/2.bin'); e.nTris = 39; delete e.sha256; });
  const t5 = await throwsWith(() => readSession(badCounts), /surfaces\/2\.bin/);
  check('surface bytes that disagree with nVerts/nTris → error naming the member', t5.ok && /nVerts|nTris|vertices|triangles/i.test(t5.msg), t5.msg);
  const badIndex = rezip((files, m) => { const e = m.members.find(x => x.path === 'surfaces/2.bin'); delete e.sha256; const b = files['surfaces/2.bin'];
    const off = 41 * 24; b[off] = 0xff; b[off + 1] = 0xff; b[off + 2] = 0xff; b[off + 3] = 0x7f; });
  const t6 = await throwsWith(() => readSession(badIndex), /surfaces\/2\.bin/);
  check('a triangle index past the last vertex → error naming the member (it would crash the renderer later)', t6.ok && /index|vert/i.test(t6.msg), t6.msg);
  const badRefRead = await readSession(rezip((files, m) => { m.references = [{ url: 'javascript:alert(1)', kind: 'volume' }, { url: 'https://ok.example/x.cube', kind: 'volume' }, 'junk']; }));
  check('on read, a reference with a bad url or shape is dropped with a warning, good ones kept', badRefRead.references.length === 1 && badRefRead.references[0].url === 'https://ok.example/x.cube' &&
    badRefRead.warnings.some(w => /reference/i.test(w)), badRefRead.warnings.join(' | '));
}

/* ------------------------------------------------------------------ isSessionFile */
{
  check('isSessionFile: true for our file', isSessionFile(ZIP) === true);
  check('isSessionFile: false for a random zip', isSessionFile(zipSync({ 'readme.txt': enc.encode('not ours'), 'data/x.json': enc.encode('{}') })) === false);
  check('isSessionFile: false for a zip whose manifest.json is another format', isSessionFile(zipSync({ 'manifest.json': enc.encode('{"format":"pwa","version":1}') })) === false);
  check('isSessionFile: false for a PNG', isSessionFile(PNG) === false);
  check('isSessionFile: false for a text file, an empty buffer, a string, null', isSessionFile(enc.encode('HETATM    1 FE   HEM A 155')) === false && isSessionFile(new Uint8Array(0)) === false &&
    isSessionFile('PK\x03\x04') === false && isSessionFile(null) === false);
  check('isSessionFile: false for "PK" followed by garbage', isSessionFile(new Uint8Array([0x50, 0x4b, 3, 4, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9])) === false);
  check('isSessionFile: takes an ArrayBuffer', isSessionFile(ZIP.buffer.slice(ZIP.byteOffset, ZIP.byteOffset + ZIP.byteLength)) === true);
}

/* ------------------------------------------------------------------ the big one */
{
  const N = 1001;                                   // 1001×1001 vertices → 2 000 000 triangles
  const nVerts = N * N, nTris = 2 * (N - 1) * (N - 1);
  const positions = new Float32Array(nVerts * 3), normals = new Float32Array(nVerts * 3), indices = new Uint32Array(nTris * 3);
  for (let j = 0, v = 0; j < N; j++) for (let i = 0; i < N; i++, v++) {
    positions[3 * v] = i * 0.05; positions[3 * v + 1] = j * 0.05; positions[3 * v + 2] = Math.sin(i * 0.1) * Math.cos(j * 0.1);
    const nx = -0.1 * Math.cos(i * 0.1) * Math.cos(j * 0.1), ny = 0.1 * Math.sin(i * 0.1) * Math.sin(j * 0.1), l = Math.hypot(nx, ny, 1);
    normals[3 * v] = nx / l; normals[3 * v + 1] = ny / l; normals[3 * v + 2] = 1 / l;
  }
  for (let j = 0, t = 0; j < N - 1; j++) for (let i = 0; i < N - 1; i++) {
    const a = j * N + i, b = a + 1, c = a + N, d = c + 1;
    indices[t++] = a; indices[t++] = b; indices[t++] = c; indices[t++] = b; indices[t++] = d; indices[t++] = c;
  }
  const t0 = performance.now();
  const z = await buildSession({ app: APP, state: STATE, surfaces: [{ name: 'big', iso: 0.05, colour: '#3060ff', positions, normals, indices }] });
  const t1 = performance.now();
  const r = await readSession(z);
  const t2 = performance.now();
  const s = r.surfaces[0];
  check('a 2 000 000-triangle surface builds and reads back in under 3 s', t2 - t0 < 3000 && s.nTris === nTris && s.nVerts === nVerts,
    `build ${(t1 - t0).toFixed(0)} ms, read ${(t2 - t1).toFixed(0)} ms, ${(z.length / 1048576).toFixed(1)} MiB`);
  check('…and every element is equal', sameArray(s.positions, positions) && sameArray(s.normals, normals) && sameArray(s.indices, indices));
  check('…and the mesh member is stored, so the zip is the mesh plus a few hundred bytes', z.length - (nVerts * 24 + nTris * 12) < 4096, `${z.length - (nVerts * 24 + nTris * 12)} bytes over`);
}

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
