/* Manuscript figures that can be produced by script, so they can be reproduced exactly.

   Figures 1, 2 and 5 are screenshots of the real application; 4A is drawn from the force
   field's own parameter table, and 4B from three structures typed by their geometry alone.
   Everything is rendered at deviceScaleFactor 2, which is 300 dpi at figure width.

   What CANNOT be scripted, and is deliberately absent:
     Figure 3   needs Theo's own PN3P pincer geometries out of Gaussian.
     Figure 4C  is a chart of the RDKit cross-validation — made separately from
                uff-reference.json, not from a screenshot.
     Figure 4D  needs the real PDB entry 4HHB, which this container cannot download.
     Figure 2E cartoons  need a real protein. Put any .pdb beside this file (1CRN is 48 kB)
                and they are produced with the rest; a synthetic helix would look convincing
                and mean nothing, so none is offered. Anything not produced is listed at the
                end of the run rather than passed over in silence.

   Usage:  node figures.mjs [output directory]
*/
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, readdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const HERE = fileURLToPath(new URL('./', import.meta.url));
const OUT = process.argv[2] || fileURLToPath(new URL('./figures', import.meta.url));
/* panels this run could not produce, and why — printed at the end rather than left silent */
const missing = [];
mkdirSync(OUT, { recursive: true });

const PORT = 8792;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));
const made = [];
const shot = async (page, name, opt = {}) => {
  await page.screenshot({ path: `${OUT}/${name}.png`, ...opt });
  made.push(name + '.png');
  console.log('  ' + name + '.png');
};
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const browser = await chromium.launch();
async function open(width = 1500, height = 950) {
  const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  await page.goto(`http://127.0.0.1:${PORT}/index.html`);
  await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
  return page;
}
/** put a molecule in the drawing and build it in 3D */
async function build(page, smiles) {
  await page.evaluate(async (s) => { const k = await dworm2d.whenKetcher(); await k.setMolecule(s); }, smiles);
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  await sleep(400);
}
const CAFFEINE = 'Cn1cnc2c1c(=O)n(C)c(=O)n2C';
const IBUPROFEN = 'CC(C)Cc1ccc(cc1)C(C)C(=O)O';

/* =========================================================== Figure 1 — the interface */
console.log('\nFigure 1 — the interface');
{
  const page = await open();
  await page.evaluate(async () => {
    const k = await dworm2d.whenKetcher();
    await k.setMolecule('CC(=O)Oc1ccccc1C(=O)O>>CC(=O)O.Oc1ccccc1C(=O)O');
  });
  await sleep(900);
  await page.click('#btnMacMolPlt');                       // editor alone
  await sleep(400);
  await shot(page, 'fig1A_editor');

  await page.click('#btnMacMolPlt'); await page.click('#btnKetcher');   // viewer alone
  await build(page, IBUPROFEN);
  await sleep(400);
  await shot(page, 'fig1B_viewer');

  await page.click('#btnKetcher');                          // both
  await sleep(500);
  await shot(page, 'fig1C_split');

  for (const t of ['white', 'black', 'worm', 'pink']) {
    await page.evaluate(x => dworm2d.setTheme(x), t);
    await sleep(500);
    await shot(page, 'fig1D_theme_' + t);
  }
  await page.evaluate(() => dworm2d.setTheme('white'));
  await page.context().close();
}

/* ====================================================== Figure 2 — two dimensions to three */
console.log('\nFigure 2 — from two dimensions to three');
{
  const page = await open();
  await page.evaluate(async (s) => { const k = await dworm2d.whenKetcher(); await k.setMolecule(s); }, IBUPROFEN);
  await sleep(900);
  await shot(page, 'fig2A_smiles_pasted');

  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  await sleep(400);
  await shot(page, 'fig2B_generated');

  await page.evaluate(() => { dworm2d.opts.field = 'mmff'; dworm2d.minimizeCurrent(); });
  await page.waitForFunction(() => /kcal\/mol/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
  await sleep(300);
  await shot(page, 'fig2C_minimised');
  console.log('    status: ' + (await page.textContent('#status3d')).slice(0, 120));

  await page.evaluate(() => dworm2d.bestConformation());
  await page.waitForFunction(() => /lowest of/.test(document.getElementById('status3d').textContent), null, { timeout: 300000 });
  await sleep(300);
  await shot(page, 'fig2D_best_conformer');
  console.log('    status: ' + (await page.textContent('#status3d')).slice(0, 120));

  /* (E) the representations, 3D panel only so the panels crop cleanly. A cartoon of ibuprofen
     is not a picture of anything — the two cartoon panels are taken from a protein below. */
  await page.click('#btnKetcher'); await sleep(300);
  for (const style of ['bs', 'bssas', 'tube', 'wire', 'cpk']) {
    await page.selectOption('#selStyle', style);
    await sleep(style === 'bssas' ? 1400 : 350);
    await shot(page, 'fig2E_style_' + style, { clip: await page.$eval('#panel3d', e => {
      const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height };
    }) });
  }
  // (F) outline weight and hidden hydrogens
  await page.selectOption('#selStyle', 'bs'); await sleep(300);
  for (const o of ['0', '0.06', '0.15']) {
    await page.selectOption('#selOutline', o);
    await sleep(350);
    await shot(page, 'fig2F_outline_' + o.replace('.', 'p'), { clip: await page.$eval('#panel3d', e => {
      const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height };
    }) });
  }
  await page.selectOption('#selOutline', '0');
  await page.check('#chkHideH'); await sleep(350);
  await shot(page, 'fig2F_hidden_H', { clip: await page.$eval('#panel3d', e => {
    const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height };
  }) });

  /* The two cartoon panels need a real protein, and this container has no network. Drop any
     .pdb beside this script — 1CRN is 48 kB — and they are produced with everything else.
     A synthetic helix would look convincing and mean nothing, so it is not offered. */
  const pdbs = readdirSync(HERE).filter(f => /\.(pdb|ent)$/i.test(f));
  if (pdbs.length) {
    const text = readFileSync(`${HERE}/${pdbs[0]}`, 'utf8');
    console.log('    cartoon panels from ' + pdbs[0]);
    await page.evaluate(([t, n]) => dworm2d.show3d(t, 'pdb', 'file', n), [text, pdbs[0]]);
    await sleep(1200);
    for (const style of ['cartoon', 'cartoonstick']) {
      await page.selectOption('#selStyle', style);
      await sleep(1400);
      await shot(page, 'fig2E_style_' + style, { clip: await page.$eval('#panel3d', e => {
        const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height };
      }) });
    }
  } else {
    missing.push('fig2E_style_cartoon / _cartoonstick — put a .pdb (e.g. 1CRN) beside figures.mjs');
  }
  await page.context().close();
}

/* ============================================ Figure 6 — the same view in four languages
   The point of the figure is what does NOT change: the panels are at the same pixel offsets
   in all four, because the layout does not mirror. The script prints those offsets, so the
   caption can state them rather than assert them. */
console.log('\nFigure 6 — the interface in four languages');
{
  const page = await open(1500, 950);
  await build(page, CAFFEINE);
  const where = {};
  for (const [code, name] of [['en', 'english'], ['ar', 'arabic'], ['zh', 'chinese'], ['pt', 'portuguese']]) {
    await page.evaluate(c => dworm2d.setLang(c), code);
    await sleep(700);
    await shot(page, 'fig6_' + name);
    where[code] = await page.evaluate(() => [
      Math.round(document.getElementById('panel2d').getBoundingClientRect().x),
      Math.round(document.getElementById('panel3d').getBoundingClientRect().x),
    ]);
  }
  await page.evaluate(() => dworm2d.setLang('en'));
  const same = JSON.stringify(Object.values(where).map(v => v.join(','))).match(/"[^"]+"/g);
  console.log('    panel x-offsets: ' + JSON.stringify(where));
  console.log('    ' + (new Set(same).size === 1
    ? 'identical in all four — this is the caption'
    : 'THEY DIFFER. The layout moved; do not publish this figure until it does not.'));
  await page.context().close();
}

/* ================================ Figure 4B — the same metal centre typed from its geometry */
console.log('\nFigure 4B — geometry-driven atom typing');
{
  const page = await open(900, 760);
  await page.click('#btnKetcher'); await sleep(300);
  /* IRON, twice, differing ONLY in where the ligands are. Nothing anywhere states an
     oxidation state — the type comes from the measured coordination alone, and iron is the
     right element to show it with because UFF gives it both a tetrahedral and an octahedral
     type. (Nickel is the honest counter-example: UFF offers only the square-planar Ni4+2,
     whatever the geometry, and the status line says so rather than hiding it.) */
  const L = 2.05;
  const geoms = {
    Fe_tetrahedral:   ['Fe', [[L,L,L],[L,-L,-L],[-L,L,-L],[-L,-L,L]].map(v => v.map(x => x / Math.sqrt(3)))],
    Fe_octahedral:    ['Fe', [[L,0,0],[-L,0,0],[0,L,0],[0,-L,0],[0,0,L],[0,0,-L]]],
    Ni_square_planar: ['Ni', [[1.95,0,0],[-1.95,0,0],[0,1.95,0],[0,-1.95,0]]],
  };
  const report = [];
  for (const [name, [metal, pos]] of Object.entries(geoms)) {
    const xyz = [`${pos.length + 1}`, name.replace(/_/g, ' '), `${metal} 0.000 0.000 0.000`,
      ...pos.map(p => 'Cl ' + p.map(v => v.toFixed(3)).join(' '))].join('\n') + '\n';
    await page.evaluate(t => dworm2d.show3d(t, 'xyz', 'file', 'ni.xyz'), xyz);
    await sleep(400);
    const typed = await page.evaluate(async (stamp) => {
      const uff = await import('./lib/uff.js?v=' + stamp);
      const s = dworm2d.viewerStruct();
      const t = uff.assignTypes(s.atoms, s.bonds);
      return { type: t.types[0], coord: t.coord ? t.coord[0] : null, assumed: (t.assumed || []).join('; ') };
    }, `${(await page.evaluate(() => dworm2d.APP.version))}.${await page.evaluate(() => dworm2d.APP.build)}`);
    report.push(`${name.padEnd(17)} ${pos.length}-coordinate  ->  UFF type ${typed.type}` +
                (typed.assumed ? `  [${typed.assumed}]` : ''));
    console.log('    ' + report[report.length - 1]);
    await shot(page, 'fig4B_' + name, { clip: await page.$eval('#panel3d', e => {
      const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height };
    }) });
  }
  writeFileSync(`${OUT}/fig4B_typing.txt`, report.join('\n') + '\n');
  made.push('fig4B_typing.txt');
  await page.context().close();
}

/* ======================================================== Figure 5 — sharing */
console.log('\nFigure 5 — sharing');
{
  const page = await open();
  await build(page, CAFFEINE);
  await page.click('#btnShare');
  await page.waitForFunction(() => document.getElementById('shareUrl').value.length > 0, null, { timeout: 60000 });
  await sleep(600);
  await shot(page, 'fig5A_share_dialog');
  const url = await page.inputValue('#shareUrl');
  await page.context().close();

  // (B) the same session opened at a phone viewport
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true,
  });
  const phone = await ctx.newPage();
  await phone.goto(url.replace('http://localhost', 'http://127.0.0.1'));
  await phone.waitForFunction(() => /Shared structure loaded|Ready/.test(document.getElementById('msg').textContent), null, { timeout: 90000 });
  await sleep(1200);
  await shot(phone, 'fig5B_phone');
  await ctx.close();
}

/* ============================ Figure 4A — what each force field can type, drawn as an SVG */
console.log('\nFigure 4A — periodic-table coverage');
{
  const uff = await import(APP + 'lib/uff.js');
  const covered = new Set(uff.UFF_ELEMENTS);
  /* MMFF94's element coverage: the main-group set it was parameterised for. Taken from
     Halgren's papers, not from any implementation's source. */
  const MMFF = new Set(['H','C','N','O','F','Si','P','S','Cl','Br','I',
                        'Li','Na','K','Zn','Ca','Cu','Mg','Fe']);
  const ROWS = [
    ['H','','','','','','','','','','','','','','','','','He'],
    ['Li','Be','','','','','','','','','','','B','C','N','O','F','Ne'],
    ['Na','Mg','','','','','','','','','','','Al','Si','P','S','Cl','Ar'],
    ['K','Ca','Sc','Ti','V','Cr','Mn','Fe','Co','Ni','Cu','Zn','Ga','Ge','As','Se','Br','Kr'],
    ['Rb','Sr','Y','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag','Cd','In','Sn','Sb','Te','I','Xe'],
    ['Cs','Ba','La','Hf','Ta','W','Re','Os','Ir','Pt','Au','Hg','Tl','Pb','Bi','Po','At','Rn'],
    ['Fr','Ra','Ac','Rf','Db','Sg','Bh','Hs','Mt','Ds','Rg','Cn','','','','','',''],
  ];
  const LN = ['Ce','Pr','Nd','Pm','Sm','Eu','Gd','Tb','Dy','Ho','Er','Tm','Yb','Lu'];
  const AN = ['Th','Pa','U','Np','Pu','Am','Cm','Bk','Cf','Es','Fm','Md','No','Lr'];
  const S = 40, G = 3, X0 = 20, Y0 = 54;
  const cell = (el, col, row) => {
    if (!el) return '';
    const x = X0 + col * (S + G), y = Y0 + row * (S + G);
    const inUff = covered.has(el) || (el === 'Lr' && covered.has('Lw'));
    const inMmff = MMFF.has(el);
    const fill = inMmff ? '#2f6f3f' : inUff ? '#c8891f' : '#e6e6e6';
    const fg = inUff || inMmff ? '#fff' : '#9a9a9a';
    return `<rect x="${x}" y="${y}" width="${S}" height="${S}" rx="4" fill="${fill}"/>` +
           `<text x="${x + S / 2}" y="${y + S / 2 + 5}" text-anchor="middle" font-size="15" font-weight="600" fill="${fg}">${el}</text>`;
  };
  let body = '';
  ROWS.forEach((r, i) => r.forEach((el, j) => { body += cell(el, j, i); }));
  LN.forEach((el, j) => { body += cell(el, j + 3, 8); });
  AN.forEach((el, j) => { body += cell(el, j + 3, 9); });
  const W = X0 * 2 + 18 * (S + G), H = Y0 + 10 * (S + G) + 20;
  const key = (x, c, t) => `<rect x="${x}" y="18" width="18" height="18" rx="3" fill="${c}"/>` +
    `<text x="${x + 25}" y="32" font-size="14" fill="#333">${t}</text>`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" font-family="system-ui, sans-serif">
<rect width="${W}" height="${H}" fill="#fff"/>
${key(20, '#2f6f3f', 'MMFF94s+ (OpenChemLib)')}
${key(260, '#c8891f', `UFF (this work) — ${covered.size} elements, ${Object.keys(uff.UFF_PARAMS).length} atom types`)}
${key(600, '#e6e6e6', 'neither')}
${body}
</svg>`;
  writeFileSync(`${OUT}/fig4A_coverage.svg`, svg);
  made.push('fig4A_coverage.svg');
  const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 2 });
  await page.setContent(svg);
  await page.screenshot({ path: `${OUT}/fig4A_coverage.png` });
  made.push('fig4A_coverage.png');
  console.log(`  fig4A_coverage.svg / .png — ${covered.size} UFF types, ${MMFF.size} MMFF elements`);
  await page.close();
}

await browser.close(); server.kill();
console.log(`\n${made.length} files written to ${OUT}`);
if (missing.length) {
  console.log('\nNot produced here:');
  for (const m of missing) console.log('  - ' + m);
}
