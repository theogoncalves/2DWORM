/* In the browser: force-field routing, FAST/QUALITY, CLEAR, and the worker build stamp. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8775;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/* A ruthenium complex: MMFF has no parameters for Ru, so 'auto' must fall through to UFF. */
const ruXyz = `13
Ru(NH3)6 fragment, deliberately distorted
Ru  0.000000  0.000000  0.000000
N   2.400000  0.150000  0.000000
N  -2.250000  0.000000  0.200000
N   0.100000  2.350000  0.000000
N   0.000000 -2.300000  0.150000
N   0.000000  0.100000  2.400000
N   0.150000  0.000000 -2.250000
H   2.900000  1.000000  0.100000
H   2.900000 -0.800000  0.150000
H  -2.800000  0.850000  0.200000
H   0.700000  2.900000  0.600000
H   0.600000  0.700000  2.900000
H   0.700000  0.600000 -2.800000
`;
const ethanolXyz = `9
ethanol, distorted
C   0.000000  0.000000  0.000000
C   1.600000  0.100000  0.050000
O   2.100000  1.350000  0.000000
H  -0.400000  1.000000  0.100000
H  -0.400000 -0.500000  0.900000
H  -0.350000 -0.550000 -0.850000
H   1.950000  -0.450000  0.950000
H   1.950000  -0.500000 -0.800000
H   3.050000  1.300000  0.050000
`;

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

async function minimiseAndWait() {
  // do not wait for the "running" class: a small structure can finish inside one poll
  // interval. Wait for the status line to say something new and the button to be idle.
  const before = await page.$eval('#status3d', e => e.textContent);
  await page.evaluate(t => { document.getElementById('status3d').dataset.before = t; }, before);
  await page.click('#btnMinimize');
  await page.waitForFunction(() => {
    const el = document.getElementById('status3d');
    return el.textContent !== el.dataset.before && !document.getElementById('btnMinimize').classList.contains('running');
  }, null, { timeout: 180000 });
  await page.waitForTimeout(150);
  return page.evaluate(() => ({
    status: document.getElementById('status3d').textContent,
    cls: document.getElementById('status3d').className,
    n: dworm2d.viewer.getModel() ? dworm2d.viewer.getModel().selectedAtoms({}).length : 0,
    fmt: dworm2d.state3d.format,
    data: dworm2d.state3d.data.slice(0, 200),
  }));
}
function bond(a, b) { return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z); }

/* ---------------------------------------------- 1. auto picks MMFF for an organic */
await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'ethanol.xyz'), ethanolXyz);
let r = await minimiseAndWait();
check('auto uses MMFF94s+ for an ordinary organic molecule', /MMFF94s\+\)/.test(r.status) && r.cls === 'ok', r.status);
check('the structure survives it', r.n === 9, 'atoms ' + r.n);

/* ---------------------------------------------- 2. auto falls through to UFF for Ru */
await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'ru.xyz'), ruXyz);
r = await minimiseAndWait();
check('auto falls through to UFF when MMFF has no parameters', /\(UFF\)/.test(r.status) && r.cls === 'ok', r.status);
check('it says why MMFF could not', /MMFF94s\+ could not/.test(r.status), r.status);
check('the ruthenium complex is still there', r.n === 13, 'atoms ' + r.n);
check('the file keeps its own format through a UFF minimisation', r.fmt === 'xyz', r.fmt);

const geom = await page.evaluate(() => {
  const a = dworm2d.viewer.getModel().selectedAtoms({});
  const ang = (i, j, k) => {
    const u = { x: a[i].x - a[j].x, y: a[i].y - a[j].y, z: a[i].z - a[j].z };
    const v = { x: a[k].x - a[j].x, y: a[k].y - a[j].y, z: a[k].z - a[j].z };
    const lu = Math.hypot(u.x, u.y, u.z), lv = Math.hypot(v.x, v.y, v.z);
    return Math.acos(Math.max(-1, Math.min(1, (u.x * v.x + u.y * v.y + u.z * v.z) / (lu * lv)))) * 180 / Math.PI;
  };
  const out = [];
  for (let i = 1; i <= 6; i++) for (let j = i + 1; j <= 6; j++) out.push(ang(i, 0, j));
  return { angles: out, ruN: Math.hypot(a[1].x - a[0].x, a[1].y - a[0].y, a[1].z - a[0].z) };
});
const n90 = geom.angles.filter(a => Math.abs(a - 90) < 12).length;
check('UFF pulls the complex towards an octahedron', n90 >= 10, `${n90} of 12 angles near 90 deg, Ru–N ${geom.ruN.toFixed(2)} A`);

/* ---------------------------------------------- 3. asking for MMFF explicitly must fail loudly */
await page.selectOption('#selField', 'mmff');
r = await minimiseAndWait();
check('MMFF chosen by hand refuses rather than silently switching to UFF',
  r.cls === 'err' && /MMFF94s\+ could not do it/.test(r.status), r.status);
check('the refusal carries no internal class names from OpenChemLib', !/Class\$/.test(r.status), r.status);
check('the structure is untouched by the refusal', r.n === 13, 'atoms ' + r.n);

/* ---------------------------------------------- 4. UFF chosen by hand on an organic */
await page.selectOption('#selField', 'uff');
await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'ethanol.xyz'), ethanolXyz);
r = await minimiseAndWait();
check('UFF can be chosen by hand for an organic molecule', /\(UFF\)/.test(r.status) && r.cls === 'ok', r.status);
const co = await page.evaluate(() => {
  const a = dworm2d.viewer.getModel().selectedAtoms({});
  return { cc: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y, a[0].z - a[1].z),
           co: Math.hypot(a[1].x - a[2].x, a[1].y - a[2].y, a[1].z - a[2].z) };
});
check('UFF gives sensible ethanol bond lengths', Math.abs(co.cc - 1.51) < 0.06 && Math.abs(co.co - 1.43) < 0.08,
  `C–C ${co.cc.toFixed(3)}, C–O ${co.co.toFixed(3)} A`);

/* ---------------------------------------------- 5. BEST refuses for UFF, with a reason */
await page.click('#btnBest');
await page.waitForTimeout(400);
let s = await page.evaluate(() => ({ t: document.getElementById('status3d').textContent, c: document.getElementById('status3d').className }));
check('BEST CONFORMATION refuses while UFF is selected', /not available with UFF/.test(s.t) && s.c === 'err', s.t.slice(0, 120));
check('the refusal is instant, not after ten failed conformers',
  !(await page.evaluate(() => document.getElementById('btnBest').classList.contains('running'))));

await page.selectOption('#selField', 'auto');
await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'ru.xyz'), ruXyz);
await page.click('#btnBest');
await page.waitForTimeout(400);
s = await page.evaluate(() => ({ t: document.getElementById('status3d').textContent, c: document.getElementById('status3d').className }));
check('BEST CONFORMATION refuses for a structure containing a metal', /not available for a structure containing Ru/.test(s.t) && s.c === 'err', s.t.slice(0, 140));
check('and it names MINIMIZE as what to do instead', /MINIMIZE will relax this structure with UFF/.test(s.t));

/* ---------------------------------------------- 6. FAST / QUALITY */
function bigPdb(nRes) {
  let out = 'HEADER    TEST\n', serial = 1;
  for (let r2 = 0; r2 < nRes; r2++) {
    for (const [name, el, x, y, z] of [['N', 'N', 0, 0, 0], ['CA', 'C', 1.45, 0, 0], ['C', 'C', 2.0, 1.4, 0], ['O', 'O', 3.2, 1.5, 0]]) {
      const a = r2 * 0.4, R = 4;
      out += 'ATOM  ' + String(serial).padStart(5) + ' ' + name.padEnd(4) + ' GLY A' + String(r2 + 1).padStart(4) + '    ' +
             (x + R * Math.cos(a)).toFixed(3).padStart(8) + (y + R * Math.sin(a)).toFixed(3).padStart(8) +
             (z + r2 * 1.5).toFixed(3).padStart(8) + '  1.00  0.00          ' + el.padStart(2) + '\n';
      serial++;
    }
  }
  return out + 'END\n';
}
await page.evaluate(() => { dworm2d.opts.labels = 'elem'; });
await page.evaluate(p => { document.__big = p; dworm2d.show3d(p, 'pdb', 'file', 'big.pdb'); }, bigPdb(500));   // 2000 atoms
const auto = await page.evaluate(() => ({
  mode: dworm2d.opts.render,
  on: document.querySelector('#renderSeg button.on').dataset.render,
  status: document.getElementById('status3d').textContent,
  labels: dworm2d.viewer.getModel() ? 0 : 0,
}));
check('a 2000-atom structure opens in FAST by itself', auto.mode === 'fast' && auto.on === 'fast', JSON.stringify(auto.mode));
check('and the status line says so', /FAST view/.test(auto.status), auto.status.slice(-60));

/* A PROTEIN OPENS AS A RIBBON. Five hundred residues in ball and stick is a hairball: two
   thousand sticks, no fold, and nothing anybody opened it to see. The page chooses the
   ribbon until somebody chooses something else, and then stops choosing — like FAST and
   QUALITY and the periodic box. */
const auto2 = await page.evaluate(() => ({
  style: dworm2d.opts.style, sel: document.getElementById('selStyle').value,
  protein: dworm2d.viewer.getModel().selectedAtoms({ atom: 'CA' }).length }));
check('a protein opens as a ribbon with its ligands drawn, not as a hairball of sticks',
  auto2.style === 'cartoonstick' && auto2.sel === 'cartoonstick',
  `${auto2.protein} alpha carbons → ${auto2.style}`);
const chosen = await page.evaluate(async () => {
  const sel = document.getElementById('selStyle');
  sel.value = 'tube'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 600));
  const was = dworm2d.opts.style;
  /* open the same protein again: the page must now leave the choice alone */
  dworm2d.show3d(document.__big, 'pdb', 'file', 'big2.pdb');
  await new Promise(r => setTimeout(r, 600));
  return { was, now: dworm2d.opts.style };
});
check('and once you have chosen a scheme yourself the page stops choosing for you',
  chosen.was === 'tube' && chosen.now === 'tube', `${chosen.was} → ${chosen.now}`);
await page.evaluate(() => { dworm2d.opts.style = 'bs'; document.getElementById('selStyle').value = 'bs'; });

/* Measure what FAST actually changes rather than raw frame time: this container renders in
   software, where fill rate dominates, the two modes come out within noise of each other,
   and a wall-clock comparison fails at random. Count the work instead — one setStyle for the
   whole structure rather than one per element, no outline pass, no labels. Those are the
   savings; on a real GPU they are what the frame time follows. */
const applyWork = await page.evaluate(() => {
  const v = dworm2d.viewer, realStyle = v.setStyle.bind(v), realView = v.setViewStyle.bind(v);
  const t = (mode) => {
    let styles = 0, outline = false;
    v.setStyle = (...a) => { styles++; return realStyle(...a); };
    v.setViewStyle = (s) => { if (s && s.style === 'outline') outline = true; return realView(s); };
    /* ball and stick, because this measures the PER-ELEMENT SPHERE SIZING, which only the
       sphere schemes do — a ribbon is one call whatever the mode */
    dworm2d.opts.style = 'bs';
    dworm2d.opts.render = mode; dworm2d.opts.outline = 0.06; dworm2d.opts.labels = 'elem';
    const t0 = performance.now();
    dworm2d.applyStyle(v);
    const ms = performance.now() - t0;
    v.setStyle = realStyle; v.setViewStyle = realView;
    return { styles, outline, labels: v.labels.length, ms };
  };
  const quality = t('quality'), fast = t('fast');
  return { quality, fast, elems: new Set(v.getModel().selectedAtoms({}).map(a => a.elem)).size };
});
/* One setStyle sets the representation itself; what follows is the sphere sizes, and that is
   where the two modes differ — one call for the whole structure against one per element, each
   of which rescans every atom and rebuilds its geometry. */
check('FAST sizes the atoms in one call, QUALITY one call per element',
  applyWork.fast.styles === 2 && applyWork.quality.styles === applyWork.elems + 1,
  `FAST ${applyWork.fast.styles}, QUALITY ${applyWork.quality.styles} for ${applyWork.elems} elements`);
check('FAST skips the outline pass as well',
  applyWork.quality.outline && !applyWork.fast.outline,
  `QUALITY outline ${applyWork.quality.outline}, FAST ${applyWork.fast.outline} · ` +
  `${applyWork.fast.ms.toFixed(0)} ms vs ${applyWork.quality.ms.toFixed(0)} ms here`);
const off = await page.evaluate(() => {
  dworm2d.opts.render = 'fast'; dworm2d.opts.outline = 0.15; dworm2d.opts.labels = 'elem';
  dworm2d.applyStyle(dworm2d.viewer);
  const labelsDrawn = dworm2d.viewer.labels.length;
  return { labelsDrawn };
});
check('FAST draws no labels at all', off.labelsDrawn === 0, 'labels ' + off.labelsDrawn);
const capped = await page.evaluate(() => {
  dworm2d.opts.render = 'quality'; dworm2d.opts.labels = 'elem';
  dworm2d.drawLabels(dworm2d.viewer);
  return dworm2d.viewer.labels.length;
});
check('QUALITY caps labels too, so 2000 atoms cannot hang the view', capped === 0, 'labels ' + capped);

// an exported image is always full quality
await page.evaluate(() => { dworm2d.opts.render = 'fast'; dworm2d.opts.outline = 0.06; });
const img = await page.evaluate(async () => {
  const url = await dworm2d.render3dImage(1, 'image/png');
  return { len: url.length, stillFast: dworm2d.opts.render };
});
check('an exported image is drawn at full quality even in FAST mode', img.len > 5000 && img.stillFast === 'fast', img.len + ' chars');

/* ---------------------------------------------- 7. CLEAR */
await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('c1ccccc1O'); });
await page.click('#btnClear3d');
await page.waitForTimeout(200);
const cleared = await page.evaluate(async () => ({
  model: dworm2d.viewer.getModel(),
  data: dworm2d.state3d.data,
  overlay: getComputedStyle(document.getElementById('msg3d')).display !== 'none',
  msg: document.getElementById('msg').textContent,
  smiles: await (await dworm2d.whenKetcher()).getSmiles(),
}));
check('CLEAR empties the 3D view', cleared.model === null && cleared.data === null);
check('CLEAR brings back the "drop a file here" overlay', cleared.overlay);
check('CLEAR leaves the drawing alone', /c1|C1/.test(cleared.smiles), cleared.smiles);
check('CLEAR says what it did', /3D view cleared/.test(cleared.msg), cleared.msg);

/* ---------------------------------------------- 8. the worker really is this build */
const hello = await page.evaluate(() => ({
  url: dworm2d.workerUrl, build: dworm2d.workerBuild(), app: `${dworm2d.APP.version}.${dworm2d.APP.build}`,
}));
check('the worker URL carries the build, so a cached one cannot be silently reused',
  /\?v=\d+\.\d+\.\d+\.\d+$/.test(hello.url), hello.url);
check('the worker reports the same build as the page', hello.build === hello.app,
  `worker ${hello.build}, page ${hello.app}`);

/* ---------------------------------------------- 9. a 2-coordinate nickel (the danteo.org report) */
const niXyz = `9
dimethylnickel
Ni  0.000000  0.000000  0.000000
C   1.900000  0.000000  0.000000
C  -1.900000  0.000000  0.000000
H   2.500000  1.000000  0.000000
H   2.500000 -0.500000  0.870000
H   2.500000 -0.500000 -0.870000
H  -2.500000  1.000000  0.000000
H  -2.500000 -0.500000  0.870000
H  -2.500000 -0.500000 -0.870000
`;
await page.selectOption('#selField', 'uff');
await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'ni.xyz'), niXyz);
r = await minimiseAndWait();
check('UFF minimises a nickel compound when UFF is selected',
  /\(UFF\)/.test(r.status) && r.cls === 'ok', r.status);
check('MMFF is never even attempted when UFF is chosen', !/MMFF94s\+/.test(r.status), r.status);
check('and it says which geometry UFF had to assume for the nickel',
  /Ni: 2-coordinate, but UFF only offers Ni4\+2/.test(r.status), r.status);
const ni = await page.evaluate(() => {
  const a = dworm2d.viewer.getModel().selectedAtoms({});
  const d = (p, q) => Math.hypot(p.x - q.x, p.y - q.y, p.z - q.z);
  return { nic: d(a[0], a[1]), n: a.length };
});
check('the nickel structure is sane afterwards', ni.n === 9 && Math.abs(ni.nic - 1.92) < 0.1,
  `Ni–C ${ni.nic.toFixed(3)} A`);

/* ------------------------------------------------------- the representations
   Every scheme, on a structure that suits it and on one that does not. 3Dmol builds its
   meshes inside render(), so a scheme it cannot construct throws LATER than where it was
   chosen — which is why the page must catch it and draw something rather than leaving a
   blank panel and an error in a console nobody has open. */
{
  /* A real alpha helix — 3.6 residues to a turn, 1.5 A rise — not a ring of atoms with the
     right names. A cartoon is drawn from the backbone geometry, so a "protein" whose N, CA
     and O sit on top of one another tests nothing about cartoons. */
  const pdbProtein = (nRes) => {
    const R = 2.3, rise = 1.5, dphi = 2 * Math.PI / 3.6;
    const off = [['N', 'N', -0.30, 0.00, 0.0], ['CA', 'C', 0.00, 0.55, 0.0],
                 ['C', 'C', 0.35, 1.05, 0.0], ['O', 'O', 0.45, 1.55, 0.6], ['CB', 'C', 0.10, 0.75, 1.4]];
    let out = 'HEADER    HELIX\n', n = 1;
    for (let r = 0; r < nRes; r++) {
      for (const [nm, el, dp, dz, dr] of off) {
        const p = r * dphi + dp, rr = R + dr, z = r * rise + dz;
        out += 'ATOM  ' + String(n).padStart(5) + ' ' + nm.padEnd(4) + ' ALA A' +
               String(r + 1).padStart(4) + '    ' +
               (rr * Math.cos(p)).toFixed(3).padStart(8) +
               (rr * Math.sin(p)).toFixed(3).padStart(8) +
               z.toFixed(3).padStart(8) +
               '  1.00  0.00          ' + el.padStart(2) + '\n';
        n++;
      }
    }
    return out + 'END\n';
  };
  /* Earlier checks in this file leave the page wherever they finished — a dialog open, a
     panel hidden — and a control that is covered or hidden cannot be operated. Put it back
     to a known state first, and say what was in the way if it is still not reachable.
     Labels go off too: section 6 left them on, and what is being measured here is the
     representation, not the labelling. */
  await page.evaluate(() => {
    document.querySelectorAll('.modal.open').forEach(m => m.classList.remove('open'));
    if (document.getElementById('panel3d').hidden) document.getElementById('btnMacMolPlt').click();
    dworm2d.opts.labels = 'none';
  });
  await page.waitForTimeout(500);
  if (!(await page.isVisible('#selStyle'))) {
    check('the representation menu is reachable', false, await page.evaluate(() => JSON.stringify({
      hidden3d: document.getElementById('panel3d').hidden,
      hidden2d: document.getElementById('panel2d').hidden,
      modals: [...document.querySelectorAll('.modal.open')].map(m => m.id),
      w: innerWidth,
    })));
  }
  const STYLES = ['bs', 'bssas', 'tube', 'wire', 'cpk', 'cartoon', 'cartoonstick', 'surface'];
  const look = async (st) => {
    await page.selectOption('#selStyle', st);
    await page.waitForTimeout(1300);
    return page.evaluate(() => ({
      msg: document.getElementById('msg').textContent,
      surfaces: dworm2d.viewer.surfaces ? Object.keys(dworm2d.viewer.surfaces).length : -1,
      drawn: dworm2d.viewer.modelGroup ? dworm2d.viewer.modelGroup.children.length : -1,
    }));
  };

  await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'p.pdb'), pdbProtein(60));
  await page.waitForTimeout(600);
  for (const st of STYLES) {
    const r = await look(st);
    check(`${st} draws something on a protein`, r.drawn > 0 && !/could not be built/.test(r.msg),
      `${r.drawn} objects, ${r.surfaces} surfaces — ${r.msg.slice(0, 50)}`);
  }
  const withSurf = await look('bssas');
  check('ball & stick + surface really adds a surface', withSurf.surfaces === 1, withSurf.surfaces + ' surfaces');

  await page.evaluate(() => { document.querySelector('#renderSeg button[data-render="fast"]').click(); });
  await page.waitForTimeout(900);
  check('and FAST leaves it out and says so',
    /not drawn in FAST/.test(await page.textContent('#msg')), (await page.textContent('#msg')).slice(0, 60));
  await page.evaluate(() => { document.querySelector('#renderSeg button[data-render="quality"]').click(); });
  await page.waitForTimeout(1200);

  /* 3Dmol redraws the whole scene for every label unless it is told not to, which made
     labelling 300 atoms take a minute and a half here. Count the redraws rather than the
     seconds: a wall-clock threshold would just flake on a slower machine. */
  const redraws = await page.evaluate(() => {
    const v = dworm2d.viewer, real = v.render.bind(v);
    let n = 0; v.render = (...a) => { n++; return real(...a); };
    dworm2d.opts.labels = 'elem';
    const t0 = performance.now();
    dworm2d.drawLabels(v);
    const ms = performance.now() - t0;
    const labels = v.labels.length;
    dworm2d.opts.labels = 'none'; dworm2d.drawLabels(v);
    v.render = real;
    return { n, labels, ms };
  });
  /* Not 300 labels any more, and deliberately: overlapping captions are dropped front to
     back, so a 300-atom protein is labelled on the atoms whose captions can actually be read.
     What is still being measured here is the redraw count — one full scene redraw per label is
     what made this take a minute and a half — and that a crowded structure still gets a useful
     number of labels rather than none or all of them. */
  check('labelling 300 atoms does not redraw the scene once per label',
    redraws.n <= 3 && redraws.labels > 20 && redraws.labels < 300,
    `${redraws.labels} of 300 atoms labelled, ${redraws.n} redraws, ${redraws.ms.toFixed(0)} ms`);

  // a small molecule has no backbone: the cartoon must give way, and say why
  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  const cart = await look('cartoon');
  check('a cartoon of a molecule with no backbone falls back and explains itself',
    /needs a protein backbone/.test(cart.msg) && cart.drawn > 0, cart.msg.slice(0, 70));
  const back = await look('bs');
  check('and the warning is taken back once a scheme that works is chosen',
    !/needs a protein backbone/.test(back.msg), back.msg.slice(0, 60));
  await page.selectOption('#selStyle', 'bs');
}


/* ================================================ the ready-made looks, and black and white
   The looks that arrived as a suggestion did not run as written — `ChainHetatm` for
   `chainHetatm`, a `bonded` selector that is not one, a `white` colourscheme that does not
   exist. These are the same looks against the API that is actually there, so each is checked
   for drawing something rather than for being spelt a particular way. */
{
  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CC(=O)Oc1ccccc1C(=O)O'); });
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  await page.waitForTimeout(400);
  for (const st of ['bs', 'ink', 'crystal', 'publication']) {
    await page.selectOption('#selStyle', st);
    await page.waitForTimeout(1100);
    const r = await page.evaluate(() => ({ drawn: dworm2d.viewer.modelGroup.children.length,
                                           msg: document.getElementById('msg').textContent }));
    check(`the ${st} look draws`, r.drawn > 0 && !/could not be built/.test(r.msg), `${r.drawn} objects`);
  }
  /* a look is only itself against the right background: neon is nothing on white, an ink
     drawing is nothing on black, so choosing one sets the background with it */
  const bgs = await page.evaluate(() => {
    const out = {};
    for (const st of ['neon', 'crystal', 'ink']) {
      document.getElementById('selStyle').value = st;
      document.getElementById('selStyle').dispatchEvent(new Event('change'));
      out[st] = dworm2d.opts.bg;
    }
    return out;
  });
  check('a look that needs a dark room gets one, and an ink drawing gets paper',
    bgs.neon === '#000000' && bgs.crystal === '#000000' && bgs.ink === '#ffffff', JSON.stringify(bgs));

  await page.selectOption('#selStyle', 'bs');
  await page.selectOption('#selOutline', '0');
  await page.waitForTimeout(700);
  /* B&W is a colouring handed to 3Dmol, not a filter over the picture: it has to reach the
     BONDS as well, or a C–O stick comes out half red, which is the one thing a black and
     white figure must not do. */
  const bw = await page.evaluate(async () => {
    const out = {};
    for (const mode of ['colour', 'bw']) {
      document.querySelector(`#colourSeg button[data-colour="${mode}"]`).click();
      await new Promise(r => setTimeout(r, 500));
      const o = dworm2d.viewer.getModel().selectedAtoms({}).find(x => x.elem === 'O');
      out[mode] = { sphere: !!(o && o.style.sphere && o.style.sphere.colorscheme),
                    stick: !!(o && o.style.stick && o.style.stick.colorscheme),
                    drawn: dworm2d.viewer.modelGroup.children.length };
    }
    return out;
  });
  check('B&W colours the atoms AND the bonds', bw.bw.sphere && bw.bw.stick && bw.bw.drawn > 0, JSON.stringify(bw.bw));
  check('and COLOUR takes it away again', !bw.colour.sphere && !bw.colour.stick, JSON.stringify(bw.colour));
  await page.evaluate(() => document.querySelector('#colourSeg button[data-colour="colour"]').click());
  await page.waitForTimeout(400);
}

/* ============================================= MINIMIZE SELECTED — partial optimisation
   Relaxing a fragment inside its surroundings rather than in vacuum. The frozen atoms are
   still in the terms and in the pair list, so they push and pull on the ones that move; what
   is zeroed is their gradient, which is why they must not move by even a rounding error. */
{
  const ethane = `8\ndistorted ethane\nC  0.000  0.000  0.000\nC  1.900  0.000  0.000\n` +
                 `H -0.500  0.900  0.000\nH -0.500 -0.900  0.000\nH -0.500  0.000  0.900\n` +
                 `H  2.400  0.900  0.000\nH  2.400 -0.900  0.000\nH  2.400  0.000  0.900\n`;
  await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'ethane.xyz'), ethane);
  await page.waitForTimeout(600);
  check('MINIMIZE SELECTED is not offered with nothing picked', await page.isHidden('#btnMinSel'));
  await page.evaluate(() => { dworm2d.state3d.sel = [5, 6, 7]; dworm2d.applyStyle(dworm2d.viewer); dworm2d.saySelection(); });
  await page.waitForTimeout(300);
  check('and appears as soon as atoms are picked', await page.isVisible('#btnMinSel'));

  const before = await page.evaluate(() => dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
  await page.evaluate(t => { document.getElementById('status3d').dataset.before = t; }, await page.textContent('#status3d'));
  await page.click('#btnMinSel');
  await page.waitForFunction(() => {
    const el = document.getElementById('status3d');
    return el.textContent !== el.dataset.before && !document.getElementById('btnMinSel').classList.contains('running');
  }, null, { timeout: 180000 });
  await page.waitForTimeout(250);
  const after = await page.evaluate(() => ({
    xyz: dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]),
    status: document.getElementById('status3d').textContent, cls: document.getElementById('status3d').className,
    sel: dworm2d.state3d.sel.slice(),
  }));
  const moved = before.map((p, i) => Math.hypot(p[0] - after.xyz[i][0], p[1] - after.xyz[i][1], p[2] - after.xyz[i][2]));
  check('a partial optimisation always runs UFF, whatever the field menu says',
    /\(UFF\)/.test(after.status) && after.cls === 'ok', after.status.slice(0, 110));
  check('the atoms that were not picked do not move by so much as a rounding error',
    moved.slice(0, 5).every(x => x === 0), moved.slice(0, 5).join(', '));
  check('the picked ones do', moved.slice(5).some(x => x > 0.05), moved.slice(5).map(x => x.toFixed(3)).join(', '));
  check('and the status line says how many were free to move', /free to move/.test(after.status),
    after.status.slice(-70));
  check('the selection survives, so the next adjustment does not have to be picked again',
    JSON.stringify(after.sel) === '[5,6,7]', JSON.stringify(after.sel));
  await page.evaluate(() => { dworm2d.state3d.sel = []; dworm2d.saySelection(); });
}

const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
