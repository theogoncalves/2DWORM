/* Clicking atoms to pick them, the highlight, the measurements, and carrying a selection
   inside a shared link. Plus every file format 3Dmol parses natively. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8785;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/* water plus a methyl, so there is something to measure an angle and a torsion across */
const XYZ = `6
test
O   0.000000  0.000000  0.000000
H   0.958000  0.000000  0.000000
H  -0.240000  0.927000  0.000000
C   2.400000  0.000000  0.000000
H   2.760000  1.020000  0.000000
H   2.760000 -0.510000  0.880000
`;

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1300, height: 850 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });
/* The checks below describe the SOLID mark — one translucent sphere per picked atom. Build 24
   made DOUBLE (a tinted atom inside a contrasting cage) the default, so the solid mark is
   chosen here explicitly, and DOUBLE has its own checks in build24.mjs. */
await page.evaluate(() => { window.dworm2d.opts.halo = 'solid'; });

await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'test.xyz'), XYZ);
await page.waitForTimeout(300);

/* Pick atoms the way a click does — through the same code path the click handler runs. */
async function pick(...idx) {
  return page.evaluate((list) => {
    const all = dworm2d.viewer.getModel().selectedAtoms({});
    for (const i of list) {
      const at = dworm2d.state3d.sel.indexOf(i);
      if (at >= 0) dworm2d.state3d.sel.splice(at, 1); else dworm2d.state3d.sel.push(i);
    }
    dworm2d.applyStyle(dworm2d.viewer);
    return { sel: dworm2d.state3d.sel.slice(), text: dworm2d.selectionText() };
  }, idx);
}

/* ------------------------------------------------------- picking and the halo */
{
  const before = await page.evaluate(() => ({
    style: JSON.stringify(dworm2d.viewer.getModel().selectedAtoms({})[0].style.sphere || null),
    shapes: dworm2d.viewer.shapes.length,
  }));
  check('nothing is marked before anything is picked', before.shapes === 0, before.shapes + ' shapes');
  const one = await pick(0);
  check('clicking an atom selects it', one.sel.length === 1 && one.sel[0] === 0, JSON.stringify(one.sel));
  check('and the status line names it', /1 selected: O1/.test(one.text), one.text);
  /* The highlight is a SHAPE around the atom, not a style on it. That distinction is the
     whole fix: a second sphere style does not stack on the first, it replaces it, and the
     atom disappeared inside a solid magenta ball. So check both halves — that a marker
     appeared, and that the atom underneath is untouched. */
  const halo = await page.evaluate(() => {
    const v = dworm2d.viewer, a = v.getModel().selectedAtoms({});
    const s = v.shapes[0], sp = s && s.intersectionShape.sphere[0];
    return {
      shapes: v.shapes.length,
      col: s ? [s.color.r, s.color.g, s.color.b] : null,
      opacity: s ? s.opacity : null,
      r: sp ? sp.radius : null,
      atCentre: sp ? Math.hypot(sp.center.x - a[0].x, sp.center.y - a[0].y, sp.center.z - a[0].z) : null,
      pickedStyle: JSON.stringify(a[0].style.sphere || null),
      otherStyle: JSON.stringify(a[1].style.sphere || null),
    };
  });
  check('the selected atom is marked, with one halo per atom (solid mark)', halo.shapes === 1, halo.shapes + ' shapes');
  check('the halo sits on the atom it marks', halo.atCentre < 1e-6, 'offset ' + halo.atCentre);
  check('the halo colour is not an element colour',
    Math.abs(halo.col[0] - 1) < 0.02 && Math.abs(halo.col[1] - 0.176) < 0.02 && Math.abs(halo.col[2] - 0.584) < 0.02,
    JSON.stringify(halo.col));
  check('the atom itself keeps its own size and colour under the halo',
    halo.pickedStyle === before.style && /radius/.test(halo.pickedStyle),
    `${halo.pickedStyle} was ${before.style}`);

  const again = await pick(0);
  check('clicking it again lets it go', again.sel.length === 0);
}
/* ------------------------------------------------------------- measurements */
{
  const two = await pick(0, 1);
  check('two atoms give the distance', /0\.958\s*Å/.test(two.text), two.text);
  const three = await pick(2);
  check('three give the angle', /°/.test(three.text) && /3 selected/.test(three.text), three.text);
  const four = await pick(3);
  check('four give the torsion', /4 selected/.test(four.text) && /°/.test(four.text), four.text);
  await page.evaluate(() => dworm2d.clearSelection());
  const cleared = await page.evaluate(() => ({ n: dworm2d.state3d.sel.length, hidden: document.getElementById('btnSel').hidden }));
  check('the clear button empties the selection and hides itself', cleared.n === 0 && cleared.hidden === true, JSON.stringify(cleared));
}
/* --------------------------------------------------- the selection travels */
{
  await pick(1, 3, 4);
  const hash = await page.evaluate(async () => {
    const st = await dworm2d.buildState('full');
    return { hash: await dworm2d.encodeState(st), sel: st.sel };
  });
  check('the picked atoms go into the shared state', JSON.stringify(hash.sel) === '[1,3,4]', JSON.stringify(hash.sel));

  const page2 = await ctx.newPage();
  page2.on('pageerror', e => errors.push('page2: ' + e.message));
  await page2.goto(`http://127.0.0.1:${PORT}/index.html#` + hash.hash);
  await page2.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
  const got = await page2.evaluate(() => ({
    sel: dworm2d.state3d.sel.slice(),
    msg: document.getElementById('msg').textContent,
    status: document.getElementById('status3d').textContent,
    shapes: dworm2d.viewer.shapes.length,
    col: dworm2d.viewer.shapes[0] ? [dworm2d.viewer.shapes[0].color.r, dworm2d.viewer.shapes[0].color.b] : null,
  }));
  check('and come back on the other device', JSON.stringify(got.sel) === '[1,3,4]', JSON.stringify(got.sel));
  check('the recipient is told the sender highlighted something', /highlighted 3 atoms/.test(got.msg), got.msg);
  check('and sees the same three halos', got.shapes === 3 && got.col &&
    Math.abs(got.col[0] - 1) < 0.02 && Math.abs(got.col[1] - 0.584) < 0.02,
    `${got.shapes} shapes, ${JSON.stringify(got.col)}`);
  await page2.close();
}
/* a selection must not survive a different structure being loaded */
{
  await page.evaluate(x => dworm2d.show3d(x, 'xyz', 'file', 'other.xyz'), XYZ.replace('test', 'other'));
  await page.waitForTimeout(200);
  const after = await page.evaluate(() => dworm2d.state3d.sel.length);
  check('loading another structure drops the selection', after === 0, 'still ' + after);
}
/* but it must survive a minimisation, which keeps the same atoms in the same order */
{
  await pick(0, 1);
  await page.click('#btnMinimize');
  await page.waitForFunction(() => /kcal\/mol|cannot/.test(document.getElementById('status3d').textContent)
    && !document.getElementById('btnMinimize').classList.contains('running'), null, { timeout: 120000 });
  await page.waitForTimeout(200);
  const kept = await page.evaluate(() => dworm2d.state3d.sel.slice());
  check('minimising keeps the selection, because the atoms are the same ones',
    JSON.stringify(kept) === '[0,1]', JSON.stringify(kept));
  await page.evaluate(() => dworm2d.clearSelection());
}

/* ------------------------------------------------ every native 3Dmol format */
const FILES = {
  'x.cif': `data_test
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
O1 O 0.00000 0.00000 0.00000
H1 H 0.09580 0.00000 0.00000
H2 H -0.02400 0.09270 0.00000
`,
  'x.mol2': `@<TRIPOS>MOLECULE
water
 3 2 1 0 0
SMALL
NO_CHARGES

@<TRIPOS>ATOM
      1 O           0.0000    0.0000    0.0000 O.3     1  HOH   0.0000
      2 H           0.9580    0.0000    0.0000 H       1  HOH   0.0000
      3 H          -0.2400    0.9270    0.0000 H       1  HOH   0.0000
@<TRIPOS>BOND
     1    1    2 1
     2    1    3 1
`,
  'x.pqr': `ATOM      1  O   HOH A   1       0.000   0.000   0.000 -0.8340 1.7683
ATOM      2  H1  HOH A   1       0.958   0.000   0.000  0.4170 0.0000
ATOM      3  H2  HOH A   1      -0.240   0.927   0.000  0.4170 0.0000
END
`,
  /* Correct PDB columns, with AutoDock types where the element belongs — which is exactly
     what makes a plain PDB reader drop every hydrogen, and what pdbqtToPdb() strips. */
  'x.pdbqt': `ATOM      1  O   LIG A   1       0.000   0.000   0.000  1.00  0.00    -0.834 OA
ATOM      2  H1  LIG A   1       0.958   0.000   0.000  1.00  0.00     0.417 HD
ATOM      3  H2  LIG A   1      -0.240   0.927   0.000  1.00  0.00     0.417 HD
END
`,
  'x.cube': `water cube
generated for a test
    3    0.000000    0.000000    0.000000
    2    0.500000    0.000000    0.000000
    2    0.000000    0.500000    0.000000
    2    0.000000    0.000000    0.500000
    8    8.000000    0.000000    0.000000    0.000000
    1    1.000000    1.810322    0.000000    0.000000
    1    1.000000   -0.453543    1.751823    0.000000
 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1
`,
  'x.gro': `water
    3
    1SOL     OW    1   0.000   0.000   0.000
    1SOL    HW1    2   0.096   0.000   0.000
    1SOL    HW2    3  -0.024   0.093   0.000
   2.00000   2.00000   2.00000
`,
  'x.sdf': `water
  test

  3  2  0  0  0  0  0  0  0  0999 V2000
    0.0000    0.0000    0.0000 O   0  0
    0.9580    0.0000    0.0000 H   0  0
   -0.2400    0.9270    0.0000 H   0  0
  1  2  1  0
  1  3  1  0
M  END
$$$$
`,
};
for (const [name, text] of Object.entries(FILES)) {
  await page.evaluate(async ([n, t]) => { await dworm2d.openFile(new File([t], n, { type: 'text/plain' })); }, [name, text]);
  await page.waitForTimeout(350);
  const r = await page.evaluate(() => ({
    n: dworm2d.viewer.getModel() ? dworm2d.viewer.getModel().selectedAtoms({}).length : 0,
    msg: document.getElementById('msg').textContent,
    cls: document.getElementById('msg').className,
  }));
  check(`${name} opens`, r.n === 3 && r.cls !== 'err', `${r.n} atoms — ${r.msg.slice(0, 90)}`);
}
{
  const poscar = `water
1.0
 10.0 0.0 0.0
 0.0 10.0 0.0
 0.0 0.0 10.0
O H
1 2
Cartesian
 0.000 0.000 0.000
 0.958 0.000 0.000
 -0.240 0.927 0.000
`;
  await page.evaluate(async (t) => { await dworm2d.openFile(new File([t], 'CONTCAR', { type: 'text/plain' })); }, poscar);
  await page.waitForTimeout(300);
  const n = await page.evaluate(() => dworm2d.state3d.nAtoms);
  check('CONTCAR opens by its name', n === 3, 'atoms ' + n);
}
/* a topology with no coordinates must say so, not show an empty panel */
{
  await page.evaluate(async () => {
    await dworm2d.openFile(new File(['%VERSION  VERSION_STAMP = V0001.000\n%FLAG TITLE\n%FORMAT(20a4)\ntest\n'], 'x.prmtop', { type: 'text/plain' }));
  });
  await page.waitForTimeout(300);
  const r = await page.evaluate(() => ({ msg: document.getElementById('msg').textContent, cls: document.getElementById('msg').className }));
  check('an Amber topology with no coordinates explains itself',
    /no coordinates|inpcrd|rst7|coordinate/i.test(r.msg), r.msg.slice(0, 120));
}

/* The one that mattered most: 3Dmol's PDB reader discards hydrogens unless asked not to,
   so until keepH was passed every .pdb arrived stripped of them — invisibly, because a
   structure without hydrogens looks perfectly ordinary. */
{
  const withH = `ATOM      1  O   LIG A   1       0.000   0.000   0.000  1.00  0.00           O
ATOM      2  H1  LIG A   1       0.958   0.000   0.000  1.00  0.00           H
ATOM      3  H2  LIG A   1      -0.240   0.927   0.000  1.00  0.00           H
END
`;
  await page.evaluate(async (t) => { await dworm2d.openFile(new File([t], 'h.pdb', { type: 'text/plain' })); }, withH);
  await page.waitForTimeout(300);
  const r = await page.evaluate(() => {
    const a = dworm2d.viewer.getModel().selectedAtoms({});
    return { n: a.length, h: a.filter(x => x.elem === 'H').length, status: document.getElementById('status3d').textContent };
  });
  check('a PDB keeps its hydrogens', r.n === 3 && r.h === 2, `${r.n} atoms, ${r.h} H — ${r.status}`);
}

/* ------------------------------------------- the measurement, read at arm's length
   A bond length hidden at the end of a status sentence is a number you have to hunt for.
   It gets its own line: the WORD first so you know what you are being told, then the figure
   large enough to read from across a desk, then which atoms it belongs to. */
{
  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CC(C)Cc1ccc(cc1)C(C)C(=O)O'); });
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  const read = async (n) => page.evaluate(k => {
    const d = window.dworm2d;
    d.state3d.sel = [...Array(k).keys()];
    d.applyStyle(d.viewer); d.saySelection();
    const el = document.getElementById('measure3d');
    return { hidden: el.hidden,
             what: (el.querySelector('.what') || {}).textContent,
             val: (el.querySelector('.val') || {}).textContent,
             who: (el.querySelector('.who') || {}).textContent,
             size: parseFloat(getComputedStyle(el.querySelector('.val') || el).fontSize),
             bold: getComputedStyle(el.querySelector('.val') || el).fontWeight };
  }, n);
  const two = await read(2);
  check('two atoms give a distance, with the word first and the number after',
    two.what === 'Distance' && /^\d+\.\d{3} Å$/.test(two.val), JSON.stringify(two));
  check('and the number is large and bold, not buried in a sentence',
    two.size >= 18 && Number(two.bold) >= 600, `${two.size}px, weight ${two.bold}`);
  check('and it says which atoms it measured', /^[A-Z][a-z]?\d+ – [A-Z][a-z]?\d+$/.test(two.who), two.who);
  const three = await read(3);
  check('three atoms give an angle', three.what === 'Angle' && /°$/.test(three.val), JSON.stringify(three));
  const four = await read(4);
  check('four atoms give a dihedral', four.what === 'Dihedral' && /°$/.test(four.val), JSON.stringify(four));
  const one = await read(1);
  check('one atom measures nothing, and the line goes away', one.hidden === true);

  /* The halo is glass, not paint: it read as a big coloured ATOM before, and a selected
     carbon could be taken for an element that is not in the molecule. */
  await page.evaluate(() => { const d = window.dworm2d; d.state3d.sel = [0, 1]; d.applyStyle(d.viewer); });
  const halo = await page.evaluate(() => {
    const v = dworm2d.viewer, a = v.getModel().selectedAtoms({});
    const s = v.shapes[0];
    return s ? { op: s.opacity, r: s.intersectionShape.sphere[0].radius,
                 atom: a[0].style.sphere ? a[0].style.sphere.radius : null } : null;
  });
  check('a selected atom is marked with a transparent halo you can see through',
    halo && halo.op > 0 && halo.op < 0.6, JSON.stringify(halo));
  check('and it is only a little larger than the atom, not a replacement for it',
    halo && halo.atom && halo.r / halo.atom > 1.1 && halo.r / halo.atom < 1.8,
    `halo ${halo && halo.r} vs atom ${halo && halo.atom}`);
}


/* ============================ residues in the readout, and one chain at a time
   A deposited structure names its atoms far better than we can — CA says something, C312
   says nothing — so the readout uses the file's own atom names and reports which residues
   the picked atoms sit in. A drawing has neither, and must get no empty brackets. */
{
  const twoChain = (() => {
    let out = 'HEADER TEST\n', n = 1;
    for (const [ch, nres] of [['A', 6], ['B', 4]]) {
      for (let r = 0; r < nres; r++) {
        for (const [nm, el, dx] of [['N', 'N', 0], ['CA', 'C', 1.45], ['C', 'C', 2.4], ['O', 'O', 3.0], ['CB', 'C', 1.6]]) {
          out += 'ATOM  ' + String(n).padStart(5) + ' ' + nm.padEnd(4) + ' ' + (r % 2 ? 'LEU' : 'ALA') + ' ' + ch +
                 String(r + 1).padStart(4) + '    ' +
                 (dx + r * 3.5).toFixed(3).padStart(8) +
                 ((ch === 'A' ? 0 : 8) + (nm === 'CB' ? 1.4 : 0)).toFixed(3).padStart(8) +
                 (r * 0.7).toFixed(3).padStart(8) + '  1.00  0.00          ' + el.padStart(2) + '\n';
          n++;
        }
      }
    }
    return out + 'END\n';
  })();
  await page.evaluate(p2 => dworm2d.show3d(p2, 'pdb', 'file', 'two.pdb'), twoChain);
  await page.waitForTimeout(700);

  const ch = await page.evaluate(() => ({
    hidden: document.getElementById('selChain').hidden,
    opts: [...document.getElementById('selChain').options].map(o => o.value),
  }));
  check('a structure with two chains offers to show one at a time',
    !ch.hidden && ch.opts.join(',') === ',A,B', JSON.stringify(ch));
  await page.selectOption('#selChain', 'B');
  await page.waitForTimeout(600);
  const only = await page.evaluate(() => {
    const styled = dworm2d.viewer.getModel().selectedAtoms({}).filter(a => a.style && Object.keys(a.style).length);
    return { n: styled.length, chains: [...new Set(styled.map(a => a.chain))] };
  });
  check('and choosing one leaves only that chain drawn', only.chains.join('') === 'B' && only.n === 20,
    JSON.stringify(only));
  await page.selectOption('#selChain', '');
  await page.waitForTimeout(400);

  await page.evaluate(() => { dworm2d.state3d.sel = [0, 1, 5, 6]; dworm2d.applyStyle(dworm2d.viewer); dworm2d.saySelection(); });
  await page.waitForTimeout(250);
  const m = await page.evaluate(() => {
    const el = document.getElementById('measure3d');
    return { who: el.querySelector('.who').textContent,
             res: el.querySelector('.res') ? el.querySelector('.res').textContent : null };
  });
  check('the atoms are named the way the file names them', m.who === 'N – CA – N – CA', m.who);
  check('and the residues are in brackets, three-letter, with number and chain',
    m.res === '(ALA 1 A, LEU 2 A)', String(m.res));

  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CCCC'); });
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  await page.evaluate(() => { dworm2d.state3d.sel = [0, 1]; dworm2d.saySelection(); });
  const drawn = await page.evaluate(() => {
    const el = document.getElementById('measure3d');
    return { who: el.querySelector('.who').textContent, res: !!el.querySelector('.res'),
             chain: document.getElementById('selChain').hidden };
  });
  check('a drawing has no residues, so it gets no brackets and no chain menu',
    !drawn.res && drawn.chain && drawn.who === 'C1 – C2', JSON.stringify(drawn));
}

const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
