/* EXPERT: moving atoms and changing bonds by hand in the 3D view.
 *
 * These tools are the only place in the page where the mouse changes the STRUCTURE rather
 * than the view, so the things worth testing are the ones that are invisible in a screenshot
 * and obvious in use: that a drag goes where the pointer went — the vertical sign above all,
 * which is the classic error here and looks perfectly normal until you try it — that dragging
 * a molecule takes the whole molecule and nothing else, that a removed bond stays removed
 * rather than being perceived back, that a dashed line is not a bond anywhere it would
 * matter, and that undo really restores what was there.
 *
 * Everything is driven through real pointer events at real screen positions, not by calling
 * the functions with made-up numbers: the arithmetic that could be wrong is the arithmetic
 * between a pixel and an angstrom.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8796;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
/* The 3D panel gets the whole window (⛶ once — solo, with its own bars still there). The drag
   tests click on atoms by their projected positions, and in a half-width panel under three
   rows of EXPERT controls two atoms of ethanol project four pixels apart: a click meant for
   one lands on the other, and the failure looks like a bug in the tools. Build 24 found the
   same thing when the EXPERT bar wrapped; build 25 added a row to it. A wide canvas is what a
   person editing by hand would use too. */
await page.click('#btnSolo3d');
await page.waitForTimeout(400);

const build = async (smiles) => {
  await page.evaluate(async (s) => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule(s); }, smiles);
  await page.click('#btnMake3d');
  await page.waitForFunction((s) => window.dworm2d.state3d.nAtoms > 0 && !document.getElementById('btnMake3d').classList.contains('running'), smiles, { timeout: 120000 });
  await page.waitForTimeout(250);
};
/** Where every atom is on screen right now, in the same page coordinates a click uses. */
const screenPts = () => page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  return window.dworm2d.viewer.modelToScreen(a.map(x => ({ x: x.x, y: x.y, z: x.z })));
});
const coords = () => page.evaluate(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => [a.x, a.y, a.z]));
const bondsOf = () => page.evaluate(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map(a => (a.bonds || []).slice().sort((x, y) => x - y)));
const drag = async (from, dx, dy) => {
  await page.mouse.move(from.x, from.y);
  await page.mouse.down();
  await page.mouse.move(from.x + dx, from.y + dy, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(220);
};
const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]);

/* ------------------------------------------------------------------ the mode */
await build('CCO');
check('the editing row is behind its button, not in the way of everyone else',
  await page.getAttribute('#editBar', 'hidden') !== null && await page.isVisible('#btnEdit'));
await page.click('#btnEdit');
check('EXPERT opens it', await page.isVisible('#editBar') && await page.evaluate(() => window.dworm2d.editOn));
check('and it opens on VIEW, so nothing is armed until it is chosen',
  await page.evaluate(() => window.dworm2d.editTool) === '' &&
  await page.getAttribute('#orderSeg', 'hidden') !== null);

/* ------------------------------------------------------- DRAG ATOM, and the sign */
await page.click('#toolSeg button[data-tool="atom"]');
check('DRAG ATOM arms, and says what to do', await page.evaluate(() => window.dworm2d.editTool) === 'atom' &&
  /Drag an atom/.test(await page.textContent('#editHint')));
let pts = await screenPts();
const before = await coords();
await drag(pts[0], 0, 70);
let now = await screenPts();
/* THE VERTICAL SIGN. Screen y grows downward and model y grows upward, so a mapping that
   forgets it moves the atom the opposite way — which looks entirely normal in a picture and
   is unusable in the hand. Asserted in pixels, at the place the pointer actually went. */
check('an atom follows the pointer DOWN the screen, and by the distance the pointer moved',
  Math.abs((now[0].y - pts[0].y) - 70) < 4 && Math.abs(now[0].x - pts[0].x) < 4,
  `moved ${(now[0].y - pts[0].y).toFixed(1)} px down, ${(now[0].x - pts[0].x).toFixed(1)} across, asked for 70 and 0`);
await drag(now[0], 90, 0);
now = await screenPts();
check('and to the RIGHT when the pointer goes right',
  Math.abs((now[0].x - pts[0].x) - 90) < 4 && Math.abs((now[0].y - pts[0].y) - 70) < 4,
  `now ${(now[0].x - pts[0].x).toFixed(1)} across, ${(now[0].y - pts[0].y).toFixed(1)} down`);
const moved = await coords();
check('it moved in the plane of the screen and not toward the camera',
  moved.slice(1).every((p, i) => dist(p, before[i + 1]) < 1e-6),
  'other atoms displaced by at most ' + Math.max(...moved.slice(1).map((p, i) => dist(p, before[i + 1]))).toExponential(1) + ' A');
check('UNDO is offered once there is something to undo', await page.evaluate(() => window.dworm2d.undoDepth) === 2 &&
  await page.getAttribute('#btnUndo', 'disabled') === null);
await page.click('#btnUndo');
await page.click('#btnUndo');
await page.waitForTimeout(250);
const restored = await coords();
check('UNDO restores the structure exactly, one step at a time',
  restored.every((p, i) => dist(p, before[i]) < 1e-9) && await page.evaluate(() => window.dworm2d.undoDepth) === 0,
  'largest residual ' + Math.max(...restored.map((p, i) => dist(p, before[i]))).toExponential(1) + ' A');
check('and switches itself off when there is nothing left', await page.getAttribute('#btnUndo', 'disabled') !== null);

/* --------------------------------------------------------------- a whole molecule */
await build('CCO.O');
await page.click('#toolSeg button[data-tool="move"]');
const two = await page.evaluate(() => ({ a: window.dworm2d.fragmentOf(0).length, all: window.dworm2d.viewer.getModel().selectedAtoms({}).length }));
check('two molecules in one structure are seen as two',
  two.all === 12 && two.a === 9, `${two.all} atoms, the first molecule has ${two.a}`);
pts = await screenPts();
const bothBefore = await coords();
const frag = await page.evaluate(() => window.dworm2d.fragmentOf(0));
await drag(pts[0], 0, 60);
const bothAfter = await coords();
const inFrag = frag.map(i => dist(bothAfter[i], bothBefore[i]));
const outside = bothAfter.map((p, i) => frag.includes(i) ? 0 : dist(p, bothBefore[i]));
check('DRAG MOLECULE moves every atom of that molecule by the same amount',
  Math.max(...inFrag) - Math.min(...inFrag) < 1e-6 && Math.min(...inFrag) > 0.2,
  `each of ${frag.length} atoms moved ${inFrag[0].toFixed(3)} A`);
check('and leaves the other molecule exactly where it was',
  Math.max(...outside) < 1e-9, 'the water moved ' + Math.max(...outside).toExponential(1) + ' A');
const shape = (c, f) => f.map(i => dist(c[i], c[f[0]]));
check('a molecule that is dragged is not deformed by it',
  shape(bothAfter, frag).every((d, i) => Math.abs(d - shape(bothBefore, frag)[i]) < 1e-6));

/* ------------------------------------------------ ALT + DRAG MOLECULES: turning it
   D-WORM's third tool has a modifier: with ALT held, the fragment turns about its own
   centroid instead of sliding. This used to be shipped here AS "angle pan", which was the
   bug — angle panning is a different gesture entirely and is tested below. */
const centre = (c, f) => f.reduce((a, i) => [a[0] + c[i][0] / f.length, a[1] + c[i][1] / f.length, a[2] + c[i][2] / f.length], [0, 0, 0]);
pts = await screenPts();
const turnBefore = await coords();
await page.keyboard.down('Alt');
await drag(pts[0], 100, 0);
await page.keyboard.up('Alt');
const turnAfter = await coords();
const c0 = centre(turnBefore, frag), c1 = centre(turnAfter, frag);
check('ALT + DRAG MOLECULES turns it about its own centre, which does not move',
  dist(c0, c1) < 1e-6 && frag.some(i => dist(turnAfter[i], turnBefore[i]) > 0.3),
  `centre moved ${dist(c0, c1).toExponential(1)} A, the furthest atom ${Math.max(...frag.map(i => dist(turnAfter[i], turnBefore[i]))).toFixed(2)} A`);
check('turning changes no bond length: it is a rotation, not a stretch',
  frag.every(i => Math.abs(dist(turnAfter[i], c1) - dist(turnBefore[i], c0)) < 1e-6),
  'largest change in radius ' + Math.max(...frag.map(i => Math.abs(dist(turnAfter[i], c1) - dist(turnBefore[i], c0)))).toExponential(1) + ' A');
check('and it turns only the molecule that was grabbed',
  turnAfter.every((p, i) => frag.includes(i) || dist(p, turnBefore[i]) < 1e-9));

/* --------------------------------------------------------------- ANGLE PANNING
   The tool that was missing. In D-WORM it is not a rotation of the fragment: the grabbed
   atom SWINGS about a pivot neighbour, carrying everything attached to it, with the bond to
   the pivot frozen so that only the 3D angle changes. Nothing else in the structure moves —
   the pivot least of all. ALT frees the length and lets the bond stretch as it swings.

   Ethanol, atom 0, is the terminal methyl carbon: its pivot is the heavy neighbour with the
   larger branch (atom 1), so the SMALLER side — the methyl and its three hydrogens — is what
   swings. That is the rule that makes the tool feel right: grabbing the small end of a
   molecule moves the small end. */
await build('CCO');
await page.click('#toolSeg button[data-tool="angle"]');
check('ANGLE PANNING arms, and says what the modifier does',
  await page.evaluate(() => window.dworm2d.editTool) === 'angle' &&
  /swings about its pivot/.test(await page.textContent('#editHint')) &&
  /ALT frees the bond/.test(await page.textContent('#editHint')));
const nbOf = () => page.evaluate(() => window.dworm2d.neighboursOf());
const nb = await nbOf();
const pivot0 = await page.evaluate(() => window.dworm2d.pivotFor(0, window.dworm2d.neighboursOf()));
check('the pivot of a terminal carbon is its heavy neighbour, not one of its hydrogens',
  pivot0 === 1, 'pivot chosen: atom ' + pivot0 + ', neighbours ' + JSON.stringify(nb[0]));
const swing0 = (await page.evaluate(() => [...window.dworm2d.swingSet(0, 1, window.dworm2d.neighboursOf())])).sort((a, b) => a - b);
check('and what swings is the branch AWAY from the pivot — the methyl, hydrogens included',
  swing0.length === 4 && swing0.includes(0) && !swing0.includes(1) && !swing0.includes(2),
  'moving set ' + JSON.stringify(swing0));
pts = await screenPts();
const swBefore = await coords();
const ang0 = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  const v = (p, q) => [p.x - q.x, p.y - q.y, p.z - q.z], d = (u, w) => u[0] * w[0] + u[1] * w[1] + u[2] * w[2];
  const u = v(a[0], a[1]), w = v(a[2], a[1]);
  return Math.acos(d(u, w) / Math.sqrt(d(u, u) * d(w, w))) * 180 / Math.PI;
});
await drag(pts[0], 0, 90);
const swAfter = await coords();
const ang1 = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  const v = (p, q) => [p.x - q.x, p.y - q.y, p.z - q.z], d = (u, w) => u[0] * w[0] + u[1] * w[1] + u[2] * w[2];
  const u = v(a[0], a[1]), w = v(a[2], a[1]);
  return Math.acos(d(u, w) / Math.sqrt(d(u, u) * d(w, w))) * 180 / Math.PI;
});
check('the atom swings: the C–C bond length is FROZEN, to nine figures',
  Math.abs(dist(swAfter[0], swAfter[1]) - dist(swBefore[0], swBefore[1])) < 1e-6,
  `${dist(swBefore[0], swBefore[1]).toFixed(6)} -> ${dist(swAfter[0], swAfter[1]).toFixed(6)} A`);
/* How MUCH it swings depends on how many pixels an angstrom is worth, which depends on the
   size of the panel — so the threshold is deliberately loose. What is being asserted is that
   the angle is the thing that moved while the bond length above did not; the exact number is
   the pointer's business, not the tool's. */
check('and the angle it subtends at the pivot is what actually changed',
  Math.abs(ang1 - ang0) > 3, `C–C–O went ${ang0.toFixed(1)}° -> ${ang1.toFixed(1)}°`);
check('the pivot does not move — it is the thing being swung about',
  dist(swAfter[1], swBefore[1]) < 1e-9, dist(swAfter[1], swBefore[1]).toExponential(1) + ' A');
check('everything attached to the grabbed atom comes with it',
  swing0.filter(i => i !== 0).every(i => dist(swAfter[i], swBefore[i]) > 0.2),
  'carried atoms moved ' + swing0.filter(i => i !== 0).map(i => dist(swAfter[i], swBefore[i]).toFixed(2)).join(', ') + ' A');
check('and nothing on the far side of the pivot moves at all',
  swBefore.every((p, i) => swing0.includes(i) || dist(swAfter[i], p) < 1e-9),
  'largest stray displacement ' +
  Math.max(...swBefore.map((p, i) => swing0.includes(i) ? 0 : dist(swAfter[i], p))).toExponential(1) + ' A');
const rigid = (a, b, set) => set.every(i => set.every(j => Math.abs(dist(a[i], a[j]) - dist(b[i], b[j])) < 1e-6));
check('the swinging group is carried rigidly: it turns, it does not deform',
  rigid(swBefore, swAfter, swing0));
/* ALT is the escape hatch: sometimes you want the bond to get longer while you aim it. */
pts = await screenPts();
const altBefore = await coords();
await page.keyboard.down('Alt');
await drag(pts[0], 70, 0);
await page.keyboard.up('Alt');
const altAfter = await coords();
check('ALT frees the length: the same gesture now stretches the bond as it swings',
  Math.abs(dist(altAfter[0], altAfter[1]) - dist(altBefore[0], altBefore[1])) > 0.2,
  `${dist(altBefore[0], altBefore[1]).toFixed(3)} -> ${dist(altAfter[0], altAfter[1]).toFixed(3)} A`);
check('but it still swings about the pivot, which still does not move',
  dist(altAfter[1], altBefore[1]) < 1e-9);
check('and it still carries only the branch away from the pivot',
  altBefore.every((p, i) => swing0.includes(i) || dist(altAfter[i], p) < 1e-9));

/* ------------------------------------------------------- a ring has no far side
   Swinging an atom of a ring about a ring neighbour would have to break the ring, because
   the "branch away from the pivot" comes back round to the pivot. D-WORM's answer is to
   swing the atom with its exocyclic groups only and leave the ring where it is. */
await build('c1ccccc1');
await page.click('#toolSeg button[data-tool="angle"]');
const ringSet = (await page.evaluate(() => {
  const nb = window.dworm2d.neighboursOf();
  return [...window.dworm2d.swingSet(0, window.dworm2d.pivotFor(0, nb), nb)];
})).sort((a, b) => a - b);
check('a ring atom swings with its exocyclic hydrogen only — the ring is not torn open',
  ringSet.length === 2 && ringSet[0] === 0, 'moving set ' + JSON.stringify(ringSet));
pts = await screenPts();
const ringBefore = await coords();
await drag(pts[0], 0, 55);
const ringAfter = await coords();
check('so five of the six carbons of benzene stay exactly where they were',
  ringBefore.every((p, i) => ringSet.includes(i) || dist(ringAfter[i], p) < 1e-9) &&
  dist(ringAfter[0], ringBefore[0]) > 0.2,
  'the grabbed carbon moved ' + dist(ringAfter[0], ringBefore[0]).toFixed(2) + ' A');

/* --------------------------------------------- what one selected atom is actually for
   A press that does not move is a PICK, and a pick names the pivot for the next swing and
   the bond to keep for ALT + DRAG ATOM. Ethanol's oxygen has two neighbours, so without a
   pick there is nothing for ALT + DRAG ATOM to hold on to. */
await build('CCO');
await page.click('#toolSeg button[data-tool="atom"]');
pts = await screenPts();
await page.mouse.click(pts[1].x, pts[1].y);
await page.waitForTimeout(450);
check('a press without a drag picks the atom rather than moving it, and says why',
  JSON.stringify(await page.evaluate(() => window.dworm2d.state3d.sel)) === '[1]' &&
  /pivot for the next swing/.test(await page.textContent('#editHint')),
  JSON.stringify(await page.evaluate(() => window.dworm2d.state3d.sel)));
check('and a pick is not an undo step: nothing was changed',
  await page.evaluate(() => window.dworm2d.undoDepth) === 0);
/* a selection makes MINIMISE SELECTION appear, which reflows the bar above the viewer, so
   every screen position taken before the pick is now a few pixels out */
pts = await screenPts();
const holdBefore = await coords();
await page.keyboard.down('Alt');
await drag(pts[2], 60, 40);
await page.keyboard.up('Alt');
const holdAfter = await coords();
check('ALT + DRAG ATOM then holds the bond to the PICKED neighbour, exactly',
  Math.abs(dist(holdAfter[2], holdAfter[1]) - dist(holdBefore[2], holdBefore[1])) < 1e-6 &&
  dist(holdAfter[2], holdBefore[2]) > 0.2,
  `O–C ${dist(holdBefore[2], holdBefore[1]).toFixed(6)} -> ${dist(holdAfter[2], holdAfter[1]).toFixed(6)} A, ` +
  `the oxygen moved ${dist(holdAfter[2], holdBefore[2]).toFixed(2)} A`);
check('it moves that atom alone: ALT + DRAG ATOM is not a swing',
  holdBefore.every((p, i) => i === 2 || dist(holdAfter[i], p) < 1e-9));
check('the picked atom is now the pivot a swing would use',
  await page.evaluate(() => window.dworm2d.pivotFor(2, window.dworm2d.neighboursOf())) === 1);
/* the same drag without ALT is the plain tool again: the bond is free to stretch */
const freeBefore = await coords();
pts = await screenPts();
/* 120 px to the RIGHT, not 50 to the left: since build 25 a structure opens framed to its
   extent (120 px/A at most), and this conformer's C-O bond points nearly at the camera, so a
   drag towards the carbon's projection barely changes the length (0.07 A, under the
   threshold) while a drag away from it stretches it plainly. */
await drag(pts[2], 120, 0);
const freeAfter = await coords();
check('without ALT the bond stretches, which is the whole difference between the two',
  Math.abs(dist(freeAfter[2], freeAfter[1]) - dist(freeBefore[2], freeBefore[1])) > 0.15,
  `${dist(freeBefore[2], freeBefore[1]).toFixed(3)} -> ${dist(freeAfter[2], freeAfter[1]).toFixed(3)} A`);
await page.evaluate(() => window.dworm2d.clearSelection());

/* ---------------------------------------------------- a terminal atom needs no pick */
await build('CCO');
await page.click('#toolSeg button[data-tool="atom"]');
const hIdx = await page.evaluate(() => window.dworm2d.viewer.getModel().selectedAtoms({}).findIndex(a => a.elem === 'H'));
const hHost = (await nbOf())[hIdx][0];
pts = await screenPts();
const hBefore = await coords();
await page.keyboard.down('Alt');
await drag(pts[hIdx], 45, 45);
await page.keyboard.up('Alt');
const hAfter = await coords();
check('an atom with ONE neighbour needs no pick: ALT holds the only bond it has',
  Math.abs(dist(hAfter[hIdx], hAfter[hHost]) - dist(hBefore[hIdx], hBefore[hHost])) < 1e-6 &&
  dist(hAfter[hIdx], hBefore[hIdx]) > 0.1,
  `H${hIdx}–${hHost} ${dist(hBefore[hIdx], hBefore[hHost]).toFixed(6)} -> ${dist(hAfter[hIdx], hAfter[hHost]).toFixed(6)} A`);
/* Running the pointer past the edge of the sphere has no solution; the rim is used instead,
   which is what stops the atom vanishing when you overshoot. */
pts = await screenPts();
const rimBefore = await coords();
await page.keyboard.down('Alt');
await drag(pts[hIdx], 400, 0);
await page.keyboard.up('Alt');
const rimAfter = await coords();
check('and dragging far past the sphere pins the atom to its rim rather than losing it',
  Math.abs(dist(rimAfter[hIdx], rimAfter[hHost]) - dist(rimBefore[hIdx], rimBefore[hHost])) < 1e-6 &&
  rimAfter[hIdx].every(Number.isFinite),
  `bond ${dist(rimAfter[hIdx], rimAfter[hHost]).toFixed(6)} A, at ` + rimAfter[hIdx].map(n => n.toFixed(2)).join(', '));
await build('CCO.O');
await page.click('#toolSeg button[data-tool="move"]');

/* ----------------------------------------------------------------------- bonds */
await build('CCO.O');
await page.click('#toolSeg button[data-tool="bond"]');
check('the bond-order row appears only for the BOND tool', await page.getAttribute('#orderSeg', 'hidden') === null);

/* ------------------------------------------- the atom a bond is being drawn FROM
   Two clicks make a bond, and between them the page has to show which atom it is drawing
   from. It did not, and "I click two atoms and see nothing" is what came back. The mark is
   BLUE, where a picked atom is magenta, because they mean different things: one is a choice
   that travels in a shared link, the other is a half-finished gesture. */
/* 3Dmol keeps a shape's colour as r/g/b floats rather than a string, so the two markers are
   told apart by which channel dominates: blue for a bond in progress, magenta for a pick. */
const shapes = () => page.evaluate(() => window.dworm2d.viewer.shapes.map(sh => {
  const c = sh.color || {};
  const kind = (c.b > c.r ? 'blue' : c.r > c.b ? 'magenta' : '?');
  return kind + (sh.wireframe ? ' cage' : '');
}));
pts = await screenPts();
const noMark = await shapes();
await page.mouse.click(pts[0].x, pts[0].y);
await page.waitForTimeout(250);
const oneMark = await shapes();
check('the first atom of a bond is marked, in blue, as soon as it is clicked',
  oneMark.length === noMark.length + 1 && oneMark.some(k => k.startsWith('blue')),
  JSON.stringify(oneMark));
await page.keyboard.press('Escape');
await page.waitForTimeout(250);
check('and the mark goes when the bond is abandoned',
  (await shapes()).length === noMark.length);
await page.click('#toolSeg button[data-tool="bond"]');
await page.click('#orderSeg button[data-order="1"]');
pts = await screenPts();
await page.mouse.click(pts[0].x, pts[0].y);
await page.mouse.click(pts[1].x, pts[1].y);
await page.waitForTimeout(250);
check('and it goes when the bond is made, because the gesture is finished',
  (await shapes()).filter(c => c.startsWith('blue')).length === 0, JSON.stringify(await shapes()));

/* -------------------------------------------------- three ways of marking an atom
   The outline is ONE pass over the whole scene and there is no per-object way to turn it
   off — except that the renderer skips any WIREFRAME material, which is what `cage` is for.
   Measured on a black background: a solid halo under a white outline comes out entirely
   white, and a cage keeps its own colour. `tint` adds no shape at all. */
await page.evaluate(() => { window.dworm2d.state3d.sel.splice(0, 99, 0, 1); window.dworm2d.applyStyle(window.dworm2d.viewer); });
await page.waitForTimeout(450);
const haloCount = async (style) => {
  await page.selectOption('#selHalo', style);
  await page.waitForTimeout(250);
  return page.evaluate(() => ({
    n: window.dworm2d.viewer.shapes.length,
    cage: window.dworm2d.viewer.shapes.filter(sh => sh.wireframe).length,
    opt: window.dworm2d.opts.halo }));
};
const solid = await haloCount('solid'), cage = await haloCount('cage'), tint = await haloCount('tint');
check('solid draws a filled ball for each picked atom', solid.n === 2 && solid.cage === 0, JSON.stringify(solid));
check('cage draws the same balls as WIREFRAME, which is the one thing the outline pass skips',
  cage.n === 2 && cage.cage === 2, JSON.stringify(cage));
check('tint adds no shape at all — it colours the atoms themselves, so nothing is added to the picture',
  tint.n === 0 && tint.opt === 'tint', JSON.stringify(tint));
check('and the choice travels in a shared link, so the recipient sees the same marks',
  (await page.evaluate(async () => (await window.dworm2d.buildState('full')).o.halo)) === 'tint');
await page.selectOption('#selHalo', 'solid');
await page.evaluate(() => window.dworm2d.clearSelection());
await page.click('#toolSeg button[data-tool="bond"]');
await page.click('#orderSeg button[data-order="2"]');
pts = await screenPts();
const b0 = await bondsOf();
/* atom 0 and atom 2 are the two carbons and the oxygen of ethanol: 0-1 is a real bond */
check('ethanol arrives bonded as ethanol', b0[0].includes(1) && !b0[0].includes(2), JSON.stringify(b0.slice(0, 3)));
await page.click('#orderSeg button[data-order="2"]');
await page.mouse.click(pts[0].x, pts[0].y);
check('one click arms the first atom and says so', /second atom/.test(await page.textContent('#editHint')));
await page.mouse.click(pts[1].x, pts[1].y);
await page.waitForTimeout(450);
const order = await page.evaluate(() => {
  const a = window.dworm2d.viewer.getModel().selectedAtoms({});
  return a[0].bondOrder[a[0].bonds.indexOf(1)];
});
check('two clicks make it a double bond', order === 2, 'order ' + order);
check('and the molfile the page would export says so too',
  /^ {2}1 {2}2 {2}2/m.test(await page.evaluate(() => window.dworm2d.state3d.molblock || '')),
  (await page.evaluate(() => (window.dworm2d.state3d.molblock || '').split('\n').slice(-4, -1).join(' | '))));
await page.click('#orderSeg button[data-order="x"]');
await page.mouse.click(pts[0].x, pts[0].y);
await page.mouse.click(pts[1].x, pts[1].y);
await page.waitForTimeout(450);
const b1 = await bondsOf();
check('and ✕ removes it', !b1[0].includes(1) && !b1[1].includes(0), JSON.stringify(b1.slice(0, 2)));
/* The trap: bond perception fills in bonds around any atom left with none, and around every
   metal. Without a flag saying an edit has happened it would put this one straight back. */
check('a removed bond STAYS removed — perception does not undo an explicit edit',
  !/^ {2}1 {2}2/m.test(await page.evaluate(() => window.dworm2d.state3d.molblock || '')) &&
  await page.evaluate(() => window.dworm2d.state3d.bondsEdited) === true);
check('the exported .xyz still has every atom, because a bond is not a coordinate',
  (await page.evaluate(() => window.dworm2d.toXYZ(window.dworm2d.viewerStruct()))).split('\n')[0].trim() === '12',
  (await page.evaluate(() => window.dworm2d.toXYZ(window.dworm2d.viewerStruct()))).split('\n')[0].trim() + ' atoms');

/* ------------------------------------------------------- a dashed line is not a bond */
await build('CCO.O');
await page.click('#toolSeg button[data-tool="bond"]');
await page.click('#orderSeg button[data-order="0"]');
pts = await screenPts();
await page.mouse.click(pts[2].x, pts[2].y);       // the ethanol oxygen
await page.mouse.click(pts[9].x, pts[9].y);       // the water oxygen
await page.waitForTimeout(250);
check('a dashed line is drawn between the two atoms',
  (await page.evaluate(() => window.dworm2d.dashedBonds.length)) === 1 &&
  (await page.evaluate(() => window.dworm2d.viewer.shapes.length)) >= 1,
  JSON.stringify(await page.evaluate(() => window.dworm2d.dashedBonds)));
const bd = await bondsOf();
check('and it is NOT a bond: nothing was joined',
  !bd[2].includes(9) && !bd[9].includes(2) && await page.evaluate(() => window.dworm2d.state3d.bondsEdited) === false,
  JSON.stringify([bd[2], bd[9]]));
check('it is not written into the molfile either',
  !/^ {2}3 {2}10/m.test(await page.evaluate(() => window.dworm2d.state3d.molblock || '')));
check('nor counted as connectivity by the force field',
  (await page.evaluate(() => window.dworm2d.viewerStruct().bonds.filter(b => (b.a === 2 && b.b === 9) || (b.a === 9 && b.b === 2)).length)) === 0);

/* -------------------------------------------------------------------- sharing */
const st = await page.evaluate(() => window.dworm2d.buildState('full'));
check('the dashed line travels in a shared link, because it is part of the picture',
  Array.isArray(st.dash) && st.dash.length === 1 && st.dash[0][0] === 2 && st.dash[0][1] === 9,
  JSON.stringify(st.dash));
check('and so do the coordinates, as a molfile with the bonds in it',
  typeof st.m3 === 'string' && /V2000/.test(st.m3) && st.m3f === 'mol',
  st.m3f + ', ' + (st.m3 || '').length + ' chars');
await page.evaluate(async (s) => { await window.dworm2d.applyState(s); }, st);
await page.waitForTimeout(600);
check('opening that link reproduces the dashed line',
  (await page.evaluate(() => window.dworm2d.dashedBonds.length)) === 1,
  JSON.stringify(await page.evaluate(() => window.dworm2d.dashedBonds)));
/* a link is text somebody else can edit, so an index past the end must not be drawn */
await page.evaluate(async (s) => { await window.dworm2d.applyState({ ...s, dash: [[0, 9999], [1, 2], ['x', 3], [4, 4]] }); }, st);
await page.waitForTimeout(600);
check('a link naming atoms that do not exist draws only the line that does',
  (await page.evaluate(() => JSON.stringify(window.dworm2d.dashedBonds))) === '[[1,2]]',
  await page.evaluate(() => JSON.stringify(window.dworm2d.dashedBonds)));

/* ------------------------------------------------- the drawing is never written to */
await build('CCO');
const ketBefore = await page.evaluate(async () => (await window.dworm2d.whenKetcher()).getSmiles());
await page.click('#toolSeg button[data-tool="atom"]');
pts = await screenPts();
await drag(pts[0], 120, 40);
const ketAfter = await page.evaluate(async () => (await window.dworm2d.whenKetcher()).getSmiles());
check('editing in 3D does not touch the drawing in Ketcher — there is no way back and it says so',
  ketBefore === ketAfter && /Ketcher is unchanged/.test(await page.textContent('#msg')),
  (await page.textContent('#msg')).slice(0, 70));
check('but the edited structure is what a link would now carry',
  await page.evaluate(() => window.dworm2d.state3d.source) === 'edited' &&
  typeof (await page.evaluate(async () => (await window.dworm2d.buildState('full')).m3)) === 'string');

/* ------------------------------------------ the viewer still belongs to the viewer */
await page.click('#toolSeg button[data-tool="atom"]');
const view0 = await page.evaluate(() => window.dworm2d.viewer.getView().slice(4).map(n => +n.toFixed(4)));
const rect = await page.$eval('#viewer3d', el => { const r = el.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; });
await drag({ x: rect.x + 20, y: rect.y + 20 }, 80, 60);       // empty background, no atom there
const view1 = await page.evaluate(() => window.dworm2d.viewer.getView().slice(4).map(n => +n.toFixed(4)));
check('with a tool armed, dragging the BACKGROUND still rotates the structure',
  view0.join(',') !== view1.join(','), view0.join(',') + ' -> ' + view1.join(','));
const c2 = await coords();
check('and rotating moves nothing: the structure is only being looked at',
  (await coords()).every((p, i) => dist(p, c2[i]) < 1e-12));
await page.keyboard.press('Escape');
check('Escape puts the mouse back to normal', await page.evaluate(() => window.dworm2d.editTool) === '');
await page.click('#btnEdit');
check('and the button closes the row again',
  await page.getAttribute('#editBar', 'hidden') !== null && await page.evaluate(() => window.dworm2d.editOn) === false);

/* --------------------------------------------------- a new structure forgets the old */
await build('CCO.O');
await page.click('#btnEdit');
await page.click('#toolSeg button[data-tool="bond"]');
await page.click('#orderSeg button[data-order="0"]');
pts = await screenPts();
await page.mouse.click(pts[2].x, pts[2].y);
await page.mouse.click(pts[9].x, pts[9].y);
await page.waitForTimeout(450);
check('there is a dashed line and an undo step to forget', await page.evaluate(() => window.dworm2d.dashedBonds.length) === 1);
await build('c1ccccc1');
check('a different structure drops them both, rather than drawing a line between two unrelated atoms',
  await page.evaluate(() => window.dworm2d.dashedBonds.length) === 0 &&
  await page.evaluate(() => window.dworm2d.undoDepth) === 0 &&
  await page.evaluate(() => window.dworm2d.state3d.bondsEdited) === false);

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
