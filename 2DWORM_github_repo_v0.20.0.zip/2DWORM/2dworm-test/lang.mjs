/* English, Arabic and Chinese, and Arabic right-to-left; then the Latin-script languages of
   build 20, and in build 24 Hindi (Devanagari) and Urdu (Perso-Arabic, right-to-left like
   Arabic and under the same rule: the text turns, the page does not).

   The design under test: the dictionary is keyed by the English string itself, so a missing
   translation is never a broken placeholder — it is English. That property is what makes a
   half-finished language safe to ship, so most of what is checked here is that a partial or
   damaged file degrades to English rather than to nonsense. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8789;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '6' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/* ------------------------------------------------- the files, before the browser */
const LANGS = ['en', 'ar', 'zh', 'pt', 'es', 'pl', 'de', 'it', 'hi', 'ur'];
const files = Object.fromEntries(LANGS.map(l =>
  [l, JSON.parse(readFileSync(APP + 'lang/' + l + '.json', 'utf8'))]));
const keys = (o) => Object.keys(o).filter(k => !k.startsWith('//'));
check('there is a language file for each offered language',
  readdirSync(APP + 'lang').filter(f => f.endsWith('.json')).length === LANGS.length,
  readdirSync(APP + 'lang').filter(f => f.endsWith('.json')).join(' '));
check('all of them carry exactly the same keys',
  LANGS.every(l => keys(files[l]).join(' ') === keys(files.en).join(' ')),
  LANGS.map(l => l + ' ' + keys(files[l]).length).join(', '));
check('the English file is the template: every value equals its key',
  keys(files.en).every(k => files.en[k] === k));
/* Which strings stay as they are is WRITTEN DOWN in the file, not inferred: "the Chinese is
   the same as the English" cannot tell an oversight from a decision about a brand name. */
const keep = new Set((files.en['//keep'] || '').split(': ').slice(1).join(': ').split(', '));
/* A word can come out of a translation unchanged and be perfectly correct — "Error" is
   "Error" in Spanish. That is a decision, not an oversight, so the file that made it says so
   in its own //same line rather than the check guessing which coincidences are allowed. */
const same = Object.fromEntries(LANGS.map(l =>
  [l, new Set((files[l]['//same'] || '').split(': ').slice(1).join(': ').split(', ').filter(Boolean))]));
const slipped = keys(files.en).filter(k => /[a-z]/.test(k) && !keep.has(k) &&
                                           LANGS.filter(l => l !== 'en').some(l => files[l][k] === k && !same[l].has(k)));
check('nothing is left untranslated by accident', slipped.length === 0, slipped.slice(0, 4).join(' | '));
check('and the ones that stay in English say so where a translator will see it',
  keep.size > 5 && keep.has('PubChem') && keep.has('Molfile V2000'), keep.size + ' listed');
check('the Arabic file really is Arabic', /[؀-ۿ]/.test(Object.values(files.ar).join('')));
check('the Chinese file really is Chinese', /[一-鿿]/.test(Object.values(files.zh).join('')));
check('the Portuguese file really is Portuguese', /ç|ã|õ|é/.test(Object.values(files.pt).join('')));
check('the Hindi file really is Devanagari', /[ऀ-ॿ]/.test(Object.values(files.hi).join('')));
check('the Urdu file really is Arabic script', /[؀-ۿ]/.test(Object.values(files.ur).join('')));
/* Urdu and Arabic share a block, so the block alone cannot tell an Urdu file from an Arabic
   one pasted under the wrong name. Urdu has letters Arabic does not — ٹ ڈ ڑ ں ے ہ — and any
   real Urdu text uses some of them within a sentence or two. */
check('and it is Urdu, not Arabic under another name: it uses letters Arabic does not have',
  /[ٹڈڑںےہ]/.test(Object.values(files.ur).join('')));
check('each file explains itself to whoever has to edit it',
  LANGS.every(l => /stays in English/.test(files[l]['//'] || '')));
check('and names a place for the reviewer to sign',
  ['ar', 'zh', 'pt', 'hi', 'ur'].every(l => /reviewed by/.test(files[l]['//lang'] || '')));

/* every key must actually occur in the page, or it is translating something that is gone */
const source = readFileSync(APP + 'index.html', 'utf8').replace(/&amp;/g, '&')
  + readdirSync(APP + 'lib').filter(f => f.endsWith('.js')).map(f => readFileSync(APP + 'lib/' + f, 'utf8')).join('');
const orphans = keys(files.en).filter(k => !source.includes(k));
check('every string in the files still exists in the page', orphans.length === 0, orphans.slice(0, 4).join(' | '));

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });

const txt = (s) => page.textContent(s);
const dir = () => page.evaluate(() => document.documentElement.dir);
/* A language whose button the page does not have yet is a FAIL line, not a crash: page.click
   would wait thirty seconds and then throw, taking the tally and every later check with it,
   and the later checks (partial files, the remembered choice) are exactly the ones that still
   say something while a new language waits for its button. */
async function to(lang) {
  const b = await page.$(`#langSeg button[data-lang="${lang}"]`);
  if (!b) { console.log(`     (no #langSeg button for "${lang}" in the page)`); return false; }
  await b.click(); await page.waitForTimeout(700); return true;
}
const PICKER = 'EN عربي 中文 PT ES PL DE IT हिन्दी اردو';

/* The picker itself must be readable by someone who cannot read the page's current language —
   that is the whole point of it, so its own labels are never translated. */
const labels = () => page.$$eval('#langSeg button', b => b.map(x => x.textContent.trim()));
check('the picker is buttons, one per language, each written in its own script',
  (await labels()).join(' ') === PICKER, (await labels()).join(' '));

check('the page starts in English', (await txt('#btnOpen')).trim() === 'OPEN' && await dir() === 'ltr');

/* where everything is BEFORE the language changes */
/* The ORDER, not the exact pixels: "OPEN" and "فتح" are not the same width, so every button
   after one of them shifts a little and always will. What must not happen is the order
   changing, which is what mirroring did. */
/* The visual ORDER, expressed as "which element comes first, second, third", not the exact
   pixels and not the labels: "OPEN" and "فتح" are not the same width so everything after one
   of them shifts a little and always will, and their text differs by definition. What must
   not happen is the order changing, which is exactly what mirroring the page did. */
/* Rows are BUCKETED before sorting. Two buttons side by side do not share a y to the pixel —
   a taller one sits a little higher — so ordering by raw y puts neighbours in an arbitrary
   order that flips as soon as a label changes width. Round to the nearest row first, then
   read left to right, which is what "the same order" actually means. */
/* LEFT TO RIGHT, WITHIN A ROW. That is what "the same order" has to mean here, and the
   qualifier is not a weakening: a toolbar wraps where it runs out of room, translated text is
   never the same width as English text, so which control begins a new row differs between
   languages and always will — that is flex-wrap doing its job, not the page rearranging
   itself. What must never happen is the order REVERSING, which is what mirroring the whole
   page for Arabic did and what this check exists to catch. So each bar is read row by row,
   and on every row the buttons must appear in the order the markup puts them in. */
const outOfOrder = () => page.$$eval('header, .ptitle', bars => {
  const bad = [];
  bars.forEach((bar, b) => {
    const rows = new Map();
    [...bar.querySelectorAll('button')].forEach((e, i) => {
      const r = e.getBoundingClientRect();
      if (!r.width) return;                       // hidden: not on any row
      const k = Math.round(r.y / 24);
      (rows.get(k) || rows.set(k, []).get(k)).push({ i, x: r.x, t: (e.textContent || '').trim().slice(0, 12) });
    });
    for (const [k, row] of rows) {
      const seen = row.slice().sort((p, q) => p.x - q.x);
      for (let n = 1; n < seen.length; n++) {
        if (seen[n].i < seen[n - 1].i) bad.push(`bar ${b} row ${k}: ${seen[n - 1].t} before ${seen[n].t}`);
      }
    }
  });
  return bad;
});
const positions = () => page.$$eval('header button, .ptitle button',
  els => els.map((e, i) => { const r = e.getBoundingClientRect(); return [i, r.x, Math.round(r.y / 24)]; })
            .sort((a, b) => (a[2] - b[2]) || (a[1] - b[1]))
            .map(r => r[0]).join(','));
const beforePos = await positions();
check('every toolbar reads left to right in the order the markup puts it in, to begin with',
  (await outOfOrder()).length === 0, (await outOfOrder()).slice(0, 3).join(' | '));
const before2d = await page.evaluate(() => document.getElementById('panel2d').getBoundingClientRect().x);
const before3d = await page.evaluate(() => document.getElementById('panel3d').getBoundingClientRect().x);

await to('ar');
const after2d = await page.evaluate(() => document.getElementById('panel2d').getBoundingClientRect().x);
const after3d = await page.evaluate(() => document.getElementById('panel3d').getBoundingClientRect().x);
check('Arabic translates the buttons', (await txt('#btnOpen')).trim() === files.ar['OPEN'], await txt('#btnOpen'));
check('and the tooltips', (await page.getAttribute('#btnFind', 'title')) === files.ar['Find a structure by name in the RCSB PDB or in PubChem and bring it in']);
check('and the dropdown options', (await txt('#selStyle option[value=cpk]')).trim() === files.ar['Space filling']);
check('and the placeholder in the ID box', (await page.getAttribute('#idInput', 'placeholder')) === files.ar['ID']);
check('and the status line, which the script writes rather than the markup',
  (await txt('#msg')) === files.ar['Ready – draw in Ketcher, then press MAKE 3D.'], await txt('#msg'));
check('and says which language it is in, for a screen reader',
  await page.evaluate(() => document.documentElement.lang) === 'ar');
/* NOTHING MOVES. Mirroring the page for Arabic swapped the drawing and 3D panels and shuffled
   every toolbar, so changing language felt like the program had been replaced — and a chemist
   who knows where MINIMIZE is should find it there in any language. Only the text changes. */
check('the drawing panel does not move to the other side of the screen',
  Math.abs(after2d - before2d) < 1 && Math.abs(after3d - before3d) < 1,
  `2D ${before2d} -> ${after2d}, 3D ${before3d} -> ${after3d}`);
check('and every toolbar still reads left to right in that same order in Arabic',
  (await outOfOrder()).length === 0, (await outOfOrder()).slice(0, 3).join(' | '));
check('nor does any of them cross to the other half of the header',
  await page.$$eval('header button', els => {
    const w = innerWidth;
    return els.every(e => { const x = e.getBoundingClientRect().x; return x >= 0 && x < w; });
  }));
check('Arabic text still runs right-to-left inside its own button',
  await page.$eval('#btnOpen', b => getComputedStyle(b).unicodeBidi) === 'plaintext');
check("Ketcher's own toolbars stay left-to-right, because they are a separate program",
  await page.getAttribute('#ketcherFrame', 'dir') === 'ltr');
check('a chemical formula is not reversed by the right-to-left layout',
  await page.evaluate(() => getComputedStyle(document.getElementById('status3d')).direction) === 'ltr');
check('the journal citations stay in English, as citations should',
  /Bioinformatics/.test(await txt('#infoDlg')) && /Rappé/.test(await txt('#infoDlg')));

check('and its labels stay put even when the page is in Arabic',
  (await labels()).join(' ') === PICKER, (await labels()).join(' '));
check('the language in use is marked on its button',
  (await page.$$eval('#langSeg button.on', b => b.map(x => x.dataset.lang))).join('') === 'ar');

await to('zh');
check('Chinese translates the buttons', (await txt('#btnMake3d')).trim() === files.zh['MAKE 3D'], await txt('#btnMake3d'));
check('and the page is left-to-right throughout', await dir() === 'ltr');
check('and from Chinese you can still find Portuguese, which is the point of the labels',
  (await labels()).join(' ') === PICKER, (await labels()).join(' '));

await to('pt');
check('Portuguese translates the buttons', (await txt('#btnMake3d')).trim() === files.pt['MAKE 3D'], await txt('#btnMake3d'));
check('and the status line', (await txt('#msg')) === files.pt['Ready – draw in Ketcher, then press MAKE 3D.'], await txt('#msg'));

/* The two languages added in build 20. Spanish and Polish are Latin script and
   left-to-right, so what has to be checked is that the files are real translations and that
   the picker reaches them — not the layout, which cannot move for them. */
await to('es');
check('Spanish translates the buttons', (await txt('#btnMake3d')).trim() === files.es['MAKE 3D'], await txt('#btnMake3d'));
check('and its own file really is Spanish', /ñ|á|é|í|ó|ú|¿/.test(Object.values(files.es).join('')));
check('and the page stays left-to-right', await dir() === 'ltr');
await to('pl');
check('Polish translates the buttons', (await txt('#btnMake3d')).trim() === files.pl['MAKE 3D'], await txt('#btnMake3d'));
check('and its own file really is Polish', /ą|ć|ę|ł|ń|ó|ś|ź|ż/.test(Object.values(files.pl).join('')));
await to('de');
check('German translates the buttons', (await txt('#btnMake3d')).trim() === files.de['MAKE 3D'], await txt('#btnMake3d'));
check('and its own file really is German', /ä|ö|ü|ß|Ä|Ö|Ü/.test(Object.values(files.de).join('')));
await to('it');
check('Italian translates the buttons', (await txt('#btnMake3d')).trim() === files.it['MAKE 3D'], await txt('#btnMake3d'));
check('and its own file really is Italian', /à|è|é|ì|ò|ù/.test(Object.values(files.it).join('')));
check('the language in use is marked on its button, whichever it is',
  (await page.$$eval('#langSeg button.on', b => b.map(x => x.dataset.lang))).join('') === 'it');

/* The two languages added in build 24. Hindi is Devanagari and left-to-right, so as with
   Spanish it is the file and the picker that are checked. Urdu is the Perso-Arabic script and
   runs right-to-left, so it gets the Arabic checks too: the text turns inside its own button,
   and nothing on the page moves — the rule is the same and so must the behaviour be. */
const hasHi = await to('hi');
check('Hindi translates the buttons', hasHi && (await txt('#btnMake3d')).trim() === files.hi['MAKE 3D'], await txt('#btnMake3d'));
check('and the status line', hasHi && (await txt('#msg')) === files.hi['Ready – draw in Ketcher, then press MAKE 3D.'], await txt('#msg'));
check('and says which language it is in, for a screen reader', await page.evaluate(() => document.documentElement.lang) === 'hi');
check('and the page stays left-to-right', hasHi && await dir() === 'ltr');
const hasUr = await to('ur');
check('Urdu translates the buttons', hasUr && (await txt('#btnMake3d')).trim() === files.ur['MAKE 3D'], await txt('#btnMake3d'));
check('and the tooltips', hasUr && (await page.getAttribute('#btnFind', 'title')) === files.ur['Find a structure by name in the RCSB PDB or in PubChem and bring it in']);
check('and the status line', hasUr && (await txt('#msg')) === files.ur['Ready – draw in Ketcher, then press MAKE 3D.'], await txt('#msg'));
check('and says which language it is in, for a screen reader', await page.evaluate(() => document.documentElement.lang) === 'ur');
check('Urdu does not move the drawing panel to the other side of the screen either',
  hasUr && Math.abs(await page.evaluate(() => document.getElementById('panel2d').getBoundingClientRect().x) - before2d) < 1 &&
  Math.abs(await page.evaluate(() => document.getElementById('panel3d').getBoundingClientRect().x) - before3d) < 1);
check('and every toolbar still reads left to right in that same order in Urdu',
  hasUr && (await outOfOrder()).length === 0, (await outOfOrder()).slice(0, 3).join(' | '));
check('and the page direction itself stays left-to-right, as for Arabic', hasUr && await dir() === 'ltr');
check('Urdu text still runs right-to-left inside its own button',
  hasUr && await page.$eval('#btnOpen', b => getComputedStyle(b).unicodeBidi) === 'plaintext');
check('the language in use is marked on its button, for the new ones too',
  (await page.$$eval('#langSeg button.on', b => b.map(x => x.dataset.lang))).join('') === 'ur');

await to('en');
check('switching back restores the English exactly',
  (await txt('#btnOpen')).trim() === 'OPEN' && (await txt('#btnMake3d')).trim() === 'MAKE 3D' &&
  (await page.getAttribute('#btnFind', 'title')) === 'Find a structure by name in the RCSB PDB or in PubChem and bring it in');

/* the choice is remembered, and survives a reload */
await to('ar');
const page2 = await ctx.newPage();
await page2.goto(`http://127.0.0.1:${PORT}/index.html`);
await page2.waitForFunction(() => document.documentElement.lang === 'ar', null, { timeout: 90000 });
check('the language is remembered for the next visit', (await page2.textContent('#btnOpen')).trim() === files.ar['OPEN']);
await page2.close();

/* the property the whole design rests on: a partial file is safe */
await to('en');
await page.route('**/lang/ar.json*', r => r.fulfill({ contentType: 'application/json',
  body: JSON.stringify({ 'OPEN': 'فتح' }) }));
await to('ar');
check('a file with one line translates that line', (await txt('#btnOpen')).trim() === 'فتح');
check('and leaves everything else in English, not blank and not a key name',
  (await txt('#btnMake3d')).trim() === 'MAKE 3D' && (await txt('#btnShare')).trim() === 'SHARE');
await page.route('**/lang/ar.json*', r => r.fulfill({ contentType: 'application/json',
  body: JSON.stringify({ 'OPEN': '', 'SHARE': null, 'MAKE 3D': 42 }) }));
await to('en'); await to('ar');
check('an empty, null or nonsense value falls back to English rather than emptying the button',
  (await txt('#btnOpen')).trim() === 'OPEN' && (await txt('#btnShare')).trim() === 'SHARE' &&
  (await txt('#btnMake3d')).trim() === 'MAKE 3D');
await page.route('**/lang/ar.json*', r => r.fulfill({ status: 404, body: 'gone' }));
await to('en'); await to('ar');
check('a missing language file leaves the page in English instead of breaking it',
  (await txt('#btnOpen')).trim() === 'OPEN' && await dir() === 'ltr');
await page.unroute('**/lang/ar.json*');

/* nothing is fetched for English, which is what most visitors get */
const asked = [];
const page3 = await ctx.newPage();
page3.on('request', r => { if (/lang\//.test(r.url())) asked.push(r.url()); });
await page3.goto(`http://127.0.0.1:${PORT}/index.html`);
await page3.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
check('an English visit downloads no language file at all', asked.length === 0, asked.join(' '));

const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
