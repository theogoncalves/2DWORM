/* Molecular-dynamics readers: LAMMPS data and dump, AMBER prmtop + rst7, NAMD psf + coor
   + xsc, CHARMM crd — and the PAIRING of them, which is the point of the module.
   Every fixture below is written the way the program writes it: fixed widths where the
   format is fixed-width (a prmtop's 20a4 names, an rst7's %12.7f, a crd's 3F10.5), so that
   the traps — names with no separator, negatives running together, scaled coordinates,
   bond indices times three — are the real traps and not typed approximations. */
import { sniffMD, parseMDSet, parseLammpsData, parseLammpsDump, parseAmberPrmtop, parseAmberRst7,
         parsePsf, parseNamdCoor, parseNamdXsc, parseCharmmCrd, elemFromMass, elemFromLabelMass, elemFromAtomName } from '../2dworm/lib/mdgeom.js';
import { cellParams } from '../2dworm/lib/qcgeom.js';
import { readFileSync } from 'node:fs';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const near = (a, b, t = 1e-4) => Math.abs(a - b) <= t;
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const elems = (r) => r.atoms.map(a => a.elem).join(' ');
const hasBond = (r, a, b) => !!(r.bonds || []).find(x => (x.a === a && x.b === b) || (x.a === b && x.b === a));
const throws = (fn) => { try { fn(); return null; } catch (e) { return e.message; } };
const corpus = (n) => readFileSync(new URL('./corpus/' + n, import.meta.url), 'latin1');

/* Fortran-style fixed fields, so the fixtures are what the programs write */
const F = (v, w, d) => Number(v).toFixed(d).padStart(w);          // Fw.d
const A = (s, w) => String(s).padEnd(w).slice(0, w);              // Aw, left-justified
const I = (v, w) => String(v).padStart(w);                        // Iw

/* ================================================================ LAMMPS data */
/* methanol-ish: C, O, 3 H and an Fe, plus a coarse-grained bead type of 72 u that is no
   element; `# full` on the Atoms line; ids deliberately out of order and not 1..N, so that
   the Bonds section (which names ids) only comes out right through an id map */
const LMP_FULL = `LAMMPS data file via write_data, version 2 Aug 2023, timestep = 1000

7 atoms
4 atom types
2 bonds
1 bond types

-5.0 15.0 xlo xhi
0.0 20.0 ylo yhi
0.0 20.0 zlo zhi

Masses

1 12.011
2 1.008
3 55.845
4 72.0  # P4

Atoms # full

12 1 1 -0.18 0.000 0.000 0.000 0 0 0
10 1 2 0.06 1.090 0.000 0.000 0 0 0
11 1 2 0.06 -0.363 1.027 0.000 0 0 0
15 1 2 0.06 -0.363 -0.513 -0.889 0 0 0
14 1 2 0.06 -0.363 -0.513 0.889 0 0 0
20 2 3 0.0 8.0 8.0 8.0 1 0 0
21 3 4 0.0 12.0 12.0 12.0 0 0 0

Velocities

12 0.0 0.0 0.0
10 0.0 0.0 0.0

Bonds

1 1 12 10
2 1 12 11
`;
{
  const r = parseLammpsData(LMP_FULL);
  check('LAMMPS data: 7 atoms sorted by id', r.atoms.length === 7 && r.program === 'LAMMPS data', elems(r));
  check('LAMMPS data: masses 12.011 → C, 1.008 → H, 55.845 → Fe', elems(r) === 'H H C H H Fe X', elems(r));
  check('LAMMPS data: a 72 u bead is X and the note says so', r.atoms[6].elem === 'X' && /match no element/.test(r.note), r.note);
  check('LAMMPS data: the bead label P4 is not read as phosphorus', !elems(r).includes('P'), elems(r));
  check('LAMMPS data: bonds go through the id map (12–10 and 12–11 are atoms 2–0 and 2–1)',
    r.bonds.length === 2 && hasBond(r, 2, 0) && hasBond(r, 2, 1) && !hasBond(r, 0, 1), JSON.stringify(r.bonds));
  check('LAMMPS data: C–H is 1.09 A as written', near(dist(r.atoms[2], r.atoms[0]), 1.09), dist(r.atoms[2], r.atoms[0]).toFixed(4));
  check('LAMMPS data: orthogonal cell 20 × 20 × 20 with its origin at (-5, 0, 0)',
    r.cell && near(r.cell.a[0], 20) && near(r.cell.b[1], 20) && near(r.cell.c[2], 20) && r.origin && near(r.origin[0], -5) && r.periodic === 'a LAMMPS box',
    JSON.stringify(r.cell) + ' ' + JSON.stringify(r.origin));
  check('LAMMPS data: image flags are read past and not applied (the Fe stays at 8, 8, 8)', near(r.atoms[5].x, 8) && /image flags/.test(r.note), r.atoms[5].x + ' ' + r.note);
  check('LAMMPS data: atom_style taken from the Atoms line', /atom_style full/.test(r.note), r.note);
  check('LAMMPS data: the molecule id becomes the residue number', r.atoms[0].resi === 1 && r.atoms[6].resi === 3, JSON.stringify(r.atoms.map(a => a.resi)));
  const crlf = parseLammpsData(LMP_FULL.replace(/\n/g, '\r\n'));
  check('LAMMPS data: reads the same with CRLF', elems(crlf) === elems(r) && crlf.bonds.length === 2, elems(crlf));
}
/* triclinic: xy xz yz → A = (lx,0,0), B = (xy,ly,0), C = (xz,yz,lz); `Atoms # atomic` */
const LMP_TRI = `LAMMPS triclinic data file

2 atoms
1 atom types

0.0 10.0 xlo xhi
0.0 8.0 ylo yhi
0.0 6.0 zlo zhi
2.0 -1.0 0.5 xy xz yz

Masses

1 26.9815

Atoms # atomic

1 1 0.0 0.0 0.0
2 1 5.5 4.25 3.0
`;
{
  const r = parseLammpsData(LMP_TRI);
  check('LAMMPS data triclinic: cell vectors carry the tilt', r.cell && JSON.stringify(r.cell) === JSON.stringify({ a: [10, 0, 0], b: [2, 8, 0], c: [-1, 0.5, 6] }), JSON.stringify(r.cell));
  check('LAMMPS data triclinic: 26.9815 → Al', elems(r) === 'Al Al', elems(r));
  const p = cellParams(r.cell);
  check('LAMMPS data triclinic: gamma is acos(xy/|b|)', near(p.gamma, Math.acos(2 / Math.hypot(2, 8)) * 180 / Math.PI, 1e-6), p.gamma.toFixed(4));
}
/* no style comment: the column count decides */
const lmpBody = (rows) => `title\n\n${rows.length} atoms\n2 atom types\n\n0 10 xlo xhi\n0 10 ylo yhi\n0 10 zlo zhi\n\nMasses\n\n1 15.999\n2 1.008\n\nAtoms\n\n${rows.join('\n')}\n`;
{
  const atomic = parseLammpsData(lmpBody(['1 1 5.0 5.0 5.0', '2 2 5.958 5.0 5.0', '3 2 4.76 5.93 5.0']));
  check('LAMMPS data: 5 columns → atomic', elems(atomic) === 'O H H' && /atomic/.test(atomic.note) && near(dist(atomic.atoms[0], atomic.atoms[1]), 0.958), atomic.note);
  const charge = parseLammpsData(lmpBody(['1 1 -0.834 5.0 5.0 5.0', '2 2 0.417 5.958 5.0 5.0', '3 2 0.417 4.76 5.93 5.0']));
  check('LAMMPS data: 6 columns with a fractional third → charge', elems(charge) === 'O H H' && /charge/.test(charge.note) && near(dist(charge.atoms[0], charge.atoms[1]), 0.958), charge.note);
  const molecular = parseLammpsData(lmpBody(['1 1 1 5.0 5.0 5.0', '2 1 2 5.958 5.0 5.0', '3 1 2 4.76 5.93 5.0']));
  check('LAMMPS data: 6 columns with a type in the third → molecular, and the note calls it a guess',
    elems(molecular) === 'O H H' && /molecular/.test(molecular.note) && /guess/.test(molecular.note) && near(dist(molecular.atoms[0], molecular.atoms[1]), 0.958), molecular.note);
  const full = parseLammpsData(lmpBody(['1 1 1 -0.834 5.0 5.0 5.0', '2 1 2 0.417 5.958 5.0 5.0', '3 1 2 0.417 4.76 5.93 5.0']));
  check('LAMMPS data: 7 columns → full', elems(full) === 'O H H' && /full/.test(full.note) && near(dist(full.atoms[0], full.atoms[1]), 0.958), full.note);
  const flags = parseLammpsData(lmpBody(['1 1 5.0 5.0 5.0 0 0 0', '2 2 5.958 5.0 5.0 0 0 1', '3 2 4.76 5.93 5.0 0 0 0']));
  check('LAMMPS data: 8 columns → atomic with image flags', elems(flags) === 'O H H' && near(dist(flags.atoms[0], flags.atoms[1]), 0.958), flags.note);
  const intCoords = parseLammpsData(lmpBody(['1 1 1 0 5 5 5', '2 1 2 0 6 5 5', '3 1 2 0 4 6 5']));
  check('LAMMPS data: 7 integer-looking columns are still full, not atomic plus flags', elems(intCoords) === 'O H H' && near(intCoords.atoms[1].x, 6), intCoords.note);
  const labels = parseLammpsData(`title\n\n2 atoms\n2 atom types\n\n0 10 xlo xhi\n0 10 ylo yhi\n0 10 zlo zhi\n\nAtom Type Labels\n\n1 OW\n2 HW\n\nMasses\n\nOW 15.999\nHW 1.008\n\nAtoms # atomic\n\n1 OW 5 5 5\n2 HW 5.958 5 5\n`);
  check('LAMMPS data: type labels in Masses and Atoms are resolved', elems(labels) === 'O H', elems(labels));
  const noMass = parseLammpsData(`title\n\n1 atoms\n1 atom types\n\n0 10 xlo xhi\n0 10 ylo yhi\n0 10 zlo zhi\n\nAtoms # atomic\n\n1 1 5 5 5\n`);
  check('LAMMPS data: without a Masses section the element is X and the note says why', elems(noMass) === 'X' && /no Masses/.test(noMass.note), noMass.note);
  const commentEl = parseLammpsData(`title\n\n1 atoms\n1 atom types\n\n0 10 xlo xhi\n0 10 ylo yhi\n0 10 zlo zhi\n\nMasses\n\n1 55.0 # Fe\n\nAtoms # atomic\n\n1 1 5 5 5\n`);
  check('LAMMPS data: 55.0 with a "# Fe" comment is iron (by mass alone it would be manganese)', elems(commentEl) === 'Fe', elems(commentEl));
  const commentType = parseLammpsData(`title\n\n1 atoms\n1 atom types\n\n0 10 xlo xhi\n0 10 ylo yhi\n0 10 zlo zhi\n\nMasses\n\n1 12.011 # CA\n\nAtoms # atomic\n\n1 1 5 5 5\n`);
  check('LAMMPS data: 12.011 with a "# CA" comment is a carbon, not calcium', elems(commentType) === 'C', elems(commentType));
  /* general triclinic: avec bvec cvec and abc origin, coordinates in that frame */
  const general = parseLammpsData(`title\n\n1 atoms\n1 atom types\n\n10 0 0 avec\n2 8 0 bvec\n-1 0.5 6 cvec\n1 1 1 abc origin\n\nMasses\n\n1 12.011\n\nAtoms # atomic\n\n1 1 6.5 5.25 4.0\n`);
  check('LAMMPS data: a general triclinic box (avec bvec cvec, abc origin)', JSON.stringify(general.cell) === JSON.stringify({ a: [10, 0, 0], b: [2, 8, 0], c: [-1, 0.5, 6] }) && JSON.stringify(general.origin) === '[1,1,1]', JSON.stringify(general.cell));
  const asBytes = parseMDSet([{ name: 'run.data', bytes: new TextEncoder().encode(LMP_TRI) }]);
  check('LAMMPS data: a text file that arrived as bytes still reads', elems(asBytes) === 'Al Al' && !!asBytes.cell, elems(asBytes));
}

/* ================================================================ LAMMPS dump */
/* water in a 20 A box, SCALED coordinates: read as x y z the O–H would be 0.048 A. Two
   frames, the first with the molecule elsewhere, so that "last frame" is tested. */
const DUMP_SCALED = `ITEM: TIMESTEP
0
ITEM: NUMBER OF ATOMS
3
ITEM: BOX BOUNDS pp pp pp
0.0000000000000000e+00 2.0000000000000000e+01
0.0000000000000000e+00 2.0000000000000000e+01
0.0000000000000000e+00 2.0000000000000000e+01
ITEM: ATOMS id type xs ys zs element
1 1 0.1 0.1 0.1 O
2 2 0.1479 0.1 0.1 H
3 2 0.088 0.14635 0.1 H
ITEM: TIMESTEP
500
ITEM: NUMBER OF ATOMS
3
ITEM: BOX BOUNDS pp pp pp
0.0000000000000000e+00 2.0000000000000000e+01
0.0000000000000000e+00 2.0000000000000000e+01
0.0000000000000000e+00 2.0000000000000000e+01
ITEM: ATOMS id type xs ys zs element
3 2 0.488 0.54635 0.5 H
1 1 0.5 0.5 0.5 O
2 2 0.5479 0.5 0.5 H
`;
{
  const r = parseLammpsDump(DUMP_SCALED);
  check('LAMMPS dump: last frame, sorted by id, elements from the element column', r.atoms.length === 3 && elems(r) === 'O H H' && r.program === 'LAMMPS dump', elems(r));
  check('LAMMPS dump: xs ys zs are multiplied out by the box (O–H = 0.958 A, not 0.048)', near(dist(r.atoms[0], r.atoms[1]), 0.958, 1e-6) && near(r.atoms[0].x, 10), dist(r.atoms[0], r.atoms[1]).toFixed(4));
  check('LAMMPS dump: the note says the frame and that the coordinates were scaled', /timestep 500/.test(r.note) && /SCALED/.test(r.note) && /2 frames/.test(r.note), r.note);
  check('LAMMPS dump: the box is the cell', r.cell && near(r.cell.a[0], 20) && near(r.cell.b[1], 20) && near(r.cell.c[2], 20) && r.periodic === 'a LAMMPS box', JSON.stringify(r.cell));
  const c = parseLammpsDump(DUMP_SCALED.replace(/\n/g, '\r\n'));
  check('LAMMPS dump: reads the same with CRLF', elems(c) === 'O H H' && near(dist(c.atoms[0], c.atoms[1]), 0.958, 1e-6));
}
/* triclinic dump: BOX BOUNDS are the BOUNDING box. Same cell as LMP_TRI (xy 2, xz -1, yz 0.5):
   xlo_bound = 0 + min(0, 2, -1, 1) = -1, xhi_bound = 10 + max(...) = 12, ylo_bound = 0,
   yhi_bound = 8.5. The atom at fractions (0.5, 0.5, 0.5) sits at (5.5, 4.25, 3). */
const DUMP_TRI = `ITEM: TIMESTEP
100
ITEM: NUMBER OF ATOMS
2
ITEM: BOX BOUNDS xy xz yz pp pp pp
-1.0000000000000000e+00 1.2000000000000000e+01 2.0000000000000000e+00
0.0000000000000000e+00 8.5000000000000000e+00 -1.0000000000000000e+00
0.0000000000000000e+00 6.0000000000000000e+00 5.0000000000000000e-01
ITEM: ATOMS id type xs ys zs
1 1 0 0 0
2 1 0.5 0.5 0.5
`;
{
  const data = parseLammpsData(LMP_TRI);
  const r = parseLammpsDump(DUMP_TRI, data);
  check('LAMMPS dump triclinic: the bounding box is undone and the cell equals the data file\'s', JSON.stringify(r.cell) === JSON.stringify(data.cell), JSON.stringify(r.cell));
  check('LAMMPS dump triclinic: scaled (0.5, 0.5, 0.5) lands at (5.5, 4.25, 3) — the tilt goes into x and y',
    near(r.atoms[1].x, 5.5) && near(r.atoms[1].y, 4.25) && near(r.atoms[1].z, 3), [r.atoms[1].x, r.atoms[1].y, r.atoms[1].z].join(' '));
  check('LAMMPS dump triclinic: elements come from the data file\'s Masses (type 1 = Al)', elems(r) === 'Al Al' && /Masses/.test(r.note), r.note);
  check('LAMMPS dump: with types only and no data file the error names the partner', /drop the data file/.test(throws(() => parseLammpsDump(DUMP_TRI)) || ''), throws(() => parseLammpsDump(DUMP_TRI)));
}
/* unwrapped xu yu zu with a mass column, and a units line */
const DUMP_XU = `ITEM: UNITS
metal
ITEM: TIMESTEP
7
ITEM: NUMBER OF ATOMS
2
ITEM: BOX BOUNDS pp pp pp
0 10
0 10
0 10
ITEM: ATOMS id type xu yu zu mass q
2 2 12.958 5 5 1.008 0.417
1 1 12 5 5 15.999 -0.834
`;
{
  const r = parseLammpsDump(DUMP_XU);
  check('LAMMPS dump: xu yu zu as written (outside the box is fine), elements by the mass column', elems(r) === 'O H' && near(r.atoms[0].x, 12) && near(dist(r.atoms[0], r.atoms[1]), 0.958), elems(r) + ' ' + r.note);
  check('LAMMPS dump: the charge column is kept', near(r.atoms[0].charge, -0.834), String(r.atoms[0].charge));
  const bohr = parseLammpsDump(DUMP_XU.replace('metal', 'electron'));
  check('LAMMPS dump: ITEM: UNITS electron is bohr and is converted', near(bohr.atoms[0].x, 12 * 0.529177210903, 1e-6) && near(bohr.cell.a[0], 10 * 0.529177210903, 1e-6), bohr.note);
}
/* dump + data through parseMDSet: bonds from the data file, matched by id */
{
  const r = parseMDSet([{ name: 'run.data', text: LMP_FULL }, { name: 'run.lammpstrj', text: `ITEM: TIMESTEP\n3\nITEM: NUMBER OF ATOMS\n7\nITEM: BOX BOUNDS pp pp pp\n-5 15\n0 20\n0 20\nITEM: ATOMS id type x y z\n21 4 12 12 12\n20 3 8 8 8\n14 2 -0.363 -0.513 0.889\n15 2 -0.363 -0.513 -0.889\n11 2 -0.363 1.027 0\n10 2 1.09 0 0\n12 1 0 0 0\n` }]);
  check('set: dump + data → elements by mass and bonds by id', r.program === 'LAMMPS dump' && elems(r) === 'H H C H H Fe X' && r.bonds && r.bonds.length === 2 && hasBond(r, 2, 0) && hasBond(r, 2, 1), elems(r) + ' ' + JSON.stringify(r.bonds));
}

/* ================================================================ AMBER prmtop
   ACE (6 atoms) and a TIP3P water (3): nine atoms, so that an un-divided bond entry is
   still a valid atom index and would join the WRONG atoms — `3 6 2` is CH3–HH32 (atoms
   1–2); read as 3–6 it would bond HH33 to the water oxygen. Names are 20a4 with no
   separator, exactly as tleap writes them. */
const PRMTOP = `%VERSION  VERSION_STAMP = V0001.000  DATE = 09/12/26  10:00:00
%FLAG TITLE
%FORMAT(20a4)
ACE + water
%FLAG POINTERS
%FORMAT(10I8)
       9       5       5       2       6       1       9       0       0       0
      20       2       2       1       0       4       3       3       5       0
       0       0       0       0       0       0       0       1       6       0
       0
%FLAG ATOM_NAME
%FORMAT(20a4)
HH31CH3 HH32HH33C   O   O   H1  H2
%FLAG CHARGE
%FORMAT(5E16.8)
  2.04636429E+00 -6.67300626E+00  2.04636429E+00  2.04636429E+00  1.08823576E+01
 -1.03484442E+01 -1.51974000E+01  7.59870000E+00  7.59870000E+00
%FLAG ATOMIC_NUMBER
%FORMAT(10I8)
       1       6       1       1       6       8       8       1       1
%FLAG MASS
%FORMAT(5E16.8)
  1.00800000E+00  1.20100000E+01  1.00800000E+00  1.00800000E+00  1.20100000E+01
  1.60000000E+01  1.60000000E+01  1.00800000E+00  1.00800000E+00
%FLAG RESIDUE_LABEL
%FORMAT(20a4)
ACE WAT
%FLAG RESIDUE_POINTER
%FORMAT(10I8)
       1       7
%FLAG BONDS_INC_HYDROGEN
%FORMAT(10I8)
       3       6       2       3       9       2       0       3       2      18
      21       4      18      24       4
%FLAG BONDS_WITHOUT_HYDROGEN
%FORMAT(10I8)
      12      15       1       3      12       3
%FLAG AMBER_ATOM_TYPE
%FORMAT(20a4)
HC  CT  HC  HC  C   O   OW  HW  HW
%FLAG BOX_DIMENSIONS
%FORMAT(5E16.8)
  9.00000000E+01  2.50000000E+01  2.60000000E+01  2.70000000E+01
`;
{
  const r = parseAmberPrmtop(PRMTOP);
  check('prmtop: nine atoms, elements from ATOMIC_NUMBER', r.atoms.length === 9 && elems(r) === 'H C H H C O O H H', elems(r));
  check('prmtop: 20a4 names are cut by width, not split on spaces', r.atoms.map(a => a.atom).join(',') === 'HH31,CH3,HH32,HH33,C,O,O,H1,H2', r.atoms.map(a => a.atom).join(','));
  check('prmtop: residues from RESIDUE_LABEL and RESIDUE_POINTER', r.atoms[0].resn === 'ACE' && r.atoms[0].resi === 1 && r.atoms[6].resn === 'WAT' && r.atoms[6].resi === 2 && r.atoms[5].resn === 'ACE',
    r.atoms.map(a => a.resn + a.resi).join(' '));
  check('prmtop: bond entries are divided by three (3 6 → atoms 1–2, not 3–6)', hasBond(r, 1, 2) && !hasBond(r, 3, 6), JSON.stringify(r.bonds));
  check('prmtop: seven bonds, 0-based, both lists read', r.bonds.length === 7 && hasBond(r, 0, 1) && hasBond(r, 1, 3) && hasBond(r, 1, 4) && hasBond(r, 4, 5) && hasBond(r, 6, 7) && hasBond(r, 6, 8), JSON.stringify(r.bonds));
  check('prmtop: no coordinates on its own', r.atoms.every(a => a.x === undefined));
  check('prmtop: BOX_DIMENSIONS (beta, a, b, c) → a 25 × 26 × 27 cell', r.cell && near(r.cell.a[0], 25) && near(r.cell.b[1], 26) && near(r.cell.c[2], 27) && /AMBER box/.test(r.periodic), JSON.stringify(r.cell));
  /* the same file with ATOMIC_NUMBER removed: the masses decide; and with a mass that is
     not an element (extra point, 0) the atom is X */
  const noZ = PRMTOP.replace(/%FLAG ATOMIC_NUMBER[\s\S]*?(?=%FLAG MASS)/, '');
  const m = parseAmberPrmtop(noZ);
  check('prmtop: without ATOMIC_NUMBER the masses decide (12.01 → C, 16.00 → O)', elems(m) === 'H C H H C O O H H' && /masses/.test(m.note), elems(m) + ' ' + m.note);
  const ep = noZ.replace('  1.60000000E+01  1.00800000E+00  1.00800000E+00', '  0.00000000E+00  1.00800000E+00  1.00800000E+00');
  const e = parseAmberPrmtop(ep);
  check('prmtop: a massless particle is X, not read from its name', e.atoms[6].elem === 'X' && /X/.test(e.note), elems(e));
  /* CA by name when neither Z nor mass helps: ALA's CA is a carbon, the CA residue's CA a calcium */
  const CANAME = `%VERSION  VERSION_STAMP = V0001.000
%FLAG POINTERS
%FORMAT(10I8)
       2       0       0       0       0       0       0       0       0       0
       0       2
%FLAG ATOM_NAME
%FORMAT(20a4)
CA  CA
%FLAG RESIDUE_LABEL
%FORMAT(20a4)
ALA CA
%FLAG RESIDUE_POINTER
%FORMAT(10I8)
       1       2
`;
  const ca = parseAmberPrmtop(CANAME);
  check('prmtop: names alone — CA in ALA is carbon, CA in the CA residue is calcium', elems(ca) === 'C Ca', elems(ca));
  const rn = parseAmberPrmtop(PRMTOP + '%FLAG RESIDUE_NUMBER\n%COMMENT Residue number (resSeq) read from PDB file; DIMENSION(NRES)\n%FORMAT(20I4)\n10001001\n%FLAG RESIDUE_CHAINID\n%FORMAT(20a4)\nA   B   \n');
  check('prmtop: a 20I4 RESIDUE_NUMBER that runs together is cut by width (1000, 1001), %COMMENT lines are skipped',
    rn.atoms[0].resi === 1000 && rn.atoms[6].resi === 1001, rn.atoms.map(a => a.resi).join(' '));
  check('prmtop: RESIDUE_CHAINID becomes the chain', rn.atoms[0].chain === 'A' && rn.atoms[8].chain === 'B', rn.atoms.map(a => a.chain).join(' '));
  /* AMBER's iron is 55.0 u, which by mass alone is manganese; without ATOMIC_NUMBER the
     name in its residue must win — and a CA of the same haem-less file stays a carbon */
  const HEME = `%VERSION  VERSION_STAMP = V0001.000
%FLAG POINTERS
%FORMAT(10I8)
       3       0       0       0       0       0       0       0       0       0
       0       2
%FLAG ATOM_NAME
%FORMAT(20a4)
FE  NA  CA
%FLAG MASS
%FORMAT(5E16.8)
  5.50000000E+01  1.40100000E+01  1.20100000E+01
%FLAG RESIDUE_LABEL
%FORMAT(20a4)
HEM ALA
%FLAG RESIDUE_POINTER
%FORMAT(10I8)
       1       3
`;
  const heme = parseAmberPrmtop(HEME);
  check('prmtop: FE at 55.0 u is iron by its name, not manganese by its mass; NA in the haem is nitrogen; ALA\'s CA carbon', elems(heme) === 'Fe N C', elems(heme));
}

/* ================================================================ AMBER rst7
   %12.7f, six to a line. Coordinates at or below -100 fill their field and run into the
   one before: the fixture is FORMATTED, so `-100.1234567-100.7654321` is what it holds. */
const rst7Of = (title, xyz, opt = {}) => {
  const vals = xyz.flat().concat(opt.vel ? xyz.flat().map(v => v / 100) : []);
  let s = title + '\n' + I(xyz.length, 5) + (opt.time != null ? F(opt.time, 15, 7).replace(/^(\s*)(\S+)$/, (m, a, b) => (a + b).padStart(15)) : '') + '\n';
  for (let i = 0; i < vals.length; i += 6) s += vals.slice(i, i + 6).map(v => F(v, 12, 7)).join('') + '\n';
  if (opt.box) s += opt.box.map(v => F(v, 12, 7)).join('') + '\n';
  return s;
};
const XYZ9 = [[-100.1234567, -100.7654321, 12.3456789], [-99.1654567, -100.7654321, 12.3456789], [-100.4864567, -99.7384321, 12.3456789],
              [-100.4864567, -101.2784321, 11.4566789], [-100.4864567, -101.2784321, 13.2346789], [-101.6534567, -100.7654321, 12.3456789],
              [5, 5, 5], [5.958, 5, 5], [4.76, 5.93, 5]];
{
  const text = rst7Of('ACE + water', XYZ9, { time: 10, box: [25, 26, 27, 90, 90, 90] });
  check('rst7 fixture: the fields really run together', /-100\.1234567-100\.7654321/.test(text), text.split('\n')[2]);
  const r = parseAmberRst7(text);
  check('rst7: nine atoms, every value in place despite the run-together fields', r.atoms.length === 9 && near(r.atoms[0].x, -100.1234567, 1e-9) && near(r.atoms[0].y, -100.7654321, 1e-9) &&
    near(r.atoms[0].z, 12.3456789, 1e-9) && near(r.atoms[1].x, -99.1654567, 1e-9) && near(r.atoms[8].y, 5.93, 1e-9), JSON.stringify(r.atoms.slice(0, 2)));
  check('rst7: the last line is the box, not an atom', r.cell && near(r.cell.a[0], 25) && near(r.cell.b[1], 26) && near(r.cell.c[2], 27) && r.periodic === 'an AMBER box', JSON.stringify(r.cell));
  check('rst7: the time is read from the count line', /t = 10 ps/.test(r.note), r.note);
  const v = parseAmberRst7(rst7Of('with velocities', XYZ9, { vel: true, box: [25, 26, 27, 90, 90, 90] }));
  check('rst7: velocities (6N + 6 values) are skipped and the box still found', v.atoms.length === 9 && /velocities skipped/.test(v.note) && v.cell && near(v.cell.c[2], 27), v.note);
  const bare = parseAmberRst7(rst7Of('no box', XYZ9));
  check('rst7: coordinates only → no cell', bare.atoms.length === 9 && !bare.cell, bare.note);
  const oct = parseAmberRst7(rst7Of('truncated octahedron', XYZ9, { box: [40, 40, 40, 109.4712190, 109.4712190, 109.4712190] }));
  check('rst7: a truncated-octahedral box gives a triclinic cell and says so', oct.cell && near(cellParams(oct.cell).alpha, 109.4712, 1e-3) && /octahedral/.test(oct.periodic), oct.periodic);
  check('rst7: a wrong count is refused with the arithmetic in the message', /3N/.test(throws(() => parseAmberRst7('t\n    8\n' + text.split('\n').slice(2).join('\n'))) || ''));
  check('rst7: no elements on its own', r.atoms.every(a => a.elem === undefined));
  const c = parseAmberRst7(text.replace(/\n/g, '\r\n'));
  check('rst7: reads the same with CRLF', c.atoms.length === 9 && near(c.atoms[0].x, -100.1234567, 1e-9) && !!c.cell);
}

/* ================================================================ the AMBER pair */
{
  const rst = rst7Of('ACE + water', XYZ9, { time: 10, box: [25, 26, 27, 90, 90, 90] });
  const r = parseMDSet([{ name: 'ace.rst7', text: rst }, { name: 'ace.prmtop', text: PRMTOP }]);
  check('set: prmtop + rst7 → a full structure with elements, names, residues, bonds and coordinates',
    r.program === 'AMBER' && elems(r) === 'H C H H C O O H H' && r.atoms[0].atom === 'HH31' && r.atoms[6].resn === 'WAT' && r.bonds.length === 7 && near(r.atoms[7].x, 5.958, 1e-9),
    elems(r) + ' ' + r.note);
  check('set: the pair takes the box from the restart', r.cell && near(r.cell.a[0], 25) && r.periodic === 'an AMBER box', JSON.stringify(r.cell));
  check('set: the water O–H from the paired coordinates is 0.958 A', near(dist(r.atoms[6], r.atoms[7]), 0.958, 1e-6), dist(r.atoms[6], r.atoms[7]).toFixed(4));
  const alone = throws(() => parseMDSet([{ name: 'ace.rst7', text: rst }]));
  check('set: an rst7 alone is refused and the message names the .prmtop', /carries no elements/.test(alone || '') && /\.prmtop/.test(alone || ''), alone);
  const topoAlone = throws(() => parseMDSet([{ name: 'ace.prmtop', text: PRMTOP }]));
  check('set: a prmtop alone is refused and the message names the .rst7', /no coordinates/.test(topoAlone || '') && /\.rst7/.test(topoAlone || ''), topoAlone);
  const mismatch = throws(() => parseMDSet([{ name: 'ace.prmtop', text: PRMTOP }, { name: 'other.rst7', text: rst7Of('x', XYZ9.slice(0, 3)) }]));
  check('set: a topology and a restart with different atom counts are not a pair', /not a pair/.test(mismatch || '') && /9 atoms/.test(mismatch || '') && /holds 3/.test(mismatch || ''), mismatch);
  const inpcrd = parseMDSet([{ name: 'ace.prmtop', text: PRMTOP }, { name: 'ace.inpcrd', text: rst7Of('inpcrd', XYZ9) }]);
  check('set: an .inpcrd without a box uses the topology\'s BOX_DIMENSIONS', inpcrd.cell && near(inpcrd.cell.b[1], 26), JSON.stringify(inpcrd.cell));
  const none = throws(() => parseMDSet([{ name: 'a.xyz', text: '3\nwater\nO 0 0 0\nH 0.958 0 0\nH -0.24 0.927 0\n' }]));
  check('set: a set with no MD file in it says what it reads', /LAMMPS/.test(none || '') && /prmtop/.test(none || ''), none);
  const crowd = parseMDSet([{ name: 'ace.prmtop', text: PRMTOP }, { name: 'ace.rst7', text: rst }, { name: 'later.rst7', text: rst }, { name: 'notes.txt', text: 'hello' }]);
  check('set: a second file of the same kind and a stranger are named in the note, not read', /later\.rst7 \(a second AMBER restart\)/.test(crowd.note) && /notes\.txt not read here/.test(crowd.note), crowd.note);
}

/* ================================================================ PSF
   X-PLOR style with segids (what NAMD and CHARMM-GUI write), then a CHARMM-style file with
   numeric types and no segid. Masses: a lone pair at 0 (X), a coarse-grained residue whose
   beads are 72 u (X, and its type `P4` is not read as phosphorus). */
const PSF = `PSF CMAP

       1 !NTITLE
 REMARKS mdgeom fixture

      10 !NATOM
       1 PROA 1    ALA  N    NH3   -0.300000       14.0070           0
       2 PROA 1    ALA  HT1  HC     0.330000        1.0080           0
       3 PROA 1    ALA  CA   CT1    0.070000       12.0110           0
       4 PROA 1    ALA  C    C      0.510000       12.0110           0
       5 PROA 1    ALA  O    O     -0.510000       15.9990           0
       6 IONS 1    SOD  SOD  SOD    1.000000       22.9898           0
       7 IONS 2    CAL  CAL  CAL    2.000000       40.0800           0
       8 WAT  1    TIP4 OH2  OT    -0.000000       15.9994           0
       9 WAT  1    TIP4 OM   LP    -1.040000        0.0000           0
      10 CG   1    BEAD BB   P4     0.000000       72.0000           0

       4 !NBOND: bonds
       1       2       1       3       3       4       4       5

       0 !NTHETA: angles

`;
{
  const r = parsePsf(PSF);
  check('psf: ten atoms, elements by mass (14.007 N, 1.008 H, 12.011 C, 15.999 O)', r.atoms.length === 10 && elems(r).startsWith('N H C C O'), elems(r));
  check('psf: SOD 22.9898 → Na and CAL 40.08 → Ca by mass, whatever the type spells', r.atoms[5].elem === 'Na' && r.atoms[6].elem === 'Ca', elems(r));
  check('psf: a massless lone pair is X', r.atoms[8].elem === 'X', elems(r));
  check('psf: a 72 u bead in a residue with no atomic mass is X, not phosphorus from its type', r.atoms[9].elem === 'X' && /X/.test(r.note), elems(r) + ' ' + r.note);
  check('psf: names, residues and segids kept', r.atoms[2].atom === 'CA' && r.atoms[2].resn === 'ALA' && r.atoms[2].resi === 1 && r.atoms[2].chain === 'PROA' && r.atoms[6].chain === 'IONS' && r.atoms[6].resi === 2,
    JSON.stringify(r.atoms[2]));
  check('psf: four bonds, 0-based', r.bonds.length === 4 && hasBond(r, 0, 1) && hasBond(r, 0, 2) && hasBond(r, 2, 3) && hasBond(r, 3, 4), JSON.stringify(r.bonds));
  const charmm = parsePsf(`PSF\n\n       1 !NTITLE\n* fixture\n\n       3 !NATOM\n       1      66   GLY  N    N     -0.415700       14.0100           0\n       2      66   GLY  H    H      0.271900        1.0080           0\n       3      66   GLY  CA   CT    -0.025200       12.0100           0\n\n       2 !NBOND: bonds\n       1       2       1       3\n`);
  check('psf: a file without segids (id resid resname name type charge mass) reads the same way', elems(charmm) === 'N H C' && charmm.atoms[2].atom === 'CA' && charmm.atoms[2].resi === 66 && charmm.bonds.length === 2 && !charmm.atoms[0].chain, elems(charmm));
  const numeric = parsePsf(`PSF CMAP CHEQ\n\n       2 !NATOM\n       1 4AKE 1    MET  N      56  -0.300000       14.0070           0   0.00000     -0.301140E-02\n       2 4AKE 1    MET  HT1     2   0.330000       1.00800           0   0.00000     -0.301140E-02\n\n       1 !NBOND: bonds\n       2       1\n`);
  check('psf: CHARMM numeric types with CHEQ columns', elems(numeric) === 'N H' && numeric.atoms[0].chain === '4AKE' && numeric.bonds.length === 1, elems(numeric));
  const ext = parsePsf(`PSF EXT CMAP CHEQ\n\n         2 !NATOM\n         1 PROA     1        ALA      N          72  -0.300000       14.0070           0   0.00000     -0.301140E-02\n         2 PROA     1        ALA      HT1        32   0.330000       1.00800           0   0.00000     -0.301140E-02\n\n         1 !NBOND: bonds\n         2         1\n`);
  check('psf: the EXT layout reads the same', elems(ext) === 'N H' && ext.atoms[1].atom === 'HT1', elems(ext));
  const c = parsePsf(PSF.replace(/\n/g, '\r\n'));
  check('psf: reads the same with CRLF', elems(c) === elems(r) && c.bonds.length === 4);
}

/* ================================================================ NAMD coor and xsc */
const coorBytes = (xyz, little = true) => {
  const buf = new ArrayBuffer(4 + 24 * xyz.length);
  const dv = new DataView(buf);
  dv.setInt32(0, xyz.length, little);
  xyz.forEach((p, i) => p.forEach((v, j) => dv.setFloat64(4 + 24 * i + 8 * j, v, little)));
  return buf;
};
const XYZ10 = [[0, 0, 0], [0.5, 0.8, 0], [1.5, 0, 0], [2.5, 0.8, 0], [3.5, 0, 0], [10, 10, 10], [12, 12, 12], [5, 5, 5], [5.15, 5, 5], [20, 20, 20]];
const XSC = `# NAMD extended system configuration output file
#$LABELS step a_x a_y a_z b_x b_y b_z c_x c_y c_z o_x o_y o_z s_x s_y s_z s_u s_v s_w
5000 62.2 0 0 0 61.5 0 0 0 63.1 31.1 30.75 31.55 0 0 0 0 0 0
`;
{
  const r = parseNamdCoor(coorBytes(XYZ10));
  check('coor: int32 count then 3N doubles, little-endian', r.atoms.length === 10 && near(r.atoms[1].y, 0.8, 1e-12) && near(r.atoms[9].z, 20, 1e-12) && r.atoms[0].elem === undefined, r.note);
  const u8 = new Uint8Array(coorBytes(XYZ10));
  check('coor: a Uint8Array works as well as an ArrayBuffer', parseNamdCoor(u8).atoms.length === 10);
  check('coor: a big-endian file is recognised by its count matching the length', parseNamdCoor(coorBytes(XYZ10, false)).atoms.length === 10 && /big-endian/.test(parseNamdCoor(coorBytes(XYZ10, false)).note));
  const truncated = throws(() => parseNamdCoor(coorBytes(XYZ10).slice(0, 100)));
  check('coor: a wrong length is refused with the 4 + 24N rule in the message', /24/.test(truncated || ''), truncated);
  const x = parseNamdXsc(XSC);
  check('xsc: the cell vectors from the LABELS columns', JSON.stringify(x.cell) === JSON.stringify({ a: [62.2, 0, 0], b: [0, 61.5, 0], c: [0, 0, 63.1] }) && x.step === 5000, JSON.stringify(x.cell));
  check('xsc: o_x o_y o_z is the cell CENTRE; origin is the lower corner o − (a+b+c)/2, here (0, 0, 0)',
    JSON.stringify(x.center) === JSON.stringify([31.1, 30.75, 31.55]) && x.origin.every(v => near(v, 0, 1e-12)), JSON.stringify(x.origin) + ' ' + JSON.stringify(x.center));
  const moved = parseNamdXsc('#$LABELS step o_x o_y o_z a_x a_y a_z b_x b_y b_z c_x c_y c_z\n1 0 0 0 10 0 0 0 11 0 0 0 12\n');
  check('xsc: columns are found by their labels, not their position', near(moved.cell.a[0], 10) && near(moved.cell.b[1], 11) && near(moved.cell.c[2], 12), JSON.stringify(moved.cell));
  const flat = throws(() => parseNamdXsc('#$LABELS step a_x a_y a_z b_x b_y b_z o_x o_y o_z\n1 10 0 0 0 10 0 0 0 0\n'));
  check('xsc: a cell periodic in two directions only is refused and says so', /a, b of a, b, c/.test(flat || ''), flat);
  const xst = parseNamdXsc(XSC + '6000 63.0 0 0 0 62.0 0 0 0 64.0 31.5 31 32 0 0 0 0 0 0\n');
  check('xsc: an .xst with many rows gives the LAST cell', near(xst.cell.a[0], 63) && xst.step === 6000, JSON.stringify(xst.cell));
}
/* the NAMD set */
{
  const r = parseMDSet([{ name: 'run.psf', text: PSF }, { name: 'run.coor', bytes: coorBytes(XYZ10) }, { name: 'run.xsc', text: XSC }]);
  check('set: psf + coor → structure with the psf\'s elements and the coor\'s positions', r.program === 'NAMD' && elems(r) === 'N H C C O Na Ca O X X' && near(r.atoms[1].y, 0.8, 1e-12) && r.bonds.length === 4, elems(r));
  check('set: the xsc in the set becomes the cell', r.cell && near(r.cell.a[0], 62.2) && r.periodic === 'a NAMD cell' && /run\.xsc/.test(r.note), r.note);
  const noXsc = parseMDSet([{ name: 'run.psf', text: PSF }, { name: 'run.coor', bytes: new Uint8Array(coorBytes(XYZ10)) }]);
  check('set: psf + coor without an xsc has no cell', !noXsc.cell && !noXsc.periodic, String(noXsc.periodic));
  const alone = throws(() => parseMDSet([{ name: 'run.coor', bytes: coorBytes(XYZ10) }]));
  check('set: a coor alone is refused and the message names the .psf', /positions only/.test(alone || '') && /\.psf/.test(alone || ''), alone);
  const psfAlone = throws(() => parseMDSet([{ name: 'run.psf', text: PSF }]));
  check('set: a psf alone is refused and the message names the .coor', /no coordinates/.test(psfAlone || '') && /\.coor/.test(psfAlone || ''), psfAlone);
  const asText = throws(() => parseMDSet([{ name: 'run.psf', text: PSF }, { name: 'run.coor', text: Buffer.from(coorBytes(XYZ10)).toString('latin1') }]));
  check('set: a coor handed over as text is refused with "ArrayBuffer" in the message', /ArrayBuffer/.test(asText || ''), asText);
  const cellOnly = parseMDSet([{ name: 'run.xsc', text: XSC }]);
  check('set: an xsc alone → a cell with no atoms, labelled a NAMD cell', cellOnly.atoms.length === 0 && cellOnly.cell && near(cellOnly.cell.c[2], 63.1) && cellOnly.periodic === 'a NAMD cell' && /already open/.test(cellOnly.note), cellOnly.note);
  const wrongPair = throws(() => parseMDSet([{ name: 'run.psf', text: PSF }, { name: 'run.coor', bytes: coorBytes(XYZ10.slice(0, 4)) }]));
  check('set: a psf and a coor of different sizes are not a pair', /not a pair/.test(wrongPair || ''), wrongPair);
  const prmCoor = parseMDSet([{ name: 'ace.prmtop', text: PRMTOP }, { name: 'ace.coor', bytes: coorBytes(XYZ9) }]);
  check('set: NAMD run on an AMBER topology — prmtop + coor pairs too', prmCoor.program === 'NAMD' && elems(prmCoor) === 'H C H H C O O H H' && near(prmCoor.atoms[0].x, -100.1234567, 1e-9), elems(prmCoor));
}

/* ================================================================ CHARMM crd
   Standard format, I5 I5 1X A4 1X A4 3F10.5 1X A4 1X A4 F10.5, generated by the format so
   that a coordinate at or below -100 fills its ten columns and runs into the next field.
   The CA cases: ALA's CA (carbon), the CAL residue's CAL and the CA residue's CA (calcium);
   a haem's NA and CAD (nitrogen, carbon) and FE (iron); a ligand's CL1 (chlorine) and HG1
   (hydrogen); SOD (sodium); a modified residue with a peptide backbone (SEP: CA is carbon). */
const crdRow = (i, resno, res, type, x, y, z, seg, resid) =>
  I(i, 5) + I(resno, 5) + ' ' + A(res, 4) + ' ' + A(type, 4) + F(x, 10, 5) + F(y, 10, 5) + F(z, 10, 5) + ' ' + A(seg, 4) + ' ' + A(resid, 4) + F(0, 10, 5);
const CRD_ROWS = [
  [1, 1, 'ALA', 'N', -100.12345, 26.307, 10.41, 'PROA', '1'],
  [2, 1, 'ALA', 'CA', -101.1, 26.6, 10.9, 'PROA', '1'],
  [3, 1, 'ALA', 'C', -102.1, 27.0, 11.5, 'PROA', '1'],
  [4, 1, 'ALA', 'O', -102.5, 28.0, 11.4, 'PROA', '1'],
  [5, 2, 'SEP', 'N', -103.0, 26.0, 12.0, 'PROA', '2'],
  [6, 2, 'SEP', 'CA', -104.0, 26.0, 12.5, 'PROA', '2'],
  [7, 2, 'SEP', 'C', -105.0, 26.5, 13.0, 'PROA', '2'],
  [8, 2, 'SEP', 'P', -104.5, 24.0, 12.0, 'PROA', '2'],
  [9, 3, 'CAL', 'CAL', 5.0, 5.0, 5.0, 'IONS', '1'],
  [10, 4, 'CA', 'CA', 8.0, 5.0, 5.0, 'IONS', '2'],
  [11, 5, 'SOD', 'SOD', 11.0, 5.0, 5.0, 'IONS', '3'],
  [12, 6, 'HEM', 'FE', 20.0, 20.0, 20.0, 'HETA', '1'],
  [13, 6, 'HEM', 'NA', 22.0, 20.0, 20.0, 'HETA', '1'],
  [14, 6, 'HEM', 'NB', 20.0, 22.0, 20.0, 'HETA', '1'],
  [15, 6, 'HEM', 'CAD', 24.0, 20.0, 20.0, 'HETA', '1'],
  [16, 6, 'HEM', 'C1A', 24.0, 21.0, 20.0, 'HETA', '1'],
  [17, 6, 'HEM', 'HHA', 25.0, 21.0, 20.0, 'HETA', '1'],
  [18, 7, 'LIG', 'C1', 30.0, 30.0, 30.0, 'HETB', '1'],
  [19, 7, 'LIG', 'CL1', 31.7, 30.0, 30.0, 'HETB', '1'],
  [20, 7, 'LIG', 'HG1', 29.0, 30.5, 30.0, 'HETB', '1'],
  [21, 7, 'LIG', 'N1', 30.0, 31.4, 30.0, 'HETB', '1'],
  [22, 7, 'LIG', 'BR1', 30.0, 30.0, 31.9, 'HETB', '1'],
  [23, 8, 'TIP3', 'OH2', 40.0, 40.0, 40.0, 'WAT', '1'],
  [24, 8, 'TIP3', 'H1', 40.958, 40.0, 40.0, 'WAT', '1'],
  [25, 8, 'TIP3', 'H2', 39.76, 40.93, 40.0, 'WAT', '1'],
];
const CRD = '* MDGEOM FIXTURE\n*  DATE:     9/12/26     10:00:00      CREATED BY USER: dante\n*\n' + I(CRD_ROWS.length, 5) + '\n' + CRD_ROWS.map(r => crdRow(...r)).join('\n') + '\n';
{
  check('crd fixture: the first row really runs -100.12345 into 26.30700', /-100\.12345  26\.30700/.test(CRD), CRD.split('\n')[4]);
  const r = parseCharmmCrd(CRD);
  const want = 'N C C O N C C P Ca Ca Na Fe N N C C H C Cl H N Br O H H';
  check('crd: 25 atoms, standard columns', r.atoms.length === 25 && r.program === 'CHARMM', String(r.atoms.length));
  check('crd: CA is carbon in ALA, calcium in CAL and in the CA residue', r.atoms[1].elem === 'C' && r.atoms[8].elem === 'Ca' && r.atoms[9].elem === 'Ca', elems(r));
  check('crd: SOD is sodium', r.atoms[10].elem === 'Na', elems(r));
  check('crd: a haem\'s FE is iron, its NA and NB nitrogens, its CAD a carbon', r.atoms[11].elem === 'Fe' && r.atoms[12].elem === 'N' && r.atoms[13].elem === 'N' && r.atoms[14].elem === 'C', elems(r));
  check('crd: a ligand\'s CL1 and BR1 are halogens, its HG1 a hydrogen, its N1 a nitrogen', r.atoms[18].elem === 'Cl' && r.atoms[21].elem === 'Br' && r.atoms[19].elem === 'H' && r.atoms[20].elem === 'N', elems(r));
  check('crd: a modified residue with a peptide backbone (SEP) keeps CA a carbon and reads P as phosphorus', r.atoms[5].elem === 'C' && r.atoms[7].elem === 'P', elems(r));
  check('crd: water', r.atoms[22].elem === 'O' && near(dist(r.atoms[22], r.atoms[23]), 0.958), elems(r));
  check('crd: the whole assignment', elems(r) === want, elems(r));
  check('crd: the run-together coordinate is read by column (-100.12345, 26.307)', near(r.atoms[0].x, -100.12345, 1e-9) && near(r.atoms[0].y, 26.307, 1e-9) && near(r.atoms[0].z, 10.41, 1e-9), JSON.stringify(r.atoms[0]));
  check('crd: names, residues, resid and segid kept', r.atoms[1].atom === 'CA' && r.atoms[1].resn === 'ALA' && r.atoms[1].resi === 1 && r.atoms[1].chain === 'PROA' && r.atoms[10].resi === 3 && r.atoms[10].chain === 'IONS', JSON.stringify(r.atoms[10]));
  /* EXT: I10 I10 2X A8 2X A8 3F20.10 2X A8 2X A8 F20.10 */
  const extRow = (i, resno, res, type, x, y, z, seg, resid) =>
    I(i, 10) + I(resno, 10) + '  ' + A(res, 8) + '  ' + A(type, 8) + F(x, 20, 10) + F(y, 20, 10) + F(z, 20, 10) + '  ' + A(seg, 8) + '  ' + A(resid, 8) + F(0, 20, 10);
  const EXT = '* GENERATED BY CHARMM-GUI\n*\n' + I(CRD_ROWS.length, 10) + '  EXT\n' + CRD_ROWS.map(r => extRow(...r)).join('\n') + '\n';
  const e = parseCharmmCrd(EXT);
  check('crd EXT: the wide format reads to the same atoms', e.atoms.length === 25 && elems(e) === want && near(e.atoms[0].x, -100.12345, 1e-9) && e.atoms[1].chain === 'PROA' && /EXT/.test(e.note), elems(e));
  const free = parseCharmmCrd('* free\n*\n    3\n1 1 TIP3 OH2 0.0 0.0 0.0 WAT 1 0.0\n2 1 TIP3 H1 0.958 0.0 0.0 WAT 1 0.0\n3 1 TIP3 H2 -0.24 0.927 0.0 WAT 1 0.0\n');
  check('crd: a file written free-format falls back to whitespace', elems(free) === 'O H H' && near(dist(free.atoms[0], free.atoms[1]), 0.958), elems(free));
  const c = parseCharmmCrd(CRD.replace(/\n/g, '\r\n'));
  check('crd: reads the same with CRLF', elems(c) === want && near(c.atoms[0].x, -100.12345, 1e-9));
  const alone = parseMDSet([{ name: 'system.crd', text: CRD }]);
  check('set: a crd alone is a structure (names carry the elements), no bonds, no cell', alone.program === 'CHARMM' && elems(alone) === want && !alone.bonds && !alone.cell, alone.note);
  const pair = parseMDSet([{ name: 'w.psf', text: `PSF\n\n       3 !NATOM\n       1 WAT  1    TIP3 OH2  OT    -0.834000       15.9994           0\n       2 WAT  1    TIP3 H1   HT     0.417000        1.0080           0\n       3 WAT  1    TIP3 H2   HT     0.417000        1.0080           0\n\n       2 !NBOND: bonds\n       1       2       1       3\n` },
                            { name: 'w.crd', text: '* water\n*\n    3\n' + crdRow(1, 1, 'TIP3', 'OH2', 0, 0, 0, 'WAT', '1') + '\n' + crdRow(2, 1, 'TIP3', 'H1', 0.958, 0, 0, 'WAT', '1') + '\n' + crdRow(3, 1, 'TIP3', 'H2', -0.24, 0.927, 0, 'WAT', '1') + '\n' }]);
  check('set: psf + crd → the psf\'s bonds on the crd\'s coordinates', pair.program === 'CHARMM' && pair.bonds.length === 2 && near(dist(pair.atoms[0], pair.atoms[1]), 0.958) && elems(pair) === 'O H H', pair.note);
}

/* ================================================================ the element helpers */
{
  check('elemFromMass: 12.011 C, 1.008 H, 55.845 Fe, 22.99 Na, 65.4 Zn (AMBER\'s rounding), 40.08 Ca',
    elemFromMass(12.011) === 'C' && elemFromMass(1.008) === 'H' && elemFromMass(55.845) === 'Fe' && elemFromMass(22.99) === 'Na' && elemFromMass(65.4) === 'Zn' && elemFromMass(40.08) === 'Ca');
  check('elemFromMass: cobalt and nickel are told apart (58.933 / 58.693)', elemFromMass(58.933) === 'Co' && elemFromMass(58.693) === 'Ni');
  check('elemFromMass: 72 (a MARTINI bead), 0 (a virtual site) and 0.4 (a Drude particle) match nothing',
    elemFromMass(72) === null && elemFromMass(0) === null && elemFromMass(0.4) === null);
  /* the trap the label rule exists for: AMBER's iron is 55.0, and 54.938 (Mn) is nearer than 55.845 */
  check('elemFromMass: 55.0 alone is manganese — which is why a label within a unit of the mass wins', elemFromMass(55.0) === 'Mn', String(elemFromMass(55.0)));
  check('elemFromLabelMass: FE 55.0 → Fe, SOD 22.9898 → Na (the mass), CA 12.011 → C (agreement), Ca 40.0 → Ca (Ar by mass alone), P4 72 → nothing',
    elemFromLabelMass('FE', 55.0) === 'Fe' && elemFromLabelMass('SOD', 22.9898) === 'Na' && elemFromLabelMass('CA', 12.011) === 'C' &&
    elemFromLabelMass('Ca', 40.0) === 'Ca' && elemFromLabelMass('P4', 72) === null && elemFromLabelMass('', 12.011) === 'C',
    [elemFromLabelMass('FE', 55.0), elemFromLabelMass('SOD', 22.9898), elemFromLabelMass('CA', 12.011), elemFromLabelMass('Ca', 40.0), elemFromLabelMass('P4', 72)].join(' '));
  check('elemFromAtomName: CA in a protein residue is C, in a one-atom CA residue is Ca', elemFromAtomName('CA', 'GLY') === 'C' && elemFromAtomName('CA', 'CA', new Set(['CA'])) === 'Ca');
  check('elemFromAtomName: AMBER\'s NALA and CGLY are amino acids', elemFromAtomName('CA', 'NALA') === 'C' && elemFromAtomName('CD', 'CGLY') === 'C');
  check('elemFromAtomName: MSE\'s SE is selenium, CYS\'s SG sulphur, HIS\'s NE2 nitrogen', elemFromAtomName('SE', 'MSE') === 'Se' && elemFromAtomName('SG', 'CYS') === 'S' && elemFromAtomName('NE2', 'HIS') === 'N');
  check('elemFromAtomName: chlorophyll\'s residue is CLA and its MG is magnesium', elemFromAtomName('MG', 'CLA', new Set(['MG', 'NA', 'NB', 'C1A', 'C2A']), 60) === 'Mg');
  check('elemFromAtomName: the chloride ion residue CLA', elemFromAtomName('CLA', 'CLA', new Set(['CLA']), 1) === 'Cl');
  check('elemFromAtomName: a mercury ion residue HG is mercury; HG in anything else is hydrogen', elemFromAtomName('HG', 'HG', new Set(['HG']), 1) === 'Hg' && elemFromAtomName('HG', 'LIG', new Set(['HG', 'C1']), 2) === 'H');
  check('elemFromAtomName: AMBER ion names Na+, Cl-, K+', elemFromAtomName('Na+', 'Na+', new Set(['Na+']), 1) === 'Na' && elemFromAtomName('Cl-', 'Cl-', new Set(['Cl-']), 1) === 'Cl' && elemFromAtomName('K+', 'K+', new Set(['K+']), 1) === 'K');
  check("elemFromAtomName: a nucleotide's C1' and P", elemFromAtomName("C1'", 'DG') === 'C' && elemFromAtomName('P', 'DG') === 'P' && elemFromAtomName("O5'", 'RC') === 'O');
}

/* ================================================================ sniffMD */
{
  const rst = rst7Of('ACE + water', XYZ9, { time: 10, box: [25, 26, 27, 90, 90, 90] });
  const cases = [
    ['run.data', LMP_FULL, 'lammps-data'], ['run.lmp', LMP_TRI, 'lammps-data'], ['x', lmpBody(['1 1 5 5 5']), 'lammps-data'],
    ['run.lammpstrj', DUMP_SCALED, 'lammps-dump'], ['dump.txt', DUMP_TRI, 'lammps-dump'], ['a.dump', DUMP_XU, 'lammps-dump'],
    ['ace.prmtop', PRMTOP, 'amber-prmtop'], ['ace.parm7', PRMTOP.replace(/^%VERSION[^\n]*\n/, ''), 'amber-prmtop'],
    ['ace.rst7', rst, 'amber-rst7'], ['ace.inpcrd', rst7Of('inpcrd', XYZ9), 'amber-rst7'], ['ace.rst', rst7Of('t', XYZ9, { vel: true }), 'amber-rst7'],
    ['run.psf', PSF, 'psf'], ['run.xsc', XSC, 'namd-xsc'], ['run.restart.xsc', '# NAMD extended system configuration restart file\n#$LABELS step a_x a_y a_z b_x b_y b_z c_x c_y c_z o_x o_y o_z\n1 10 0 0 0 10 0 0 0 10 0 0 0\n', 'namd-xsc'],
    ['system.crd', CRD, 'charmm-crd'], ['system.cor', CRD, 'charmm-crd'],
    ['amber.crd', rst7Of('an AMBER inpcrd that calls itself .crd', XYZ9), 'amber-rst7'],   // .crd is AMBER's name for it too: the content decides
  ];
  for (const [name, text, want] of cases) check(`sniffMD: ${name} → ${want}`, sniffMD(name, text) === want, String(sniffMD(name, text)));
  check('sniffMD: a binary .coor by its 4 + 24N length', sniffMD('run.coor', coorBytes(XYZ10)) === 'namd-coor' && sniffMD('run.restart.coor', new Uint8Array(coorBytes(XYZ10))) === 'namd-coor');
  check('sniffMD: a .vel has the same shape and is not coordinates', sniffMD('run.vel', coorBytes(XYZ10)) === null);
  check('sniffMD: bytes of the wrong length are not a .coor', sniffMD('run.coor', coorBytes(XYZ10).slice(0, 100)) === null);
  check('sniffMD: a .coor that arrived as text is still reported, so the page re-reads it as bytes', sniffMD('run.coor', Buffer.from(coorBytes(XYZ10)).toString('latin1')) === 'namd-coor');
  check('sniffMD: a PDB written by NAMD as a .coor (binaryoutput no) is not claimed', sniffMD('run.coor', 'REMARK NAMD\nATOM      1  N   MET A   1     -11.921  26.307  10.410  1.00  0.00      4AKE N\nEND\n') === null);
  const negatives = [
    ['water.xyz', '3\nwater\nO 0.000000 0.000000 0.000000\nH 0.958000 0.000000 0.000000\nH -0.240000 0.927000 0.000000\n'],
    ['numeric-comment.xyz', '3\n  -76.4\nO 0.0000000 0.0000000 0.0000000\nH 0.9580000 0.0000000 0.0000000\nH -0.2400000 0.9270000 0.0000000\n'],
    ['water.gro', 'water\n    3\n    1WATER  OW1    1   0.126   1.624   1.679\n    1WATER  HW2    2   0.190   1.661   1.747\n    1WATER  HW3    3   0.177   1.568   1.613\n   1.82060   1.82060   1.82060\n'],
    ['ache.mdcrd', 'ACE\n   6.653   6.671  -8.596   7.313   5.836  -8.829   8.325   6.223  -8.710   7.083\n   5.504  -9.842   7.113   4.617  -7.973\n'],
    ['opt_N.out', corpus('opt_N.out')], ['Urea.cif', corpus('Urea.cif')], ['DNA.pdb', corpus('DNA.pdb')],
    ['2hydronium_30w_-sol.vasp', corpus('2hydronium_30w_-sol.vasp')], ['GAMESS_US.inp', corpus('GAMESS_US.inp')], ['C18-B9N9.out', corpus('C18-B9N9.out')],
    ['in.lammps', 'units real\natom_style full\nread_data system.data\n# 100 atoms\npair_style lj/cut 10.0\nrun 1000\n'],
    ['log.lammps', 'LAMMPS (2 Aug 2023)\nReading data file ...\n  orthogonal box = (0 0 0) to (10 10 10)\n  reading atoms ...\n  100 atoms\n  100 velocities\nLoop time of 1.2 on 1 procs for 1000 steps with 100 atoms\n'],
    ['empty.txt', ''],
  ];
  for (const [name, text] of negatives) check(`sniffMD: ${name} → null`, sniffMD(name, text) === null, String(sniffMD(name, text)));
}

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
