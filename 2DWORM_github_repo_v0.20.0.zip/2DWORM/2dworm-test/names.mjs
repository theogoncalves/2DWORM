/* A NAME TYPED INTO THE PAGE, ANSWERED WITHOUT ASKING ANYONE.
 *
 * lib/names.js is a table of trivial names — water, aspirin, DMF — and nothing more, because
 * no browser build of OPSIN exists (see the header of that file for the search). What is
 * checked here is not chemistry cleverness but the two things a table can get wrong: a SMILES
 * with a typo, which draws a plausible-looking wrong molecule, and a name that is quietly
 * accepted when it should not be. So every entry's SMILES is parsed by OpenChemLib and its
 * formula compared with the one declared beside it; the stereocentres of the sugars and amino
 * acids are read back as CIP labels and compared with the labels in their IUPAC names; and a
 * systematic or nonsense name must throw an error that points at FIND, not return anything.
 *
 * OpenChemLib is the same 9.5.0 bundle the page ships, imported from the app.
 */
import { nameToSmiles, isKnownName, knownNames, NAME_TABLE, NameError, normaliseName } from '../2dworm/lib/names.js';
import OCL from '../2dworm/lib/openchemlib.js';

const { Molecule } = OCL;
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const idcode = (smi) => Molecule.fromSmiles(smi).getIDCode();
const formulaOf = (smi) => Molecule.fromSmiles(smi).getMolecularFormula().formula;
/** CIP label of every stereocentre, in SMILES atom order — "R", "S" per centre. */
const cipOf = (smi) => {
  const m = Molecule.fromSmiles(smi);
  m.ensureHelperArrays(Molecule.cHelperCIP);
  const out = [];
  for (let i = 0; i < m.getAllAtoms(); i++) {
    const p = m.getAtomCIPParity(i);
    if (p) out.push(p === Molecule.cAtomCIPParityRorM ? 'R' : p === Molecule.cAtomCIPParitySorP ? 'S' : '?');
  }
  return out.join('');
};
const fails = async (name) => { try { await nameToSmiles(name); return null; } catch (e) { return e; } };

/* ------------------------------------------------ the names the task asked about */
const ethanol = await nameToSmiles('ethanol');
check('"ethanol" is answered from the table', ethanol && ethanol.source === 'table' && idcode(ethanol.smiles) === idcode('CCO'), JSON.stringify(ethanol));
check('— and the answer carries a display name, a formula and an (empty) warnings list',
  ethanol.name === 'ethanol' && ethanol.formula === 'C2H6O' && Array.isArray(ethanol.warnings) && ethanol.warnings.length === 0);

const tbuoh = await nameToSmiles('2-methylpropan-2-ol');
check('"2-methylpropan-2-ol" — tert-butanol is common enough to be in the table', idcode(tbuoh.smiles) === idcode('CC(C)(C)O'), tbuoh.name);

const dmf = await nameToSmiles('N,N-dimethylformamide');
check('"N,N-dimethylformamide" is DMF', idcode(dmf.smiles) === idcode('CN(C)C=O') && idcode((await nameToSmiles('DMF')).smiles) === idcode(dmf.smiles));

const aspirin = await nameToSmiles('acetylsalicylic acid');
check('"acetylsalicylic acid" is aspirin, C9H8O4', idcode(aspirin.smiles) === idcode('CC(=O)Oc1ccccc1C(=O)O') && aspirin.formula === 'C9H8O4');

/* A coordination name. OPSIN would read it; a table cannot, and must say so rather than guess. */
const cr = await fails('hexacarbonylchromium');
check('"hexacarbonylchromium" is refused — systematic and coordination names need OPSIN, which is not bundled',
  cr instanceof NameError && /not a name this page knows/.test(cr.message), cr && cr.message);
const sys = await fails('3-ethylpentane');
check('a plain systematic name not in the table is refused the same way', sys instanceof NameError && sys.kind === 'unknown');

const nonsense = await fails('flurbogaster');
check('a nonsense name throws a NameError that points at FIND, PubChem, Wikidata and the NCI resolver',
  nonsense instanceof NameError && nonsense.kind === 'unknown' &&
  /try FIND/.test(nonsense.message) && /PubChem/.test(nonsense.message) && /Wikidata/.test(nonsense.message) && /NCI/.test(nonsense.message),
  nonsense && nonsense.message);
check('— the error remembers what was asked', nonsense && nonsense.query === 'flurbogaster');
const empty = await fails('   ');
check('an empty name is refused as empty, not as unknown', empty instanceof NameError && empty.kind === 'empty');
const notString = await fails(undefined);
check('— and so is no name at all', notString instanceof NameError && notString.kind === 'empty');

/* ---------------------------------------------------- spelling that people use */
check('case, surrounding blanks and repeated spaces do not matter',
  (await nameToSmiles('  ETHANOL ')).name === 'ethanol' && (await nameToSmiles('Acetic   Acid')).name === 'acetic acid');
check('an en-dash or em-dash typed for the hyphen is accepted',
  (await nameToSmiles('N,N–dimethylformamide')).name === 'N,N-dimethylformamide' &&
  (await nameToSmiles('2—methylpropan—2—ol')).name === 'tert-butanol');
check('"dimethyl sulfoxide" and "dimethylsulfoxide" are the same entry',
  (await nameToSmiles('dimethyl sulfoxide')).name === (await nameToSmiles('dimethylsulfoxide')).name);
check('a trailing full stop is forgiven', (await nameToSmiles('caffeine.')).name === 'caffeine');
check('lab shorthand: THF, DMSO, EtOH, MeCN, DCM, EtOAc',
  (await nameToSmiles('THF')).name === 'tetrahydrofuran' && (await nameToSmiles('dmso')).name === 'dimethyl sulfoxide' &&
  (await nameToSmiles('EtOH')).name === 'ethanol' && (await nameToSmiles('MeCN')).name === 'acetonitrile' &&
  (await nameToSmiles('DCM')).name === 'dichloromethane' && (await nameToSmiles('EtOAc')).name === 'ethyl acetate');
check('IUPAC spellings of table entries are aliases: propan-2-one, ethanoic acid, oxolane, methylbenzene, oxidane',
  (await nameToSmiles('propan-2-one')).name === 'acetone' && (await nameToSmiles('ethanoic acid')).name === 'acetic acid' &&
  (await nameToSmiles('oxolane')).name === 'tetrahydrofuran' && (await nameToSmiles('methylbenzene')).name === 'toluene' &&
  (await nameToSmiles('oxidane')).name === 'water');
check('normaliseName is what the lookup uses, and is exported so the page can key a datalist on it',
  normaliseName(' N,N–Dimethyl  Formamide. ') === 'n,n-dimethyl formamide');
check('isKnownName agrees with nameToSmiles, synchronously',
  isKnownName('Aspirin') === true && isKnownName('hexacarbonylchromium') === false && isKnownName('') === false);
const names = knownNames();
check('knownNames lists every display name once, sorted, for a datalist',
  Array.isArray(names) && names.length === NAME_TABLE.length && new Set(names).size === names.length &&
  names.every((n, i) => i === 0 || names[i - 1].localeCompare(n) < 0), names.length + ' names');

/* --------------------------------------------- the twenty the brief listed, by name */
const asked = ['water', 'methanol', 'ethanol', 'benzene', 'toluene', 'phenol', 'acetic acid', 'aspirin', 'acetylsalicylic acid',
  'caffeine', 'glucose', 'urea', 'ammonia', 'ethylene', 'acetone', 'DMSO', 'DMF', 'THF', 'pyridine', 'ferrocene', 'EDTA'];
const missing = [];
for (const n of asked) if (!isKnownName(n)) missing.push(n);
check('every name the brief listed is in the table', missing.length === 0, missing.join(', ') || 'all present');

/* ---------------------------------------------- every entry: formula and stereo */
let bad = [], dupAlias = [], seen = new Map();
for (const e of NAME_TABLE) {
  let f;
  try { f = formulaOf(e.smiles); } catch (err) { bad.push(`${e.name}: SMILES does not parse (${err.message})`); continue; }
  if (f !== e.formula) bad.push(`${e.name}: SMILES is ${f}, table says ${e.formula}`);
  if (e.cip !== undefined && cipOf(e.smiles) !== e.cip) bad.push(`${e.name}: stereocentres read ${cipOf(e.smiles)}, table says ${e.cip}`);
  if (e.cip === undefined && cipOf(e.smiles) !== '') bad.push(`${e.name}: has stereocentres (${cipOf(e.smiles)}) but declares none`);
  for (const a of [e.name, ...e.aliases]) {
    const k = normaliseName(a);
    if (seen.has(k)) dupAlias.push(`"${a}" → ${seen.get(k)} and ${e.name}`);
    seen.set(k, e.name);
  }
}
check('every SMILES in the table parses and has the formula written beside it', bad.length === 0, bad.slice(0, 4).join(' | '));
check('every entry with stereocentres declares their CIP labels, and they match', !bad.some(b => /stereo/.test(b)));
check('no spelling is listed twice — in two entries, or twice in one', dupAlias.length === 0, dupAlias.slice(0, 3).join(' | '));
check('the table is small — a trivial-name table, not a nomenclature engine', NAME_TABLE.length >= 20 && NAME_TABLE.length <= 80, NAME_TABLE.length + ' entries');

/* The two sugars and the amino acids are where a wrong '@' draws the enantiomer, which
   is the wrong molecule, so their labels are pinned by hand as well as by the table. */
const glc = await nameToSmiles('glucose');
check('"glucose" is β-D-glucopyranose, (2R,3R,4S,5S,6R)-6-(hydroxymethyl)oxane-2,3,4,5-tetrol',
  glc.formula === 'C6H12O6' && cipOf(glc.smiles) === 'RRRSS' && idcode(glc.smiles) === idcode('C([C@@H]1[C@H]([C@@H]([C@H]([C@@H](O1)O)O)O)O)O'),
  cipOf(glc.smiles));
check('— and "D-glucose", "dextrose", "beta-D-glucose" are the same entry',
  (await nameToSmiles('D-glucose')).name === glc.name && (await nameToSmiles('dextrose')).name === glc.name &&
  (await nameToSmiles('β-D-glucose')).name === glc.name);
const ala = await nameToSmiles('alanine');
check('"alanine" is L-alanine, (S)-2-aminopropanoic acid', ala.formula === 'C3H7NO2' && cipOf(ala.smiles) === 'S');
const fc = await nameToSmiles('ferrocene');
check('"ferrocene" is Fe(II) with two cyclopentadienide rings, C10H10Fe — a form every SMILES reader accepts',
  fc.formula === 'C10H10Fe' && /Fe\+2|Fe\+\+/.test(fc.smiles) && fc.warnings.length === 1 && /η|hapto|sandwich/i.test(fc.warnings[0]),
  fc.warnings[0]);
check('"EDTA" is the tetra-acid, C10H16N2O8', (await nameToSmiles('EDTA')).formula === 'C10H16N2O8');
check('"caffeine" is 1,3,7-trimethylxanthine, C8H10N4O2',
  idcode((await nameToSmiles('caffeine')).smiles) === idcode('CN1C=NC2=C1C(=O)N(C(=O)N2C)C') &&
  (await nameToSmiles('1,3,7-trimethylxanthine')).name === 'caffeine');

/* --------------------------------------------------------------- the result shape */
const shape = await nameToSmiles('urea');
check('the result is exactly { smiles, name, formula, source, warnings }',
  Object.keys(shape).sort().join(',') === 'formula,name,smiles,source,warnings' && shape.source === 'table');
check('the result is a fresh object each time, so a caller may edit it', (await nameToSmiles('urea')) !== shape);

const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
