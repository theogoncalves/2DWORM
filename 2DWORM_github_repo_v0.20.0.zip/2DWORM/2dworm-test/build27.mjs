/* BUILD 27 — Dante's first test of build 26, in a real browser.
   The FIND dialog that had no text box (the database menu had grown to the width of the
   dialog); the BUG palette crossing to 2DWORM-VR and back, and into a link; the horizon
   background with its ground; the bigger pick cubes; pictures; the help card on the hand and
   the HELP overlay on the flat page. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8827;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP], { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const errors = [];

/* ------------------------------------------------------------ FIND: a box to type in, at three sizes */
for (const [w, h, name] of [[1400, 900, 'a PC'], [1024, 768, 'a tablet'], [430, 900, 'a phone']]) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h } });
  const page = await ctx.newPage();
  page.on('pageerror', e => errors.push(e.message));
  await page.goto(`http://127.0.0.1:${PORT}/index.html`);
  await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
  await page.click('#btnFind'); await page.waitForTimeout(700);
  const f = await page.evaluate(() => {
    const dlg = document.getElementById('findDlg').getBoundingClientRect();
    const inp = document.getElementById('findInput').getBoundingClientRect();
    const sel = document.getElementById('findWhere').getBoundingClientRect();
    const go = document.getElementById('btnFindGo').getBoundingClientRect();
    const opts = document.getElementById('findWhere').options.length;
    return { inp: Math.round(inp.width), sel: Math.round(sel.width), goIn: go.width > 0 && go.right <= dlg.right + 1 && go.bottom <= dlg.bottom + 1, opts };
  });
  check(`FIND on ${name}: the text box is a text box (${f.inp} px wide), the database menu is capped (${f.sel} px), SEARCH is inside the dialog, ${f.opts} databases listed`,
    f.inp >= 140 && f.sel <= 320 && f.goIn && f.opts >= 3);
  await ctx.close();
}

/* ------------------------------------------------------------ the rest, on one page */
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await ctx.newPage();
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
const D = (fn, arg) => page.evaluate(fn, arg);
check('it is build 27 or later', (parseInt((await page.$eval('#buildTag', e => e.textContent)).match(/build (\d+)/)[1], 10) >= 27), await page.$eval('#buildTag', e => e.textContent));
await D(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CC(=O)Oc1ccccc1C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 21, null, { timeout: 120000 });

/* ------------------------------------------------------------ BUG: a palette from two numbers */
const p1 = await D(() => { const a = window.dworm2d.makeBugPalette(200, true), b = window.dworm2d.makeBugPalette(200, true), c = window.dworm2d.makeBugPalette(200, false); return { same: JSON.stringify(a) === JSON.stringify(b), differ: a.pal.bg !== c.pal.bg, hue: a.hue, dark: a.dark, nullIsRandom: window.dworm2d.makeBugPalette(null, null).hue }; });
check('a BUG palette is a function of its hue and side: the same numbers give the same palette', p1.same && p1.differ && p1.hue === 200 && p1.dark === true);
check('and a missing hue is random, not zero (null used to coerce to 0)', (() => { const hs = new Set(); return D(() => { const s = new Set(); for (let i = 0; i < 12; i++) s.add(window.dworm2d.makeBugPalette(null, null).hue); return s.size; }).then(n => n > 1); })());
await page.click('#themeSeg button[data-theme="bug"]'); await page.waitForTimeout(300);
const pageBug = await D(() => ({ hue: window.dworm2d.bugPalette.hue, dark: window.dworm2d.bugPalette.dark, bg: window.dworm2d.opts.bg }));
/* the link carries it */
const st = await D(() => window.dworm2d.buildState('compact'));
check('a link made with BUG on carries the two numbers of its palette', st && st.t === 'bug' && Array.isArray(st.tp) && st.tp[0] === pageBug.hue && st.tp[1] === (pageBug.dark ? 1 : 0), JSON.stringify(st && st.tp));
await page.click('#themeSeg button[data-theme="white"]'); await page.waitForTimeout(200);
await D(async (s) => { await window.dworm2d.applyState(s); }, st);
await page.waitForTimeout(400);
check('and applying that link brings the SAME palette back, not a new roll', await D(() => document.documentElement.getAttribute('data-theme')) === 'bug' && (await D(() => window.dworm2d.bugPalette.hue)) === pageBug.hue && (await D(() => window.dworm2d.opts.bg)) === pageBug.bg);

/* ------------------------------------------------------------ BUG crosses to 2DWORM-VR and back */
await D(() => window.dworm2d.goVR());
await page.waitForFunction(() => window.dwormVR && window.dwormVR.booted, null, { timeout: 90000 });
await page.waitForTimeout(1200);
const vrTheme = await D(() => ({ theme: document.documentElement.getAttribute('data-theme'), hue: window.dwormVR.bugPalette && window.dwormVR.bugPalette.hue, bg: window.__plugin.canvas3d.props.renderer.backgroundColor, cssBg: getComputedStyle(document.documentElement).getPropertyValue('--bg').trim(), btn: !!document.querySelector('#themeSeg button[data-theme="bug"]') }));
check('2DWORM-VR arrives in BUG, with the same palette, and Mol*\'s canvas takes its background', vrTheme.theme === 'bug' && vrTheme.hue === pageBug.hue && vrTheme.bg === parseInt(pageBug.bg.slice(1), 16) && /^hsl\(/.test(vrTheme.cssBg) && vrTheme.btn, JSON.stringify(vrTheme));
await page.click('#themeSeg button[data-theme="bug"]'); await page.waitForTimeout(200);
const vrHue = await D(() => window.dwormVR.bugPalette.hue);
check('BUG pressed on the VR page rolls a new palette there', Number.isFinite(vrHue));
/* the hand menu, the help card, a picture, the horizon */
const menu = await D(async () => { const V = window.dwormVR; const ok = await V.buildVRMenu(); return { ok, ids: V.vrMenuButtons.filter(b => !b.card).map(b => b.id).join(' '), reprs: V.vrMenuReprs.length, help: !!V.vrHelpRepr, helpHidden: V.vrHelpRepr ? V.vrHelpRepr.state.visible === false : null, lines: V.VR_HELP_LINES.length, font: V.VR_HELP_LINES.every(l => [...l].every(ch => ch in V.VR_FONT)) }; });
check('the hand menu has Help and Picture, fifteen buttons, the way out still last', menu.ok && menu.ids === 'render chain hide surface field resid slab bg fit save recall clear help picture leave', menu.ids);
check('the help card is built with the menu as its own representation, hidden to begin with', menu.reprs >= 2 && menu.help && menu.helpHidden === true, `${menu.reprs} representations`);
check('and every character of its twelve lines is in the panel font', menu.lines === 12 && menu.font);
const helpOn = await D(async () => { const V = window.dwormVR; V.toggleHelp(); await new Promise(r => setTimeout(r, 300)); return { on: V.vrHelpOn, card: V.vrHelpRepr.state.visible, buttons: V.vrMenuReprs[0].state.visible, msg: document.getElementById('msg').textContent }; });
check('Help shows the card and hides the buttons', helpOn.on && helpOn.card === true && helpOn.buttons === false, helpOn.msg);
const helpOff = await D(async () => { const V = window.dwormVR; V.showHelp(false); await new Promise(r => setTimeout(r, 300)); return { on: V.vrHelpOn, card: V.vrHelpRepr.state.visible, buttons: V.vrMenuReprs[0].state.visible }; });
check('and a press puts the buttons back', !helpOff.on && helpOff.card === false && helpOff.buttons === true);
const pic = await D(async () => { const V = window.dwormVR; const n = await V.takePicture(); const g = document.getElementById('vrGallery'); return { n, shots: V.vrShots.length, strip: g ? g.querySelectorAll('a[download]').length : 0, png: V.vrShots[0] && V.vrShots[0].uri.startsWith('data:image/png'), size: V.vrShots[0] ? V.vrShots[0].uri.length : 0, msg: document.getElementById('msg').textContent }; });
check('PICTURE takes a PNG through Mol*\'s screenshot helper and puts it in the strip under the view', /\.png$/.test(pic.n || '') && pic.shots === 1 && pic.strip === 1 && pic.png && pic.size > 2000, `${pic.n} · ${pic.size} chars · ${pic.msg}`);
check('the picture is named after the structure and the time', /^aspirin|^2dworm|^acetyl|^[\w.-]+_VR_\d{8}_\d{6}\.png$/.test(pic.n || ''), pic.n);
const hz = await D(async () => {
  const V = window.dwormVR; let c = null;
  for (let k = 0; k < V.VR_BG_COLOURS.length; k++) { c = V.setVRBackground(k); if (c.horizon) break; }
  await new Promise(r => setTimeout(r, 800));
  V.groundLocal = [0.2, -1.6, -0.3];
  const LA = molstar.lib.math.LinearAlgebra; const inv = LA.Mat4.invert(LA.Mat4(), window.__plugin.canvas3d.camera.view);
  V.placeGround(inv);
  const g = V.vrDyn.ground;
  const sp = g.spheres[0] && g.spheres[0].obj.values.boundingSphere.ref.value;
  return { name: c.name, bg: window.__plugin.canvas3d.props.renderer.backgroundColor, on: g.on, repr: !!g.repr, radius: sp ? sp.radius : 0, mPerUnit: V.metresPerSceneUnit(), n: V.VR_BG_COLOURS.length, across: 2 * (V.VR_GROUND_RADIUS_M || 6) };
});
check('a seventh background, HORIZON: a sky colour, and a ground built in the scene', hz.n === 7 && hz.name === 'horizon' && hz.bg === 0x2b3a4d && hz.on && hz.repr, JSON.stringify(hz));
check(`the ground is ${hz.across} metres across in the room (twelve in build 27, twenty since 28), placed through the same bridge as the hand menu`, hz.radius > 0 && Math.abs(hz.radius * hz.mPerUnit - hz.across / 2) / (hz.across / 2) < 0.35, `radius ${hz.radius.toFixed(1)} units × ${hz.mPerUnit.toFixed(4)} m = ${(hz.radius * hz.mPerUnit).toFixed(1)} m`);
const hzOff = await D(async () => { const V = window.dwormVR; const c = V.setVRBackground(V.VR_BG_COLOURS.findIndex(x => x.name === 'black')); await new Promise(r => setTimeout(r, 500)); return { name: c.name, on: V.vrDyn.ground.on, repr: !!V.vrDyn.ground.repr, bg: window.__plugin.canvas3d.props.renderer.backgroundColor }; });
check('any other background takes the ground away again, and black is still the session default', hzOff.name === 'black' && !hzOff.on && !hzOff.repr && hzOff.bg === 0 && (await D(() => window.dwormVR.VR_BG_COLOURS.findIndex(c => c.name === 'black'))) === 5);
check('the pick cubes are half as big again (0.33 Å half-size, was 0.22)', (await D(() => window.dwormVR.VR_PICK_HALF)) === 0.33);
check('the help card mentions the horizon backgrounds, the picture and the card itself', (await D(() => window.dwormVR.VR_HELP_LINES.join('|'))).includes('PICTURE') && (await D(() => window.dwormVR.VR_HELP_LINES.join('|'))).includes('THIS CARD') && (await D(() => window.dwormVR.VR_HELP_LINES.join('|'))).includes('BACKGROUNDS'));
/* the flat HELP overlay */
await page.click('#btnHelp'); await page.waitForTimeout(200);
check('HELP on the flat page opens a list of the controls, here and in the headset', await page.isVisible('#helpDlg') && /In the headset/.test(await page.textContent('#helpDlg')) && /PICTURE/.test(await page.textContent('#helpDlg')) && /horizon/.test(await page.textContent('#helpDlg')));
await page.keyboard.press('Escape'); await page.waitForTimeout(200);
check('and Escape closes it', !(await page.isVisible('#helpDlg')));
/* RETURN brings the VR page's palette home */
await D(() => document.getElementById('btnReturn').click());
await page.waitForFunction(() => /Back from/.test(document.getElementById('msg').textContent), null, { timeout: 90000 });
await page.waitForTimeout(500);
const home = await D(() => ({ theme: document.documentElement.getAttribute('data-theme'), hue: window.dworm2d.bugPalette && window.dworm2d.bugPalette.hue }));
check('RETURN brings the palette chosen in 2DWORM-VR back to 2D-WORM', home.theme === 'bug' && home.hue === vrHue && vrHue !== pageBug.hue, `${pageBug.hue} → VR ${vrHue} → back ${home.hue}`);

check('no page errors', errors.filter(e => !/favicon|ResizeObserver|WebGL|swiftshader|Could not create/i.test(e)).length === 0, errors.slice(0, 3).join(' | '));
await browser.close(); server.kill();
const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
