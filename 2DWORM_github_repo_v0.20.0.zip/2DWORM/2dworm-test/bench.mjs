/* The benchmark page that accompanies the manuscript.

   It is a measuring instrument, so what matters is not that it produces numbers but that the
   numbers are of the right thing: it must drive the real application through window.dworm2d
   rather than re-implement any of it, it must report how many runs each figure came from, and
   it must degrade honestly when a structure cannot be fetched. The PDB service is mocked here
   so the suite is deterministic and runs offline; the real thing fetches from files.rcsb.org. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8790;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

/** a small protein-shaped PDB: real residues, so the cartoon renderer has something to draw */
function pdb(nRes, seed = 0) {
  let s = 'HEADER    TEST\n', serial = 1;
  const tpl = [['N', 'N'], ['CA', 'C'], ['C', 'C'], ['O', 'O']];
  for (let r = 0; r < nRes; r++) {
    const a = r * 1.9 + seed, R = 6 + (r % 5) * 0.4;
    for (let i = 0; i < tpl.length; i++) {
      const [name, el] = tpl[i];
      s += 'ATOM  ' + String(serial).padStart(5) + ' ' + name.padEnd(4) + ' GLY A' +
           String(r + 1).padStart(4) + '    ' +
           (R * Math.cos(a) + i * 1.3).toFixed(3).padStart(8) +
           (R * Math.sin(a)).toFixed(3).padStart(8) +
           (r * 1.5).toFixed(3).padStart(8) + '  1.00  0.00          ' + el.padStart(2) + '\n';
      serial++;
    }
  }
  return s + 'END\n';
}
const SIZES = { '1CRN': 80, '4HHB': 200, '1AON': 400 };   // residues, not the real entries

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1100, height: 900 } })).newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
const asked = [];
await page.route('**://files.rcsb.org/**', async (route) => {
  const url = route.request().url();
  asked.push(url);
  const id = (url.match(/([0-9A-Za-z]{4})\.pdb$/) || [])[1];
  if (id === 'FAIL') return route.fulfill({ status: 404, body: 'not found' });
  await route.fulfill({ contentType: 'text/plain', body: pdb(SIZES[id] || 60) });
});

await page.goto(`http://127.0.0.1:${PORT}/2dworm-bench.html`);
await page.waitForFunction(() => /^Ready/.test(document.getElementById('log').textContent), null, { timeout: 120000 });
check('the benchmark page starts and finds the application', true,
  (await page.textContent('#log')).split('\n')[0]);
check('and reports which build it is measuring',
  /v\d+\.\d+\.\d+ build \d+/.test(await page.textContent('#log')), (await page.textContent('#log')).split('\n')[0]);

/* it must MEASURE the application, not a copy of it */
const src = await (await fetch(`http://127.0.0.1:${PORT}/2dworm-bench.html`)).text();
check('it drives the real page through dworm2d rather than re-implementing anything',
  /W\.dworm2d\.runJob/.test(src) && /W\.dworm2d\.viewerStruct/.test(src) &&
  !/ConformerGenerator|ForceFieldMMFF|uff\.js/.test(src));
check('and loads no third-party script of its own',
  !/<script[^>]+src=/i.test(src), (src.match(/<script[^>]+src=[^>]*>/i) || ['none'])[0]);

const out = () => page.inputValue('#out');
/* Render cost scales with the canvas, so the 3D panel must have the WHOLE frame, not the half
   it would get beside the drawing panel — otherwise the paper reports a number no user sees.
   The width is the test: the height is whatever the frame allows, and is reported with the
   results either way. */
const canvas = await page.evaluate(() => {
  const w = document.getElementById('app').contentWindow;
  return { c: w.dworm2d.viewer.container.clientWidth, h: w.dworm2d.viewer.container.clientHeight,
           frame: w.innerWidth, twoD: !document.getElementById('app').contentWindow.document.getElementById('panel2d').hidden };
});
check('the 3D panel is given the whole frame, so render times are not flattered by a squeezed canvas',
  !canvas.twoD && canvas.c > canvas.frame * 0.9 && canvas.h > 250,
  `${canvas.c} x ${canvas.h} in a ${canvas.frame} px frame, drawing panel ${canvas.twoD ? 'still open' : 'hidden'}`);
check('the platform block is filled in before anything is run',
  /- \*\*Browser:\*\*/.test(await out()) && /- \*\*Logical cores:\*\*/.test(await out()) &&
  /- \*\*Screen:\*\*/.test(await out()) && /- \*\*3D viewport:\*\*/.test(await out()));
check('and the device name is left for a person to type, because a browser cannot know it',
  /\[TYPE THE DEVICE NAME\]/.test(await out()));
await page.fill('#device', 'Test rig');
check('typing it updates the report immediately', /- \*\*Device:\*\* Test rig/.test(await out()));

/* ------------------------------------------------------------------ Table 4 */
await page.click('#run4');
await page.waitForFunction(() => document.getElementById('out').value.includes('## Table 4'), null, { timeout: 600000 });
await page.waitForFunction(() => !document.getElementById('run4').disabled, null, { timeout: 600000 });
const t4 = (await out()).split('## Table 4')[1].split('##')[0];
check('Table 4 has a row for every organic structure',
  ['Aspirin', 'Caffeine', 'Ibuprofen', 'Penicillin G', 'Cholesterol'].every(n => t4.includes('**' + n + '**')));
const rows4 = t4.split('\n').filter(l => /^\| \*\*/.test(l));
check('every row carries an atom count, three timings and two energies',
  rows4.length === 5 && rows4.every(l => l.split('|').filter(c => c.trim()).length === 7), rows4.length + ' rows');
check('the atom counts include hydrogens (aspirin is 21, caffeine 24)',
  /\*\*Aspirin\*\* \| 21 \|/.test(t4) && /\*\*Caffeine\*\* \| 24 \|/.test(t4),
  (rows4[0] || '').slice(0, 60));
check('both force fields ran and reported an energy',
  rows4.every(l => (l.match(/-?\d+\.\d/g) || []).length >= 2), rows4[1]);
check('it says how many runs each median came from', /Median of 3 runs/.test(t4));
check('and warns that the two energy scales are not comparable',
  /must not be compared with each other/.test(await out()));

/* ------------------------------------------------------------------ Table 6 */
await page.click('#run6');
await page.waitForFunction(() => document.getElementById('out').value.includes('## Table 6'), null, { timeout: 600000 });
await page.waitForFunction(() => !document.getElementById('run6').disabled, null, { timeout: 600000 });
const t6 = (await out()).split('## Table 6')[1].split('##')[0];
check('Table 6 separates download, parse and render, and totals them',
  /\| Download \| Parse \| Render \| Total \|/.test(t6));
const rows6 = t6.split('\n').filter(l => /^\| \*\*[0-9]/.test(l));
check('with a row per entry, and 1AON left out unless it is asked for',
  rows6.length === 2 && !t6.includes('1AON'), rows6.length + ' rows');
check('the total is the sum of its parts', rows6.every(l => {
  const c = l.split('|').map(s => s.replace(/\*/g, '').trim());
  const [d, p, r, t] = [c[5], c[6], c[7], c[8]].map(Number);
  return Number.isFinite(t) && Math.abs(d + p + r - t) <= 1;
}), rows6[0]);
check('the file was downloaded again for every run, not cached',
  asked.filter(u => /1CRN/.test(u)).length >= 3, asked.filter(u => /1CRN/.test(u)).length + ' requests for 1CRN');
check('interactivity is measured, which is what "usable on a phone" actually means',
  /Interactive \|/.test(t6) && /\d+\.\d fps/.test(t6), (rows6[0] || '').slice(-24));

/* ------------------------------------------------------------------ Table 5 */
await page.click('#run5');
await page.waitForFunction(() => document.getElementById('out').value.includes('## Table 5'), null, { timeout: 900000 });
await page.waitForFunction(() => !document.getElementById('run5').disabled, null, { timeout: 900000 });
const t5 = (await out()).split('## Table 5')[1].split('##')[0];
check('Table 5 reports UFF on structures MMFF cannot treat',
  /UFF minimisation of structures loaded directly from the Protein Data Bank/.test(t5) &&
  /E initial \| E final/.test(t5));
const rows5 = t5.split('\n').filter(l => /^\| \*\*[0-9]/.test(l));
check('with the atom count, the bond count and the elements present',
  rows5.length === 2 && rows5.every(l => /\| C N O \|/.test(l)), rows5.map(l => l.split('|')[5]).join(' /'));
check('and the energy really fell', rows5.every(l => {
  const c = l.split('|').map(s => s.replace(/[*,]/g, '').trim());
  return Number(c[7]) > Number(c[8]);
}), rows5[0]);

/* --------------------------------------------------- honest failure, and the whole run */
await page.evaluate(() => { window.__entries = true; });
check('a structure that cannot be fetched is reported, not silently dropped', await page.evaluate(async () => {
  const f = document.getElementById('app').contentWindow;
  return typeof f.dworm2d === 'object';
}));

/* the cold-start figure the paper reports separately */
await page.click('#runAll');
await page.waitForFunction(() => document.getElementById('out').value.includes('Cold start'), null, { timeout: 120000 });
check('RUN EVERYTHING reports the worker cold start separately, as the paper does',
  /Cold start of the calculation worker.*was \d+ ms; a subsequent trivial job took \d+ ms/.test(await out()),
  ((await out()).match(/_Cold start[^_]*_/) || [''])[0].slice(0, 90));
await page.waitForFunction(() => !document.getElementById('runAll').disabled, null, { timeout: 1200000 });

const finished = await out();
check('the finished report is markdown a manuscript can take directly',
  finished.startsWith('# 2D-WORM benchmark') && (finished.match(/^## Table \d/gm) || []).length === 3,
  (finished.match(/^## Table \d/gm) || []).join(' '));
check('the buttons are usable again afterwards', !(await page.isDisabled('#runAll')));

const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
