/* Validation for lib/uff.js. A subtly wrong force field is worse than none, so this
   checks three separate things:
     1. the analytic gradients against finite differences, term by term
     2. the published UFF natural bond lengths, which catch a mistyped parameter
     3. real geometries: ethane, water, benzene planarity, an octahedral complex
*/
import { uffMinimize, uffEnergy, assignTypes, naturalBondLength, UFF_PARAMS, buildTerms, energyAndGradient } from '../2dworm/lib/uff.js';

const results = [];
const check = (name, ok, info = '') => { results.push({ name, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); };
const near = (a, b, tol) => Math.abs(a - b) <= tol;

/* ------------------------------------------------------- helpers */
function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z); }
function angle(a, b, c) {          // angle a–b–c in degrees
  const ux = a.x - b.x, uy = a.y - b.y, uz = a.z - b.z;
  const vx = c.x - b.x, vy = c.y - b.y, vz = c.z - b.z;
  const lu = Math.hypot(ux, uy, uz), lv = Math.hypot(vx, vy, vz);
  return Math.acos(Math.max(-1, Math.min(1, (ux * vx + uy * vy + uz * vz) / (lu * lv)))) * 180 / Math.PI;
}
function planeRms(atoms) {         // rms distance from the best plane through the atoms
  const n = atoms.length;
  const c = atoms.reduce((s, a) => ({ x: s.x + a.x / n, y: s.y + a.y / n, z: s.z + a.z / n }), { x: 0, y: 0, z: 0 });
  let xx = 0, xy = 0, xz = 0, yy = 0, yz = 0, zz = 0;
  for (const a of atoms) {
    const p = a.x - c.x, q = a.y - c.y, r = a.z - c.z;
    xx += p * p; xy += p * q; xz += p * r; yy += q * q; yz += q * r; zz += r * r;
  }
  // smallest-eigenvector direction by power iteration on the inverse-ish: brute force is fine here
  let best = Infinity;
  for (let i = 0; i < 2000; i++) {
    const t = Math.PI * i / 2000, u = 2 * Math.PI * i * 0.618;
    const nx = Math.sin(t) * Math.cos(u), ny = Math.sin(t) * Math.sin(u), nz = Math.cos(t);
    const v = nx * (xx * nx + xy * ny + xz * nz) + ny * (xy * nx + yy * ny + yz * nz) + nz * (xz * nx + yz * ny + zz * nz);
    if (v < best) best = v;
  }
  return Math.sqrt(best / n);
}

/* ------------------------------------------------------- 1. gradients */
/* One molecule per kind of term, deliberately distorted so every term is active and
   nothing sits at a symmetric point where a wrong gradient could still read as zero. */
const gradCases = {
  'bond + angle (water, bent)': {
    atoms: [{ elem: 'O', x: 0, y: 0, z: 0 }, { elem: 'H', x: 0.85, y: 0.31, z: 0.1 }, { elem: 'H', x: -0.3, y: 0.9, z: -0.2 }],
    bonds: [{ a: 0, b: 1, o: 1 }, { a: 0, b: 2, o: 1 }],
  },
  'torsion sp3-sp3 (ethane, twisted)': {
    atoms: [
      { elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'C', x: 1.54, y: 0.05, z: 0.03 },
      { elem: 'H', x: -0.4, y: 1.0, z: 0.1 }, { elem: 'H', x: -0.4, y: -0.5, z: 0.9 }, { elem: 'H', x: -0.35, y: -0.55, z: -0.85 },
      { elem: 'H', x: 1.95, y: 0.6, z: 0.9 }, { elem: 'H', x: 1.9, y: -0.95, z: 0.1 }, { elem: 'H', x: 1.95, y: 0.5, z: -0.9 },
    ],
    bonds: [{ a: 0, b: 1, o: 1 }, { a: 0, b: 2, o: 1 }, { a: 0, b: 3, o: 1 }, { a: 0, b: 4, o: 1 },
            { a: 1, b: 5, o: 1 }, { a: 1, b: 6, o: 1 }, { a: 1, b: 7, o: 1 }],
  },
  'torsion sp2-sp2 + vdW (butadiene, skewed)': {
    atoms: [
      { elem: 'C', x: 0, y: 0, z: 0 }, { elem: 'C', x: 1.34, y: 0.1, z: 0.05 },
      { elem: 'C', x: 2.1, y: 1.3, z: 0.4 }, { elem: 'C', x: 3.44, y: 1.4, z: 0.2 },
      { elem: 'H', x: -0.6, y: -0.85, z: -0.2 }, { elem: 'H', x: -0.5, y: 0.95, z: 0.1 },
      { elem: 'H', x: 1.9, y: -0.8, z: -0.1 }, { elem: 'H', x: 1.6, y: 2.2, z: 0.7 },
      { elem: 'H', x: 4.0, y: 0.55, z: -0.2 }, { elem: 'H', x: 4.0, y: 2.3, z: 0.4 },
    ],
    bonds: [{ a: 0, b: 1, o: 2 }, { a: 1, b: 2, o: 1 }, { a: 2, b: 3, o: 2 },
            { a: 0, b: 4, o: 1 }, { a: 0, b: 5, o: 1 }, { a: 1, b: 6, o: 1 },
            { a: 2, b: 7, o: 1 }, { a: 3, b: 8, o: 1 }, { a: 3, b: 9, o: 1 }],
  },
  'octahedral metal (Ru(NH3)6, distorted)': (() => {
    const atoms = [{ elem: 'Ru', x: 0, y: 0, z: 0 }];
    const bonds = [];
    const dirs = [[1, 0, 0], [-1, 0.1, 0], [0, 1, 0.05], [0.05, -1, 0], [0, 0, 1], [0.1, 0, -1]];
    dirs.forEach((d, i) => {
      atoms.push({ elem: 'N', x: d[0] * 2.2, y: d[1] * 2.2, z: d[2] * 2.2 });
      bonds.push({ a: 0, b: atoms.length - 1, o: 1 });
    });
    return { atoms, bonds };
  })(),
};
for (const [name, s] of Object.entries(gradCases)) {
  const { types } = assignTypes(s.atoms, s.bonds);
  const terms = buildTerms(s.atoms, s.bonds, types);
  const n = s.atoms.length;
  const x1 = new Float64Array(n), D1 = new Float64Array(n);
  for (let i = 0; i < n; i++) { x1[i] = UFF_PARAMS[types[i]][2]; D1[i] = UFF_PARAMS[types[i]][3]; }
  // every non-bonded pair, so the vdW gradient is exercised too
  const excl = new Set();
  for (const b of terms.bondTerms) excl.add(b.a < b.b ? b.a + ',' + b.b : b.b + ',' + b.a);
  for (const a of terms.angleTerms) excl.add(a.i < a.k ? a.i + ',' + a.k : a.k + ',' + a.i);
  const pairs = [];
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (!excl.has(i + ',' + j)) pairs.push(i, j);
  const params = { x1, D1, cut2: 1e6 };
  const xyz = new Float64Array(n * 3);
  for (let i = 0; i < n; i++) { xyz[3 * i] = s.atoms[i].x; xyz[3 * i + 1] = s.atoms[i].y; xyz[3 * i + 2] = s.atoms[i].z; }
  const f = (v) => energyAndGradient(v, terms, new Int32Array(pairs), params);
  const { g } = f(xyz);
  const h = 1e-6;
  let worst = 0, worstAt = -1;
  for (let i = 0; i < xyz.length; i++) {
    const save = xyz[i];
    xyz[i] = save + h; const ep = f(xyz).E;
    xyz[i] = save - h; const em = f(xyz).E;
    xyz[i] = save;
    const num = (ep - em) / (2 * h);
    const err = Math.abs(num - g[i]) / Math.max(1, Math.abs(num));
    if (err > worst) { worst = err; worstAt = i; }
  }
  check(`analytic gradient matches finite differences: ${name}`, worst < 1e-5,
    `worst relative error ${worst.toExponential(2)} at coordinate ${worstAt}`);
  check(`  terms present: ${name}`, terms.bondTerms.length > 0 && terms.angleTerms.length > 0,
    `${terms.bondTerms.length} bonds, ${terms.angleTerms.length} angles, ${terms.torsionTerms.length} torsions`);
}

/* ------------------------------------------------------- 2. natural bond lengths
   The widely quoted UFF values. A typo in r1 or in the GMP electronegativity shows up
   here at once, because r_ij = r_i + r_j + r_BO − r_EN uses both.
   NOTE these are UFF's numbers, not experimental ones: UFF puts O–H at 0.99 A where
   experiment says 0.96, and that difference is the force field, not a bug. */
const refBonds = [
  ['C_3', 'C_3', 1,   1.514, 'ethane C–C'],
  ['C_3', 'H_',  1,   1.109, 'C–H'],
  ['C_R', 'C_R', 1.5, 1.379, 'benzene C–C'],
  ['C_2', 'O_2', 2,   1.221, 'carbonyl C=O'],
];
for (const [ti, tj, o, want, what] of refBonds) {
  const got = naturalBondLength(ti, tj, o);
  check(`natural length ${ti}–${tj} (${what})`, near(got, want, 0.012), `${got.toFixed(4)} A, published ${want}`);
}
/* The electronegativity correction, worked by hand for one polar bond, so the
   implementation of eq. 4 is checked and not just the parameters:
     O_3–H_ : r = 0.658 + 0.354 − r_EN
       r_EN = 0.658·0.354·(√8.741 − √4.528)² / (8.741·0.658 + 4.528·0.354) */
{
  const ri = 0.658, rj = 0.354, xi = 8.741, xj = 4.528;
  const d = Math.sqrt(xi) - Math.sqrt(xj);
  const byHand = ri + rj - ri * rj * d * d / (xi * ri + xj * rj);
  check('electronegativity correction matches a hand calculation',
    near(naturalBondLength('O_3', 'H_', 1), byHand, 1e-9), `${byHand.toFixed(4)} A`);
}

/* ------------------------------------------------------- 3. real geometries */
function minimised(struct, opt) { return uffMinimize(struct, opt); }

// ethane from a deliberately bad starting geometry
{
  const s = gradCases['torsion sp3-sp3 (ethane, twisted)'];
  const r = minimised({ atoms: s.atoms.map(a => ({ ...a })), bonds: s.bonds });
  const a = r.atoms;
  check('ethane: energy goes down', r.e1 < r.e0, `${r.e0.toFixed(2)} → ${r.e1.toFixed(2)} kcal/mol in ${r.its} steps`);
  check('ethane: C–C is the UFF length', near(dist(a[0], a[1]), 1.514, 0.02), dist(a[0], a[1]).toFixed(3) + ' A');
  const ch = [2, 3, 4].map(i => dist(a[0], a[i]));
  check('ethane: C–H is the UFF length', ch.every(d => near(d, 1.109, 0.02)), ch.map(d => d.toFixed(3)).join(', '));
  const hch = angle(a[2], a[0], a[3]);
  check('ethane: H–C–H near tetrahedral', near(hch, 109.5, 3), hch.toFixed(1) + ' deg');
}
// water and ammonia: the equilibrium angle is read straight off theta0 in the table,
// so these two confirm t0(O_3) = 104.51 and t0(N_3) = 106.70 independently of the bonds
{
  const s = gradCases['bond + angle (water, bent)'];
  const r = minimised({ atoms: s.atoms.map(a => ({ ...a })), bonds: s.bonds });
  const a = r.atoms;
  check('water: O–H is the UFF length', near(dist(a[0], a[1]), 0.990, 0.02), dist(a[0], a[1]).toFixed(3) + ' A');
  const hoh = angle(a[1], a[0], a[2]);
  check('water: H–O–H is the UFF angle', near(hoh, 104.51, 2), hoh.toFixed(2) + ' deg');
}
{
  const atoms = [{ elem: 'N', x: 0, y: 0, z: 0 }, { elem: 'H', x: 1.0, y: 0.1, z: 0.1 },
                 { elem: 'H', x: -0.4, y: 0.95, z: -0.1 }, { elem: 'H', x: -0.35, y: -0.5, z: 0.9 }];
  const bonds = [{ a: 0, b: 1, o: 1 }, { a: 0, b: 2, o: 1 }, { a: 0, b: 3, o: 1 }];
  const r = minimised({ atoms, bonds });
  const angs = [angle(r.atoms[1], r.atoms[0], r.atoms[2]), angle(r.atoms[1], r.atoms[0], r.atoms[3]), angle(r.atoms[2], r.atoms[0], r.atoms[3])];
  check('ammonia: H–N–H is the UFF angle, so it stays pyramidal',
    angs.every(a => near(a, 106.7, 2)), angs.map(a => a.toFixed(1)).join(', ') + ' deg');
}
// benzene: start puckered, it must come back flat with equal bonds
{
  const atoms = [], bonds = [];
  for (let i = 0; i < 6; i++) {
    const t = i * Math.PI / 3;
    atoms.push({ elem: 'C', x: 1.42 * Math.cos(t), y: 1.42 * Math.sin(t), z: (i % 2 ? 0.25 : -0.25) });
  }
  for (let i = 0; i < 6; i++) {
    const t = i * Math.PI / 3;
    atoms.push({ elem: 'H', x: 2.5 * Math.cos(t), y: 2.5 * Math.sin(t), z: (i % 2 ? 0.45 : -0.45) });
  }
  for (let i = 0; i < 6; i++) { bonds.push({ a: i, b: (i + 1) % 6, o: 4 }); bonds.push({ a: i, b: 6 + i, o: 1 }); }
  const r = minimised({ atoms, bonds }, { maxIts: 800 });
  const cc = [];
  for (let i = 0; i < 6; i++) cc.push(dist(r.atoms[i], r.atoms[(i + 1) % 6]));
  const rms = planeRms(r.atoms);
  check('benzene: typed as resonant carbon', r.types.slice(0, 6).every(t => t === 'C_R'), r.types.slice(0, 6).join(' '));
  check('benzene: all six C–C equal at the UFF length',
    cc.every(d => near(d, 1.379, 0.03)) && (Math.max(...cc) - Math.min(...cc)) < 0.01,
    cc.map(d => d.toFixed(3)).join(', '));
  check('benzene: comes back flat from a puckered start', rms < 0.03, 'rms out of plane ' + rms.toFixed(4) + ' A');
}
// an octahedral complex must keep its 90 degree angles
{
  const s = gradCases['octahedral metal (Ru(NH3)6, distorted)'];
  const struct = { atoms: s.atoms.map(a => ({ ...a })), bonds: s.bonds };
  const { types } = assignTypes(struct.atoms, struct.bonds);
  check('metal typed from its coordination geometry', types[0] === 'Ru6+2', types[0]);
  const r = minimised(struct, { maxIts: 800 });
  const angles = [];
  for (let i = 1; i <= 6; i++) for (let j = i + 1; j <= 6; j++) angles.push(angle(r.atoms[i], r.atoms[0], r.atoms[j]));
  const near90 = angles.filter(a => near(a, 90, 8)).length;
  const near180 = angles.filter(a => near(a, 180, 8)).length;
  check('octahedron: twelve 90 deg and three 180 deg angles', near90 === 12 && near180 === 3,
    `${near90} near 90, ${near180} near 180`);
  check('octahedron: Ru–N is sensible', near(dist(r.atoms[0], r.atoms[1]), 2.17, 0.15), dist(r.atoms[0], r.atoms[1]).toFixed(3) + ' A');
}
// square planar must be recognised from the geometry, not guessed
{
  const atoms = [{ elem: 'Pd', x: 0, y: 0, z: 0 }];
  const bonds = [];
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    atoms.push({ elem: 'Cl', x: dx * 2.3, y: dy * 2.3, z: 0 });
    bonds.push({ a: 0, b: atoms.length - 1, o: 1 });
  }
  const { types } = assignTypes(atoms, bonds);
  check('four ligands with a 180 deg angle read as square planar', types[0] === 'Pd4+2', types[0]);
}
// an element with no parameters must say so rather than produce nonsense
{
  try {
    uffMinimize({ atoms: [{ elem: 'Xx', x: 0, y: 0, z: 0 }, { elem: 'Xx', x: 1.5, y: 0, z: 0 }], bonds: [{ a: 0, b: 1, o: 1 }] });
    check('an unparameterised element is refused', false, 'no error thrown');
  } catch (e) {
    check('an unparameterised element is refused', /no parameters/i.test(e.message), e.message);
  }
}
// speed: a protein-sized structure must be usable, not just possible
{
  const atoms = [], bonds = [];
  const N = 1500;
  for (let i = 0; i < N; i++) {
    const t = i * 0.4, R = 4 + i * 0.001;
    atoms.push({ elem: i % 3 === 0 ? 'N' : 'C', x: R * Math.cos(t), y: R * Math.sin(t), z: i * 0.35 });
    if (i) bonds.push({ a: i - 1, b: i, o: 1 });
  }
  const t0 = Date.now();
  const r = uffMinimize({ atoms, bonds }, { maxIts: 60 });
  const ms = Date.now() - t0;
  check('1500 atoms minimise in reasonable time', ms < 20000 && r.e1 < r.e0,
    `${ms} ms, ${r.its} steps, ${r.e0.toFixed(0)} → ${r.e1.toFixed(0)} kcal/mol`);
}

const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
