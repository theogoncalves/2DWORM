/* pPBC — the pseudo-periodic box guesser, tested without a browser.
   The things that are easy to get wrong here are geometric invariants rather than parsing:
   a rigid-body move must not stretch the molecule, a minimiser must not report a volume
   that went UP, and a box that claims to hold the molecule must actually hold every
   van-der-Waals sphere. Each of those gets its own check, on shapes whose right answer can
   be written down by hand (a straight chain, a flat ring, one atom, two atoms) as well as
   on a random cloud where only the invariants are known. */
import { VDW, vdw, envelopeBox, principalAxes, guessBox, wrapCheck, describe } from '../2dworm/lib/ppbc.js';

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol;

/* A tiny deterministic generator, so a failure can be reproduced exactly. */
let seed = 20260912;
const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };

/* Rotate a point by an arbitrary tilt, used to hide the right answer from the solver. */
function tilt(p, a, b, c) {
  let [x, y, z] = p;
  let t;
  t = y * Math.cos(a) - z * Math.sin(a); z = y * Math.sin(a) + z * Math.cos(a); y = t;
  t = z * Math.cos(b) - x * Math.sin(b); x = z * Math.sin(b) + x * Math.cos(b); z = t;
  t = x * Math.cos(c) - y * Math.sin(c); y = x * Math.sin(c) + y * Math.cos(c); x = t;
  return [x, y, z];
}
const dist = (p, q) => Math.hypot(p.x - q.x, p.y - q.y, p.z - q.z);
const allPairs = (atoms) => { const d = []; for (let i = 0; i < atoms.length; i++) for (let j = i + 1; j < atoms.length; j++) d.push(dist(atoms[i], atoms[j])); return d; };

/* ---------------------------------------------------------------- the table */
check('VDW is the page\'s table: C 1.70, H 1.20, Fe 2.04', VDW.C === 1.70 && VDW.H === 1.20 && VDW.Fe === 2.04);
check('vdw() is case-insensitive and defaults to 1.7', vdw('fe') === 2.04 && vdw('CL') === 1.75 && vdw('Xx') === 1.7 && vdw('') === 1.7);

/* ---------------------------------------------------------------- envelopeBox */
{
  const atoms = [{ x: 0, y: 0, z: 0, elem: 'C' }, { x: 3, y: 0, z: 0, elem: 'C' }];
  const e = envelopeBox(atoms);
  check('envelopeBox: centre ± vdw on every face', near(e.min[0], -1.7) && near(e.max[0], 4.7) && near(e.lengths[1], 3.4));
  check('envelopeBox: volume is the product of the lengths', near(e.volume, e.lengths[0] * e.lengths[1] * e.lengths[2], 1e-9));
  const g = envelopeBox(atoms, 2);
  check('envelopeBox: a gap of 2 Å adds exactly 2 Å to every length', [0, 1, 2].every(k => near(g.lengths[k], e.lengths[k] + 2, 1e-12)));
  const before = JSON.stringify(atoms);
  envelopeBox(atoms, 1.5);
  check('envelopeBox does not touch its input', JSON.stringify(atoms) === before);
}

/* ---------------------------------------------------------------- principalAxes */
{
  const atoms = [];
  for (let i = 0; i < 10; i++) { const p = tilt([i * 1.5, 0, 0], 0.4, -1.1, 2.3); atoms.push({ x: p[0], y: p[1], z: p[2], elem: 'C' }); }
  const R = principalAxes(atoms);
  const det = R[0][0] * (R[1][1] * R[2][2] - R[1][2] * R[2][1]) - R[0][1] * (R[1][0] * R[2][2] - R[1][2] * R[2][0]) + R[0][2] * (R[1][0] * R[2][1] - R[1][1] * R[2][0]);
  const dot = (u, v) => u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  const ortho = near(dot(R[0], R[0]), 1, 1e-10) && near(dot(R[1], R[1]), 1, 1e-10) && near(dot(R[2], R[2]), 1, 1e-10) &&
                near(dot(R[0], R[1]), 0, 1e-10) && near(dot(R[0], R[2]), 0, 1e-10) && near(dot(R[1], R[2]), 0, 1e-10);
  check('principalAxes returns an orthonormal matrix with determinant +1', ortho && near(det, 1, 1e-10), 'det ' + det.toFixed(12));
}

/* ---------------------------------------------------------------- a straight chain */
{
  const atoms = [];
  for (let i = 0; i < 10; i++) { const p = tilt([i * 1.5, 0, 0], 0.73, 1.9, -0.4); atoms.push({ x: p[0], y: p[1], z: p[2], elem: 'C' }); }
  const bonds = []; for (let i = 0; i < 9; i++) bonds.push({ a: i, b: i + 1, o: 1 });
  const r = guessBox({ atoms, bonds });
  const L = r.cell.a[0], W = r.cell.b[1], T = r.cell.c[2];
  check('chain of 10 carbons: the long axis comes out on x', L > W + 1e-9 && W >= T - 1e-9, `${L.toFixed(3)} ${W.toFixed(3)} ${T.toFixed(3)}`);
  check('chain of 10 carbons: a = 9×1.5 + 2×1.70 = 16.9 Å', near(L, 9 * 1.5 + 2 * 1.70, 1e-6), L.toFixed(6));
  check('chain of 10 carbons: the other two are two vdW radii thick', near(W, 3.4, 1e-6) && near(T, 3.4, 1e-6));
  const g2 = guessBox({ atoms, bonds }, { gap: 2 });
  check('guessBox: a gap of 2 Å adds exactly 2 Å to every cell length',
    near(g2.cell.a[0], L + 2, 1e-6) && near(g2.cell.b[1], W + 2, 1e-6) && near(g2.cell.c[2], T + 2, 1e-6));
}

/* ---------------------------------------------------------------- a flat ring */
{
  const atoms = [], bonds = [];
  for (let i = 0; i < 6; i++) {
    const th = i * Math.PI / 3;
    const p = tilt([1.4 * Math.cos(th), 1.4 * Math.sin(th), 0], -1.3, 0.6, 2.7);
    atoms.push({ x: p[0], y: p[1], z: p[2], elem: 'C' });
    bonds.push({ a: i, b: (i + 1) % 6, o: i % 2 ? 1 : 2 });
  }
  const r = guessBox({ atoms, bonds });
  check('flat hexagon: c is two vdW radii thick (3.40 Å)', near(r.cell.c[2], 3.4, 1e-6), r.cell.c[2].toFixed(6));
  const zs = r.struct.atoms.map(a => a.z);
  check('flat hexagon: the ring lies in the xy plane', zs.every(z => near(z, 1.7, 1e-6)));
  check('flat hexagon: bonds are carried through untouched', JSON.stringify(r.struct.bonds) === JSON.stringify(bonds));
}

/* ---------------------------------------------------------------- a random cloud */
{
  const ELEMS = ['C', 'N', 'O', 'H', 'S', 'Cl'];
  const atoms = [];
  for (let i = 0; i < 200; i++) atoms.push({ x: (rnd() - 0.5) * 24, y: (rnd() - 0.5) * 16, z: (rnd() - 0.5) * 9, elem: ELEMS[i % 6] });
  const bonds = []; for (let i = 0; i < 199; i++) bonds.push({ a: i, b: i + 1, o: 1 });
  const struct = { atoms, bonds };
  const frozen = JSON.stringify(struct);
  const d0 = allPairs(atoms);

  const r = guessBox(struct, { gap: 0, cycles: 60, step: 15 });
  check('200 atoms: the input structure is not mutated', JSON.stringify(struct) === frozen);
  check('200 atoms: bonds come back identical', JSON.stringify(r.struct.bonds) === JSON.stringify(bonds));

  let mono = true;
  for (let i = 1; i < r.volumes.length; i++) if (r.volumes[i] > r.volumes[i - 1] + 1e-9) mono = false;
  check('200 atoms: the recorded volumes are non-increasing', mono && r.volumes.length > 1, r.volumes.length + ' steps');
  check('200 atoms: it terminates within the cycle cap', r.cycles <= 60 && r.cycles >= 1, r.cycles + ' cycles');

  const pa = r.volumes[0], fin = r.volume;
  check('200 atoms: the refined volume is never worse than the principal-axis one', fin <= pa + 1e-9,
    pa.toFixed(1) + ' → ' + fin.toFixed(1) + ' Å³');
  check('200 atoms: the reported volume is the product of the cell lengths',
    near(r.volume, r.cell.a[0] * r.cell.b[1] * r.cell.c[2], 1e-6));

  const d1 = allPairs(r.struct.atoms);
  let worst = 0; for (let i = 0; i < d0.length; i++) worst = Math.max(worst, Math.abs(d0[i] - d1[i]));
  check('200 atoms: every interatomic distance is preserved to 1e-9', worst < 1e-9, 'worst ' + worst.toExponential(2));

  const L = [r.cell.a[0], r.cell.b[1], r.cell.c[2]];
  let inside = true, spheres = true;
  for (const a of r.struct.atoms) {
    const p = [a.x, a.y, a.z], rad = vdw(a.elem);
    for (let k = 0; k < 3; k++) {
      if (p[k] < -1e-9 || p[k] > L[k] + 1e-9) inside = false;
      if (p[k] - rad < -1e-9 || p[k] + rad > L[k] + 1e-9) spheres = false;
    }
  }
  check('200 atoms: every atom centre is inside the box', inside);
  check('200 atoms: every vdW sphere is inside the box', spheres);

  const R = r.rotation;
  const dot = (u, v) => u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  const det = R[0][0] * (R[1][1] * R[2][2] - R[1][2] * R[2][1]) - R[0][1] * (R[1][0] * R[2][2] - R[1][2] * R[2][0]) + R[0][2] * (R[1][0] * R[2][1] - R[1][1] * R[2][0]);
  check('200 atoms: the total rotation is orthonormal with determinant +1',
    near(det, 1, 1e-9) && [0, 1, 2].every(i => near(dot(R[i], R[i]), 1, 1e-9)) &&
    near(dot(R[0], R[1]), 0, 1e-9) && near(dot(R[0], R[2]), 0, 1e-9) && near(dot(R[1], R[2]), 0, 1e-9));

  /* The integrator may want to move something else (a probe, a dipole arrow) into the new
     frame, so the reported rotation has to be the one that was actually applied: rotate the
     centred input by it, shift by the box corner, and the answer must be the output. */
  let cx = 0, cy = 0, cz = 0;
  for (const a of atoms) { cx += a.x; cy += a.y; cz += a.z; }
  cx /= atoms.length; cy /= atoms.length; cz /= atoms.length;
  const rot = (a) => [0, 1, 2].map(i => R[i][0] * (a.x - cx) + R[i][1] * (a.y - cy) + R[i][2] * (a.z - cz));
  const shift = [0, 1, 2].map(k => [r.struct.atoms[0].x, r.struct.atoms[0].y, r.struct.atoms[0].z][k] - rot(atoms[0])[k]);
  let rotOk = true;
  for (let i = 0; i < atoms.length; i++) {
    const p = rot(atoms[i]), o = r.struct.atoms[i];
    if (!near(p[0] + shift[0], o.x, 1e-9) || !near(p[1] + shift[1], o.y, 1e-9) || !near(p[2] + shift[2], o.z, 1e-9)) rotOk = false;
  }
  check('200 atoms: the reported rotation is the one actually applied', rotOk);

  check('wrapCheck: nothing is outside after guessBox', wrapCheck(r.struct, r.cell).outside.length === 0);
  const pushed = { atoms: r.struct.atoms.map(a => ({ ...a })), bonds };
  pushed.atoms[37].y = L[1] + 5;
  check('wrapCheck: an atom pushed out by hand is named', JSON.stringify(wrapCheck(pushed, r.cell).outside) === '[37]');

  check('describe calls it a guess', /guess/.test(describe(r)) && /Å³/.test(describe(r)), describe(r));
}

/* ---------------------------------------------------------------- degenerate shapes */
{
  const one = guessBox({ atoms: [{ x: 3, y: -2, z: 7, elem: 'S' }], bonds: [] });
  check('a single atom gives a cube of side 2·vdw', near(one.cell.a[0], 3.6, 1e-9) && near(one.cell.b[1], 3.6, 1e-9) && near(one.cell.c[2], 3.6, 1e-9),
    one.cell.a[0].toFixed(6));
  check('a single atom sits at the centre of its cube', near(one.struct.atoms[0].x, 1.8, 1e-9) && near(one.struct.atoms[0].z, 1.8, 1e-9));

  /* Two atoms of the SAME element: there the bond-aligned box really is the smallest one, so
     the answer can be written down. (With two different radii it is not — the fat sphere
     already sets the width, so leaning the bond over shortens the box without widening it,
     and the refinement correctly declines to line the bond up. That is checked below.) */
  const p = tilt([1.54, 0, 0], 0.9, -2.2, 0.35);
  const two = guessBox({ atoms: [{ x: 0, y: 0, z: 0, elem: 'C' }, { x: p[0], y: p[1], z: p[2], elem: 'C' }], bonds: [{ a: 0, b: 1, o: 1 }] });
  const dy = two.struct.atoms[1].y - two.struct.atoms[0].y, dz = two.struct.atoms[1].z - two.struct.atoms[0].z;
  check('a two-atom molecule comes out aligned with its bond', near(dy, 0, 1e-6) && near(dz, 0, 1e-6), `dy ${dy.toExponential(1)} dz ${dz.toExponential(1)}`);
  check('the two-atom box is the bond plus the two radii', near(two.cell.a[0], 1.54 + 1.70 + 1.70, 1e-6), two.cell.a[0].toFixed(6));

  const q = tilt([1.43, 0, 0], 0.9, -2.2, 0.35);
  const co = guessBox({ atoms: [{ x: 0, y: 0, z: 0, elem: 'C' }, { x: q[0], y: q[1], z: q[2], elem: 'O' }], bonds: [{ a: 0, b: 1, o: 2 }] });
  check('unequal radii: the refined box beats the bond-aligned one rather than matching it',
    co.volume <= (1.43 + 1.70 + 1.52) * 3.4 * 3.4 + 1e-9, co.volume.toFixed(3) + ' vs ' + ((1.43 + 1.70 + 1.52) * 3.4 * 3.4).toFixed(3) + ' Å³');

  check('an empty structure is handled rather than thrown at', guessBox({ atoms: [], bonds: [] }).volume === 0);
}

/* ---------------------------------------------------------------- scale */
{
  const atoms = [];
  for (let i = 0; i < 5000; i++) atoms.push({ x: (rnd() - 0.5) * 60, y: (rnd() - 0.5) * 40, z: (rnd() - 0.5) * 30, elem: i % 3 ? 'C' : 'H' });
  const t0 = Date.now();
  const r = guessBox({ atoms, bonds: [] });
  const ms = Date.now() - t0;
  check('5,000 atoms, 60 cycles of refinement, in under a second', ms < 1000 && r.volume > 0, ms + ' ms, ' + r.cycles + ' cycles');
}

const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
