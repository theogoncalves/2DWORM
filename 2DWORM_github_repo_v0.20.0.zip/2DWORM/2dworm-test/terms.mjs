/* The Terms of Use and Privacy Policy: that the page reaches them, and — the part that
   actually matters — that what they CLAIM still matches what the code DOES.

   A privacy policy is the one document that gets worse on its own. The code changes, the
   promise stays where it was, and nobody notices until it is a problem. So the numbers in
   TERMS.md are asserted against the source they describe: change the retention period in
   core.php without changing the policy and this suite fails. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8788;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '6' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const terms = readFileSync(APP + 'TERMS.md', 'utf8');
const core  = readFileSync(APP + 'QRsharing/lib/core.php', 'utf8');
const admin = readFileSync(APP + 'QRsharing/admin.php', 'utf8');
const page_ = readFileSync(APP + 'index.html', 'utf8');

/* ---------------------------------------------- the promises against the code
   The policy is matched against its text with the line wrapping removed, so re-flowing a
   paragraph never breaks a test and never hides one either. */
const says = (re) => re.test(terms.replace(/\s+/g, ' '));

const maxAgeDays = Number((core.match(/'max_age_days'\s*=>\s*(\d+)/) || [])[1]);
check('the retention the policy promises is the retention the code applies',
  maxAgeDays === 730 && says(/not opened for \*\*two years\*\* is deleted/),
  `core.php max_age_days = ${maxAgeDays} (= two years)`);

const rlWindow = Number((core.match(/DELETE FROM rl WHERE t < \?'\)->execute\(\[\$now - (\d+)/) || [])[1]);
check('the rate-limit window the policy promises is the one the code uses',
  rlWindow === 7200 && says(/it is deleted after two hours/),
  `core.php keeps a rate-limit row for ${rlWindow} s (= two hours)`);

check('the policy calls the rate limiter a hash of the address, not "nothing is stored"',
  says(/one-way hash/) && says(/random secret/) && says(/current hour/) &&
  /hash\('sha256', dw_client_ip\(\)/.test(core));

const fold = Number((admin.match(/if \(\$n < (\d+) \|\| \$cc === 'ZZ'\)/) || [])[1]);
check('the small-count folding threshold matches the admin page',
  fold === 5 && says(/fewer than five actions are folded into "Other"/), `admin.php folds n < ${fold}`);

/* ------------------------------------------------------------ the counters
   Counting is the single change most likely to leave a privacy policy quietly untrue: the
   code grows a new number and the promise stays where it was. So every sentence about the
   counters is pinned here to the line of code it describes. */
const count = readFileSync(APP + 'QRsharing/count.php', 'utf8');
const share = readFileSync(APP + 'QRsharing/share.php', 'utf8');
const table = (name) => ((core.match(new RegExp('CREATE TABLE IF NOT EXISTS ' + name + ' \\(([\\s\\S]*?)\\)\'')) || [])[1] || '');
const colsOf = (body) => (body.match(/(\w+) +(?:TEXT|INTEGER)/g) || []).map(s => s.split(/ +/)[0]);
const tallyBody = table('usage_tally'), dayBody = table('usage_day');

check('a usage row is a day, a label and a count — there is nowhere to put anything else',
  colsOf(tallyBody).join(',') === 'day,kind,key,n' && colsOf(dayBody).join(',') === 'day,country,action,n' &&
  says(/every one of them is \*\*a day, a label and a count\*\* — nothing else/),
  colsOf(tallyBody).join(',') + ' / ' + colsOf(dayBody).join(','));

check('the country counts and the device counts live in tables that cannot be joined',
  !/country/.test(tallyBody) && !/(kind|platform|headset|feature)/.test(dayBody) &&
  !/dw_country|dw_count\(/.test(count) &&
  says(/counts cannot be joined/) && says(/that row does not exist here/));

check('counting can be switched off, and every counter obeys the switch',
  /'count_usage' *=>/.test(core) &&
  (core.match(/if \(empty\(\$cfg\['count_usage'\]\)\) \{ return; \}/g) || []).length === 2 &&
  /empty\(\$CFG\['count_usage'\]\)/.test(count) &&
  says(/administrator can turn counting on and off with one setting/));

check('the user agent becomes one word before anything is written, and never reaches the table',
  /\$_SERVER\['HTTP_USER_AGENT'\]/.test(count) && !/return \$ua/.test(core) &&
  !/dw_tally\([^)]*\$ua[^)]*\)/.test(count.replace(/dw_(?:headset|platform)_bucket\(\$ua\)/g, 'BUCKET')) &&
  says(/user-agent string never reaches the database/) && says(/\*\*No user-agent strings\.\*\*/));

const feats = ((count.match(/const DW_FEATURES = \[([\s\S]*?)\];/) || [])[1] || '').match(/'[a-z0-9_]+'/g) || [];
check('only names from a fixed list are counted, and an unknown one is discarded',
  feats.length >= 15 && /!in_array\(\(string\) \$key, DW_FEATURES, true\)\) \{ continue; \}/.test(count) &&
  says(/Only names from a fixed list are accepted/), feats.length + ' names');

check('the three machine words the policy quotes are words the code can really produce',
  ["'Windows'", "'Android'", "'Meta Quest'"].every(w => core.includes(w)) &&
  says(/"Windows", "Android", "Meta Quest"/));

const every = Number((page_.match(/tallyTimer = setTimeout\([\s\S]{0,90}?\}, (\d+)\)/) || [])[1]);
check('the page batches for as long as the policy says, and sends once more on the way out',
  every === 120000 && says(/at most once every two minutes/) &&
  /addEventListener\('pagehide'/.test(page_) && says(/once more when you close the tab/),
  `index.html flushes every ${every / 1000} s`);

const prune = (core.match(/function dw_prune\([\s\S]*?\n\}/) || [''])[0];
check('the counts really are kept rather than pruned, which is what the policy now admits',
  !/usage_/.test(prune) && says(/not deleted on a schedule/) &&
  /const COUNT_API = 'QRsharing\/count\.php'/.test(page_) && says(/never leave this server/));

/* ------------------------------------------- the policy, the defaults and the admin page
   Making the limits settable from a web page is exactly the change that lets a privacy policy
   go stale unnoticed: the operator lowers a retention period and the policy keeps promising
   the old one. core.php answers that with DW_POLICY, a written-down copy of the numbers the
   policy states, which the admin page compares the LIVE settings against. Two of the three
   locks are checked here — that DW_POLICY still matches TERMS.md, and that it still matches
   the shipped defaults. The third is the operator's warning banner, which admin.mjs drives. */
const policy = Object.fromEntries([...(core.match(/const DW_POLICY = \[([\s\S]*?)\];/) || ['', ''])[1]
  .matchAll(/'(\w+)'\s*=>\s*\[(-?\d+),/g)].map(m => [m[1], Number(m[2])]));
const defaults = Object.fromEntries([...core.matchAll(/'(\w+)'\s*=>\s*([\d*\s]+),\s*(?:\/[/*]|$)/gm)]
  .map(m => [m[1], Function('return ' + m[2].trim())()]));
check('the numbers the policy states are written down where the admin page can check them',
  Object.keys(policy).length === 4 && policy.max_age_days === 730 && policy.small_wait === 10 &&
  policy.large_wait === 60 && policy.read_wait === 0,
  JSON.stringify(policy));
check('and they are the numbers this build actually ships',
  Object.entries(policy).every(([k, v]) => defaults[k] === v),
  Object.entries(policy).filter(([k, v]) => defaults[k] !== v).map(([k, v]) => `${k}: policy ${v}, code ${defaults[k]}`).join('; ') || 'all four agree');
check('the policy says a few seconds to store and longer for a large one, which is what those numbers are',
  says(/asks you to wait a few seconds before it stores an ordinary drawing, and rather longer before a large one/));
check('and it does NOT tell anyone that opening a drawing makes them wait, because by default it does not',
  !says(/wait .{0,20}before .{0,20}open/i) && policy.read_wait === 0);

/* The five that must never be reachable from a web form. Somebody who got into the admin page
   could otherwise change the password, point the service at another database, read a file of
   their choosing, or send every link anybody shares to a site of their own. */
const settable = ((core.match(/const DW_SETTABLE = \[([\s\S]*?)\n\];/) || ['', ''])[1].match(/'(\w+)'\s*=>/g) || [])
  .map(x => x.replace(/\W/g, ''));
check('the admin page cannot reach the password, the database, the geo file or the two URLs',
  settable.length === 18 &&
  ['admin_hash', 'db_path', 'geo_csv', 'page_url', 'short_base'].every(k => !settable.includes(k)),
  settable.length + ' settable: ' + settable.join(', '));
/* EVERY SWITCH SAYS WHAT IT DOES. A page of fifteen numbers with no explanation is a page
   nobody dares change anything on, which is the same as not being able to change it — and a
   description that lives anywhere but beside the setting drifts away from it. Asserted key
   for key so that adding a setting without explaining it fails the build. */
const help = ((core.match(/const DW_SETTING_HELP = \[([\s\S]*?)\n\];/) || ['', ''])[1].match(/'(\w+)'\s*=>/g) || [])
  .map(x => x.replace(/\W/g, ''));
check('and every setting it CAN reach says in a sentence what it does',
  settable.length > 0 && settable.every(k => help.includes(k)) && help.length === settable.length,
  help.length + ' described of ' + settable.length);
/* Closing the store must stop new drawings and nothing else: every QR code already printed
   on a poster goes on working, and a full link never reaches the server in either direction. */
check('the store can be closed to NEW drawings without breaking the ones already shared',
  /empty\(\$CFG\['store_on'\]\)/.test(share) && /store_closed/.test(share) &&
  !/store_on/.test(share.split("if ($method === 'POST')")[0]),
  'checked on POST only');

/* the sentence is wrapped in the source, so the comparison is on the unwrapped text */
const flat = (t) => t.replace(/\s+/g, ' ');
check('a setting is stored in the database, never written back into an executable PHP file',
  /a web page that can rewrite an executable PHP file/.test(flat(core)) &&
  /a web page that can rewrite an executable PHP file/.test(flat(admin)) &&
  !/file_put_contents|fwrite/.test(admin.replace(/fwrite\(\$?out/g, '')) &&
  /dw_meta\(\$db, 'set\.' \. \$key, \$v\)/.test(core));

const keys = [...new Set([...page_.matchAll(/localStorage\.(?:get|set)Item\('([^']+)'/g)].map(m => m[1]))];
/* wrapping removed, exactly as for the policy: a re-flowed paragraph must not fail a test */
const manual = readFileSync(APP + 'MANUAL.md', 'utf8').replace(/\s+/g, ' ');
check('the manual no longer promises that nothing leaves the browser uninvited either',
  /count of what was used/.test(manual) && !/exactly two things that leave the browser/.test(manual) &&
  /no cookie, no session and no identifier/.test(manual));

check('the policy accounts for every localStorage key the page uses, and no others',
  keys.length === 6 && keys.includes('dworm2d.theme') && keys.includes('dworm2d.uiscale') &&
  keys.includes('dworm2d.lang') && keys.includes('dworm2d.opt.') && keys.includes('dworm2d.fragments') && keys.includes('dworm2d.noteSize') && says(/background you chose/) && says(/your own substituents/) &&
  says(/size of the Ketcher toolbars/) && says(/\*\*language\*\* you picked/) && says(/text size of the NOTES panel/) &&
  says(/\*\*OPTIONS\*\* window/) && says(/remembers six things/),
  keys.join(', '));

check('no cookie is set for ordinary visitors — only admin.php starts a session',
  says(/\*\*No cookies\*\* for ordinary visitors/) &&
  !/session_start/.test(core) &&
  !/session_start/.test(readFileSync(APP + 'QRsharing/share.php', 'utf8')) &&
  /session_start/.test(admin));

const cols = (core.match(/CREATE TABLE IF NOT EXISTS shares \(([\s\S]*?)\)'/) || [])[1] || '';
const shareCols = [...cols.matchAll(/^\s+(\w+)\s+(?:TEXT|INTEGER)/gm)].map(m => m[1]);
check('a stored drawing has ten columns and not one of them is about the person who stored it',
  shareCols.length === 10 && !/\b(ip|addr|agent|user|author|session)\b/i.test(shareCols.join(' ')),
  shareCols.join(', '));

/* the sentence that matters most, and the ones that stop a chemist regretting this */
check('the policy says plainly that a stored drawing is public to anyone with the ID',
  says(/public to anyone who has the link or the ID/) && says(/Anyone with the ID can open it/));
check('and that sharing is not archiving', says(/Sharing is not archiving/));
/* RETIREMENT, build 24. The terms have to carry BOTH halves: expires with demand (the old
   promise) AND may be retired for too much demand (the new rule), and the code has to match —
   an operator switch that is off by default, a timer rather than a deletion on the spot, the
   permanent store exempt, and a retired key that explains itself rather than 404ing. */
check('the terms say a popular code may be retired, with notice, and that a retired code explains itself',
  says(/very popular code may be retired/) && says(/period of notice/) && says(/does not simply vanish/));
check('and the QR notice in the terms is the one the page shows',
  says(/A QR code here is not permanent/) && /A QR code here is not permanent/.test(core));
check('the retirement rule is off by default and arms a timer rather than deleting',
  /'retire_hits'\s*=>\s*0,/.test(core) && /retire_at = \?/.test(core) && /dw_retire_arm/.test(core));
check('the permanent store is exempt from retirement in the code',
  /store != "keep" AND retire_at IS NOT NULL/.test(core) && /WHERE skey = \? AND store != "keep" AND retire_at IS NULL/.test(core));
check('a retired key answers 410 with the contact address', /'retired'/.test(share) && /410/.test(share) && /DW_RETIRED_MESSAGE/.test(core) && /contact@dworm\.org/.test(core));
check('the featured list is a database of its own, opened read-only for the public',
  /featured\.sqlite/.test(core) && /SQLITE_OPEN_READONLY/.test(core) && says(/molecule of the day/));
check('and that the force fields are not quantum chemistry',
  says(/empirical force fields/) && says(/not quantum chemistry/) &&
  says(/Do not cite a 2D-WORM geometry as a result/));
check('the two outside services FIND uses are named, with their own policies linked',
  says(/RCSB Protein Data Bank/) && says(/rcsb\.org\/policies/) &&
  says(/PubChem/) && says(/ncbi\.nlm\.nih\.gov\/home\/about\/policies/));
check("the hosting company's access log is admitted rather than glossed over",
  says(/access log/) && says(/include IP addresses/) && says(/outside 2D-WORM/));
check('there is a takedown route: an address, what to send, and what happens',
  says(/contact@dworm\.org/) && says(/send the ID/i) && says(/blocked \*\*by the content itself\*\*/) &&
  says(/does not bring it back/));
check('the service is not attributed to an employer or university',
  says(/not operated by, and not the responsibility of, any employer or university/));

/* --------------------------------------------------------------- in the page */

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
const fetched = []; page.on('request', r => { if (/\.md(\?|$)/.test(r.url())) fetched.push(r.url().split('/').pop()); });
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

check('neither document is downloaded until it is asked for', fetched.length === 0, fetched.join(', '));

await page.click('#btnInfo');
check('INFO offers the terms beside the manual',
  await page.isVisible('#btnTerms') && (await page.textContent('#btnMore')).trim() === 'MANUAL');
await page.click('#btnTerms');
await page.waitForFunction(() => /Terms of Use/.test(document.getElementById('readmeBody').textContent), null, { timeout: 20000 });
check('and opening them shows the document', /Terms of Use and Privacy/.test(await page.textContent('#readmeTitle')),
  await page.textContent('#readmeTitle'));
const shown = await page.textContent('#readmeBody');
check('with the privacy section, not just the terms', /What is stored when you press SHARE/.test(shown) && /Stopping abuse/.test(shown));
check('rendered as headings, not as raw markdown',
  (await page.$$eval('#readmeBody h1, #readmeBody h2', e => e.length)) > 6 && !/^#/m.test(shown),
  (await page.$$eval('#readmeBody h1, #readmeBody h2', e => e.length)) + ' headings');
check('the links inside it are real links',
  (await page.$$eval('#readmeBody a[href^="http"]', a => a.length)) >= 3);

await page.click('#readmeDlg [data-close]');
await page.click('#btnMore');
await page.waitForFunction(() => /Making a 3D structure/.test(document.getElementById('readmeBody').textContent), null, { timeout: 20000 });
check('the same window shows the manual, with its own title',
  /manual/.test(await page.textContent('#readmeTitle')) &&
  !/Terms of Use/.test(await page.textContent('#readmeBody')),
  await page.textContent('#readmeTitle'));
/* The count and the headings are asserted rather than "there is at least one table": the
   failure this catches is the renderer silently NOT recognising a table, which leaves a wall
   of vertical bars that still looks like content at a glance. Adding a table to the manual is
   meant to fail here until the number is updated — that is the check working. */
check('the manual\'s tables are drawn as tables, not as rows of vertical bars',
  (await page.$$eval('#readmeBody table', t => t.length)) === 13 &&
  (await page.$$eval('#readmeBody th', t => t.map(e => e.textContent))).join(',') ===
    'File,Goes to,Program,Coordinates,Names and bonds,Database,What is in it,Asked by a plain name?,' +
    'Program,Files,Format,For,Representation,What you get,Expression,Picks,' +
    'Mark,What it is,When,Tool,A drag,Holding ALT,Slider,Live when you have picked,' +
    'What the number means,Picked,← and →,↑ and ↓,You write,You get,,,' &&
  !/\|---\|/.test(await page.textContent('#readmeBody')),
  (await page.$$eval('#readmeBody table', t => t.length)) + ' tables');
check('a wide table scrolls inside the window instead of stretching it',
  await page.$eval('#readmeBody table', t => getComputedStyle(t).overflowX) === 'auto');
check('italics are italics, not asterisks',
  (await page.$$eval('#readmeBody i', e => e.map(x => x.textContent))).includes('aspirin') &&
  !/\*aspirin\*/.test(await page.textContent('#readmeBody')));
check('and both files were fetched exactly once each',
  fetched.filter(f => f === 'TERMS.md').length === 1 && fetched.filter(f => f === 'MANUAL.md').length === 1,
  fetched.join(', '));
await page.click('#readmeDlg [data-close]');
await page.click('#infoDlg [data-close]');

/* the link where it matters most: next to the button that uploads something */
await page.click('#btnShare');
await page.waitForFunction(() => document.getElementById('shareUrl').value.length > 0, null, { timeout: 30000 });
check('the SHARE window warns that a stored drawing is public and links to the terms',
  /public to anyone who has the ID/.test(await page.textContent('#shareDlg .note')) &&
  await page.isVisible('#shareDlg a[data-doc]'));
await page.click('#shareDlg a[data-doc]');
await page.waitForFunction(() => /Terms of Use/.test(document.getElementById('readmeBody').textContent), null, { timeout: 20000 });
check('clicking it opens the terms over the share window, without losing the link',
  await page.isVisible('#readmeDlg.open') && (await page.inputValue('#shareUrl')).length > 0);
check('and it did not navigate away from the page', page.url().includes('index.html'), page.url());
await page.click('#readmeDlg [data-close]');
check('closing them puts you back at the share window', await page.isVisible('#shareDlg.open'));
await page.click('#shareDlg [data-close]');

await page.click('#btnFind');
check('the FIND window links to them too', await page.isVisible('#findDlg a[data-doc]'));
await page.click('#findDlg [data-close]');

const r = await fetch(`http://127.0.0.1:${PORT}/TERMS.md`);
check('TERMS.md is served, so it can be linked to directly', r.ok, 'HTTP ' + r.status);

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
