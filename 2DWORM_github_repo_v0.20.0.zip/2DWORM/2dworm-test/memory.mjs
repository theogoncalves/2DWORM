/* Does dropping one structure after another leak?
   Measured, with a forced garbage collection between rounds, so what is reported is what
   is actually still reachable rather than what has not been collected yet. */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8783;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 800));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

function pdb(nRes, seed) {
  let s = `HEADER    TEST ${seed}\n`, serial = 1;
  const tpl = [['N', 'N'], ['CA', 'C'], ['C', 'C'], ['O', 'O']];
  for (let r = 0; r < nRes; r++) {
    const a = r * 0.4 + seed, R = 4 + (r % 7) * 0.1;
    for (let i = 0; i < tpl.length; i++) {
      const [name, el] = tpl[i];
      s += 'ATOM  ' + String(serial).padStart(5) + ' ' + name.padEnd(4) + ' GLY A' +
           String(r + 1).padStart(4) + '    ' +
           (R * Math.cos(a) + i * 1.3).toFixed(3).padStart(8) +
           (R * Math.sin(a)).toFixed(3).padStart(8) +
           (r * 1.5).toFixed(3).padStart(8) + '  1.00  0.00          ' + el.padStart(2) + '\n';
      serial++;
    }
  }
  return s + 'END\n';
}

const browser = await chromium.launch({ args: ['--js-flags=--expose-gc'] });
const page = await (await browser.newContext({ viewport: { width: 1200, height: 800 } })).newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

async function heap() {
  return page.evaluate(async () => {
    if (window.gc) { window.gc(); await new Promise(r => setTimeout(r, 60)); window.gc(); }
    await new Promise(r => setTimeout(r, 120));
    return performance.memory ? performance.memory.usedJSHeapSize : 0;
  });
}
async function counts() {
  return page.evaluate(() => {
    const v = dworm2d.viewer;
    return {
      models: v.models ? v.models.length : -1,
      labels: v.labels ? v.labels.length : -1,
      shapes: v.shapes ? v.shapes.length : -1,
      // everything the modelGroup still holds on to
      children: v.modelGroup ? v.modelGroup.children.length : -1,
      dataBytes: dworm2d.state3d.data ? dworm2d.state3d.data.length : 0,
    };
  });
}

const ONE = pdb(500, 0);                     // 2000 atoms, about 160 kB of text
await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'warm.pdb'), ONE);
await page.waitForTimeout(400);
const base = await heap();
const c0 = await counts();
check('one structure gives one model', c0.models === 1, JSON.stringify(c0));

const ROUNDS = 12;
for (let i = 1; i <= ROUNDS; i++) {
  await page.evaluate(([p, n]) => dworm2d.show3d(p, 'pdb', 'file', 'drop' + n + '.pdb'), [pdb(500, i), i]);
  await page.waitForTimeout(120);
}
const after = await heap();
const c1 = await counts();

const grewMB = (after - base) / 1048576;
console.log(`\n  heap after one structure : ${(base / 1048576).toFixed(1)} MB`);
console.log(`  heap after ${ROUNDS} more     : ${(after / 1048576).toFixed(1)} MB   (${grewMB >= 0 ? '+' : ''}${grewMB.toFixed(1)} MB)`);
console.log('  viewer now holds        :', JSON.stringify(c1), '\n');

check('the viewer keeps exactly one model, however many were dropped', c1.models === 1, JSON.stringify(c1));
check('nothing is left behind in the scene graph', c1.children <= c0.children + 1,
  `${c0.children} then ${c1.children}`);
check('no labels accumulate', c1.labels === 0, 'labels ' + c1.labels);
/* Each drop is ~160 kB of text plus its parsed atoms. Twelve of them retained would be
   tens of megabytes; a couple of megabytes of drift is ordinary allocator noise. */
check(`the heap does not grow with every drop (${ROUNDS} structures of 2000 atoms)`, grewMB < 8,
  `${grewMB.toFixed(1)} MB after ${ROUNDS} drops`);

/* The one that actually bit: 3Dmol's removeAllLabels() removes the sprites but never
   disposes them, and only Label.dispose() frees the canvas texture behind each one.
   Labels are rebuilt whenever the zoom changes, so every rebuild used to abandon one
   texture per atom. Count the disposals against the labels made and the leak is either
   there or it is not — a JavaScript heap profiler cannot see this, because a GPU texture
   is not in the JavaScript heap. */
await page.evaluate(() => {
  window.__made = 0; window.__disposed = 0;
  const L = Object.getPrototypeOf(dworm2d.viewer.addLabel('x', { position: { x: 0, y: 0, z: 0 } }));
  dworm2d.viewer.removeAllLabels();
  const d = L.dispose;
  L.dispose = function () { window.__disposed++; return d.apply(this, arguments); };
  const add = dworm2d.viewer.addLabel.bind(dworm2d.viewer);
  dworm2d.viewer.addLabel = function () { window.__made++; return add.apply(null, arguments); };
});
{
  await page.evaluate(() => { dworm2d.opts.labels = 'elem'; dworm2d.opts.render = 'quality'; });
  await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'leak.pdb'), pdb(30, 7));
  await page.waitForTimeout(200);
  // zoom in and out, which is what forces a rebuild
  for (let i = 0; i < 15; i++) {
    await page.evaluate(z => { dworm2d.viewer.zoom(z); dworm2d.viewer.render(); }, i % 2 ? 1.25 : 0.8);
    await page.waitForTimeout(70);
  }
  await page.waitForTimeout(300);
  const t = await page.evaluate(() => ({ made: window.__made, disposed: window.__disposed }));
  check('every label that is thrown away is disposed, so its texture is freed',
    t.made > 20 && t.disposed >= t.made - 130, `${t.made} made, ${t.disposed} disposed`);
}

/* the same again with labels on, end to end */
await page.evaluate(() => { dworm2d.opts.labels = 'elem'; dworm2d.opts.render = 'quality'; });
const small = pdb(20, 99);                   // 80 atoms, inside the label cap
await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'lab.pdb'), small);
await page.waitForTimeout(300);
const lbase = await heap();
for (let i = 0; i < 12; i++) {
  await page.evaluate(([p, n]) => dworm2d.show3d(p, 'pdb', 'file', 'lab' + n + '.pdb'), [pdb(20, 100 + i), i]);
  await page.waitForTimeout(100);
}
const lafter = await heap();
const lc = await counts();
const lgrew = (lafter - lbase) / 1048576;
console.log(`  with labels on: ${(lbase / 1048576).toFixed(1)} MB -> ${(lafter / 1048576).toFixed(1)} MB (${lgrew >= 0 ? '+' : ''}${lgrew.toFixed(1)} MB), ${lc.labels} labels\n`);
check('labelled structures do not accumulate labels', lc.labels <= 80, 'labels ' + lc.labels);
check('and do not grow the heap', lgrew < 8, `${lgrew.toFixed(1)} MB`);

/* CLEAR must actually let go */
await page.evaluate(() => dworm2d.viewer && document.getElementById('btnClear3d').click());
await page.waitForTimeout(300);
const cleared = await counts();
check('CLEAR leaves no model behind', cleared.models === 0 && cleared.dataBytes === 0, JSON.stringify(cleared));

/* What an OPEN TAB costs while nobody touches it. Asked directly, and worth guarding: the
   moment anything starts polling — a status check, a keep-alive, an auto-save — a page left
   open on somebody's second monitor becomes a running bill on the server and a running drain
   on their battery. Nothing here should schedule work of its own. */
{
  await page.evaluate(p => dworm2d.show3d(p, 'pdb', 'file', 'idle.pdb'), pdb(60, 3));
  await page.waitForTimeout(1200);
  const seen = [];
  const onReq = (r) => seen.push(r.url());
  page.on('request', onReq);
  const before = await heap();
  const IDLE = 9000;
  await page.waitForTimeout(IDLE);
  page.off('request', onReq);
  const after = await heap();
  check(`an open tab makes no network requests at all while it is left alone (${IDLE / 1000} s)`,
    seen.length === 0, seen.slice(0, 3).join(', '));
  check('and its memory does not creep',
    Math.abs(after - before) / 1048576 < 4, `${((after - before) / 1048576).toFixed(1)} MB`);
  check('nothing is left running on a timer',
    await page.evaluate(() => !window.__dwormPoll), 'no poll handle');
}

const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
