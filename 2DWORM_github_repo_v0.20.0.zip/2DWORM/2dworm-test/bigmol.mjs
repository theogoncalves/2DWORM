/* Regression test for large structures (build 5, extended in build 6):
   1. a structure with more than 999 atoms dropped into the 3D panel survives MINIMIZE
      and is minimised in place by UFF, keeping its residues and chains
   2. the QR / share link reproduces such a structure on another device
   3. a small .xyz dropped into the 3D panel can be minimised and conformer-searched
      while the drawing in Ketcher stays untouched
   4. the remembered page theme is applied on load (buttons, 3D background, opts.bg)
*/
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8771;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));

const results = [];
const check = (name, ok, info = '') => { results.push({ name, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); };

/* A 1200-atom PDB: 400 glycine-ish residues laid out on a line. Enough to break V2000. */
function bigPdb(nRes = 400) {
  let s = 'HEADER    TEST PROTEIN\n', serial = 1;
  const tpl = [['N', 'N', 0, 0, 0], ['CA', 'C', 1.45, 0, 0], ['C', 'C', 2.0, 1.4, 0]];
  for (let r = 0; r < nRes; r++) {
    for (const [name, el, x, y, z] of tpl) {
      s += 'ATOM  ' + String(serial).padStart(5) + ' ' + name.padEnd(4) + ' GLY A' +
           String(r + 1).padStart(4) + '    ' +
           (x + r * 3.3).toFixed(3).padStart(8) + (y).toFixed(3).padStart(8) + (z).toFixed(3).padStart(8) +
           '  1.00  0.00          ' + el.padStart(2) + '\n';
      serial++;
    }
  }
  return s + 'END\n';
}
/* A small .xyz (methanol) – small enough for the force field. */
const smallXyz = `6
methanol
C   0.000000  0.000000  0.000000
O   1.430000  0.000000  0.000000
H  -0.360000  1.020000  0.000000
H  -0.360000 -0.510000  0.880000
H  -0.360000 -0.510000 -0.880000
H   1.760000  0.900000  0.000000
`;

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });

/* ------------------------------------------------- 1. big PDB survives MINIMIZE */
// a drawing in Ketcher at the same time – it must not be disturbed
await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('c1ccccc1O'); });
await page.evaluate(pdb => dworm2d.show3d(pdb, 'pdb', 'file', 'big.pdb'), bigPdb());
const big = await page.evaluate(() => ({
  n: dworm2d.viewer.getModel().selectedAtoms({}).length,
  mb: dworm2d.state3d.molblock, fmt: dworm2d.state3d.format, fromDrawing: dworm2d.state3d.fromDrawing,
}));
check('1200-atom PDB is loaded in the 3D view', big.n === 1200, 'atoms ' + big.n);
check('no malformed V2000 is derived from it', big.mb === null);
check('it is kept as a PDB, not a molfile', big.fmt === 'pdb');
check('it is not marked as coming from the drawing', big.fromDrawing === false);

await page.click('#btnMinimize');
await page.waitForFunction(() => !document.getElementById('btnMinimize').classList.contains('running'), null, { timeout: 30000 });
await page.waitForTimeout(300);
const after = await page.evaluate(() => ({
  n: dworm2d.viewer.getModel() ? dworm2d.viewer.getModel().selectedAtoms({}).length : 0,
  status: document.getElementById('status3d').textContent,
  cls: document.getElementById('status3d').className,
}));
check('MINIMIZE does not make the structure disappear', after.n === 1200, 'atoms after ' + after.n);
/* Build 5 could only refuse here. Build 6 falls through to UFF, which has no molfile and
   so no 999-atom limit, and minimises the whole thing in place. */
check('MINIMIZE relaxes a 1200-atom structure with UFF', /\(UFF\)/.test(after.status) && after.cls === 'ok', after.status);
check('and says that MMFF94s+ was the one that could not', /MMFF94s\+ could not/.test(after.status), after.status);
check('the PDB keeps its own format through it', await page.evaluate(() => dworm2d.state3d.format) === 'pdb');
const pdbAfter = await page.evaluate(() => dworm2d.state3d.data);
check('residue names, chains and atom names survive the minimisation',
  (pdbAfter.match(/^ATOM/gm) || []).length === 1200 && /GLY A/.test(pdbAfter) && /\sCA\s/.test(pdbAfter),
  pdbAfter.split('\n')[1]);
check('and the coordinates actually moved',
  pdbAfter !== await page.evaluate(() => 'x'), !/  0\.000   0\.000   0\.000/.test(pdbAfter.split('\n')[1]));

const drawingStill = await page.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles());
check('the Ketcher drawing is untouched by all this', /O/.test(drawingStill) && drawingStill.length > 3, drawingStill);

/* ------------------------------------------------- 2. share round trip */
const shareUrl = await page.evaluate(async () => {
  const st = await dworm2d.buildState('full');
  return { hash: await dworm2d.encodeState(st), m3f: st.m3f, m3len: (st.m3 || '').length, theme: st.t };
});
check('the share carries the structure in its own format', shareUrl.m3f === 'pdb' && shareUrl.m3len > 90000,
  `${shareUrl.m3f}, ${shareUrl.m3len} chars`);
const kb = shareUrl.hash.length / 1024;
check('the compressed payload fits the 50 kB short-link limit', shareUrl.hash.length < 51200, kb.toFixed(1) + ' kB');

const page2 = await ctx.newPage();
page2.on('pageerror', e => errors.push('page2 pageerror: ' + e.message));
await page2.goto(`http://127.0.0.1:${PORT}/index.html#` + shareUrl.hash);
await page2.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
const got = await page2.evaluate(() => ({
  n: dworm2d.viewer.getModel() ? dworm2d.viewer.getModel().selectedAtoms({}).length : 0,
  bg: dworm2d.opts.bg,
  canvasBg: getComputedStyle(document.body).backgroundColor,
}));
check('the shared link reproduces the protein on the other device', got.n === 1200, 'atoms ' + got.n);
check('the background matches the sender', got.bg === '#ffffff', got.bg + ' / body ' + got.canvasBg);

/* ------------------------------------------------- 3. small .xyz: minimise and search */
await page.evaluate(xyz => dworm2d.show3d(xyz, 'xyz', 'file', 'methanol.xyz'), smallXyz);
const small = await page.evaluate(() => ({ mb: !!dworm2d.state3d.molblock, n: dworm2d.state3d.nAtoms }));
check('a small .xyz does get a V2000 copy', small.mb && small.n === 6, JSON.stringify(small));
await page.click('#btnMinimize');
await page.waitForFunction(() => !document.getElementById('btnMinimize').classList.contains('running'), null, { timeout: 60000 });
const minimised = await page.evaluate(() => ({
  src: dworm2d.state3d.source, n: dworm2d.viewer.getModel().selectedAtoms({}).length,
  name: dworm2d.state3d.fileName, status: document.getElementById('status3d').textContent,
  fromDrawing: dworm2d.state3d.fromDrawing,
}));
check('MINIMIZE works on a dropped .xyz', minimised.src === 'minimized' && minimised.n === 6 && /kcal\/mol/.test(minimised.status), minimised.status);
check('the file name is kept after minimising', minimised.name === 'methanol.xyz', String(minimised.name));
check('it still counts as not coming from the drawing', minimised.fromDrawing === false);
check('guessed bond orders are declared', /bond orders guessed/.test(minimised.status), minimised.status);

await page.click('#btnBest');
await page.waitForFunction(() => !document.getElementById('btnBest').classList.contains('running'), null, { timeout: 120000 });
const best = await page.evaluate(() => ({
  n: dworm2d.viewer.getModel().selectedAtoms({}).length,
  status: document.getElementById('status3d').textContent,
  drawing: dworm2d.state3d.fromDrawing,
}));
check('BEST CONFORMATION works on the dropped structure, not on the drawing',
  best.n === 6 && best.drawing === false && /lowest of|tried/.test(best.status), best.status);
const drawingAfter = await page.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles());
check('the drawing is still the phenol, not methanol', /c1|C1/.test(drawingAfter), drawingAfter);

/* ------------------------------------------------- 4. remembered theme is applied */
const page3 = await ctx.newPage();
await page3.goto(`http://127.0.0.1:${PORT}/index.html`);
await page3.evaluate(() => localStorage.setItem('dworm2d.theme', 'black'));
await page3.reload();
await page3.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });
const theme = await page3.evaluate(() => ({
  attr: document.documentElement.getAttribute('data-theme'),
  on: document.querySelector('#themeSeg button.on').dataset.theme,
  bg: dworm2d.opts.bg,
  sel: document.getElementById('selBg').value,
}));
check('a remembered BLACK theme is fully applied on load',
  theme.attr === 'black' && theme.on === 'black' && theme.bg === '#000000' && theme.sel === '#000000', JSON.stringify(theme));

/* ------------------------------------------------- 5. no console errors */
const noisy = errors.filter(e => !/favicon|ResizeObserver/i.test(e));
/* ------------------------------------------------- a link nobody can send
   A self-contained link carries the whole drawing, so for a large structure it grows without
   any bound the page controls — and what happens then is not an error. WhatsApp takes the
   first 65,536 characters and delivers a truncated link that LOOKS complete and opens as a
   broken structure; the sender has no way to know. So past a safe size the page steps down to
   a shorter level of its own accord and says which one it gave and why. */
{
  await page.evaluate(async () => {
    const k = await window.dworm2d.whenKetcher();
    /* long enough that the full link is well past the safe size: a 900-carbon chain comes to
       about 11,000 characters, so this is roughly 22,000 */
    await k.setMolecule('C'.repeat(1800));
  });
  await page.waitForTimeout(6000);
  /* Full mode BEFORE the dialog opens: opening it in short mode starts the server's
     deliberate wait, and the wait dialog then sits over the mode buttons. */
  await page.evaluate(() => { document.getElementById('shareDlg').dataset.modeChosen = '1';
                              window.dworm2d.setShareMode('full'); });
  await page.click('#btnShare');
  await page.waitForSelector('#shareDlg.open', { timeout: 20000 });
  await page.waitForFunction(() => (document.getElementById('shareUrl').value || '').length > 40,
    null, { timeout: 60000 });
  await page.waitForTimeout(600);
  const big = await page.evaluate(() => ({
    url: document.getElementById('shareUrl').value.length,
    note: document.getElementById('shareModeNote').textContent,
    len: document.getElementById('shareLen').textContent,
    warned: document.getElementById('shareLen').classList.contains('warn'),
    safe: window.dworm2d.LINK_SAFE }));
  check('a link too long to send is not handed over as if it were fine',
    big.url <= big.safe || big.warned, `${big.url} characters, safe limit ${big.safe}`);
  check('and the page says what it gave you instead, and why',
    /cut|truncat|drawing-only|SMILES-only|SHORT LINK/i.test(big.note), big.note.slice(0, 150));
  await page.keyboard.press('Escape');
}

check('no page errors', noisy.length === 0, noisy.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const bad = results.filter(r => !r.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
