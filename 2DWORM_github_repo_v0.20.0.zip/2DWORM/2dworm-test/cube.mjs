/* THE VOLUME A .cube CAME WITH — drawn in 3Dmol, and carried to the headset.
 *
 * A cube file is a molecule and a grid. The molecule has always been read out of the header;
 * this is the grid, which is the reason somebody opens one. What is checked here is that the
 * grid is read, that the isovalues offered fit the data rather than being a fixed list, that
 * both lobes are drawn for signed data and one for a density, that the surface survives
 * everything else the viewer does to its shapes — and that it reaches 2DWORM-VR.
 *
 * The isosurface is a SHAPE in 3Dmol, the same category as the selection halo and the
 * periodic box, so it is torn down and rebuilt by applyStyle along with them. A test that
 * only looked at it once would not notice it failing to come back.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8801;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await context.newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });

/** A cube of a p-like function on a 16^3 grid: positive on one side, negative on the other,
    so both lobes have something to march. Two hydrogens in the header, in bohr. */
function makeCube({ signed = true, n = 16, nOrb = 0 } = {}) {
  const nAtoms = nOrb ? -2 : 2;
  const L = [' 2D-WORM test cube', ' a p-like function',
    `  ${nAtoms}    -4.000000   -4.000000   -4.000000`,
    `   ${n}     0.500000    0.000000    0.000000`,
    `   ${n}     0.000000    0.500000    0.000000`,
    `   ${n}     0.000000    0.000000    0.500000`,
    '    1    1.000000   -1.400000    0.000000    0.000000',
    '    1    1.000000    1.400000    0.000000    0.000000'];
  if (nOrb) L.push('    ' + nOrb + '    1    2');
  const vals = [];
  for (let i = 0; i < n * n * n; i++) {
    const ix = Math.floor(i / (n * n)), iy = Math.floor(i / n) % n, iz = i % n;
    const x = -4 + ix * 0.5, y = -4 + iy * 0.5, z = -4 + iz * 0.5;
    const g = Math.exp(-(x * x + y * y + z * z) / 8);
    const v = signed ? g * Math.tanh(x) : g;
    for (let k = 0; k < (nOrb || 1); k++) vals.push(v / (k + 1));
  }
  for (let i = 0; i < vals.length; i += 6) L.push(vals.slice(i, i + 6).map(v => '  ' + v.toExponential(5)).join(''));
  return L.join('\n') + '\n';
}

const openApp = async () => {
  await page.goto(`http://127.0.0.1:${PORT}/index.html`);
  await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
};
/** Drop a cube on the page exactly as a person would, through the file input. */
const openCube = async (text, name = 'orbital.cube') => {
  await page.setInputFiles('#fileInput', { name, mimeType: 'text/plain', buffer: Buffer.from(text) });
  await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 60000 });
  await page.waitForTimeout(900);
};
const shapes = () => page.evaluate(() => {
  const v = window.dworm2d.viewer;
  return (v.shapes || []).filter(Boolean).length;
});

await openApp();
await openCube(makeCube());

const opened = await page.evaluate(() => {
  const D = window.dworm2d, f = D.state3d.field;
  return { atoms: D.state3d.nAtoms, has: !!f, name: f && f.name, signed: f && f.signed,
           absMax: f && f.absMax, isos: f && f.isos, iso: D.opts.iso,
           selHidden: document.getElementById('selIso').hidden,
           selValue: document.getElementById('selIso').value,
           selCount: document.getElementById('selIso').options.length,
           msg: document.getElementById('msg').textContent };
});
check('a .cube gives up its atoms, as it always did', opened.atoms === 2, opened.atoms + ' atoms');
check('and now its grid as well, kept whole', opened.has === true && opened.name === 'orbital.cube');
/* The menu is built from the data's own largest value, so every entry on it draws something.
   A fixed list of isovalues is the thing that makes somebody type 0.02 into a density scaled
   in atomic units and conclude the file is broken. */
check('the isovalues offered are built from this grid’s own values, not from a fixed list',
  Array.isArray(opened.isos) && opened.isos.length >= 4 &&
  opened.isos[0] < opened.absMax && opened.isos[0] > opened.isos[1] &&
  opened.isos.every(v => v > 0 && v < opened.absMax),
  `max ${opened.absMax.toFixed(3)} → ${opened.isos.join(', ')}`);
check('the FIELD menu appears only now that there is a field, and starts on a value that draws',
  opened.selHidden === false && opened.selCount === opened.isos.length + 1 &&
  parseFloat(opened.selValue) === opened.iso && opened.iso > 0,
  'showing iso ' + opened.iso);
check('and the page says the grid came too, rather than leaving you to find the menu',
  /grid came too/i.test(opened.msg), opened.msg.slice(-90));

/* TWO LOBES for signed data. An orbital drawn with only its positive half is a different
   orbital. */
const drawn = await page.evaluate(() => {
  const D = window.dworm2d;
  const before = (D.viewer.shapes || []).filter(Boolean).length;
  return { before, n: D.drawField(D.viewer) };
});
check('a signed grid is drawn as two isosurfaces, one of each sign',
  drawn.n === 2, drawn.n + ' isosurfaces');

/* The isosurface is a shape, and applyStyle removes every shape and puts them back. If the
   field is not in that list it disappears the moment anything else is touched — which is
   every representation change, every pick, every time the cell box is toggled. */
const survives = await page.evaluate(async () => {
  const D = window.dworm2d;
  /* the direct drawField() above added a second pair on top of the drawn ones; one rebuild
     puts the scene back to what the page itself would have drawn */
  D.applyStyle(D.viewer); D.viewer.render();
  await new Promise(r => setTimeout(r, 400));
  const n0 = (D.viewer.shapes || []).filter(Boolean).length;
  document.getElementById('selStyle').value = 'tube';
  document.getElementById('selStyle').dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 700));
  const n1 = (D.viewer.shapes || []).filter(Boolean).length;
  document.getElementById('selStyle').value = 'bs';
  document.getElementById('selStyle').dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 700));
  return { n0, n1, n2: (D.viewer.shapes || []).filter(Boolean).length };
});
check('the field survives a change of representation, which tears every shape down and rebuilds',
  survives.n0 >= 2 && survives.n1 === survives.n0 && survives.n2 === survives.n0,
  `${survives.n0} → ${survives.n1} → ${survives.n2} shapes`);

const offOn = await page.evaluate(async () => {
  const sel = document.getElementById('selIso');
  sel.value = '0'; sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 600));
  const off = { shapes: (window.dworm2d.viewer.shapes || []).filter(Boolean).length,
                msg: document.getElementById('msg').textContent };
  sel.value = String(window.dworm2d.state3d.field.isos[2]); sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 900));
  return { off, on: { shapes: (window.dworm2d.viewer.shapes || []).filter(Boolean).length,
                      iso: window.dworm2d.opts.iso, msg: document.getElementById('msg').textContent } };
});
check('FIELD: off takes it away and says how to bring it back',
  offOn.off.shapes === 0 && /choose an isovalue/i.test(offOn.off.msg), offOn.off.msg);
check('and another isovalue redraws it at that level, with the time it took',
  offOn.on.shapes === 2 && offOn.on.iso > 0 && /ms\)/.test(offOn.on.msg), offOn.on.msg.slice(0, 80));

/* A DENSITY HAS NO NEGATIVE LOBE. Drawing one would be an isosurface at a level the data
   never reaches: empty in 3Dmol, and an error WebGL refuses outright in Mol*. */
await openApp();
await openCube(makeCube({ signed: false }), 'density.cube');
const dens = await page.evaluate(() => {
  const D = window.dworm2d;
  return { signed: D.state3d.field.signed, n: D.drawField(D.viewer), min: D.state3d.field.min,
           msg: document.getElementById('msg').textContent };
});
check('a grid with no negative values is drawn as one lobe, not two',
  dens.signed === false && dens.n === 1, dens.n + ' isosurface, min ' + dens.min);
check('and the page does not promise a red lobe there is no data for',
  !/red/.test(dens.msg), dens.msg.slice(-70));

/* SEVERAL DATA SETS IN ONE FILE. A negative atom count says so; the values are then
   interleaved. Only the first is drawn, and saying so is better than drawing a blend. */
await openApp();
await openCube(makeCube({ nOrb: 2 }), 'two.cube');
const multi = await page.evaluate(async () => {
  const D = window.dworm2d;
  const sel = document.getElementById('selIso');
  sel.value = String(D.state3d.field.isos[1]); sel.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 700));
  return { nOrb: D.state3d.field.nOrb, atoms: D.state3d.nAtoms,
           msg: document.getElementById('msg').textContent };
});
check('a cube holding two data sets is read as two, and the atoms still come out right',
  multi.nOrb === 2 && multi.atoms === 2, multi.nOrb + ' data sets, ' + multi.atoms + ' atoms');
check('and the page says only the first is drawn rather than drawing a blend',
  /2 data sets/.test(multi.msg), multi.msg.slice(0, 90));

/* THE FIELD BELONGS TO THE GEOMETRY IT WAS COMPUTED FOR. A surface drawn over a different
   molecule is not a mistake anybody catches by eye. */
const cleared = await page.evaluate(async () => {
  const D = window.dworm2d;
  const k = await D.whenKetcher(); await k.setMolecule('CCO');
  document.getElementById('btnMake3d').click();
  await new Promise(r => setTimeout(r, 3000));
  return { field: D.state3d.field, iso: D.opts.iso,
           hidden: document.getElementById('selIso').hidden,
           shapes: (D.viewer.shapes || []).filter(Boolean).length };
});
check('building another structure takes the field with the old one',
  cleared.field === null && cleared.iso === 0 && cleared.hidden === true && cleared.shapes === 0);

/* ====================== TWO GRIDS: the surface from one, the colours from the other

   An ESP map, an NCI plot and an IGM picture are all the same shape of thing — a surface
   taken from one quantity and painted with the values of another — and the only reason they
   need different software is the quantity, not the drawing. NCIPLOT, Multiwfn and every ESP
   workflow hand them over the same way: two cubes from one run, on the same grid.

   So a second cube ON THE SAME GRID must colour the first rather than replace it. Getting
   that wrong loses the shape the moment the colours arrive, which is the whole picture. */
await openApp();
await openCube(makeCube(), 'rdg.cube');
const grid = await page.evaluate(() => ({
  same: window.dworm2d.sameGrid('x\ny\n 1 0 0 0\n 8 0.5 0 0\n 8 0 0.5 0\n 8 0 0 0.5\n',
                                'other\nheader\n 1 0.000000 0 0\n 8 0.5 0 0\n 8 0 0.5 0\n 8 0 0 0.5\n'),
  diff: window.dworm2d.sameGrid('x\ny\n 1 0 0 0\n 8 0.5 0 0\n 8 0 0.5 0\n 8 0 0 0.5\n',
                                'x\ny\n 1 0 0 0\n 9 0.5 0 0\n 8 0 0.5 0\n 8 0 0 0.5\n'),
}));
/* Compared as the header's own numbers, not with a tolerance: "the same grid" is an exact
   statement, and a pair written by one program in one run agrees to the last digit. */
check('two cubes are the same grid when their counts, origin and axes agree — and not otherwise',
  grid.same === true && grid.diff === false, `same ${grid.same}, different ${grid.diff}`);

await page.setInputFiles('#fileInput', { name: 'sign_lambda2_rho.cube', mimeType: 'text/plain',
  buffer: Buffer.from(makeCube({ signed: true })) });
await page.waitForFunction(() => window.dworm2d.state3d.field2, null, { timeout: 60000 });
await page.waitForTimeout(900);
const two = await page.evaluate(() => ({
  first: window.dworm2d.state3d.field.name,
  second: window.dworm2d.state3d.field2.name,
  shapes: (window.dworm2d.viewer.shapes || []).filter(Boolean).length,
  range: window.dworm2d.opts.crange,
  hidden: document.getElementById('selCRange').hidden,
  opts: document.getElementById('selCRange').options.length,
  msg: document.getElementById('msg').textContent,
  atoms: window.dworm2d.state3d.nAtoms,
}));
check('a second cube on the same grid colours the first rather than replacing it',
  two.first === 'rdg.cube' && two.second === 'sign_lambda2_rho.cube', `${two.first} painted with ${two.second}`);
/* ONE surface, not two. A coloured surface is single-valued by construction — the reduced
   density gradient at 0.5 — and the sign is what the colour is carrying. A second surface at
   the negative of that would be an isosurface of a quantity with no negative values, which
   is an empty mesh. */
check('and it is drawn as one surface, because the sign is in the colour now',
  two.shapes === 1, two.shapes + ' surface');
check('the colour scale appears with its own range, built from the second grid’s values',
  two.hidden === false && two.opts >= 4 && two.range > 0, `±${two.range} from ${two.opts} choices`);
check('and the page says what it did, rather than looking as though the first file was lost',
  /colouring it rather than replacing/.test(two.msg), two.msg.slice(0, 110));
check('the structure is untouched by either of them', two.atoms === 2, two.atoms + ' atoms');

const ranged = await page.evaluate(async () => {
  const cs = document.getElementById('selCRange');
  cs.value = cs.options[cs.options.length - 1].value;
  cs.dispatchEvent(new Event('change'));
  await new Promise(r => setTimeout(r, 900));
  return { range: window.dworm2d.opts.crange,
           shapes: (window.dworm2d.viewer.shapes || []).filter(Boolean).length,
           msg: document.getElementById('msg').textContent };
});
check('a different range redraws it, and says which way the colours run',
  ranged.shapes === 1 && ranged.range > 0 && /blue is negative, red positive/.test(ranged.msg),
  ranged.msg.slice(0, 80));

/* A cube on a DIFFERENT grid is a different calculation, so that one does replace. */
const replaced = await page.evaluate(() => null);
await page.setInputFiles('#fileInput', { name: 'other.cube', mimeType: 'text/plain',
  buffer: Buffer.from(makeCube({ n: 10 })) });
await page.waitForFunction(() => window.dworm2d.state3d.field && window.dworm2d.state3d.field.name === 'other.cube',
  null, { timeout: 60000 });
await page.waitForTimeout(800);
const gone2 = await page.evaluate(() => ({
  first: window.dworm2d.state3d.field.name, second: window.dworm2d.state3d.field2,
  hidden: document.getElementById('selCRange').hidden,
  shapes: (window.dworm2d.viewer.shapes || []).filter(Boolean).length }));
check('but a cube on a different grid is a different calculation, and replaces it',
  gone2.first === 'other.cube' && gone2.second === null && gone2.hidden === true && gone2.shapes === 2,
  `${gone2.first}, ${gone2.shapes} lobes again`);

/* ------------------------------------------------------- and over to the headset */
await openApp();
await openCube(makeCube(), 'orbital.cube');
const handed = await page.evaluate(() => {
  const D = window.dworm2d;
  const big = 'x'.repeat(D.VR_FIELD_MAX + 10);
  return { fits: D.state3d.field.text.length <= D.VR_FIELD_MAX,
           len: D.state3d.field.text.length, cap: D.VR_FIELD_MAX, big: big.length };
});
check('a grid small enough to travel is offered to the headset',
  handed.fits === true, `${(handed.len / 1024).toFixed(0)} kB, cap ${(handed.cap / 1024 / 1024).toFixed(0)} MB`);

await page.evaluate(() => window.dworm2d.goVR());
await page.waitForFunction(() => window.dwormVR && window.dwormVR.booted, null, { timeout: 90000 });
await page.waitForTimeout(1200);
const inVR = await page.evaluate(() => {
  const V = window.dwormVR;
  return { vols: V.payload && V.payload.volumes ? V.payload.volumes.length : 0,
           loaded: V.volumes.length, name: V.volumes[0] && V.volumes[0].name,
           opts: document.getElementById('selField').options.length,
           disabled: document.getElementById('selField').disabled,
           what: document.getElementById('what').textContent };
});
check('the grid arrives in 2DWORM-VR with the structure, not as a second download',
  inVR.vols === 1 && inVR.loaded === 1 && inVR.name === 'orbital.cube',
  inVR.loaded + ' field loaded');
check('and the FIELD menu there is built from what actually arrived',
  inVR.opts === 2 && inVR.disabled === false && /1 field/.test(inVR.what), inVR.what);

const igm = await page.evaluate(async () => {
  const V = window.dwormVR;
  V.XR_ACTIONS.field();
  await new Promise(r => setTimeout(r, 1200));
  let isos = 0;
  for (const ref of V.volumes[0].refs) {
    const c = V.plugin.state.data.cells.get(ref);
    if (c && c.transform && c.transform.transformer.id === 'ms-plugin.volume-representation-3d') isos++;
  }
  return { on: V.volumes[0].on, idx: V.fieldIdx, isos, msg: document.getElementById('msg').textContent };
});
check('IGM switches it on, with a lobe of each sign as on the flat page',
  igm.on === true && igm.idx === 0 && igm.isos === 2, igm.isos + ' isosurfaces');

/* ------------------------------------------- the lock, coming home
   The headset writes the view down whenever it is left, by whatever route, and 2D-WORM picks
   it up. Nothing is pressed. Turn the structure in the headset and the page must come back
   to the turned view, not to the one it sent. */
const home = await page.evaluate(async () => {
  const V = window.dwormVR;
  const cam = V.plugin.canvas3d.camera, s = cam.getSnapshot();
  /* move the camera somewhere unmistakably different */
  s.position[0] += 14; s.position[1] -= 9;
  cam.setState(s); V.plugin.canvas3d.requestDraw();
  await new Promise(r => setTimeout(r, 400));
  const rec = V.viewRecord();
  V.writeBack();
  return { rec, stored: JSON.parse(sessionStorage.getItem(V.VR_BACK) || 'null') };
});
await page.evaluate(() => document.getElementById('btnReturn').click());
await page.waitForFunction(() => document.getElementById('msg').textContent.indexOf('Back from') === 0, null, { timeout: 90000 });
await page.waitForTimeout(600);
const back = await page.evaluate(() => {
  const D = window.dworm2d;
  return { rec: D.viewRecord(), msg: document.getElementById('msg').textContent,
           left: sessionStorage.getItem('dworm2d.vrback') };
});
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const axisOf = (q) => {          // where the view is looking, in the structure
  const c = [-q[0], -q[1], -q[2], q[3]];
  const [x, y, z, w] = c, v = [0, 0, 1];
  const tx = 2 * (y * v[2] - z * v[1]), ty = 2 * (z * v[0] - x * v[2]), tz = 2 * (x * v[1] - y * v[0]);
  return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)];
};
check('coming back shows what the headset was looking at, not what was sent to it',
  /looking at in the headset/i.test(back.msg), back.msg);
check('— the same centre',
  Math.hypot(back.rec.centre[0] - home.rec.centre[0], back.rec.centre[1] - home.rec.centre[1],
             back.rec.centre[2] - home.rec.centre[2]) < 0.02,
  Math.hypot(back.rec.centre[0] - home.rec.centre[0], back.rec.centre[1] - home.rec.centre[1],
             back.rec.centre[2] - home.rec.centre[2]).toExponential(1) + ' A apart');
check('— the same amount of the structure in frame',
  Math.abs(back.rec.half - home.rec.half) / home.rec.half < 0.02,
  `${back.rec.half.toFixed(3)} vs ${home.rec.half.toFixed(3)} A`);
check('— and looking along the same axis',
  dot(axisOf(back.rec.quat), axisOf(home.rec.quat)) > 0.999,
  dot(axisOf(back.rec.quat), axisOf(home.rec.quat)).toFixed(5));
/* Consumed once. A reload a week later is a fresh page, not a second return. */
check('the record is consumed on arrival, so a reload is not a second return', back.left === null);

check('no console or page errors',
  errors.filter(e => !/favicon|ResizeObserver|WebGL|Could not create/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
