/* The NOTES panel, and — most of this file — proving the renderer is inert.
 *
 * A note is the only text in 2D-WORM written by one person and rendered in another person's
 * browser. Everything else the page draws is either the user's own or ours. So the interesting
 * tests are not "does bold work" but "what happens when somebody who is not being friendly
 * writes the note", and they are checked against the DOM that actually results rather than
 * against the HTML string: `&lt;script&gt;` in a string is reassuring and proves nothing —
 * what matters is whether a script element exists on the page afterwards.
 *
 * The rules the renderer is held to:
 *   · the only tags on the page are ones renderNote wrote itself;
 *   · no attribute a note wrote ever reaches an element — no href, no onclick, no style, no
 *     src, so there is nothing to smuggle a scheme or an expression into;
 *   · a link is never clickable without being asked for by name, because markdown lets the
 *     visible text of a link say one thing while the link goes somewhere else;
 *   · nothing is ever fetched from another host, so a note cannot tell anybody who read it.
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8799;

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
/* anything the page tries to fetch from somewhere else, for the whole run */
const outside = [];
page.on('request', r => { if (!r.url().startsWith(`http://127.0.0.1:${PORT}/`) && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) { outside.push(r.url()); } });
/* a dialog would mean something managed to call alert(), which is the classic proof */
let dialogs = 0;
page.on('dialog', async (d) => { dialogs++; await d.dismiss(); });

await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });

/** Put a note in, render it, and report what the DOM actually became. */
const render = (src) => page.evaluate((t) => {
  document.getElementById('noteText').value = t;
  window.dworm2d.setNoteMode('read');
  const v = document.getElementById('noteView');
  return {
    html: v.innerHTML,
    text: v.textContent,
    tags: [...new Set([...v.querySelectorAll('*')].map(e => e.tagName.toLowerCase()))].sort(),
    attrs: [...new Set([...v.querySelectorAll('*')].flatMap(e => [...e.attributes].map(a => a.name)))].sort(),
    scripts: v.querySelectorAll('script').length,
    imgs: v.querySelectorAll('img,iframe,object,embed,svg,link,style,form,input').length,
    hrefs: [...v.querySelectorAll('[href],[src],[xlink\\:href]')].length,
    handlers: [...v.querySelectorAll('*')].filter(e => [...e.attributes].some(a => /^on/i.test(a.name))).length,
  };
}, src);

/* ------------------------------------------------------------------ the panel */
check('NOTES is a panel behind a button, not something in everybody\'s way',
  await page.getAttribute('#panelNote', 'hidden') !== null && await page.isVisible('#btnNotes'));
await page.click('#btnNotes');
check('the button opens it', await page.isVisible('#panelNote') && await page.isVisible('#noteText'));
check('and the other two panels are still there beside it — it is a third panel, not a takeover',
  await page.isVisible('#panel2d') && await page.isVisible('#panel3d'));
check('it says where the note goes, which is the only reason to write one here',
  /travels inside the shared link/.test(await page.textContent('#panelNote .ptitle')));

/* ------------------------------------------------------------- what it renders */
let r = await render('# A heading\n\nPlain text with **bold**, *italic* and `mono`.\n\n- one\n- two');
check('a heading, a paragraph, bold, italic, monospace and a list',
  r.tags.join(',') === 'b,code,h3,i,li,p,ul' && /A heading/.test(r.text) && /Plain text with bold/.test(r.text),
  r.tags.join(','));
r = await render('> note: something to remember\n> warn: careful with this one\n> ok: this one is settled');
check('the three blocks are roles the page colours, not colours the writer picks',
  (await page.$$eval('#noteView .cal', e => e.map(x => x.className))).join(' ') === 'cal note cal warn cal ok' &&
  !/style=/.test(r.html), (await page.$$eval('#noteView .cal', e => e.map(x => x.className))).join(' '));
check('and each says which it is, so the colour is never the only signal',
  (await page.$$eval('#noteView .cal .tag', e => e.map(x => x.textContent))).join(',') === 'NOTE,WARN,OK');

/* ----------------------------------------------------------- and what it will not
   Each of these is a real technique, not a made-up string. */
const hostile = [
  ['a script tag', '<script>window.__pwned = 1;</script>'],
  ['an image with an error handler', '<img src=x onerror="window.__pwned=1">'],
  ['an svg with an onload', '<svg/onload=alert(1)>'],
  ['a javascript: link in markdown syntax', '[click here](javascript:alert(1))'],
  ['a data: URL', '[open](data:text/html,<script>alert(1)</script>)'],
  ['an iframe', '<iframe src="https://example.invalid/"></iframe>'],
  ['a style block', '<style>body{display:none}</style>'],
  ['an inline style attribute', '<p style="position:fixed;inset:0;background:red">gotcha</p>'],
  ['a form that posts somewhere', '<form action="https://example.invalid/"><input name="x"></form>'],
  ['a remote image, which would say who is reading', '![x](https://example.invalid/pixel.png)'],
  ['a link whose text lies about where it goes', '[https://www.rcsb.org](https://evil.invalid/)'],
  ['an escaped-looking tag', '&lt;script&gt;alert(1)&lt;/script&gt;'],
  ['a broken tag the parser might repair', '<scr<script>ipt>alert(1)</scr</script>ipt>'],
  ['an attribute break-out inside a chip', '[[0,1|" onmouseover="window.__pwned=1]]'],
  ['a base tag, which would repoint every relative URL', '<base href="https://evil.invalid/">'],
  ['a meta refresh', '<meta http-equiv="refresh" content="0;url=https://evil.invalid/">'],
];
let worst = [];
for (const [what, src] of hostile) {
  const g = await render(src);
  const clean = g.scripts === 0 && g.imgs === 0 && g.hrefs === 0 && g.handlers === 0 &&
    g.tags.every(t => ['p', 'b', 'i', 'code', 'h3', 'ul', 'li', 'div', 'span', 'button', 'br'].includes(t)) &&
    g.attrs.every(a => ['class', 'type', 'data-pick', 'data-url', 'role', 'tabindex'].includes(a));
  if (!clean) { worst.push(what + ' -> ' + g.tags.join(',') + ' [' + g.attrs.join(',') + ']'); }
  check(what + ' is text and nothing else', clean, clean ? '' : g.html.slice(0, 120));
}
check('and nothing anywhere managed to run', (await page.evaluate(() => !!window.__pwned)) === false && dialogs === 0,
  'dialogs ' + dialogs);
check('no note fetched anything from another host', outside.length === 0, outside.slice(0, 3).join(' | '));

/* ------------------------------------------------------------------- real links */
r = await render('See https://www.rcsb.org/structure/1CRN for the deposited one.');
check('a bare http link is shown with the host it would really go to',
  (await page.$$eval('#noteView .lk', e => e.length)) === 1 &&
  /\(www\.rcsb\.org\)/.test(await page.textContent('#noteView .lk')),
  (await page.textContent('#noteView .lk')).trim());
check('and it is NOT a link: no href for a click to follow without being asked',
  (await page.$$eval('#noteView a', e => e.length)) === 0 && r.hrefs === 0);
r = await render('ftp://evil.invalid/x  file:///etc/passwd  javascript:alert(1)');
check('and only http and https are recognised at all — a scheme allow-list, not a block-list',
  (await page.$$eval('#noteView .lk', e => e.length)) === 0);

/* ------------------------------------------------------- the chip that re-selects */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms > 0, null, { timeout: 120000 });
await page.evaluate(() => { window.dworm2d.state3d.sel = [0, 1]; window.dworm2d.applyStyle(window.dworm2d.viewer); window.dworm2d.saySelection(); });
/* the panel is already open from the checks above; pressing the button again would shut it */
await page.evaluate(() => { document.getElementById('noteText').value = 'The bond I mean: '; window.dworm2d.setNoteMode('write'); });
await page.click('#btnNoteSel');
const written = await page.inputValue('#noteText');
check('INSERT SELECTION writes the atoms and their measurement into the note',
  /\[\[0,1\|Distance [\d.]+ Å/i.test(written), written.slice(0, 70));
await page.evaluate(() => { window.dworm2d.state3d.sel = []; window.dworm2d.applyStyle(window.dworm2d.viewer); });
await page.evaluate(() => window.dworm2d.setNoteMode('read'));
check('and it renders as a chip rather than as brackets',
  (await page.$$eval('#noteView button.pick', e => e.length)) === 1 &&
  !/\[\[/.test(await page.textContent('#noteView')),
  await page.textContent('#noteView button.pick'));
await page.click('#noteView button.pick');
await page.waitForTimeout(300);
check('clicking it picks those atoms again in the 3D view — which is the point of a note about a structure',
  (await page.evaluate(() => window.dworm2d.state3d.sel.join(','))) === '0,1',
  await page.evaluate(() => window.dworm2d.state3d.sel.join(',')));
await page.evaluate(() => { document.getElementById('noteText').value = '[[0,9999|not in this one]]'; window.dworm2d.setNoteMode('read'); });
await page.click('#noteView button.pick');
await page.waitForTimeout(250);
check('a chip naming atoms this structure does not have picks the ones it does and says so',
  (await page.evaluate(() => window.dworm2d.state3d.sel.join(','))) === '0' ||
  (await page.evaluate(() => window.dworm2d.state3d.sel.length)) === 0);

/* ------------------------------------------------------------------ the toolbar */
await page.evaluate(() => { const t = document.getElementById('noteText'); t.value = 'hello'; t.setSelectionRange(0, 5); window.dworm2d.setNoteMode('write'); });
await page.click('.notebar button[data-md="b"]');
check('the toolbar writes the syntax so nobody has to remember it',
  (await page.inputValue('#noteText')) === '**hello**', await page.inputValue('#noteText'));
await page.evaluate(() => { const t = document.getElementById('noteText'); t.value = ''; t.setSelectionRange(0, 0); });
await page.click('.notebar button[data-md="warn"]');
check('and a block button starts the block', (await page.inputValue('#noteText')) === '> warn: ', JSON.stringify(await page.inputValue('#noteText')));

/* -------------------------------------------------------------------- the cap */
const cap = await page.evaluate(() => {
  const t = document.getElementById('noteText');
  t.value = 'x'.repeat(window.dworm2d.NOTE_MAX + 5000);
  t.dispatchEvent(new Event('input'));
  return { len: t.value.length, max: window.dworm2d.NOTE_MAX, shown: document.getElementById('noteCount').textContent };
});
check('a note is capped, and the count says so before you hit it',
  cap.len === cap.max && cap.shown.includes(String(cap.max)), `${cap.len} / ${cap.max} · "${cap.shown}"`);

/* ------------------------------------------------------------------- sharing */
await page.evaluate(() => { document.getElementById('noteText').value = '# Why\n\n> warn: the metal is a guess'; });
const st = await page.evaluate(() => window.dworm2d.buildState('full'));
check('the note travels in a shared link', typeof st.note === 'string' && /the metal is a guess/.test(st.note));
const stc = await page.evaluate(() => window.dworm2d.buildState('compact'));
check('but not in a SMILES-only link, which is meant to be as small as it can be', !('note' in stc));
await page.evaluate(() => { document.getElementById('noteText').value = ''; });
await page.evaluate(async (s) => { await window.dworm2d.applyState(s); }, st);
await page.waitForTimeout(700);
check('opening such a link brings the note back, and opens the panel showing it',
  (await page.inputValue('#noteText')).includes('the metal is a guess') &&
  await page.isVisible('#panelNote') && (await page.evaluate(() => window.dworm2d.noteMode)) === 'read',
  'mode ' + await page.evaluate(() => window.dworm2d.noteMode));
const nasty = { ...st, note: '<img src=x onerror="window.__pwned2=1"> [x](javascript:alert(1))' };
await page.evaluate(async (s) => { await window.dworm2d.applyState(s); }, nasty);
await page.waitForTimeout(700);
check('and a note arriving from a LINK is put through the same renderer, not trusted',
  (await page.evaluate(() => !!window.__pwned2)) === false &&
  (await page.$$eval('#noteView img, #noteView a', e => e.length)) === 0);

/* --------------------------------------------------- the operator gets a say */
const cfg = await page.evaluate(async () => (await (await fetch('QRsharing/share.php?status')).json()));
check('a stored drawing may not carry a note unless the operator turns it on, and off is the default',
  cfg.notes === false, JSON.stringify(cfg.notes));

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));

await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
