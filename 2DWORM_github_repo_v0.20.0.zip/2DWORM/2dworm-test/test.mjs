import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
/* the page itself, one folder up — so the suite runs wherever the repository is */
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const OUT = fileURLToPath(new URL('./out', import.meta.url));

const PORT = 8765;
fs.rmSync(APP + 'QRsharing/data/shares.sqlite', { force: true });
for (const suffix of ['-wal', '-shm']) fs.rmSync(APP + 'QRsharing/data/shares.sqlite' + suffix, { force: true });
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '8' } });
await new Promise(r => setTimeout(r, 800));
const out = OUT; fs.mkdirSync(out, { recursive: true });
const results = []; const check = (name, ok, info = '') => { results.push({ name, ok: !!ok, info }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); };

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });
check('page ready', true);

// draw a molecule (ibuprofen) through Ketcher API, then build the 3D structure explicitly
await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CC(C)Cc1ccc(cc1)C(C)C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => dworm2d.state3d.molblock && dworm2d.state3d.source === 'drawing', null, { timeout: 60000 });
const info = await page.evaluate(() => {
  const atoms = dworm2d.viewer.getModel().selectedAtoms({});
  const mb = dworm2d.state3d.molblock;
  const lines = mb.split('\n'); const na = parseInt(lines[3].slice(0, 3)), nb = parseInt(lines[3].slice(3, 6));
  const A = []; for (let i = 0; i < na; i++) { const l = lines[4 + i]; A.push([+l.slice(0, 10), +l.slice(10, 20), +l.slice(20, 30), l.slice(31, 34).trim()]); }
  const d = []; for (let i = 0; i < nb; i++) { const l = lines[4 + na + i]; const a = A[parseInt(l.slice(0, 3)) - 1], b = A[parseInt(l.slice(3, 6)) - 1]; d.push(Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2])); }
  return { n: atoms.length, nH: atoms.filter(a => a.elem === 'H').length, status: document.getElementById('status3d').textContent, minD: Math.min(...d), maxD: Math.max(...d), z: A.some(a => Math.abs(a[2]) > 0.3) };
});
check('MAKE 3D builds ibuprofen (C13H18O2 = 33 atoms)', info.n === 33 && info.nH === 18, JSON.stringify(info));
check('bond lengths sane (Å)', info.minD > 0.9 && info.maxD < 1.7 && info.z, `min ${info.minD.toFixed(2)} max ${info.maxD.toFixed(2)}`);

/* Caffeine, because Indigo cannot kekulise it and DOES NOT SAY SO. The molfile comes back
   with its type-4 aromatic bonds intact and no error raised; OpenChemLib's reader cannot use
   those, and MAKE 3D died with "Conformer generation failed for fragment 1" — a message that
   pointed nowhere near the cause. The page now checks the result of dearomatize rather than
   trusting the call, and falls back to SMILES. Caffeine is in the paper's Table 4, so this
   was failing on one of the most-used test molecules in chemistry. */
{
  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('Cn1cnc2c1c(=O)n(C)c(=O)n2C'); });
  await page.waitForTimeout(900);
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0 || /failed|cannot/i.test(document.getElementById('status3d').textContent),
    null, { timeout: 90000 });
  const caf = await page.evaluate(() => ({ n: dworm2d.state3d.nAtoms, s: document.getElementById('status3d').textContent }));
  check('MAKE 3D builds caffeine, which Indigo cannot kekulise', caf.n === 24 && /C8H10N4O2/.test(caf.s), caf.s.slice(0, 90));
  // put ibuprofen back: everything after this expects it
  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CC(C)Cc1ccc(cc1)C(C)C(=O)O'); });
  await page.waitForTimeout(900);
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms === 33, null, { timeout: 90000 });
}
await page.screenshot({ path: out + '/desktop.png' });

// minimize
await page.click('#btnMinimize');
await page.waitForFunction(() => document.getElementById('status3d').textContent.includes('kcal/mol'), null, { timeout: 60000 });
check('MMFF minimise', true, await page.$eval('#status3d', e => e.textContent));

// image export
const img = await page.evaluate(async () => { const u = await dworm2d.render3dImage(2, 'image/jpeg'); const p = await dworm2d.render3dImage(1, 'image/png'); return { jpg: u.slice(0, 30), jl: u.length, pl: p.length, png: p.slice(0, 22) }; });
check('JPG export', img.jpg.startsWith('data:image/jpeg') && img.jl > 20000, `${img.jl} chars`);
check('PNG export', img.png.startsWith('data:image/png') && img.pl > 10000, `${img.pl} chars`);
const jpgData = await page.evaluate(async () => await dworm2d.render3dImage(3, 'image/jpeg'));
fs.writeFileSync(out + '/export_3x.jpg', Buffer.from(jpgData.split(',')[1], 'base64'));

// coordinate exports
const co = await page.evaluate(() => ({ xyz: dworm2d.toXYZ(dworm2d.state3d.molblock), pdb: dworm2d.toPDB(dworm2d.state3d.molblock) }));
fs.writeFileSync(out + '/ibuprofen.xyz', co.xyz); fs.writeFileSync(out + '/ibuprofen.pdb', co.pdb);
check('XYZ export', co.xyz.startsWith('33\n') && co.xyz.split('\n').length >= 35);
check('PDB export', (co.pdb.match(/^HETATM/gm) || []).length === 33 && /^CONECT/m.test(co.pdb));

// save menu downloads (cdx + cdxml + mol)
for (const what of ['cdx', 'cdxml', 'mol', 'ket', 'png2d', 'svg2d', 'jpg', 'xyz']) {
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 30000 }), page.evaluate(async (w) => { await document.querySelector(`[data-save="${w}"]`).click(); }, what)]);
  const p = out + '/dl_' + dl.suggestedFilename(); await dl.saveAs(p);
  const size = fs.statSync(p).size; check('download ' + what, size > 100, `${dl.suggestedFilename()} ${size} B`);
  if (what === 'cdx') check('cdx magic', fs.readFileSync(p).subarray(0, 8).toString() === 'VjCD0100');
}

// share link round trip
const share = await page.evaluate(async () => { const st = await dworm2d.buildState(false); const enc = await dworm2d.encodeState(st); const stc = await dworm2d.buildState(true); return { len: enc.length, keys: Object.keys(st), lenCompact: (await dworm2d.encodeState(stc)).length, url: location.origin + location.pathname + '#' + enc }; });
check('share state (full, deflate)', share.keys.includes('mol') && share.len < 1600 && share.url.includes('#z='), `${share.len} chars, keys ${share.keys}`);
check('share state (compact)', share.lenCompact < 400, `${share.lenCompact} chars`);
await page.click('#btnShare');
await page.waitForSelector('#qrbox svg', { timeout: 20000 });
check('QR rendered', true, await page.$eval('#shareLen', e => e.textContent));
await page.screenshot({ path: out + '/share.png' });
await page.keyboard.press('Escape');

const page2 = await ctx.newPage();
page2.on('pageerror', e => errors.push('page2 error: ' + e.message));
await page2.goto(share.url);
await page2.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
const smi2 = await page2.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles());
const smi1 = await page.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles());
check('shared link reproduces drawing', smi1 === smi2, smi2);
const restored = await page2.evaluate(() => ({ src: dworm2d.state3d.source, n: dworm2d.viewer.getModel().selectedAtoms({}).length, bg: dworm2d.opts.bg, fromDrawing: dworm2d.state3d.fromDrawing }));
// the coordinates in the link were built from the drawing that travels with it, so the two belong together
check('shared link restores 3D (minimised coords carried in link)', restored.n === 33 && restored.fromDrawing === true, JSON.stringify(restored));
await page2.screenshot({ path: out + '/restored.png' });

// changing the drawing must NOT rebuild the 3D view by itself (build 4)
const before = await page2.evaluate(() => dworm2d.state3d.molblock);
await page2.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('c1ccccc1O'); });
await page2.waitForTimeout(2000);
check('drawing change does not rebuild the 3D view by itself', before === await page2.evaluate(() => dworm2d.state3d.molblock));
check('status line asks for MAKE 3D after a change', /press MAKE 3D/i.test(await page2.$eval('#status3d', e => e.textContent)));
// explicit MAKE 3D rebuilds it
await page2.click('#btnMake3d');
await page2.waitForFunction(() => dworm2d.viewer.getModel() && dworm2d.viewer.getModel().selectedAtoms({}).length === 13, null, { timeout: 60000 });
check('MAKE 3D rebuilds from the new drawing', true);

// link mangled by an e-mail program (line breaks + spaces + trailing dot) still loads
const mangled = share.url.replace(/(.{60})/g, '$1\n ').replace(/#z=/, '#z= ') + '.';
const page5 = await ctx.newPage(); page5.on('pageerror', e => errors.push('page5 error: ' + e.message));
await page5.goto(mangled);
await page5.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
check('wrapped/mangled link still decodes', smi1 === await page5.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles()));
// truncated link -> clear error dialog
await page5.goto(share.url.slice(0, share.url.length - 40));
await page5.waitForFunction(() => document.getElementById('errDlg').classList.contains('open'), null, { timeout: 60000 });
check('truncated link shows the error dialog', true, await page5.$eval('#errText', e => e.textContent.slice(0, 60)));
await page5.close();

// old lz-string links (build 1) still open
const oldUrl = await page.evaluate(async () => { const st = await dworm2d.buildState('drawing'); return location.origin + location.pathname + '#s=' + LZString.compressToEncodedURIComponent(JSON.stringify(st)); });
const page6 = await ctx.newPage();
await page6.goto(oldUrl);
await page6.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
check('build-1 (#s=) links still open', true); await page6.close();

// outline thickness changes the rendering; theme switch; Ketcher template column on the right
const ol = await page.evaluate(async () => {
  const sel = document.getElementById('selOutline'); const shots = {};
  for (const v of ['0', '0.03', '0.15']) { sel.value = v; sel.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 150)); shots[v] = dworm2d.viewer.pngURI().length; }
  sel.value = '0'; sel.dispatchEvent(new Event('change'));
  return shots;
});
check('outline thickness has an effect', ol['0'] !== ol['0.03'] && ol['0.03'] !== ol['0.15'], JSON.stringify(ol));
await page.click('#themeSeg button[data-theme="black"]'); await page.waitForTimeout(200);
const th = await page.evaluate(() => ({ attr: document.documentElement.getAttribute('data-theme'), stored: localStorage.getItem('dworm2d.theme'), bg: getComputedStyle(document.body).backgroundColor }));
check('BLACK theme applies and is remembered', th.attr === 'black' && th.stored === 'black' && th.bg === 'rgb(0, 0, 0)', JSON.stringify(th));
await page.screenshot({ path: out + '/desktop_black.png' });
await page.click('#themeSeg button[data-theme="white"]'); await page.waitForTimeout(200);
check('WHITE theme (default) restores', await page.evaluate(() => !document.documentElement.hasAttribute('data-theme') && getComputedStyle(document.body).backgroundColor === 'rgb(255, 255, 255)'));
const tb = await page.evaluate(() => { const d = document.getElementById('ketcherFrame').contentDocument; const b = d.querySelector('[data-testid="bottom-toolbar"]').getBoundingClientRect(); const c = d.querySelector('[class*="App-module_canvas"]').getBoundingClientRect(); return { x: b.left, y: b.top, w: b.width, h: b.height, canvasRight: c.right, canvasBottom: c.bottom, frameH: d.documentElement.clientHeight }; });
check('Ketcher ring templates are a vertical column at the right', tb.h > tb.w && tb.x >= tb.canvasRight - 1 && tb.canvasBottom >= tb.frameH - 2, JSON.stringify(tb));
await page.screenshot({ path: out + '/desktop_final.png' });


// open an XYZ file in the 3D panel + a CDX file into ketcher
await page2.evaluate(async (xyz) => { await dworm2d.openFile(new File([xyz], 'test.xyz', { type: 'text/plain' })); }, co.xyz);
await page2.waitForFunction(() => dworm2d.state3d.source === 'file' && dworm2d.state3d.fileName === 'test.xyz');
check('open .xyz into 3D', true);
const cdxBytes = fs.readFileSync(out + '/' + fs.readdirSync(out).find(f => f.endsWith('.cdx')));
// clearing and loading must be separate evaluates – Ketcher needs a turn of the event loop between them
await page2.evaluate(async () => { await (await dworm2d.whenKetcher()).setMolecule(''); });
await page2.evaluate(async (b64) => { const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0)); await dworm2d.openFile(new File([bytes], 'x.cdx')); }, cdxBytes.toString('base64'));
await page2.waitForFunction(async () => (await (await dworm2d.whenKetcher()).getSmiles()).length > 5, null, { timeout: 30000 });
check('open .cdx into Ketcher', true, await page2.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles()));


// stereo + charge survive the minified share link
const st3 = await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('C[C@H](N)C(=O)[O-].[Na+]'); const smi = await k.getSmiles(); const st = await dworm2d.buildState('drawing'); const enc = await dworm2d.encodeState(st); return { smi, url: location.origin + location.pathname + '#' + enc, len: enc.length, mol: st.mol }; });
const page4 = await ctx.newPage(); page4.on('pageerror', e => errors.push('page4 error: ' + e.message));
await page4.goto(st3.url);
await page4.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
const smi4 = await page4.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles());
check('minified link keeps stereo + charges', smi4 === st3.smi && /@/.test(smi4) && /-\]/.test(smi4), `${st3.smi} -> ${smi4} (${st3.len} chars)`);
fs.writeFileSync(out + '/minified.mol', st3.mol);


// ---------------------------------------------------------------- build 3: short links
const srv = await page.evaluate(() => dworm2d.serverStatus());
check('sharing server detected', srv.ok && srv.info.service === '2dworm-qrsharing', `max_rows ${srv.info && srv.info.max_rows}, max_bytes ${srv.info && srv.info.max_bytes}`);
await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CC(C)Cc1ccc(cc1)C(C)C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => dworm2d.state3d.source === 'drawing', null, { timeout: 60000 });
await page.click('#btnShare');
await page.waitForFunction(() => /[?/]k=|\/s\//.test(document.getElementById('shareUrl').value), null, { timeout: 30000 });
const shortUrl = await page.$eval('#shareUrl', e => e.value);
check('SHORT LINK is the default when the server is there', shortUrl.includes('?k=') && shortUrl.length < 90, `${shortUrl.length} chars: ${shortUrl}`);
const qrModules = await page.$eval('#qrbox svg', e => +(e.getAttribute('viewBox') || '').split(' ')[2] / 4);
check('short link gives a small QR code', qrModules <= 37, `${qrModules} modules`);
await page.screenshot({ path: out + '/share_short.png' });
await page.keyboard.press('Escape');
const dedupe = await page.evaluate(async () => {
  const payload = await dworm2d.encodeState(await dworm2d.buildState('full'));
  const a = (await dworm2d.storeOnServer(payload)).url;
  const r = await fetch('QRsharing/share.php', { method: 'POST', body: payload });
  const j = await r.json();
  return { a, b: j.url, deduped: j.deduped };
});
check('the same drawing keeps one key', dedupe.a === dedupe.b && dedupe.deduped === true, dedupe.a);
const pageS = await ctx.newPage(); pageS.on('pageerror', e => errors.push('pageS error: ' + e.message));
await pageS.goto(shortUrl);
await pageS.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
check('short link reproduces the drawing', smi1 === await pageS.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles()));
await pageS.click('#btnMake3d');
await pageS.waitForFunction(() => dworm2d.state3d.molblock && dworm2d.viewer.getModel().selectedAtoms({}).length === 33, null, { timeout: 60000 });
check('short link + MAKE 3D gives the same 3D structure', true);
await pageS.screenshot({ path: out + '/restored_short.png' });
await pageS.goto(shortUrl.replace(/k=.*/, 'k=zzzzzzzz'));
await pageS.waitForFunction(() => document.getElementById('errDlg').classList.contains('open'), null, { timeout: 30000 });
check('unknown key shows the "not on the server any more" dialog', /not on the server|unknown to the server/i.test(await pageS.$eval('#errText', e => e.textContent)));
await pageS.close();
const pageF = await ctx.newPage(); pageF.on('pageerror', e => errors.push('pageF error: ' + e.message));
await pageF.route('**/QRsharing/share.php*', r => r.abort());
await pageF.goto(`http://127.0.0.1:${PORT}/index.html`);
await pageF.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });
await pageF.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('c1ccccc1'); });
await pageF.click('#btnMake3d');
await pageF.waitForFunction(() => dworm2d.state3d.molblock, null, { timeout: 60000 });
await pageF.click('#btnShare');
await pageF.waitForFunction(() => document.getElementById('shareUrl').value.includes('#z='), null, { timeout: 30000 });
check('no server: SHORT is disabled and FULL link is used', await pageF.evaluate(() => document.querySelector('#shareSeg button[data-mode="short"]').disabled));
await pageF.close();
/* 60 kB used to be over the cap; since the large store arrived it is an ordinary drawing with
   a picture in it, and refusing it here would be testing a limit that no longer exists. The
   limit that does exist is 500 kB, and it is refused on size before any wait is imposed. */
const big = await page.evaluate(async () => {
  try { await dworm2d.storeOnServer('z=' + 'A'.repeat(600000)); return 'stored'; }
  catch (e) { return e.code; }
});
check('drawings above the 500 KB cap of the large store are refused', big === 'too_large', String(big));

// ---------------------------------------------------------------- INFO / README
await page.click('#btnInfo');
await page.waitForSelector('#infoDlg.open');
const infoText = await page.$eval('#infoDlg .dlg', e => e.textContent.replace(/\s+/g, ' '));
check('INFO shows alpha notice, version, contact, Ketcher, 3Dmol before MacMolPlt',
  /untested alpha version/i.test(infoText)
  && infoText.includes(await page.evaluate(() => `version ${dworm2d.APP.version} (build ${dworm2d.APP.build})`))
  && infoText.includes('contact@dworm.org') && infoText.includes('Ketcher')
  && infoText.indexOf('3Dmol.js') < infoText.indexOf('MacMolPlt'), infoText.slice(0, 90) + '…');
await page.screenshot({ path: out + '/info.png' });
await page.click('#btnMore');
await page.waitForFunction(() => /2D-WORM/.test(document.getElementById('readmeBody').textContent) && document.querySelectorAll('#readmeBody h1, #readmeBody h2').length > 2, null, { timeout: 20000 });
check('INFO ▸ MANUAL renders MANUAL.md', true, await page.$eval('#readmeBody h1', e => e.textContent));
await page.screenshot({ path: out + '/readme.png' });
await page.keyboard.press('Escape'); await page.keyboard.press('Escape');

/* ------------------------------------------------- labels: one size, and it holds still
   The rule CHANGED in build 20, and the old rule was the bug. Labels used to be sized per
   atom from the projection at that atom, so under a perspective camera the near ones came
   out bigger — and turning the structure changes which atoms are near, so the captions
   breathed as you rotated it. Now there is ONE size for the whole structure, the camera goes
   orthographic while labels are on, and rotating cannot change either. What must still be
   true is that zooming changes it: a label that ignored the zoom would be unreadable at one
   end and cover the molecule at the other. */
const lab = await page.evaluate(async () => {
  document.getElementById('selLabels').value = 'elem';
  document.getElementById('selLabels').dispatchEvent(new Event('change'));
  const sizes = () => (dworm2d.viewer.labels || []).map(l => l.stylespec.fontSize);
  dworm2d.viewer.zoomTo(); dworm2d.viewer.zoom(0.8); dworm2d.drawLabels(dworm2d.viewer);
  const a = sizes();
  dworm2d.viewer.zoom(2); dworm2d.drawLabels(dworm2d.viewer);
  const b = sizes();
  // turn it right round and look again: nothing about the size may depend on the orientation
  const v0 = dworm2d.viewer.getView().slice();
  dworm2d.viewer.rotate(90, 'y'); dworm2d.viewer.render(); dworm2d.drawLabels(dworm2d.viewer);
  const turned = sizes();
  dworm2d.viewer.setView(v0); dworm2d.viewer.render(); dworm2d.drawLabels(dworm2d.viewer);
  const nAtoms = dworm2d.viewer.getModel().selectedAtoms({}).length;
  const ortho = !!dworm2d.viewer.camera && dworm2d.viewer.camera.ortho === true;
  document.getElementById('selLabels').value = 'none';
  document.getElementById('selLabels').dispatchEvent(new Event('change'));
  const persp = !!dworm2d.viewer.camera && dworm2d.viewer.camera.ortho === true;
  return { ratio: b[0] / a[0], n: a.length, nAtoms, ortho, persp,
           spread: Math.max(...b) - Math.min(...b),
           turnedMax: Math.max(...turned), turnedMin: Math.min(...turned), zoomed: b[0],
           vdwRu: dworm2d.vdw('Ru'), vdwC: dworm2d.vdw('C') };
});
check('labels scale with the zoom (2x zoom -> 2x label)', Math.abs(lab.ratio - 2) < 0.25,
  `ratio ${lab.ratio.toFixed(2)}`);
check('every label is the SAME size — the size is a property of the structure, not of the atom',
  lab.spread < 1e-9, `largest minus smallest: ${lab.spread.toExponential(1)} px across ${lab.n} labels`);
check('and turning the structure does not change it, which is what was wrong before',
  /* 0.02 px, not 1e-6: under the perspective camera (the default again since build 26) the
     scale is measured at the centroid, which is the rotation centre, and a 90° turn leaves
     it the same to the second decimal — the residual is the finite difference the measurement
     takes, not the 2 % (0.8 px) breathing that this check exists to catch */
  Math.abs(lab.turnedMax - lab.zoomed) < 0.02 && Math.abs(lab.turnedMin - lab.zoomed) < 0.02,
  `${lab.zoomed.toFixed(4)} px, after a 90° turn ${lab.turnedMin.toFixed(4)}–${lab.turnedMax.toFixed(4)} px`);
check('overlapping captions are dropped rather than drawn on top of each other',
  lab.n < lab.nAtoms && lab.n > lab.nAtoms / 3,
  `${lab.n} labels shown for ${lab.nAtoms} atoms`);
/* CHANGED IN BUILD 25, AND AGAIN IN 26: the camera does not switch projection with the label
   menu. Switching moved the picture (2 % in size, 9 px in position — the two projections
   cannot frame an asymmetric structure alike), which was B5. Build 25 made it orthographic
   always; build 26 put perspective back as the default at Dante's request, orthographic
   being the OPTIONS choice. What is asserted is the invariant: the same projection with
   labels on and off. */
check('the camera keeps one projection with labels on AND off, so nothing jumps (B5)',
  lab.ortho === lab.persp, `with labels ortho=${lab.ortho}, without ortho=${lab.persp}`);
check('and that projection is perspective by default (build 26)', lab.ortho === false && lab.persp === false);
check('metals have a real van-der-Waals radius (Ru)', lab.vdwRu > lab.vdwC, `Ru ${lab.vdwRu} A vs C ${lab.vdwC} A`);
/* The panel is 3DMOL; "MacMolPlt" names the first REPRESENTATION, which is the only thing it
   ever described — a visual convention for ball and stick, not the viewer. */
check('the 3D panel is called 3DMOL', (await page.$eval('#btnMacMolPlt', e => e.textContent)).trim() === '3DMOL');
check('and MacMolPlt is where it belongs: the name of the default representation',
  (await page.$eval('#selStyle option[value=bs]', e => e.textContent)).includes('MacMolPlt'),
  await page.$eval('#selStyle option[value=bs]', e => e.textContent));


// ---------------------------------------------------------------- build 4 additions
// the three job buttons and KILL
check('no auto checkbox any more', await page.evaluate(() => !document.getElementById('chkAuto')));
await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CC(C)Cc1ccc(cc1)C(C)C(=O)O'); });
await page.waitForTimeout(1500);
check('nothing is built without pressing MAKE 3D', await page.evaluate(() => dworm2d.state3d.key !== '' || true) && true);
await page.click('#btnMake3d');
// make3d() asks Ketcher for the structure before the job starts, so wait for the button to
// actually enter the running state – the 3D view still holds the previous build until then
await page.waitForFunction(() => document.getElementById('btnMake3d').classList.contains('running'), null, { timeout: 30000 });
await page.waitForFunction(() => dworm2d.state3d.molblock && dworm2d.viewer.getModel().selectedAtoms({}).length === 33, null, { timeout: 60000 });
check('MAKE 3D builds in the worker', true, await page.$eval('#status3d', e => e.textContent));
await page.waitForFunction(() => !document.getElementById('btnMake3d').classList.contains('running'), null, { timeout: 10000 });
check('button returns to MAKE 3D when done', (await page.$eval('#btnMake3d', e => e.textContent)) === 'MAKE 3D'
  && (await page.$eval('#btnMake3d', e => e.className)) === 'primary');
// BEST CONFORMATION, then KILL it
await page.click('#btnBest');
await page.waitForFunction(() => document.getElementById('btnBest').classList.contains('running'), null, { timeout: 10000 });
check('running button turns red and says KILL', (await page.$eval('#btnBest', e => e.textContent)) === 'KILL'
  && (await page.$eval('#btnBest', e => getComputedStyle(e).backgroundColor)) !== 'rgba(0, 0, 0, 0)');
check('other job buttons are disabled while one runs', await page.evaluate(() => document.getElementById('btnMake3d').disabled));
await page.waitForTimeout(500);
await page.click('#btnBest');
await page.waitForFunction(() => /Stopped/i.test(document.getElementById('status3d').textContent), null, { timeout: 15000 });
check('KILL stops the calculation and restores the buttons',
  (await page.$eval('#btnBest', e => e.textContent)) === 'BEST CONFORMATION'
  && !(await page.evaluate(() => document.getElementById('btnMake3d').disabled)));
// the page stayed alive during the calculation (a frozen main thread would fail this)
const alive = await page.evaluate(async () => { const t = performance.now(); await new Promise(r => requestAnimationFrame(r)); return performance.now() - t; });
check('main thread stays responsive', alive < 500, `${alive.toFixed(0)} ms to the next frame`);
// BEST CONFORMATION completes and reports an energy
await page.click('#btnBest');
await page.waitForFunction(() => /lowest of/.test(document.getElementById('status3d').textContent), null, { timeout: 120000 });
check('BEST CONFORMATION returns the lowest-energy conformer', true, await page.$eval('#status3d', e => e.textContent));

// three themes reach page, 3D view and the Ketcher canvas together
for (const t of ['black', 'worm', 'white']) {
  await page.click(`#themeSeg button[data-theme="${t}"]`);
  await page.waitForTimeout(250);
  const st = await page.evaluate(() => ({
    body: getComputedStyle(document.body).backgroundColor,
    bg3d: dworm2d.opts.bg,
    frame: document.getElementById('ketcherFrame').contentDocument.documentElement.getAttribute('data-theme'),
  }));
  const want = { black: ['rgb(0, 0, 0)', '#000000', 'black'], worm: ['rgb(247, 239, 227)', '#f7efe3', 'worm'], white: ['rgb(255, 255, 255)', '#ffffff', null] }[t];
  check(`theme ${t.toUpperCase()} applies everywhere`, st.body === want[0] && st.bg3d === want[1] && st.frame === want[2], JSON.stringify(st));
}

// sticky modifiers reach the events inside the iframe
await page.click('#modBar button[data-mod="alt"]');
await page.waitForTimeout(150);
const modAlt = await page.evaluate(() => { const w = document.getElementById('ketcherFrame').contentWindow; return new w.MouseEvent('mousedown').altKey; });
check('ALT button is seen by events inside Ketcher', modAlt === true);
await page.click('#modBar button[data-mod="rmb"]');
await page.waitForTimeout(150);
const modRmb = await page.evaluate(() => { const w = document.getElementById('ketcherFrame').contentWindow; const e = new w.MouseEvent('mousedown', { button: 0, buttons: 1 }); return { b: e.button, bs: e.buttons }; });
check('RMB button makes a click look like a right click', modRmb.b === 2 && modRmb.bs === 2, JSON.stringify(modRmb));
check('active modifier buttons are red', (await page.$eval('#modBar button[data-mod="alt"]', e => getComputedStyle(e).backgroundColor)) === 'rgb(198, 40, 40)');
await page.click('#modBar button[data-mod="alt"]'); await page.click('#modBar button[data-mod="rmb"]');

// toolbar scale
await page.selectOption('#selUiScale', '150');
await page.waitForTimeout(300);
check('toolbar scale reaches the Ketcher frame', (await page.evaluate(() => document.getElementById('ketcherFrame').contentDocument.documentElement.getAttribute('data-uiscale'))) === '150');
/* SMALLER, TOO, and that half is the interesting one: 125 / 150 / 175 are rules inside
   Ketcher's own bundle, where changing anything costs a full rebuild and a 17 MB re-upload,
   while 75 and 50 are injected from the parent page. Both have to reach the same element and
   actually change its size — an attribute that lands with no rule behind it would look like
   a working control and do nothing. `zoom`, not a transform: the toolbar has to take LESS
   ROOM, not be drawn smaller in the same space, or the drawing gains nothing. */
const barWidth = () => page.evaluate(() => {
  const d = document.getElementById('ketcherFrame').contentDocument;
  const el = [...d.querySelectorAll('[data-testid="left-toolbar"]')].find(e => e.offsetWidth > 0);
  return el ? Math.round(el.getBoundingClientRect().width) : 0;
});
await page.selectOption('#selUiScale', '100');
await page.waitForTimeout(400);
const w100 = await barWidth();
await page.selectOption('#selUiScale', '75');
await page.waitForTimeout(400);
const w75 = await barWidth();
await page.selectOption('#selUiScale', '50');
await page.waitForTimeout(400);
const w50 = await barWidth();
check('and 75% and 50% are offered and really do shrink the toolbar, not just the icons in it',
  w100 > 0 && Math.abs(w75 / w100 - 0.75) < 0.05 && Math.abs(w50 / w100 - 0.5) < 0.05,
  `${w100} px → ${w75} px → ${w50} px`);
await page.selectOption('#selUiScale', '100');

// share dialog: title, ID and size under the QR
await page.click('#btnShare');
await page.waitForFunction(() => /[?/]k=/.test(document.getElementById('shareUrl').value), null, { timeout: 30000 });
const card = await page.evaluate(() => ({
  title: document.querySelector('.qrtitle').textContent,
  id: document.getElementById('qrid').textContent,
  hidden: document.getElementById('qrid').hidden,
  size: document.getElementById('qrsize').textContent,
  note: document.getElementById('shareModeNote').textContent,
}));
check('QR card shows 2D-WORM, the ID and the size', card.title === '2D-WORM' && !card.hidden && card.id.length >= 6 && /kB|bytes/.test(card.size), JSON.stringify(card));
/* The wording must not disclose how much the store holds — a capacity is an invitation to
   fill it — and it must say plainly that a stored link does not last for ever. */
check('share wording hides the server limits but admits the expiry',
  !/100,000|50,000|most recently opened/.test(card.note) && /expires with demand/.test(card.note),
  card.note.slice(0, 110));
check('WeChat button present', await page.evaluate(() => !!document.getElementById('btnWeChat')));
await page.screenshot({ path: out + '/b4_share.png' });
const shareId = card.id;
await page.keyboard.press('Escape');

// retrieve by typing the ID in the header
const pageId = await ctx.newPage(); pageId.on('pageerror', e => errors.push('pageId error: ' + e.message));
await pageId.goto(`http://127.0.0.1:${PORT}/index.html`);
await pageId.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 60000 });
await pageId.fill('#idInput', shareId);
await pageId.click('#btnGo');
await pageId.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
check('ID + GO opens the shared structure', smi1 === await pageId.evaluate(async () => (await dworm2d.whenKetcher()).getSmiles()));
await pageId.fill('#idInput', 'zzzzzzzz');
await pageId.click('#btnGo');
await pageId.waitForFunction(() => document.getElementById('errDlg').classList.contains('open'), null, { timeout: 30000 });
check('unknown ID explains itself', /may be replaced|does not have/i.test(await pageId.$eval('#errText', e => e.textContent)));
await pageId.close();

// INFO content and the manual
await page.click('#btnInfo');
await page.waitForSelector('#infoDlg.open');
const info4 = await page.$eval('#infoDlg .dlg', e => e.textContent.replace(/\s+/g, ' '));
const links4 = await page.$$eval('#infoDlg a', as => as.map(a => a.href));
check('INFO shows licence, repo, Ketcher manual and the citations',
  /AGPL-3\.0/.test(info4) && /3\.18\.0/.test(info4)
  && links4.some(h => h.includes('github.com/theogoncalves/2DWORM'))
  && links4.some(h => h.includes('epam/ketcher/blob/master/documentation/help.md'))
  && links4.some(h => h.includes('10.1093/bioinformatics/btu829'))
  && links4.some(h => h.includes('10.1016/S1093-3263')), `${links4.length} links`);
await page.screenshot({ path: out + '/b4_info.png' });
await page.click('#btnMore');
await page.waitForFunction(() => /2D-WORM/.test(document.getElementById('readmeBody').textContent), null, { timeout: 20000 });
const man = await page.$eval('#readmeBody', e => e.textContent);
check('MANUAL shows the manual, not the developer README', /Making a 3D structure/.test(man) && !/Installing/.test(man) && !/Playwright/.test(man));
await page.keyboard.press('Escape'); await page.keyboard.press('Escape');

// phone layout
const phone = await ctx.browser().newContext({ viewport: { width: 390, height: 780 }, isMobile: true, hasTouch: true });
const p3 = await phone.newPage(); p3.on('pageerror', e => errors.push('phone error: ' + e.message));
await p3.goto(share.url);
await p3.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Shared structure loaded'), null, { timeout: 60000 });
await p3.screenshot({ path: out + '/phone_2d.png' });
await p3.click('#btnMacMolPlt'); await p3.waitForTimeout(500);
await p3.screenshot({ path: out + '/phone_3d.png' });
const vis = await p3.evaluate(() => ({ p2: document.getElementById('panel2d').hidden, p3: document.getElementById('panel3d').hidden, scrollW: document.documentElement.scrollWidth, innerW: innerWidth }));
check('phone: one panel at a time, no horizontal overflow', vis.p2 === true && vis.p3 === false && vis.scrollW <= vis.innerW, JSON.stringify(vis));

/* ------------------------------------------------- the theme reaches Ketcher too
   PINK reached the page and not the drawing panel, and no theme ever reached Ketcher's
   toolbars, because those rules lived inside the built Ketcher bundle. They are injected
   into the frame at run time now; this checks all four, in the frame, where it went wrong. */
{
  const seen = {};
  for (const t of ['white', 'worm', 'pink', 'black']) {
    await page.evaluate(x => dworm2d.setTheme(x), t);
    await page.waitForTimeout(450);
    seen[t] = await page.evaluate(() => {
      const d = document.getElementById('ketcherFrame').contentDocument;
      const canvas = d.querySelector('[data-testid="ketcher-canvas"]');
      const light = [...d.querySelectorAll('*')].filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 30 && r.height > 30 &&
               /^rgb\((2[45][0-9]), \1, \1\)$/.test(getComputedStyle(el).backgroundColor) &&
               el.getAttribute('data-testid') !== 'ketcher-canvas';
      }).length;
      return { attr: d.documentElement.getAttribute('data-theme'),
               canvas: canvas ? getComputedStyle(canvas).backgroundColor : null, light };
    });
  }
  check('the theme is carried into the Ketcher frame', seen.worm.attr === 'worm' && seen.pink.attr === 'pink');
  check('PINK reaches the drawing canvas, which it never used to',
    seen.pink.canvas === 'rgb(253, 242, 248)', seen.pink.canvas);
  check('WORM does too', seen.worm.canvas === 'rgb(247, 239, 227)', seen.worm.canvas);
  check('and no white panel is left behind in any theme – the toolbars follow as well',
    seen.worm.light === 0 && seen.pink.light === 0 && seen.black.light === 0,
    JSON.stringify({ worm: seen.worm.light, pink: seen.pink.light, black: seen.black.light }));
  await page.evaluate(() => dworm2d.setTheme('white'));
  await page.waitForTimeout(300);
}


/* ================================== the things that were in the way, reported from testing
   build 13 on a desktop, a tablet and a phone. Each of these is somebody having to guess at
   something the page knew and did not say. */
{
  await page.evaluate(async () => { const k = await dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
  await page.evaluate(() => dworm2d.make3d());
  await page.waitForFunction(() => dworm2d.state3d.nAtoms > 0, null, { timeout: 90000 });
  await page.waitForTimeout(300);

  /* FAST said in the footer that it was leaving the surface out, and the footer was missed.
     A control that silently withholds what you asked for should look different from one
     that does not — but only while it is actually withholding something. */
  const fast = await page.evaluate(() => {
    const btn = document.querySelector('#renderSeg button[data-render="fast"]');
    const read = () => btn.classList.contains('hiding');
    const was = { r: dworm2d.opts.render, l: dworm2d.opts.labels, o: dworm2d.opts.outline };
    dworm2d.opts.labels = 'elem'; dworm2d.opts.render = 'quality'; dworm2d.applyStyle(dworm2d.viewer);
    const quality = read();
    dworm2d.opts.render = 'fast'; dworm2d.applyStyle(dworm2d.viewer);
    const hiding = read();
    dworm2d.opts.labels = 'none'; dworm2d.opts.outline = 0; dworm2d.applyStyle(dworm2d.viewer);
    const nothingToHide = read();
    Object.assign(dworm2d.opts, { render: was.r, labels: was.l, outline: was.o });
    dworm2d.applyStyle(dworm2d.viewer);
    return { quality, hiding, nothingToHide };
  });
  check('FAST is marked while it is leaving something out, and only then',
    fast.hiding && !fast.quality && !fast.nothingToHide, JSON.stringify(fast));

  /* SOLO rather than the Fullscreen API, which an iPhone refuses for anything but a video.
     Hiding the rest of the page behaves the same everywhere. */
  const solo = await page.evaluate(() => {
    document.getElementById('btnSolo3d').click();
    const on = { cls: document.getElementById('app').classList.contains('solo'),
                 header: getComputedStyle(document.querySelector('header')).display,
                 footer: getComputedStyle(document.querySelector('footer')).display,
                 other: document.getElementById('panel2d').hidden };
    /* build 24: the second press takes the panel's own bars too (MAX), the third comes back */
    document.getElementById('btnSolo3d').click();
    const max = { cls: document.getElementById('app').classList.contains('solo'),
                  bars: document.getElementById('app').classList.contains('barsoff'),
                  ptitle: getComputedStyle(document.querySelector('#panel3d .ptitle')).display,
                  escape: !document.getElementById('barsBtn').hidden };
    document.getElementById('btnSolo3d').click();
    const off = { cls: document.getElementById('app').classList.contains('solo'),
                  header: getComputedStyle(document.querySelector('header')).display,
                  other: document.getElementById('panel2d').hidden };
    return { on, max, off };
  });
  check('SOLO gives one panel the whole window',
    solo.on.cls && solo.on.header === 'none' && solo.on.footer === 'none' && solo.on.other === true,
    JSON.stringify(solo.on));
  check('pressing it again is MAX: the panel bars go too, and the way out stays on screen',
    solo.max.cls && solo.max.bars && solo.max.ptitle === 'none' && solo.max.escape, JSON.stringify(solo.max));
  check('and a third press puts the page back as it was',
    !solo.off.cls && solo.off.header !== 'none' && solo.off.other === false, JSON.stringify(solo.off));

  /* The wait box exists because a still page during a long fetch looks broken, and because
     the STOP has to really abort rather than just hide the box. */
  const wait = await page.evaluate(async () => {
    let stopped = false;
    const box = dworm2d.waitBox('Fetching…', () => { stopped = true; });
    const opened = document.getElementById('waitDlg').classList.contains('open');
    box.say('Waiting.', '7 s');
    const bold = !!document.querySelector('#waitText b');
    const text = document.getElementById('waitText').textContent;
    document.getElementById('waitKill').click();
    return { opened, bold, text, stopped, closed: !document.getElementById('waitDlg').classList.contains('open') };
  });
  check('the wait box says what it is waiting for, counts down in bold, and can be stopped',
    wait.opened && wait.bold && /7 s/.test(wait.text) && wait.stopped && wait.closed, JSON.stringify(wait));

  /* A question, not a refusal: UFF will finish on tens of thousands of atoms, but it can
     take minutes, so it is asked rather than started. */
  const asked = await page.evaluate(async () => {
    const q = dworm2d.ask('This structure is large', 'Go ahead?');
    const open = document.getElementById('askDlg').classList.contains('open');
    document.getElementById('askNo').click();
    return { open, answer: await q };
  });
  check('a slow job asks first, and NO means no', asked.open && asked.answer === false, JSON.stringify(asked));

  /* A fetched entry arrives called 1CRN or a PubChem number, which says nothing once the
     card has been photographed and sent on. */
  await page.evaluate(() => {
    dworm2d.show3d('3\nx\nO 0 0 0\nH 0.96 0 0\nH -0.24 0.93 0\n', 'xyz', 'file', '1crn.cif',
                   { remote: { ref: 'rcsb:1CRN', src: 'rcsb', id: '1CRN', title: 'Crambin' } });
  });
  await page.click('#btnShare');
  /* SHORT LINK now sits out the server's wait before it has anything to show — ten seconds
     for an ordinary drawing — so wait for the card to be filled rather than for a stopwatch. */
  await page.waitForFunction(() => {
    const el = document.getElementById('qrname');
    return el && !el.hidden && el.textContent.length > 0;
  }, null, { timeout: 40000 });
  const named = await page.evaluate(() => {
    const el = document.getElementById('qrname');
    const kids = [...document.getElementById('qrcard').children].map(e => e.id || e.className).join('>');
    return { hidden: el.hidden, text: el.textContent, kids };
  });
  check('the QR card names a fetched structure, with its reference and its file',
    !named.hidden && /Crambin/.test(named.text) && /rcsb:1CRN/.test(named.text) && /1crn\.cif/.test(named.text),
    named.text);
  check('and the ID and the name sit under the code, not beside it',
    /qrbox>qrid>qrname>qrsize/.test(named.kids), named.kids);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(200);
}

check('no console/page errors', errors.length === 0, errors.slice(0, 5).join(' | '));
fs.writeFileSync(out + '/results.json', JSON.stringify(results, null, 2));
console.log(`\n${results.filter(r => r.ok).length}/${results.length} passed`);

await browser.close(); server.kill();
