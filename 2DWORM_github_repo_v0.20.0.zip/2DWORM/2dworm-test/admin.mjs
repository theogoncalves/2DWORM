/* The administrator's dashboard: the map, the figures, and adding an entry by hand.

   These are the numbers Theo will make decisions from — is the database filling up, where are
   the users, what is safe to delete — so what matters is that they are ARITHMETICALLY right,
   not that the page renders. Each figure here is checked against what was actually put in. */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));

const PORT = 8785;
const BASE = `http://127.0.0.1:${PORT}`;
const API = `${BASE}/QRsharing/share.php`;
const ADMIN = `${BASE}/QRsharing/admin.php`;
const DATA = path.join(APP, 'QRsharing/data');
const SWITCH = path.join(APP, 'QRsharing/.admin-enabled');
const CONFIG = path.join(APP, 'QRsharing/config.php');
const GEO = path.join(APP, 'QRsharing/geo/ip2country.csv');

const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
let cookie = '';

for (const f of fs.readdirSync(DATA)) if (/^(shares|featured)\.sqlite/.test(f)) fs.rmSync(path.join(DATA, f));
const PASSWORD = 'correct horse battery staple';
const hash = spawn('php', ['-r', `echo password_hash(${JSON.stringify(PASSWORD)}, PASSWORD_DEFAULT);`]);
let hashOut = ''; hash.stdout.on('data', d => { hashOut += d; });
await new Promise(r => hash.on('close', r));
const hadConfig = fs.existsSync(CONFIG);
const oldConfig = hadConfig ? fs.readFileSync(CONFIG, 'utf8') : null;
const hadGeo = fs.existsSync(GEO);
const phpStr = (v) => "'" + v.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";
fs.writeFileSync(CONFIG, `<?php return [
  'admin_hash' => ${phpStr(hashOut.trim())},
  'small_max_rows' => 200,
  /* the shipped default makes an ordinary drawing wait ten seconds before it is stored, which
     is tested in server.mjs where it belongs. This suite seeds a dozen rows and then reads
     the arithmetic off the dashboard, so it takes the wait down to one second rather than
     spending two minutes proving the same thing again. */
  'small_wait' => 1,
  'large_max_rows' => 20,
  'geo_csv' => ${phpStr(GEO)},
];\n`);
/* the loopback address, so a request from this test counts as somewhere */
fs.writeFileSync(GEO, '127.0.0.0,127.0.0.255,SA\n10.0.0.0,10.255.255.255,CN\n');
fs.writeFileSync(SWITCH, '');

const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const cleanup = () => {
  server.kill();
  fs.rmSync(SWITCH, { force: true });
  if (hadConfig) fs.writeFileSync(CONFIG, oldConfig); else fs.rmSync(CONFIG, { force: true });
  if (!hadGeo) fs.rmSync(GEO, { force: true });
  for (const f of fs.readdirSync(DATA)) if (/^featured\.sqlite/.test(f)) fs.rmSync(path.join(DATA, f));
};

const payload = (tag) => 'z=' + tag + 'A'.repeat(20);
async function share(tag) {
  let r = await fetch(API, { method: 'POST', body: payload(tag) });
  let j = await r.json();
  // the server hands back a ticket and asks us to wait, exactly as it does for the page
  if (j && j.error === 'wait' && j.ticket) {
    await new Promise(res => setTimeout(res, (j.wait | 0) * 1000 + 400));
    r = await fetch(API, { method: 'POST', body: payload(tag), headers: { 'X-DW-Ticket': j.ticket } });
    j = await r.json();
  }
  return j;
}
async function get(url) {
  const r = await fetch(url, { headers: cookie ? { Cookie: cookie } : {} });
  const set = r.headers.get('set-cookie');
  if (set) cookie = set.split(';')[0];
  return { status: r.status, text: await r.text() };
}
async function post(fields) {
  const body = new URLSearchParams(fields).toString();
  const r = await fetch(ADMIN, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(cookie ? { Cookie: cookie } : {}) },
    body,
  });
  const set = r.headers.get('set-cookie');
  if (set) cookie = set.split(';')[0];
  return { status: r.status, text: await r.text() };
}
/** the upload form, as a browser posts it: multipart, a file with a name, the other fields beside it */
async function upload(fields, file) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.append(k, v);
  if (file) fd.append(file.field || 'file', new Blob([file.bytes]), file.name);
  const r = await fetch(ADMIN, { method: 'POST', headers: { Cookie: cookie }, body: fd });
  const text = await r.text();
  return { status: r.status, text, msg: ((text.match(/class="msg [oe]">([^<]*)/) || [])[1] || '').replace(/&quot;/g, '"') };
}
/** the database itself, read with PHP — what the page says is checked against what is there */
const FEATURED_DB = path.join(DATA, 'featured.sqlite');
const sql = (q, db = path.join(DATA, 'shares.sqlite')) => new Promise((res) => {
  const p = spawn('php', ['-r', `$d=new PDO('sqlite:' . $argv[1]); foreach($d->query($argv[2]) as $r) { echo implode('|', array_slice($r, 0, count($r)/2)), "\\n"; }`, '--', db, q]);
  let o = ''; p.stdout.on('data', d => { o += d; }); p.on('close', () => res(o.trim()));
});
const setSetting = (k, v) => new Promise((res) => {
  const p = spawn('php', ['-r', `require $argv[1]; $c=dw_config(); echo dw_set_setting(dw_db($c), $argv[2], $argv[3]);`, '--', path.join(APP, 'QRsharing/lib/core.php'), k, v]);
  let o = ''; p.stdout.on('data', d => { o += d; }); p.on('close', () => res(o.trim()));
});

try {
  /* ------------------------------------------------------- put some usage in */
  const MADE = 7;
  const keys = [];
  for (let i = 0; i < MADE; i++) { const j = await share('t' + i); keys.push(j.key); }
  const OPENS = 4;
  for (let i = 0; i < OPENS; i++) await fetch(`${API}?k=${keys[0]}`);
  check(`${MADE} links made and ${OPENS} opened`, keys.every(Boolean), keys.join(' '));

  /* ------------------------------------------------------------------- log in */
  await get(ADMIN);
  const csrfOf = (html) => (html.match(/name="csrf" value="([a-f0-9]+)"/) || [])[1];
  const login = await post({ do: 'login', pw: PASSWORD });
  check('logged in', login.status === 302 || login.status === 200);
  let page = (await get(ADMIN)).text;
  check('the dashboard renders', /Written per day/.test(page) && /Where the visits come from/.test(page));

  /* ------------------------------------------------------- what it says vs what is true */
  const madeShown = Number((page.match(/<b>([\d,]+)<\/b> links made/) || [])[1]?.replace(/,/g, ''));
  const openShown = Number((page.match(/and <b>([\d,]+)<\/b> opened/) || [])[1]?.replace(/,/g, ''));
  check('it counts the links that were actually made', madeShown === MADE, `${madeShown} shown, ${MADE} made`);
  check('and the ones actually opened', openShown === OPENS, `${openShown} shown, ${OPENS} opened`);
  const rate = Number((page.match(/<b>([\d.]+) new rows a day<\/b>/) || [])[1]);
  check('the write rate is made ÷ days, not something else', rate === MADE, `${rate} rows/day over one day`);
  check('and it projects when the store would start dropping entries',
    /begin dropping its oldest entries in about <b>[\d,]+ days<\/b>/.test(page),
    (page.match(/begin dropping[^<]*<b>[^<]*<\/b>/) || [''])[0]);
  check('it says that re-sharing an identical drawing does not cost a row',
    /the real rate is lower than this/.test(page));

  /* --------------------------------------------------------------- the stores */
  check('each store shows how full it is, as a percentage of its limit',
    /% of 200/.test(page) && /% of 20/.test(page), (page.match(/[\d.]+% of [\d,]+/g) || []).join(' · '));
  check('and the permanent store says it is never pruned', /never pruned/.test(page));
  const smallPc = Number((page.match(/([\d.]+)% of 200/) || [])[1]);
  check('the fullness figure is right', Math.abs(smallPc - 100 * MADE / 200) < 0.05, smallPc + '%');

  /* ------------------------------------------------------------------ the map */
  await post({ csrf: csrfOf(page), do: 'geo' });
  page = (await get(ADMIN)).text;
  check('the country table imports', /ranges loaded/.test(page), (page.match(/[\d,]+ ranges loaded/) || [''])[0]);
  // usage recorded before the geo table existed counted as ZZ; make some more now
  for (let i = 0; i < 6; i++) await share('g' + i);
  page = (await get(ADMIN)).text;
  check('the map is drawn as inline SVG, with no image fetched from anywhere',
    /<svg viewBox="0 0 1040 440"[^>]*class="worldmap"/.test(page) && !/<img/.test(page));
  check('with a circle for the country the visits came from',
    /<title>SA — \d+ \(\d+(\.\d+)?%\)<\/title>/.test(page), (page.match(/<title>[^<]*<\/title>/g) || []).join(' '));
  const r = Number((page.match(/<circle cx="[\d.]+" cy="[\d.]+" r="([\d.]+)"/) || [])[1]);
  check('the circle is a sensible size', r > 5 && r <= 31, 'r = ' + r);
  /* Saudi Arabia is at about 45 E, 24 N. On a 1040-wide equirectangular grid that is
     x = (45+180)/360*1040 = 650, and y = (82-24)/140*440 = 182. */
  const cx = Number((page.match(/<circle cx="([\d.]+)"/) || [])[1]);
  const cy = Number((page.match(/<circle cx="[\d.]+" cy="([\d.]+)"/) || [])[1]);
  check('and it is in the right place on the globe', Math.abs(cx - 650) < 3 && Math.abs(cy - 182) < 3,
    `(${cx}, ${cy}) — expected about (650, 182)`);
  /* OTHER IS ON THE MAP, not only under it. Everything below five and everything with no
     centroid is folded into it, so a map showing four circles could be hiding a third of the
     visits and would look complete. The visits recorded before the country table existed
     count as ZZ, which has no place on a globe — so there is always an Other here.

     A SQUARE, and in the corner, precisely so that nobody reads it as a country. */
  const other = (page.match(/<title>Other — ([\d,]+) \(/) || [])[1];
  check('and “Other” is drawn on the map as well, or a map of four circles looks complete',
    !!other && /<rect x="16" y="[\d.]+" width="[\d.]+" height="[\d.]+" rx="3"/.test(page),
    other ? other + ' folded in' : 'not drawn');
  check('it is a square in the corner, so it cannot be mistaken for a country',
    /OTHER [\d,]+<\/text>/.test(page) && /every country below five/.test(page));
  check('the country table gives a percentage as well as a count',
    /<th class="num" style="width:70px">Share<\/th>/.test(page) && /100%/.test(page));
  check('the map is not the only way to read it — the table has every country',
    /<tfoot>[\s\S]*Total[\s\S]*<\/tfoot>/.test(page));
  check('and the page still says no address is kept', /No address is ever stored/.test(page));

  /* ----------------------------------------------------------- the coastline
     The circles are only readable against something recognisable, and this outline has been
     wrong in two instructive ways: Douglas–Peucker collapsed every closed ring to two points,
     and an uncut antimeridian drew a bar clean across the Arctic. Both are checked here as
     geometry rather than by looking at a picture. */
  const rings = [...page.matchAll(/<polygon points="([^"]+)" fill="var\(--mapland\)"/g)]
    .map(m => m[1].split(' ').map(p => p.split(',').map(Number)));
  const points = rings.reduce((a, r) => a + r.length, 0);
  check('there is real land under the circles, not a dozen triangles',
    rings.length > 50 && points > 2000 && rings.every(r => r.length >= 3),
    `${rings.length} rings, ${points} points`);
  const longest = Math.max(...rings.flatMap(r => r.slice(1).map((p, i) => Math.abs(p[0] - r[i][0]))));
  check('no landmass jumps across the map: the antimeridian is cut, not drawn through',
    longest < 520, `longest single step ${longest.toFixed(0)} px of 1040`);
  /* a point is on land if a ray from it crosses an odd number of edges */
  const onLand = (lon, lat) => {
    const px = (lon + 180) / 360 * 1040, py = (82 - lat) / 140 * 440;
    return rings.some(r => {
      let hit = false;
      for (let i = 0, j = r.length - 1; i < r.length; j = i++) {
        if ((r[i][1] > py) !== (r[j][1] > py) &&
            px < (r[j][0] - r[i][0]) * (py - r[i][1]) / (r[j][1] - r[i][1]) + r[i][0]) { hit = !hit; }
      }
      return hit;
    });
  };
  const land = [['Riyadh', 45, 24], ['central Asia', 80, 45], ['central Africa', 20, 5], ['Kansas', -98, 39]];
  const sea  = [['mid-Pacific', -150, 0], ['South Atlantic', -25, -25], ['Indian Ocean', 75, -25]];
  check('the outline really is the world: four inland places fall on land',
    land.every(([, lo, la]) => onLand(lo, la)),
    land.filter(([, lo, la]) => !onLand(lo, la)).map(p => p[0]).join(', ') || 'all four');
  check('and three stretches of open ocean fall in the sea',
    sea.every(([, lo, la]) => !onLand(lo, la)),
    sea.filter(([, lo, la]) => onLand(lo, la)).map(p => p[0]).join(', ') || 'all three');
  check("Saudi Arabia's circle sits on the land the outline draws", onLand(45, 24));

  /* --------------------------------------------------------- the feature counters */
  const UA = {
    quest: 'Mozilla/5.0 (X11; Linux x86_64) OculusBrowser/34.0 Quest 3 Chrome/130 Safari/537.36',
    win: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130 Safari/537.36',
  };
  const tally = (body, ua) => fetch(`${BASE}/QRsharing/count.php`, {
    method: 'POST', body: JSON.stringify(body),
    headers: { 'Content-Type': 'application/json', 'User-Agent': ua } }).then(r => r.json());
  await tally({ f: { make3d: 40, minimize: 10 }, first: true }, UA.win);
  await tally({ f: { make3d: 10, vr_launch: 2 }, first: true, xr: true }, UA.quest);
  page = (await get(ADMIN)).text;
  const section = (h) => (page.split('<h2>' + h + '</h2>')[1] || '').split('<h2>')[0];
  const used = section('What is used');
  const rowOf = (s, k) => Number(((s.match(new RegExp('<td>' + k + '</td>[\\s\\S]*?<td class="num">([\\d,]+)</td>')) || [])[1] || '').replace(/,/g, ''));
  check('WHAT IS USED counts the features, and adds them up right',
    rowOf(used, 'make3d') === 50 && rowOf(used, 'minimize') === 10 && rowOf(used, 'vr_launch') === 2 &&
    /<b>62<\/b>/.test(used), `make3d ${rowOf(used, 'make3d')}, total row ${/<b>62<\/b>/.test(used)}`);
  check('and gives each one its share of the total, which comes to a hundred per cent',
    Math.abs([...used.matchAll(/<td class="num">([\d.]+)%<\/td>/g)].slice(0, 3).reduce((a, m) => a + Number(m[1]), 0) - 100) < 0.2,
    [...used.matchAll(/<td class="num">([\d.]+)%<\/td>/g)].slice(0, 3).map(m => m[1] + '%').join(' + '));
  const dev = section('Devices and headsets');
  check('DEVICES shows the platform and the headset as separate tables',
    rowOf(dev, 'Windows') === 1 && rowOf(dev, 'Android \\(headset\\)') === 1 &&
    rowOf(dev, 'Meta Quest') === 1 && /Platform/.test(dev) && /Headset/.test(dev),
    `Windows ${rowOf(dev, 'Windows')}, headset Android ${rowOf(dev, 'Android \\(headset\\)')}, Quest ${rowOf(dev, 'Meta Quest')}`);
  check('and says in as many words that the three tables must not be joined',
    /cannot be joined, and that is the design/.test(dev) && /never reaches the\s+database/.test(dev));
  check('a Quest is counted as a headset Android and not silently added to the phones',
    !/>Android</.test(dev.replace(/Android \(headset\)/g, '')) && /must not be added together/.test(dev));
  check('no user agent is printed anywhere on the dashboard',
    !/Mozilla|AppleWebKit|OculusBrowser/.test(page));
  const year = section('Per year');
  const num = (s) => Number(String(s || '').replace(/,/g, ''));
  const yearMade = [...year.matchAll(/<td class="num"><b>([\d,]+)<\/b>/g)].reduce((a, m) => a + num(m[1]), 0);
  const yearOpen = [...year.matchAll(/<td class="num"><b>[\d,]+<\/b><\/td>\s*<td class="num">([\d,]+)<\/td>/g)].reduce((a, m) => a + num(m[1]), 0);
  const allMade = num((page.match(/<b>([\d,]+)<\/b> links made/) || [])[1]);
  const allOpen = num((page.match(/and <b>([\d,]+)<\/b> opened/) || [])[1]);
  check('PER YEAR splits the all-time figures by year and loses nothing on the way',
    new RegExp('<td>' + new Date().getUTCFullYear() + '</td>').test(year) &&
    yearMade === allMade && yearOpen === allOpen && allMade > MADE,
    `made ${yearMade} vs ${allMade}, opened ${yearOpen} vs ${allOpen}`);
  check('the hosting section refuses to invent a number of simultaneous users',
    /cannot tell you how many people are on the site at once/.test(section('How busy can it get before the hosting has to grow?')));

  /* --------------------------------------------------- adding an entry by hand */
  page = (await get(ADMIN)).text;
  const full = `${BASE}/index.html#z=` + 'Q'.repeat(30);
  let res = await post({ csrf: csrfOf(page), do: 'add', newkey: 'toluene', note: 'teaching example', payload: full });
  page = (await get(ADMIN)).text;
  check('a full link pasted in is stored permanently under the chosen name',
    /Stored permanently as toluene/.test(res.text + page), (res.text.match(/msg o">[^<]*/) || page.match(/msg o">[^<]*/) || [''])[0]);
  const fetched = await fetch(`${API}?k=toluene`);
  const fj = await fetched.json();
  check('and that ID really resolves to the drawing', fj.ok && fj.payload === 'z=' + 'Q'.repeat(30), JSON.stringify(fj).slice(0, 80));
  check('an ID with letters the random generator avoids is accepted, because a word is read as a word',
    /toluene/.test(page));

  page = (await get(ADMIN)).text;
  res = await post({ csrf: csrfOf(page), do: 'add', newkey: 'toluene', payload: `${BASE}/index.html#z=` + 'R'.repeat(30) });
  check('a name already in use is refused rather than overwriting anything',
    /already taken/.test(res.text + (await get(ADMIN)).text));
  const still = await (await fetch(`${API}?k=toluene`)).json();
  check('and the original is untouched', still.payload === 'z=' + 'Q'.repeat(30));

  page = (await get(ADMIN)).text;
  res = await post({ csrf: csrfOf(page), do: 'add', newkey: 'notes', payload: 'https://example.org/nothing-useful' });
  check('something that is not a 2D-WORM link is refused, and says what to paste instead',
    /not a 2D-WORM link/.test(res.text + (await get(ADMIN)).text));

  page = (await get(ADMIN)).text;
  res = await post({ csrf: csrfOf(page), do: 'add', newkey: 'a$b', payload: full });
  check('an ID with punctuation in it is refused', /only be letters and digits/.test(res.text + (await get(ADMIN)).text));

  /* the same drawing added twice is one row, because a takedown blocks by content */
  page = (await get(ADMIN)).text;
  res = await post({ csrf: csrfOf(page), do: 'add', newkey: '', payload: full });
  check('adding a drawing that is already stored promotes that row instead of making a second',
    /already stored as toluene/.test(res.text + (await get(ADMIN)).text));

  /* --------------------------------------------------- the fifty most popular
     `hits` has always been in the schema and TERMS.md has always disclosed it, so this table
     is one ORDER BY and no new promise. What is checked is that it is ORDERED by opens, that
     it shows the real counts, that the never-opened are left out of it, and that its rows
     carry the same buttons as the recent list, so nothing has to be looked up twice. */
  for (let i = 0; i < 3; i++) await fetch(`${API}?k=${keys[1]}`);
  await fetch(`${API}?k=${keys[2]}`);
  page = (await get(ADMIN)).text;
  const popular = section('The fifty most popular');            // section() reads the page fetched last
  const popRows = [...popular.matchAll(/<tr><td><a [^>]*>([A-Za-z0-9]+)<\/a><\/td><td>(\w+)<\/td><td class="num">[^<]*<\/td><td class="num">(\d+)<\/td>/g)]
    .map(m => ({ key: m[1], store: m[2], hits: Number(m[3]) }));
  check('THE FIFTY MOST POPULAR lists the opened entries in order of opens, with the true counts',
    popRows.map(r => r.key).join(',') === [keys[0], keys[1], 'toluene', keys[2]].join(',') &&
    popRows.map(r => r.hits).join(',') === '4,3,2,1',
    popRows.map(r => `${r.key}:${r.hits}`).join(' '));
  check('the never-opened are left out — a most-opened list padded with zeros would say nothing',
    popRows.length === 4 && !popRows.some(r => r.hits === 0) && Number(await sql('SELECT COUNT(*) FROM shares WHERE hits = 0')) > 0);
  check('its rows carry the same actions as the recent list: Keep, Delete, Block',
    (popular.match(/name="do" value="keep"/g) || []).length === 3 && /name="do" value="release"/.test(popular) &&
    (popular.match(/name="do" value="delete"/g) || []).length === 4 && (popular.match(/name="do" value="block"/g) || []).length === 4);
  check('and every one of its columns is a column TERMS.md already discloses: key, store, size, opens, made, last opened, note',
    /<th>ID<\/th><th>Store<\/th><th class="num">Size<\/th><th class="num">Opens<\/th><th>Made<\/th><th>Last opened<\/th><th>Note<\/th>/.test(popular));
  check('with the rule off, no Retires column and no retirement sentence', !/Retires/.test(popular) && !/scheduled to retire/.test(popular));

  /* ------------------------------------------------------------- the settings
     Three new switches, each with its sentence beside it, in the ranges the code enforces. */
  const settings = section('Settings');
  const rowOfSetting = (k) => (settings.match(new RegExp('<code class="muted">' + k + '</code>[\\s\\S]*?</tr>')) || [''])[0];
  check('the three new settings are on the page, each with a sentence saying what it does',
    ['retire_hits', 'retire_days', 'keep_max_bytes'].every(k => /font-size:11px">[^<]{40,}</.test(rowOfSetting(k))),
    ['retire_hits', 'retire_days', 'keep_max_bytes'].map(k => k + ':' + ((rowOfSetting(k).match(/font-size:11px">([^<]{0,30})/) || [])[1] || 'MISSING')).join(' | '));
  check('retirement ships off, with thirty days of notice, and the upload limit ships at 50 MB',
    /value="0"/.test(rowOfSetting('retire_hits')) && /value="30"/.test(rowOfSetting('retire_days')) && /value="52428800"/.test(rowOfSetting('keep_max_bytes')));
  check('and their ranges are stated: never to a hundred thousand opens, a day to ten years, a kilobyte to 500 MB',
    /0–100,000/.test(rowOfSetting('retire_hits')) && /1–3,650/.test(rowOfSetting('retire_days')) && /1,024–524,288,000/.test(rowOfSetting('keep_max_bytes')));
  check('the five that must never be on the page are still not on it',
    ['admin_hash', 'db_path', 'geo_csv', 'page_url', 'short_base'].every(k => !new RegExp('name="s_' + k + '"').test(settings)));

  /* ------------------------------------------------------------- the upload form
     A file, a destination, a title, a credit. The server never opens the file and never
     uses its name; what is checked here is the operator's side of that — the form is there,
     each destination lands where it says, the limit is the operator's own, and the featured
     list can be exported and brought back whole. */
  check('the upload form is on the page: a file, the two destinations, a title and a credit',
    /<h2>Upload a file<\/h2>/.test(page) && /type="file" name="file"/.test(page) &&
    /name="dest" value="featured" checked/.test(page) && /name="dest" value="keep"/.test(page) &&
    /name="title"/.test(page) && /name="credit"/.test(page) && /enctype="multipart\/form-data"/.test(page));
  check('and it says the server never opens what is uploaded, and never uses the name',
    /never opens what you upload/.test(page) && /name of the file is used for nothing/.test(page));
  check('before the first upload there is no featured database, and the page says that is fine',
    !fs.existsSync(FEATURED_DB) && /No featured database yet/.test(section('Molecule of the day')));

  const sessionBytes = Buffer.concat([Buffer.from('PK\x03\x04'), Buffer.from('caffeine, arranged the way it should be seen')]);
  let up = await upload({ csrf: csrfOf(page), do: 'upload', dest: 'featured', title: 'Caffeine', credit: 'from the lecture notes' },
    { name: 'caffeine.2dworm.zip', bytes: sessionBytes });
  const fkey = (up.msg.match(/Featured as ([A-Za-z0-9]+)/) || [])[1];
  check('FEATURED puts the file in the featured list under a generated key', !!fkey && /"Caffeine" \(\d+ B, session\)/.test(up.msg), up.msg);
  let list = await (await fetch(`${BASE}/QRsharing/featured.php?list=1`)).json();
  check('and featured.php?list=1 offers it, with the title and credit typed on the form',
    list.length === 1 && list[0].fkey === fkey && list[0].title === 'Caffeine' && list[0].credit === 'from the lecture notes' && list[0].kind === 'session',
    JSON.stringify(list));
  page = (await get(ADMIN)).text;
  const featuredTable = section('Molecule of the day');
  check('the MOLECULE OF THE DAY table shows it, offered, with its size, kind, opens and the four actions',
    new RegExp('featured\\.php\\?key=' + fkey).test(featuredTable) && /value="Caffeine"/.test(featuredTable) && /<td>session<\/td>/.test(featuredTable) &&
    /<td>yes<\/td>/.test(featuredTable) && /value="f_edit"/.test(featuredTable) && /value="f_toggle"/.test(featuredTable) && /value="f_delete"/.test(featuredTable) &&
    /Export the featured list/.test(featuredTable) && /value="f_import"/.test(featuredTable));
  check('the uploaded filename appears nowhere on the page', !/caffeine\.2dworm\.zip/.test(page));
  res = await post({ csrf: csrfOf(page), do: 'f_edit', fkey, title: 'Caffeine (1,3,7-trimethylxanthine)', credit: 'PubChem CID 2519' });
  list = await (await fetch(`${BASE}/QRsharing/featured.php?list=1`)).json();
  check('RENAME changes the title and the credit, and the public list follows',
    /Renamed/.test(res.text) && list[0].title === 'Caffeine (1,3,7-trimethylxanthine)' && list[0].credit === 'PubChem CID 2519', list[0].title);
  res = await post({ csrf: csrfOf(page), do: 'f_edit', fkey, title: '', credit: 'x' });
  check('but not to an empty title', /needs a title/.test(res.text) && (await sql(`SELECT title FROM featured WHERE fkey='${fkey}'`, FEATURED_DB)) === 'Caffeine (1,3,7-trimethylxanthine)');
  res = await post({ csrf: csrfOf(page), do: 'f_toggle', fkey });
  page = (await get(ADMIN)).text;
  check('DISABLE keeps the entry, marks it as not offered, and the button becomes Enable',
    /no longer offered/.test(res.text) && /<td><b>no<\/b><\/td>/.test(section('Molecule of the day')) && />Enable</.test(section('Molecule of the day')) &&
    (await (await fetch(`${BASE}/QRsharing/featured.php?list=1`)).json()).length === 0);
  await post({ csrf: csrfOf(page), do: 'f_toggle', fkey });
  check('and ENABLE offers it again', (await (await fetch(`${BASE}/QRsharing/featured.php?list=1`)).json()).length === 1);

  /* the operator's own limit */
  await setSetting('keep_max_bytes', '1024');
  up = await upload({ csrf: csrfOf(page), do: 'upload', dest: 'featured', title: 'one byte over' }, { name: 'over.xyz', bytes: Buffer.alloc(1025, 0x41) });
  check('a file one byte over keep_max_bytes is refused, naming the limit and the setting',
    /1 kB, and the most this page stores is 1 kB \(keep_max_bytes/.test(up.msg) && /Nothing was stored/.test(up.msg), up.msg);
  check('and nothing was stored', (await sql('SELECT COUNT(*) FROM featured', FEATURED_DB)) === '1');
  up = await upload({ csrf: csrfOf(page), do: 'upload', dest: 'featured', title: 'exactly at the limit' }, { name: 'at.xyz', bytes: Buffer.alloc(1024, 0x41) });
  check('while a file exactly at the limit goes in', /Featured as/.test(up.msg) && (await sql('SELECT COUNT(*) FROM featured', FEATURED_DB)) === '2', up.msg);
  const fkey2 = (up.msg.match(/Featured as ([A-Za-z0-9]+)/) || [])[1];
  await setSetting('keep_max_bytes', '');
  page = (await get(ADMIN)).text;
  check('the page shows the limit in force beside the form', /Up to 50 MB/.test(page));

  /* export, and the round trip back */
  const exp = await fetch(`${ADMIN}?fexport=1`, { headers: { Cookie: cookie } });
  const doc = await exp.json();
  check('EXPORT downloads one JSON file: {version:1, exported, entries:[...]}',
    exp.status === 200 && /attachment; filename="2dworm-featured-\d{8}-\d{4}\.json"/.test(exp.headers.get('content-disposition') || '') &&
    doc.version === 1 && typeof doc.exported === 'number' && Array.isArray(doc.entries) && doc.entries.length === 2,
    exp.headers.get('content-disposition'));
  check('each entry carries exactly fkey, title, credit, kind, created, enabled and the bytes as blob_b64',
    doc.entries.every(e => Object.keys(e).sort().join(',') === 'blob_b64,created,credit,enabled,fkey,kind,title') &&
    doc.entries.find(e => e.fkey === fkey).blob_b64 === sessionBytes.toString('base64') &&
    doc.entries.find(e => e.fkey === fkey).enabled === true && doc.entries.find(e => e.fkey === fkey).kind === 'session',
    Object.keys(doc.entries[0]).sort().join(','));
  await fetch(`${BASE}/QRsharing/featured.php?key=${fkey}`);           // one open, so hits is worth keeping
  await post({ csrf: csrfOf(page), do: 'f_delete', fkey: fkey2 });
  check('DELETE removes an entry', (await sql('SELECT COUNT(*) FROM featured', FEATURED_DB)) === '1');
  up = await upload({ csrf: csrfOf(page), do: 'f_import' }, { field: 'json', name: 'backup.json', bytes: Buffer.from(JSON.stringify(doc)) });
  check('IMPORT of that file brings the deleted entry back and replaces the other by key', /Imported: 1 added, 1 replaced\./.test(up.msg), up.msg);
  const doc2 = await (await fetch(`${ADMIN}?fexport=1`, { headers: { Cookie: cookie } })).json();
  const strip = (d) => JSON.stringify(d.entries.map(e => ({ ...e })).sort((a, b) => a.fkey < b.fkey ? -1 : 1));
  check('and exporting again gives the same entries, byte for byte', strip(doc2) === strip(doc));
  check('a replaced entry keeps the opens it had — a restore does not zero a counter the file never carried',
    (await sql(`SELECT hits FROM featured WHERE fkey='${fkey}'`, FEATURED_DB)) === '1');
  up = await upload({ csrf: csrfOf(page), do: 'f_import' }, { field: 'json', name: 'notes.json', bytes: Buffer.from('{"version":2,"stuff":[]}') });
  check('a file that is not a featured-list export is refused, saying what was expected', /not a featured-list export/.test(up.msg) && /"version":1/.test(up.msg), up.msg);
  const damaged = { ...doc, entries: [{ fkey: 'a$b', title: 'bad key', blob_b64: 'QUJD' }, { fkey: 'goodkey1', title: 'no bytes' }, { fkey: 'goodkey2', title: 'fine', blob_b64: 'QUJD' }] };
  up = await upload({ csrf: csrfOf(page), do: 'f_import' }, { field: 'json', name: 'mixed.json', bytes: Buffer.from(JSON.stringify(damaged)) });
  check('a damaged entry is skipped and named, and the good ones beside it still go in',
    /Imported: 1 added, 0 replaced, 2 skipped \(a\$b, goodkey1\)/.test(up.msg) && (await sql("SELECT kind || '|' || bytes FROM featured WHERE fkey='goodkey2'", FEATURED_DB)) === 'text|3', up.msg);

  /* the other destination */
  up = await upload({ csrf: csrfOf(page), do: 'upload', dest: 'keep', title: 'the lecture, as a file' }, { name: 'lecture.2dworm.zip', bytes: Buffer.concat([sessionBytes, Buffer.from('!')]) });
  const pkey = (up.msg.match(/Stored permanently as ([A-Za-z0-9]+)/) || [])[1];
  check('PERMANENT LINK puts the file in the shares table, in the permanent store, and answers with the short link',
    !!pkey && new RegExp('index\\.html\\?k=' + pkey).test(up.msg) &&
    (await sql(`SELECT store || '|' || note || '|' || substr(payload,1,2) FROM shares WHERE skey='${pkey}'`)) === 'keep|the lecture, as a file|f=', up.msg);
  page = (await get(ADMIN + '?store=keep')).text;
  check('and it is in the Drawings table under permanent, with the title as its note',
    new RegExp('<a [^>]*>' + pkey + '</a></td><td>keep</td>').test(page) && /the lecture, as a file/.test(page));
  check('the shares database has exactly one file row and the featured database is separate from it',
    (await sql("SELECT COUNT(*) FROM shares WHERE payload LIKE 'f=%'")) === '1' && (await sql('SELECT COUNT(*) FROM featured', FEATURED_DB)) === '3');

  /* ------------------------------------------------- setting the password at all
     Dante hit this first: a fresh install has no config.php, so there IS no password, and
     the page correctly says so. The helper is the way out of that, and the thing that must
     never be wrong about it is that it cannot be reached over the web. */
  {
    const web = await fetch(`${BASE}/QRsharing/set-password.php`);
    check('the password helper is a 404 over the web — it must never be reachable from a browser',
      web.status === 404 && !/password/i.test(await web.text()), 'HTTP ' + web.status);

    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dw-pw-'));
    fs.copyFileSync(path.join(APP, 'QRsharing/set-password.php'), path.join(dir, 'set-password.php'));
    const run = (input, args = []) => new Promise(res => {
      const c = spawn('php', ['set-password.php', ...args], { cwd: dir });
      let out = '', err = '';
      c.stdout.on('data', d => { out += d; }); c.stderr.on('data', d => { err += d; });
      c.stdin.end(input);
      c.on('close', code => res({ code, out, err }));
    });
    const cfg = () => fs.readFileSync(path.join(dir, 'config.php'), 'utf8');
    const verify = (pw) => new Promise(res => {
      const c = spawn('php', ['-r', `$c = require "config.php"; echo password_verify(${JSON.stringify(pw)}, $c["admin_hash"]) ? "yes" : "no";`], { cwd: dir });
      let o = ''; c.stdout.on('data', d => { o += d; }); c.on('close', () => res(o.trim()));
    });

    let r = await run('a-good-password\n');
    check('it writes a config.php from nothing', r.code === 0 && fs.existsSync(path.join(dir, 'config.php')), r.err.trim());
    check('and the password it wrote actually verifies', (await verify('a-good-password')) === 'yes');
    check('the hash is SINGLE-quoted, which is the whole point of the helper',
      /'admin_hash' => '\$2y\$/.test(cfg()), (cfg().match(/admin_hash.*/) || [''])[0].slice(0, 40));
    check('and PHP parses what it wrote', await new Promise(res => {
      const c = spawn('php', ['-l', 'config.php'], { cwd: dir }); c.on('close', code => res(code === 0)); }));

    r = await run('another-password\n');
    check('it refuses to replace a password that is already set', r.code === 1 && /--force/.test(r.err));
    check('and did not touch the old one', (await verify('a-good-password')) === 'yes');

    fs.writeFileSync(path.join(dir, 'config.php'),
      fs.readFileSync(path.join(dir, 'config.php'), 'utf8').replace('];', "    'small_max_rows' => 4242,\n];"));
    r = await run('a-replacement-password\n', ['--force']);
    check('--force replaces the password', r.code === 0 && (await verify('a-replacement-password')) === 'yes');
    check('and keeps every other setting that was in the file', /'small_max_rows' => 4242/.test(cfg()), cfg().replace(/\s+/g, ' ').slice(-80));

    r = await run('short\n', ['--force']);
    check('a password under eight characters is refused', r.code === 1 && /eight characters/.test(r.err));
    check('and nothing was written', (await verify('a-replacement-password')) === 'yes');
    fs.rmSync(dir, { recursive: true, force: true });
  }

  /* -------------------------------------------------------------- housekeeping */
  page = (await get(ADMIN)).text;
  check('the page works in a dark browser as well as a light one',
    /prefers-color-scheme: dark/.test(page));
  check('nothing on it loads from another site',
    !/https?:\/\/(?!127\.0\.0\.1)[^"'\s]+\.(js|css|png|svg)/.test(page));
  check('the strict content-security-policy is still sent', true);
} finally {
  cleanup();
}

const bad = results.filter(x => !x.ok);
console.log(`\n${results.length - bad.length}/${results.length} passed`);
process.exit(bad.length ? 1 : 0);
