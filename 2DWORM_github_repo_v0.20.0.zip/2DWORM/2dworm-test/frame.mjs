/* SPACE — framing what you picked.
 *
 * Every viewer can zoom to a selection. What is worth testing here is the part that is not
 * obvious: a single atom is not a view. Framing one atom fills the window with one sphere and
 * you have lost the molecule; framing two gives a bond and no idea where it is. So a small
 * pick is GROWN — everything within 4 A of one or two atoms, within 2 A of up to eight — and
 * you land on what you picked with enough around it to know where you are. That rule, the
 * margin round the edge, and centring the bounding box rather than the centroid are the three
 * things that separate this from viewer.zoomTo().
 */
import { chromium } from '../ketcher-build/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const APP = fileURLToPath(new URL('../2dworm/', import.meta.url));
const PORT = 8807;
const server = spawn('php', ['-S', '127.0.0.1:' + PORT, '-t', APP],
  { stdio: 'ignore', env: { ...process.env, PHP_CLI_SERVER_WORKERS: '4' } });
await new Promise(r => setTimeout(r, 900));
const results = [];
const check = (n, ok, info = '') => { results.push({ n, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (info ? ' — ' + info : '')); };
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`);
await page.waitForFunction(() => document.getElementById('msg').textContent.startsWith('Ready'), null, { timeout: 90000 });
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CC(C)Cc1ccc(cc1)C(C)C(=O)O'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 33, null, { timeout: 120000 });
await page.waitForTimeout(400);

const panel = await page.$eval('#viewer3d', el => { const r = el.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; });
/* Where a set of atoms lands on screen, measured the way a person sees it. */
const extentOf = (idx) => page.evaluate((ix) => {
  const e = window.dworm2d.screenExtentOf(ix);
  return e ? { w: +e.w.toFixed(1), h: +e.h.toFixed(1), cx: +e.cx.toFixed(1), cy: +e.cy.toFixed(1) } : null;
}, idx);
const allIdx = await page.evaluate(() => window.dworm2d.viewer.getModel().selectedAtoms({}).map((a, i) => i));
const space = async () => { await page.keyboard.press('Space'); await page.waitForTimeout(350); };
const enter = async () => { await page.keyboard.press('Enter'); await page.waitForTimeout(350); };

/* TWO KEYS. Enter is the whole structure, whatever is picked; Space is what you picked, up
   close. Together they are a way of going in and coming back out without the mouse, and the
   pair only works if Enter IGNORES the selection — otherwise there is no way back out. */

/* ------------------------------------------------------- nothing picked: the structure */
await page.evaluate(() => { window.dworm2d.viewer.zoom(0.25); window.dworm2d.viewer.render(); });
await page.waitForTimeout(200);
const tiny = await extentOf(allIdx);
await space();
const framed = await extentOf(allIdx);
check('SPACE with nothing picked frames the whole structure',
  framed.w > tiny.w * 2, `${tiny.w.toFixed(0)} px wide -> ${framed.w.toFixed(0)} px`);
check('and it fills the panel without touching the edges',
  framed.w < panel.w && framed.h < panel.h &&
  (framed.w > panel.w * 0.5 || framed.h > panel.h * 0.5),
  `${framed.w.toFixed(0)}x${framed.h.toFixed(0)} in a ${panel.w.toFixed(0)}x${panel.h.toFixed(0)} panel`);
check('and the structure is centred in the panel, not merely nearby',
  Math.abs(framed.cx - (panel.x + panel.w / 2)) < 4 && Math.abs(framed.cy - (panel.y + panel.h / 2)) < 4,
  `centre off by ${(framed.cx - (panel.x + panel.w / 2)).toFixed(1)}, ${(framed.cy - (panel.y + panel.h / 2)).toFixed(1)} px`);

/* --------------------------------------------------- one atom is not a view */
await page.evaluate(() => { window.dworm2d.state3d.sel.splice(0, 99, 0); window.dworm2d.applyStyle(window.dworm2d.viewer); });
const one = await page.evaluate(() => window.dworm2d.frameTarget());
check('one picked atom is grown to everything within 4 A of it, or you would be looking at a sphere',
  one.picked === 1 && one.idx.length > 3 && one.idx.includes(0),
  `1 picked, ${one.idx.length} framed`);
await space();
const afterOne = await extentOf([0]);
check('and the atom you picked is in the middle of the window',
  Math.abs(afterOne.cx - (panel.x + panel.w / 2)) < panel.w * 0.25 &&
  Math.abs(afterOne.cy - (panel.y + panel.h / 2)) < panel.h * 0.25,
  `the picked atom is ${Math.abs(afterOne.cx - (panel.x + panel.w / 2)).toFixed(0)} px from the centre`);
check('the footer says what it framed and that it grew the pick',
  /Framed 1 picked atom/.test(await page.textContent('#status3d')) &&
  /a point rather than a view/.test(await page.textContent('#status3d')),
  (await page.textContent('#status3d')).slice(0, 110));

/* ------------------------------------------------- a handful gets less context */
await page.evaluate(() => { window.dworm2d.state3d.sel.splice(0, 99, 0, 1, 2, 3); window.dworm2d.applyStyle(window.dworm2d.viewer); });
const few = await page.evaluate(() => window.dworm2d.frameTarget());
check('four picked atoms are grown by only 2 A — they already say where they are',
  few.picked === 4 && few.idx.length > 4 && few.idx.length < one.idx.length + 8,
  `4 picked, ${few.idx.length} framed`);

/* ------------------------------------------- many picked: no growing at all */
await page.evaluate(() => { const s = window.dworm2d.state3d.sel; s.splice(0, 99);
  for (let i = 0; i < 12; i++) s.push(i); window.dworm2d.applyStyle(window.dworm2d.viewer); });
const many = await page.evaluate(() => window.dworm2d.frameTarget());
check('a dozen picked atoms are framed as they are, with nothing added',
  many.picked === 12 && many.idx.length === 12, `${many.idx.length} framed`);
await space();
const m = await extentOf(many.idx);
check('and THEY fill the panel, not the molecule they belong to',
  m.w < panel.w && m.h < panel.h && (m.w > panel.w * 0.4 || m.h > panel.h * 0.4),
  `${m.w.toFixed(0)}x${m.h.toFixed(0)} of ${panel.w.toFixed(0)}x${panel.h.toFixed(0)}`);

/* ------------------------------------- a space while typing is a space */
await page.evaluate(() => { window.dworm2d.clearSelection(); });
await page.click('#btnNotes').catch(() => {});
await page.waitForTimeout(300);
const noteThere = await page.$('#noteText');
if (noteThere) {
  await page.evaluate(() => { const t = document.getElementById('noteText'); t.hidden = false; t.focus(); t.value = ''; });
  const before = await page.evaluate(() => window.dworm2d.viewer.getView().map(n => +n.toFixed(4)).join(','));
  await page.keyboard.type('a b');
  await page.waitForTimeout(300);
  check('a space typed into the note is a space, and does not move the camera',
    (await page.evaluate(() => document.getElementById('noteText').value)) === 'a b' &&
    (await page.evaluate(() => window.dworm2d.viewer.getView().map(n => +n.toFixed(4)).join(','))) === before,
    JSON.stringify(await page.evaluate(() => document.getElementById('noteText').value)));
  await page.evaluate(() => document.getElementById('noteText').blur());
} else {
  check('a space typed into the note is a space, and does not move the camera', true, 'no note panel in this build');
}
/* the ID box is the other place a space could be swallowed */
await page.evaluate(() => document.getElementById('idInput').focus());
const viewWas = await page.evaluate(() => window.dworm2d.viewer.getView().map(n => +n.toFixed(4)).join(','));
await page.keyboard.press('Space');
await page.waitForTimeout(250);
check('and so does a space in the ID box',
  (await page.evaluate(() => window.dworm2d.viewer.getView().map(n => +n.toFixed(4)).join(','))) === viewWas);
await page.evaluate(() => document.getElementById('idInput').blur());

/* --------------------------------------------------------- ENTER comes back out */
await page.evaluate(() => { window.dworm2d.state3d.sel.splice(0, 99, 0); window.dworm2d.applyStyle(window.dworm2d.viewer); });
await space();
const close = await extentOf(allIdx);
await enter();
const wide = await extentOf(allIdx);
check('ENTER frames the whole structure even with atoms picked, so there is a way back out',
  wide.w < close.w * 0.75 && wide.w > panel.w * 0.4,
  `the structure spanned ${close.w.toFixed(0)} px close up, ${wide.w.toFixed(0)} px after ENTER`);
check('and it says so, rather than naming the selection it ignored',
  /Framed the whole structure/.test(await page.textContent('#status3d')),
  (await page.textContent('#status3d')).slice(0, 70));
check('the selection is untouched by either key — framing is a camera move, not an edit',
  JSON.stringify(await page.evaluate(() => window.dworm2d.state3d.sel)) === '[0]');
/* Enter is submit in a form and press on a button; neither may become a camera move */
await page.evaluate(() => document.getElementById('idInput').focus());
const beforeEnter = await page.evaluate(() => window.dworm2d.viewer.getView().map(n => +n.toFixed(4)).join(','));
await page.keyboard.press('Enter');
await page.waitForTimeout(250);
check('ENTER in the ID box is still submit, not a camera move',
  (await page.evaluate(() => window.dworm2d.viewer.getView().map(n => +n.toFixed(4)).join(','))) === beforeEnter);
await page.evaluate(() => document.getElementById('idInput').blur());
await page.evaluate(() => window.dworm2d.clearSelection());

/* ---------------------------------------------------- the button that keeps focus
   A button holds focus after it is clicked, and the browser's meaning for space on a focused
   button is "press it again" — so after clicking MAKE 3D with the mouse, space pressed MAKE
   3D, which by then says KILL. `:focus-visible` looks like the discriminator and is not:
   Chromium sets it as soon as any key is pressed, so it is already true by the time the
   handler runs. What is unambiguous is how the focus GOT there. */
await page.evaluate(async () => { const k = await window.dworm2d.whenKetcher(); await k.setMolecule('CCO'); });
await page.click('#btnMake3d');
await page.waitForFunction(() => window.dworm2d.state3d.nAtoms === 9, null, { timeout: 120000 });
await page.waitForTimeout(400);
check('MAKE 3D still has the focus after being clicked, which is what makes this a trap',
  await page.evaluate(() => document.activeElement.id) === 'btnMake3d');
await space();
check('SPACE right after clicking a button frames, and does NOT press that button again',
  /Framed/.test(await page.textContent('#status3d')) &&
  !/Stopped/.test(await page.textContent('#msg')),
  (await page.textContent('#status3d')).slice(0, 60));
/* And the other way round, asserted on the mechanism rather than on a downstream effect: the
   page remembers whether the focus was put where it is by TAB or by a pointer, and space only
   yields to a button in the first case. */
const flag = () => page.evaluate(() => window.dworm2d.focusFromKeyboard);
await page.click('#btnFit');
await page.waitForTimeout(150);
check('a click says the focus came from a pointer, so space is the shortcut', (await flag()) === false);
await page.keyboard.press('Tab');
await page.waitForTimeout(150);
check('and TAB says it came from the keyboard, so space is still "press this button"',
  (await flag()) === true, 'focus now on ' + await page.evaluate(() => document.activeElement.tagName));
await page.mouse.click(5, 5);
await page.waitForTimeout(150);
check('and a pointer anywhere puts it back', (await flag()) === false);
await page.evaluate(() => { if (document.activeElement.blur) document.activeElement.blur(); });

check('no page errors', errors.filter(e => !/favicon|ResizeObserver/i.test(e)).length === 0,
  errors.slice(0, 3).join(' | '));
await browser.close(); server.kill();
const failed = results.filter(x => !x.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
