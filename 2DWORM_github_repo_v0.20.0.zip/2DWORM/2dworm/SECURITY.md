# Security policy

2D-WORM is a small project maintained by one person. Reports are read and taken seriously.

## Reporting a vulnerability

**Please do not open a public issue for a security problem.**

Write to **contact@dworm.org** with:

- what the problem is and what an attacker could do with it,
- the steps to reproduce it (a URL, a file, or a short script),
- the version, from the INFO window,
- and how you would like to be credited, if at all.

You will get an acknowledgement as quickly as I can manage. Please allow a reasonable time
for a fix before disclosing publicly — I will keep you informed of progress and tell you
when a fix is released.

## Scope

In scope: this repository, and the sharing service under `QRsharing/`.

Out of scope: the third-party components bundled in `lib/` and `ketcher/` — report those to
their own projects (Ketcher and Indigo to EPAM, 3Dmol.js, OpenChemLib, lz-string,
qrcode-generator). Reports about the hosting provider's infrastructure are also out of scope.

## Things worth knowing before you test

- Everything in the page runs in the visitor's browser. No account, no cookies, no tracking.
- The only server component is `QRsharing/share.php`, which stores compressed drawings and
  returns them by a random key.
- Please test against your own installation rather than a public one, and do not run
  automated scanners against a live site you do not own.
