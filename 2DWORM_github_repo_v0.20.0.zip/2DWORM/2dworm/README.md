# 2D-WORM

**Draw a molecule, get a 3D structure, share exactly what you see.** One web page, nothing
to install, no account — for people who do not have a licence for the commercial
alternatives.

Part of the **Desert Worm (D-WORM)** family: *Workflow Wrapper for Orbitals, Receptors, and
Materials* — [dworm.org](https://dworm.org)

> **This is an untested alpha version.** Please report anything that misbehaves to
> contact@dworm.org.

---

## What it does

- **Draws** structures with [Ketcher](https://github.com/epam/ketcher) (EPAM), including
  **ChemDraw `.cdx` and `.cdxml` in and out** — plus molfiles, KET, SMILES, PNG and SVG.
- **Builds 3D structures** in the browser with hydrogens, respecting stereochemistry, and
  minimises them with **MMFF94s+** or **UFF**; a conformer search keeps the lowest-energy
  geometry, and **MINIMIZE SELECTED** relaxes just the atoms you picked while holding the rest
  where they are. UFF is implemented here from the 1992 paper, so transition-metal complexes and
  structures of any size can be relaxed — a protein is minimised in place, keeping its
  residue names, chains and `CONECT` records.
- **Views them** in a MacMolPlt-inspired ball and stick, or as tubes, wireframe, space
  filling, a **cartoon** with or without its ligands, or ball and stick inside a **solvent-
  accessible surface**; four ready-made looks under *More looks*; **black and white** for
  every one of them, for print. Exports **publication images** up to 4× the panel size.
- **Lets you move things by hand** under **EXPERT**, with three tools that are three
  *constraints* rather than three ways of moving atoms: **DRAG ATOM** (the atom follows the
  pointer, bonds stretch; ALT keeps the bond length and moves it on the sphere around its
  neighbour), **ANGLE PANNING** (the atom swings about its pivot carrying everything attached,
  bond frozen, only the 3D angle changes; ALT frees the length) and **DRAG MOLECULES** (the
  whole fragment follows; ALT turns it). Picking an atom first names the pivot. A ring cannot
  be swung open, so a ring atom moves with its exocyclic groups and the ring stays put. Plus
  make, change or remove a bond, and an undo. A drag goes where the pointer goes at any zoom
  and from any angle, and dragging the background still rotates the structure. A fourth bond
  button draws a **dashed line**, which is display only:
  it travels in a shared link because it is part of the picture, and it is never exported,
  never minimised and never counted as connectivity. The drawing in Ketcher is not touched —
  there is deliberately no way back from 3D to a 2D layout somebody made by hand.
- **Exports coordinates** as `.xyz`, `.pdb` and 3D `.mol` — ready for Gaussian, ORCA, xTB,
  GAMESS or MOPAC — and, for periodic work, as `.cif`, VASP `POSCAR`, GROMACS `.gro`, a
  Gaussian `.gjf` and an xtb/Turbomole `coord`, **each of which writes the cell**. They all
  take the same atoms and the same three lattice vectors, so converting between any two is
  reading one and writing another: open a POSCAR, save a CIF, open that, and the same crystal
  comes back.
- **Keeps the cell, and draws it.** A file that describes a repeating cell used to give up only
  a phrase saying so. The three vectors are now read from a VASP `OUTCAR` or POSCAR, CP2K,
  Gaussian `TV` lines, a `.cif`, a `.gro` box, a PDB `CRYST1` line, an XSF `PRIMVEC` or a
  Turbomole `$lattice`; the **box is drawn** with a, b and c marked at the origin; and it
  travels in a shared link, so a QR code reproduces the crystal rather than a cluster in
  vacuum.
- **Reads the charges out of a finished job** and shows them as atom captions — **CM5,
  Hirshfeld, NPA, Löwdin, ESP, CHELPG, APT, Mulliken** from Gaussian, ORCA, xTB, MOPAC and
  formatted checkpoints, each under the name its own program used. Nothing is averaged and
  nothing is renamed: two methods disagreeing by half an electron is a fact about them, so you
  choose which you are looking at. Red is electron-poor, blue electron-rich, and the sum is
  printed — the quickest way to notice the wrong table was read.
- **Opens a finished calculation**: the last geometry out of **ORCA**, **Gaussian**, **CP2K**,
  **MOPAC**, **xTB**, **VASP**, **GAMESS-US**, **NWChem**, **CASTEP**, **Q-Chem**, **Molpro**,
  **Psi4**, **Turbomole**, **Quantum ESPRESSO**, **ABINIT**, **ADF/AMS** and **Jaguar** outputs
  and inputs, plus GROMACS `.gro`, VASP `POSCAR`/`CONTCAR`, and `.cube` / `.fchk` / `.wfn` —
  read from the head, so a hundred-megabyte grid costs a few megabytes to open. **RESULTS**
  opens a window on a Gaussian, ORCA, xTB or MOPAC output: the energy against the step, any
  step in a small viewer with its convergence tests, every vibrational mode animated with an
  IR stick spectrum, and USE THIS GEOMETRY to take a step into the page. Molecular-dynamics
  sets — **AMBER**, **NAMD**, **CHARMM**, **LAMMPS** — open from their coordinate file and
  topology dropped together. Periodic structures are displayed and exported but **not
  minimised**: neither force field implements periodic boundary conditions, so the program
  refuses rather than returning a tidy, confident, meaningless answer; **MIN pPERIODIC**
  relaxes a cell against its frozen images and prints its energy in brackets, as the
  approximation it is.
- **Relaxes a piece of something too large to relax whole.** **pMODEL** cuts the picked region
  free, caps every cut bond with hydrogen at the ONIOM link-atom distance, relaxes the region
  with UFF while the cut atoms and caps are held, and puts the coordinates back under their
  original numbers. **pPBC** guesses an orthogonal box from the van-der-Waals envelope so a
  molecule can be relaxed against its own images with MIN pPERIODIC. Every p-method prints its
  energy in brackets: a deliberate approximation, and it says so. **PAUSED!** stops any of them
  at the intermediate they depend on — the frozen shell, the capped model — draws it, and waits
  for CONTINUE or STOP.
- **Builds molecules by hand**: **+H** adds a hydrogen where there is most room (and says when
  there was none), **REPLACE** turns a hydrogen — or a whole group: a methyl, an OH, a
  *tert*-butyl, a phenyl — into a substituent from a library of 38 groups or your own (a plain
  XYZ file, the same one the full D-WORM reads), **DEL** removes an atom and caps the wound —
  each one undo, the attachment atom keeping its number, and on a protein the residues,
  chains and atom names kept.
- **Shows what an edit cost**: the **ENERGY** slider scrubs the structure between where it was
  before the last edit and after it — a drag, a slider, a minimisation, a p-method — with the
  UFF energy of the geometry under the slider.
- **Builds a crystal** from a lattice system, cell parameters, one of the 230 space groups and
  the asymmetric unit in fractional coordinates, with a supercell; and **expands a CIF by its
  symmetry**, so urea's five listed atoms become the sixteen of its cell.
- **Selects atoms by rule**: a menu for the everyday cases and a small language for the rest —
  `Fe(<2.4A) _OR_ Fe`, `M(Cl)`, `SEL(+2)`, `CHAIN(A) _NOT_ HOH` — with a GROW slider that walks
  a pick out through the bonds. Marks in five colours, **kept** set by set with a legend that is
  drawn into the exported figure.
- **Saves a session**: one `.2dworm.zip` holding everything on the page — drawing, structure,
  view, marks, note, cell, charges, the original file, and a cube's surface **frozen** as the
  mesh that was on screen (a few hundred kilobytes where the cube was thirty megabytes; the
  cubes themselves on request). Drop it on any 2D-WORM and everything is as it was.
- **Finds a structure by name** in the **RCSB PDB**, **PDBe**, **PubChem**, the **COD** and
  **TCOD**, **Wikidata**, **CACTUS** or **Zenodo** — every one public domain or free without a
  credit line, listed as data in `lib/providers.json`; a CC-BY source (AlphaFold) is present
  but off, and its credit line travels with every structure when it is on. Nothing fetched is
  copied onto the server: a shared link carries the identifier, `rcsb:1CRN`, and the entry is
  fetched again when the link is opened.
- **Hands the structure to a headset.** **VR** opens **2DWORM-VR**, a separate page that draws
  the same structure with [Mol*](https://molstar.org) and enters an immersive WebXR session —
  the view arrives already matching, because what travels is the view itself (where the middle
  of it is, how much is visible in ångström, and the rotation) rather than one engine's camera
  copied into another's. One way, with a RETURN button that puts 2D-WORM back exactly as it was
  left. Mol* is 5 MB and is loaded only by the people who press the button.
  **In the session the controls are geometry, not HTML** — the Quest browser does not implement
  the module that would composite an HTML bar over an immersive view, so a menu built that way
  is simply not there. Instead a panel rides your left controller like a phone held in the
  palm, aimed at with the other one; atoms are picked with the trigger, and the distance, angle
  or dihedral appears on a card above it that is itself the button that clears it.
- **Keeps a note with the structure.** A third panel, under **NOTES**: a heading, bold, italic,
  monospace, bullets and three blocks whose colour comes from what the text *is* — a note, a
  warning, something settled — rather than from a picker, because a hand-picked colour is
  unreadable on at least one of the four themes. **INSERT SELECTION** drops the atoms you have
  picked and their measurement into the text as a chip, and clicking that chip picks them
  again — so "the bond I mean is this one" stops being a sentence you have to write. The note
  travels inside the shared link. A note is somebody else's text rendered in your browser, so
  it goes through its own deliberately small renderer: no raw HTML, no `[text](url)` (which
  lets a link say one thing and go somewhere else), no images, and a bare URL is shown with the
  host it would really go to and asks before it opens.
- **Shares the exact state**: a link and a QR code that restore the drawing, the 3D settings
  and the camera angle, so a colleague can open it, change it and send it back. A short ID
  under the QR code can be typed straight into the page. Every QR code carries a notice that it
  is not permanent and where to write for one that is; a retired code says so instead of dying.
  An empty page offers a **molecule of the day** from a list the operator keeps.
- **Speaks English, العربية, 中文, Português, Español, Polski, Deutsch, Italiano, हिन्दी and
  اردو.** Each language's button is written in its own script, so somebody who reads no English
  can still find their language — and somebody who lands in Chinese by accident can find their
  way out. Changing the language changes the words and nothing else: Arabic and Urdu read
  right-to-left inside every button and paragraph, but no panel or control moves, because the
  page is an instrument and the drawing area must not shift under your hand. A translation file
  is a plain list of English sentences, so an untranslated line stays English rather than
  breaking the page.
- **Works on a phone and a tablet**, including on-screen RMB / ALT / CTRL / SHIFT keys, an
  OPTIONS rule that stops Ketcher raising the keyboard on every tool, a three-position ⛶ that
  ends in MAX (everything but the picture gone), and a web-app manifest for Add to Home
  Screen. **Compatibility first**: nothing here works on Android and not on an iPhone; the
  headset page is the one exception.

Everything runs client-side. No drawing leaves the browser unless you choose a short link, and
the only request to any other host is a **FIND** search, which sends the words you type and
your address to the database you asked. The one thing the page sends to its own server on
its own is a count of what was used — "make3d 3, minimize 1" — batched, with no cookie, no
session and no identifier; the operator can switch it off, and
[TERMS.md](TERMS.md) says exactly what it is.

## Documentation

The user manual is **[MANUAL.md](MANUAL.md)** — also reachable inside the app under
**INFO ▸ MANUAL**. The terms of use and privacy policy for the service run at dworm.org are
**[TERMS.md](TERMS.md)**, under **INFO ▸ TERMS &amp; PRIVACY**. They cover the *service*; if you
install 2D-WORM on your own server you become its operator and they do not apply to you.
If you run the sharing service yourself, **[ADMIN.md](ADMIN.md)** explains the admin page, the
statistics, adding and removing entries, and how to keep unwanted people out.

## Installing

Upload the folder to any web space and open `index.html` over http or https (not `file://`).

```
index.html          the application
2dworm-vr.html      2DWORM-VR: the same structure in a headset (optional)
2dworm-bench.html   the benchmark page (optional; measures this machine)
MANUAL.md           the user manual, shown by INFO ▸ MANUAL
TERMS.md            terms of use and privacy, shown by INFO ▸ TERMS & PRIVACY
ADMIN.md            running the sharing service (not needed by visitors)
lang/               en, ar, zh, pt, es, pl, de, it, hi, ur — interface translations, and
                    STRINGS_TO_REVIEW.md / strings_to_review.csv, what a reviewer has not seen
manifest.json       the web-app manifest, with icons/ — Add to Home Screen
.htaccess           MIME types, caching, optional /s/KEY rewrite
ketcher/            Ketcher 3.18.0 + Indigo 1.46 WASM, built from ketcher-build/
lib/                3Dmol.js, OpenChemLib, lz-string, qrcode-generator, fflate, the 3D worker,
                    uff.js (force field), qcgeom.js (calculation readers), mdgeom.js (MD sets),
                    qcresults.js (RESULTS), crystal.js (space groups), select.js (the selection
                    language), session.js (the .2dworm.zip), fetchdb.js + providers.json (FIND),
                    names.js (the common-name table), fragments.js (the builder library),
                    pmodel.js (pMODEL), ppbc.js (pPBC)
fragments_user.xyz  your own substituents for the builder, as XYZ text (an example ships)
molstar/            Mol* 5.11.0 (5 MB) — needed only by 2dworm-vr.html
QRsharing/          optional sharing service (PHP 7.4+ with pdo_sqlite), with featured.php for
                    the molecule of the day
```

`molstar/` may be left out if you do not want the VR page: 2DWORM-VR then says so instead of
showing an empty box, and nothing else is affected. It is a straight copy of
`molstar@5.11.0/build/viewer/molstar.js` and `.css`; the hashes are in [NOTICE](NOTICE). It is
served from your own server and never from a CDN, so the page still loads nothing from anywhere
else.

The built Ketcher bundle is not kept in this repository — it is attached to each
[release](https://github.com/theogoncalves/2DWORM/releases) as a ready-to-upload zip. To
build it yourself see `ketcher-build/` and `ketcher/BUILD-NOTES.md`.

Without PHP everything still works; the short-link button simply switches itself off.
After uploading, open `QRsharing/setup-check.php` once to verify the service, then delete it.

## Development

```bash
cd ketcher-build && npm ci && npm run build     # produces ../2dworm/ketcher/
php -S 127.0.0.1:8000 -t .                      # serve the page locally
sh ../2dworm-test/run-all.sh                    # every suite below, one after another
node ../2dworm-test/qcgeom.mjs                  # calculation readers, on real files 440
node ../2dworm-test/mdgeom.mjs                  # AMBER, NAMD, CHARMM, LAMMPS         163
node ../2dworm-test/fetchdb.mjs                 # FIND: eight providers, mocked       153
node ../2dworm-test/crystal.mjs                 # 230 space groups, CIF expansion     120
node ../2dworm-test/server.mjs                  # the sharing service, retirement     109
node ../2dworm-test/session.mjs                 # the .2dworm.zip round trip           94
node ../2dworm-test/test.mjs                    # main Playwright suite                94
node ../2dworm-test/admin.mjs                   # the admin page and its arithmetic    91
node ../2dworm-test/build24.mjs                 # build 24 in a browser: session, RESULTS,
                                                #   crystal, select, marks, undo …     85
node ../2dworm-test/qcresults.mjs               # steps, modes, IRC, on real outputs   83
node ../2dworm-test/fragments.mjs               # the builder library, worm4's data    98
node ../2dworm-test/build25.mjs                 # build 25 in a browser: PAUSED!, pPBC,
                                                #   pMODEL, the builder, the small items 60
node ../2dworm-test/build26.mjs                 # build 26 in a browser: the two rows, groups,
                                                #   residues, the ENERGY slider           58
node ../2dworm-test/build27.mjs                 # build 27: FIND, BUG across, horizon,
                                                #   pictures, the help card               26
node ../2dworm-test/build28.mjs                 # build 28: the large pick, the ENERGY switch,
                                                #   X/Y/Z, FREEZE, the atom window, PAUSED!
                                                #   views, methyl caps, pREST, the VR floor 74
node ../2dworm-test/pmodel.mjs                  # cutting, capping, the round trip      56
node ../2dworm-test/ppbc.mjs                    # the guessed box                       35
node ../2dworm-test/vr.mjs                      # 2DWORM-VR: hand-over, hand menu      83
node ../2dworm-test/edit.mjs                    # EXPERT: the three drag tools         71
node ../2dworm-test/lang.mjs                    # ten languages, and the layout        68
node ../2dworm-test/field.mjs                   # fields, looks, MINIMIZE SELECTED     63
node ../2dworm-test/periodic.mjs                # the cell, the charges, MIN pPERIODIC 58
node ../2dworm-test/terms.mjs                   # TERMS.md against the code            55
node ../2dworm-test/sellang.mjs                 # the selection language               45
node ../2dworm-test/settings.mjs                # settings from the admin page         43
node ../2dworm-test/select.mjs                  # picking atoms and measuring          42
node ../2dworm-test/notes.mjs                   # the note renderer, mostly hostile    41
node ../2dworm-test/qcopen.mjs                  # calculation files, periodic guard    34
node ../2dworm-test/names.mjs                   # the common-name table                33
node ../2dworm-test/cube.mjs                    # the volume a .cube came with         32
node ../2dworm-test/geo.mjs                     # the sliders and the arrow keys       30
node ../2dworm-test/uff.mjs                     # UFF gradients, reference geometries  29
node ../2dworm-test/bench.mjs                   # the benchmark page measures right    27
node ../2dworm-test/bigmol.mjs                  # large structures and sharing         26
node ../2dworm-test/counts.mjs                  # the counters, and what they refuse   25
node ../2dworm-test/frame.mjs                   # SPACE and ENTER framing              21
node ../2dworm-test/reps.mjs                    # one look for part of a structure     15
node ../2dworm-test/memory.mjs                  # leaks, and what an idle tab costs    13
node ../2dworm-test/uff-cross.mjs               # UFF against an independent code       9
node ../2dworm-test/figures.mjs                 # the manuscript figures (not a test)
node ../2dworm-test/perf.mjs                    # what makes a large structure slow
node ../2dworm-test/strings.mjs                 # the strings a translator has not seen (not a test)
```

Run them **one at a time** — several Playwright browsers at once starve each other in a small
container and produce failures that are not real; `run-all.sh` does exactly that and prints a
tally per suite. **2,702 checks in total.** The real test files live in
`2dworm-test/corpus/` (the large cube files are not in the repository, and the suites that use
them say SKIP).

Four of them are unusual and worth knowing about. `terms.mjs` asserts the claims in `TERMS.md`
against the code they describe: change the retention period in `core.php` and the privacy policy
fails the build until it is changed too, because a policy is the one document that goes stale
without anyone noticing. `notes.mjs` is mostly hostile input — sixteen real techniques put
through the note renderer, each checked against the DOM that results rather than the HTML
string, because `&lt;script&gt;` in a string is reassuring and proves nothing. `counts.mjs` is
about what must **not** end up in the database: it reads the tables directly rather than
believing the endpoint, and fails if a user-agent string, a country beside a device, or anything
per-visitor ever appears in them. `admin.mjs` checks the dashboard's *arithmetic* against what
was actually put into the database — the figures are what decisions get made from.

## Contributing

Bug reports and awkward test files are the most useful thing you can send. Code
contributions need the short [CLA](CLA.md) — see **[CONTRIBUTING.md](CONTRIBUTING.md)**,
which also explains how credit works.

Security problems: please write to contact@dworm.org rather than opening an issue.
See [SECURITY.md](SECURITY.md).

## Citing

See [CITATION.cff](CITATION.cff), or the "How to cite" entry in the INFO window.
Citations are what keep this project alive.

## Licence

**GNU Affero General Public License v3.0 or later** — see [LICENSE](LICENSE).

The names "2D-WORM", "D-WORM" and "DESERT WORM" and the logo are trademarks; the code is
free to fork, but a modified version needs a different name. See [TRADEMARK.md](TRADEMARK.md).

Bundled third-party components and the papers to cite are listed in [NOTICE](NOTICE).
Chemical drawing by **Ketcher** and **Indigo** (EPAM, Apache-2.0); 3D display by
**3Dmol.js** (Rego & Koes, *Bioinformatics* 2015); visual style after **MacMolPlt**
(Bode & Gordon, *J. Mol. Graphics Mod.* 1998), no MacMolPlt code used; 3D generation and
MMFF94s+ minimisation by **OpenChemLib**.

`lib/uff.js` is our own implementation of UFF (Rappé *et al.*, *JACS* 1992) — the complete
Table 1, 127 atom types across all 103 elements — AGPL-3.0 like the rest, and cross-checked
against RDKit's independent UFF by `2dworm-test/uff-cross.mjs`. **If you extend it, extend it
from the paper**: Open Babel's UFF is GPL-2-*only*, with no "or later" clause, so copying from
it — its parameter file included — would make this project undistributable. See [NOTICE](NOTICE).
