# 2D-WORM — Terms of Use and Privacy

*In force from 10 September 2026. Contact: contact@dworm.org*

2D-WORM is a small free program that runs in your browser, together with an optional service
that stores a drawing so it can be shared by a short link. It is written and run by
**Theo P. Goncalves** as a personal project. It is not operated by, and not the
responsibility of, any employer or university.

## The short version

- **Drawing, building 3D structures, minimising and exporting images all happen inside your
  browser.** Nothing is sent anywhere unless you press SHARE or FIND.
- **A shared drawing is public to anyone who has the link or the ID.** There are no accounts
  and no passwords on shared drawings. Do not share anything confidential.
- **Sharing is not archiving.** Stored drawings are kept while they are being used and are
  deleted when the space is needed.
- **No address of yours is stored**, and no cookies are set for ordinary visitors.
- **The service counts how much it is used** — plain per-day totals such as "MAKE 3D was
  pressed 214 times today". No cookie, no session, no identifier, nothing that describes a
  person, and nothing sent to anybody else. It is spelled out below.
- **This is alpha software with no warranty.** A minimised geometry is a force-field result,
  not a validated scientific answer.
- To have something removed, write to **contact@dworm.org** with the ID.

---

# Terms of Use

## 1. The software

2D-WORM is free software under the **GNU Affero General Public License, version 3 or later**.
You may use, study, change and redistribute it under that licence; the full text is in
`LICENSE`, and the source is at <https://github.com/theogoncalves/2DWORM>.

The licence covers the program. These terms cover the **service** run at dworm.org — the page
itself and the sharing service behind the SHARE button. If you install 2D-WORM on your own
server, these terms do not apply to your installation; you become its operator.

## 2. No warranty, and what that means for chemistry

The licence disclaims all warranties (sections 15 to 17), and so does this service. It is
offered as it is, with no promise that it works, that it stays available, or that anything you
store remains stored.

That is worth spelling out for the chemistry rather than leaving it as boilerplate:

- **MINIMIZE and BEST CONFORMATION use empirical force fields** — MMFF94s+ and UFF. They give
  a plausible geometry quickly. They are not quantum chemistry, they carry no error bars, and
  UFF in particular is a general-purpose field that will happily produce a confident-looking
  structure for a metal complex it has no business describing.
- **Read what the status line says.** It names the field that actually ran, and it warns when
  it had to assume something — for example that UFF offers only a square-planar type for
  nickel, whatever the real coordination is.
- **Check anything you intend to publish** against a proper calculation or an experimental
  structure. Do not cite a 2D-WORM geometry as a result.

## 3. Sharing

Pressing SHARE and choosing SHORT LINK stores your drawing on the server and gives you an ID.

- **Anyone with the ID can open it.** The ID is short, and short IDs can be guessed. Treat a
  shared drawing as public.
- **Do not share confidential material** — unpublished results, anything under an NDA, patient
  or personal data, or anything a colleague has not agreed to make public.
- If you want to send something to one person and no one else, use **FULL LINK** (nothing is
  stored on any server, the drawing travels inside the link itself) or send the file from the
  SAVE menu.
- **A stored drawing may be deleted at any time.** Entries are kept while they are being
  opened; the least recently opened ones are removed when a store is full, and anything not
  opened for two years goes. In other words a stored link **expires with demand** — the ones
  nobody opens are the first to go. For anything you need to keep, use FULL LINK or save the
  file.
- **A very popular code may be retired.** The operator may switch on a rule under which a
  code opened more than a set number of times — a code on a poster, say — is retired after a
  period of notice, unless it has been arranged with the operator. A retired code answers with
  a message saying so and how to write in; it does not simply vanish. The page says this
  beside every QR code it makes, before the code is printed anywhere. Two things never expire
  and need no arrangement: FULL LINK, which carries the drawing inside itself, and SAVE
  SESSION, which gives you a file.
- **Storing takes a moment on purpose.** The server asks you to wait a few seconds before it
  stores an ordinary drawing, and rather longer before a large one. The page shows the
  countdown. It is there so that one person cannot fill the database faster than a person
  could ever draw, and it is enforced by the server, not by the page.

## 4. What you may not store

Do not use the sharing service to store or distribute:

- material that is unlawful where you are or where the server is;
- images of, or material sexualising, children;
- personal data about other people;
- malware, phishing pages, or anything designed to deceive;
- material that infringes somebody else's copyright or trade marks;
- bulk automated uploads, or anything meant to fill or break the service.

Note that a 2D-WORM drawing can contain a **pasted picture**, so it can carry far more than
chemistry. That is the reason this section exists.

## 5. Reporting something — takedown

If you find a shared drawing that should not be there, write to **contact@dworm.org** with
the ID (the short code under the QR code, or in the link after `?k=`). Include a sentence
saying what is wrong with it.

Reports are dealt with by hand, by one person, as soon as he sees them. When something is
removed, it is blocked **by the content itself**, not just by its ID — so uploading the same
thing again does not bring it back.

You can also ask for **your own** shared drawing to be deleted. Send the ID; no explanation is
needed.

## 6. Availability, changes and shutdown

There is no service level. The service may be slow, may refuse large drawings, may be taken
down for maintenance, and may be **switched off permanently** with no notice and no export.
The page keeps working without it: everything except the SHORT LINK button runs in your
browser alone.

These terms may change. The date at the top says when this version came into force.

---

# Privacy

## What is stored when you press SHARE

One row, containing:

- the **ID** in your link;
- the **drawing itself**, compressed — the structure, the 3D settings, the camera angle, any
  picture you pasted, and any atoms you selected;
- a **hash of that content**, used to notice that the same drawing has been stored before, and
  to keep a removed drawing from being re-uploaded;
- its **size**, the time it was **created**, the time it was **last opened**, and **how many
  times** it has been opened;
- an **administrator's note**, if one was ever written about it.

There is nothing in that row about who stored it. No name, no address, no session, no browser
fingerprint. Two people who store the same drawing get the same ID and share one row.

**How long.** While it is being used. An entry not opened for **two years** is deleted, and
before that the least recently opened entries are deleted whenever a store reaches its size
limit. When the operator has enabled it, an entry opened more than a set number of times is
retired after a period of notice (the row then keeps a **retirement time** until it goes). A
small number of entries can be marked permanent by the administrator, and those are never
pruned or retired; nothing you store becomes permanent by itself.

**The QR code notice.** Beside every QR code the page says: *A QR code here is not permanent.
Codes are kept while they are in use and removed when they are not, so one printed on a poster
may stop working later. If you need one to keep working — for a paper, a thesis, a poster that
will be up for a year — write to contact@dworm.org with what it is for, who you are, how long
you need it and roughly how much use you expect. It can be made permanent. Two alternatives
that never expire and need no permission: FULL LINK carries the drawing inside the link itself,
and SAVE SESSION gives you a file. For anything large, SAVE SESSION is the better choice — a
file has no size limit and does not depend on this server at all.*

**The featured list.** The operator may publish a small set of structures of his own choosing
("molecule of the day"). They live in a database of their own, are never mixed with anything
you store, and opening one records nothing about you beyond a count on that entry.

## What is not stored

- **No IP addresses.** Not in the drawings table, not in the usage counts.
- **No accounts, no e-mail addresses, no names.**
- **No cookies** for ordinary visitors. The only cookie this site can set is a login session
  for the administrator, and only while he is logged in.
- **No third-party analytics, no tracking pixels, no scripts from anywhere else.** The page
  loads nothing from any host but the one serving it, and no measurement of any kind is sent
  to another company. The service does keep counts of its own — per-day totals, described in
  the next section but one — and they never leave this server.
- **No user-agent strings.** The browser sends one with every request, as browsers do, but it
  is reduced to a single word out of a short list — "Windows", "Android", "Meta Quest" —
  before anything is written, and the string itself is never stored.
- **Nothing is sold, shared or handed to anyone**, except where the law requires it.

## Stopping abuse

To stop one person filling the database, the service counts how many links come from the same
place in an hour. It does that **without keeping the address**: the address is mixed with a
random secret that belongs to this installation and with the current hour, and only the
resulting one-way hash is stored, next to a counter. The hash cannot be read back as an
address, it is not attached to anything you stored, it changes every hour, and it is deleted
after two hours.

## Counting how much the service is used

The administrator can turn counting on and off with one setting. While it is on, three sorts
of number are kept, and every one of them is **a day, a label and a count** — nothing else:

- **Sharing** — a day, a country and an action: "2026-09-09, SA, share, 14". Your address is
  turned into a country inside the request that carries it and is then gone. Countries with
  fewer than five actions are folded into "Other", so that a single visit cannot be picked out.
- **Which parts of the page are used** — a day, the name of a feature and a count:
  "2026-09-09, make3d, 214". The page adds up what was used and sends the totals at most once
  every two minutes, and once more when you close the tab. Only names from a fixed list are
  accepted, so the table cannot be used as a place to write arbitrary text.
- **What sort of machine the page runs on** — a day, one word and a count: "2026-09-09,
  Windows, 31", and, when someone actually enters an immersive session, "2026-09-09, Meta
  Quest, 2". The word is chosen on the server out of a short list; the browser's user-agent
  string never reaches the database, because a full one is close to a fingerprint.

**The counts cannot be joined, and that is the point.** There is a count of visits from Saudi
Arabia today, a count of Windows machines today and a count of MAKE 3D presses today, and
nothing relates any of them to any other. A single row saying "Saudi Arabia, PICO, Android,
MAKE 3D, today, 1" would describe one identifiable person; that row does not exist here and
cannot be reconstructed from the rows that do.

Behind all of this there is no cookie, no session and no identifier of any kind, so two visits
by you and one visit each by two people are indistinguishable. Because the counts contain
nothing about anybody, they are not deleted on a schedule: a per-day total is kept for as long
as the service runs, and erasing it would protect no one.

## 2DWORM-VR

The **VR** button opens a second page that draws the same structure with Mol* and can enter a
headset session. It changes nothing here: the structure is handed from one page to the other
inside your own browser, in this tab's own memory, and is gone when the tab closes. Nothing is
uploaded, no drawing is stored, and the viewer itself is served from this server rather than
from anybody else's — so the sentence above about the page loading nothing from another host
stays true on that page too. The only thing recorded is one number in the counts described
below: that the VR page was opened.

## Your own browser

The page remembers six things, in your browser's local storage, which never leave your
computer: the **background you chose** (white, black or worm), the **size of the Ketcher
toolbars**, the **language** you picked, the choices made in the **OPTIONS** window (the
on-screen keyboard rule, the camera, what a session file carries, the PAUSED!, pMODEL, pREST
and pPBC settings), **your own substituents** for the builder's REPLACE tool, as the XYZ text
you typed or imported, and the **text size of the NOTES panel**. Clearing your site data
removes all six.

## FIND — the only requests to anyone else

**FIND** searches outside databases, and your browser talks to them directly:

- the **RCSB Protein Data Bank** — <https://www.rcsb.org/policies>
- **PDBe**, the same archive at EMBL-EBI — <https://www.ebi.ac.uk/about/terms-of-use>
- **PubChem**, at the US National Center for Biotechnology Information —
  <https://www.ncbi.nlm.nih.gov/home/about/policies/>
- the NCI **Chemical Identifier Resolver** (CACTUS), at the US National Cancer Institute —
  <https://cactus.nci.nih.gov/>
- the **Crystallography Open Database** (COD) and its theoretical sister (TCOD) —
  <https://www.crystallography.net/cod/>
- **Wikidata** — <https://www.wikidata.org/wiki/Wikidata:General_disclaimer>
- **Zenodo**, at CERN — <https://about.zenodo.org/terms/>
- the **AlphaFold Protein Structure Database** at EMBL-EBI, which is present in the list but
  **switched off** unless the operator turns it on — <https://alphafold.ebi.ac.uk/about>

The list itself is in `lib/providers.json`, and only what is in that file can be asked. A search
sends **the words you type and your network address** to whichever of them is being searched,
and opening a structure fetches it from there. What happens to that request is governed by
their policies, not by this one. This is the only request 2D-WORM makes to any host other than
the one serving the page — if you never press FIND, it never happens. The **molecule of the
day** in the empty 3D panel comes from this server, from a list the operator keeps, and only
when you press OPEN.

Structures you bring in this way are **not copied onto this server**. A link you share carries
the identifier, such as `rcsb:1CRN`, and whoever opens it fetches the entry themselves — which
means their browser contacts that database in turn.

## The web server's own log

Like every web server, the machine that serves this page keeps an access log of the requests
it receives, and such logs normally include IP addresses. That log belongs to the hosting
company and is outside 2D-WORM: no part of the program reads it, writes to it or uses it.

## Getting something removed

Write to **contact@dworm.org**. If it is a shared drawing, send the ID and it will be deleted.
Since nothing stored is linked to a person, there is no account to close and nothing else to
erase — apart from the hosting company's log, which is theirs.

## Contact

**contact@dworm.org** — for takedown requests, privacy questions, and everything else.
