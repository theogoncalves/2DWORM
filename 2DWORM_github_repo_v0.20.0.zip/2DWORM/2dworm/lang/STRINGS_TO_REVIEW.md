# 2D-WORM — strings for review (v0.20.0, build 28)

Every English string in the page that is not yet in the language files: 425 of them, 309 short labels and 116 sentences. Fill the two columns (or one of them) and send the file back; the keys go into `lang/hi.json` and `lang/ur.json` exactly as written here. A string may stay in English — leave the cell empty and it will. Do not change the *English* column: it is the key the page looks up.

Made by `2dworm-test/strings.mjs`; the `where` column says which control the text belongs to (a tooltip is a `title`).

## Labels and short strings

| English | where | हिन्दी | اردو |
|---|---|---|---|
| A large structure | ask() |  |  |
| Extend the cell? | ask() |  |  |
| Share it as | ask() |  |  |
| This structure is large | ask() |  |  |
| That is the last atom. | editHint() |  |  |
| aspirin · haemoglobin · caffeine · 1CRN | placeholder #findInput |  |  |
| Fe(<2.4A) _OR_ M(Cl) | placeholder #selExpr |  |  |
| Na 0 0 0 Cl 0.5 0.5 0.5 | placeholder #crysAtoms |  |  |
| OTf | placeholder #fragKey |  |  |
| triflate | placeholder #fragName |  |  |
| Could not load the shared link | say() |  |  |
| Could not open | say() |  |  |
| Could not open the shared drawing. | say() |  |  |
| CRYSTAL: | say() |  |  |
| Fetching | say() |  |  |
| Ketcher: | say() |  |  |
| Layout: | say() |  |  |
| Minimisation not started. | say() |  |  |
| Opening in | say() |  |  |
| RESULTS: | say() |  |  |
| Save failed: | say() |  |  |
| SMILES copied to clipboard: | say() |  |  |
| SMILES: | say() |  |  |
| 3D generation failed: | say3d() |  |  |
| Building the periodic surroundings… | say3d() |  |  |
| Framed | say3d() |  |  |
| Image export failed: | say3d() |  |  |
| Marks cleared. | say3d() |  |  |
| Nothing is loaded to put in a box. | say3d() |  |  |
| Nothing is loaded to select from. | say3d() |  |  |
| Nothing is loaded. | say3d() |  |  |
| Pick the atoms first, then MARK ▸ KEEP. | say3d() |  |  |
| Rendering image… | say3d() |  |  |
| Selection: | say3d() |  |  |
| That step has no geometry to take. | say3d() |  |  |
| , then | text #fragDlg |  |  |
| ; small molecules from | text #findDlg |  |  |
| .       A PDB identifier ( | text #findDlg |  |  |
| .2dworm.zip | text #saveMenu |  |  |
| .abi | text #saveMenu |  |  |
| .cdx | text #saveMenu |  |  |
| .cdxml | text #saveMenu |  |  |
| .cif | text #saveMenu |  |  |
| .gjf | text #saveMenu |  |  |
| .gro | text #saveMenu |  |  |
| .jpg | text #saveMenu |  |  |
| .ket | text #saveMenu |  |  |
| .mol | text #saveMenu |  |  |
| .mol (3D, with bonds) | text #selNoteCoords |  |  |
| .pdb | text #saveMenu |  |  |
| .png | text #saveMenu |  |  |
| .pwi | text #saveMenu |  |  |
| .smi | text #saveMenu |  |  |
| .svg | text #saveMenu |  |  |
| .xyz | text #saveMenu |  |  |
| ) or a PubChem CID ( | text #findDlg |  |  |
| +H | text #toolSeg |  |  |
| 🥽 MolStar-VR | text #btnVR |  |  |
| 0 Å — the images touch | text #optGap |  |  |
| 1CRN | text #findDlg |  |  |
| 2D-WORM | text #app |  |  |
| 2D-WORM version 0.20.0 (build 28) | text #infoVersion |  |  |
| 2DWORM session | text #saveMenu |  |  |
| 2DWORM session + cube files | text #btnSaveSessionVol |  |  |
| 3 Å around the model | text #optRest |  |  |
| 3D camera | text #optDlg |  |  |
| 5 Å around the model | text #optRest |  |  |
| 8 Å around the model | text #optRest |  |  |
| a× | text #crysDlg |  |  |
| ABINIT | text #saveMenu |  |  |
| ADD TO SELECTION | text #selExprAdd |  |  |
| after | text #energyAfter |  |  |
| AFTER | text #energyEnd |  |  |
| ALL | text #pauseView |  |  |
| all atoms | text #selPick |  |  |
| All chains | text #selChain |  |  |
| ALT | text #modBar |  |  |
| Amplitude | text #resFreq |  |  |
| ANGLE | text #geoBar |  |  |
| any bond, without the warnings | text #optCut |  |  |
| APPLY | text #selListApply |  |  |
| Are you sure? | text #askTitle |  |  |
| Asymmetric unit | text #crysDlg |  |  |
| B&W | text #colourSeg |  |  |
| b× | text #crysDlg |  |  |
| ball & stick | text #selRepSel |  |  |
| before | text #energyBefore |  |  |
| beside | text #fragDlg |  |  |
| bigger | text #selNoteSpan |  |  |
| blue | text #selNoteSpan |  |  |
| BUG | text #themeSeg |  |  |
| BUILD | text #crysBuild |  |  |
| by number… | text #selPick |  |  |
| c× | text #crysDlg |  |  |
| Cell | text #crysDlg |  |  |
| CELL EXTEND | text #btnCellExtend |  |  |
| CELL FIX | text #btnCellFix |  |  |
| clear | text #selPick |  |  |
| CLICK ORDER | text #selListOrder |  |  |
| COLOUR | text #colourSeg |  |  |
| COMMAS | text #selListSep |  |  |
| contact@dworm.org | text #infoDlg |  |  |
| CONTINUE | text #pauseGo |  |  |
| coord | text #saveMenu |  |  |
| COORDINATES… | text #selNoteCoords |  |  |
| COPY | text #selListCopy |  |  |
| CRYSTAL | text #btnCrystal |  |  |
| CTRL | text #modBar |  |  |
| cyan | text #selMarkColour |  |  |
| DEL | text #toolSeg |  |  |
| DELETE ALL OF MINE | text #fragClear |  |  |
| DIHEDRAL | text #geoBar |  |  |
| DOWNLOAD fragments_user.xyz | text #fragDownload |  |  |
| dworm.org | text #app |  |  |
| El x y z | text #fragDlg |  |  |
| element | text #atomWin |  |  |
| ENERGY | text #energyRow |  |  |
| expression… | text #selPick |  |  |
| Field: off | text #selIso |  |  |
| Fix: atoms | text #selCellFix |  |  |
| Fix: molecules | text #selCellFix |  |  |
| Fix: whole molecules (periodic) | text #selCellFix |  |  |
| fragments_user.xyz | text #fragDlg |  |  |
| FREEZE | text #btnFreeze |  |  |
| FREEZE A | text #geoBar |  |  |
| FREEZE B | text #geoBar |  |  |
| FREQUENCIES | text #resTabs |  |  |
| FROM THE 3D VIEW (P1) | text #crysFromView |  |  |
| frozen surfaces only (small) | text #optSurf |  |  |
| Gaussian .gjf | text #selNoteCoords |  |  |
| github.com/theogoncalves/2DWORM | text #infoDlg |  |  |
| glass | text #selRepSel |  |  |
| Glass (transparent) | text #selStyle |  |  |
| green | text #selMarkColour |  |  |
| grey | text #selNoteSpan |  |  |
| GROW | text #growRow |  |  |
| grow: +1 bond | text #selPick |  |  |
| grow: +2 bonds | text #selPick |  |  |
| grow: within 3 Å | text #selPick |  |  |
| HD | text #renderSeg |  |  |
| hidden | text #selRepSel |  |  |
| hydrogen — a link atom on the cut bond | text #optCap |  |  |
| IMPORT FILE… | text #fragImport |  |  |
| index.html | text #fragDlg |  |  |
| ink | text #selRepSel |  |  |
| invert | text #selPick |  |  |
| is read when the page opens. | text #fragDlg |  |  |
| KEEP | text #btnMark |  |  |
| key | text #fragDlg |  |  |
| key=… name="…" group=… | text #fragDlg |  |  |
| LABELS | text #btnLabelsPicked |  |  |
| labels on the picked atoms only | text #selListDlg |  |  |
| Lattice system | text #crysDlg |  |  |
| leave the browser to decide | text #optKbd |  |  |
| LIBRARY… | text #btnFragLib |  |  |
| lines. A dummy atom | text #fragDlg |  |  |
| magenta | text #selMarkColour |  |  |
| make an edit first | text #energyV |  |  |
| Mark: cage | text #selHalo |  |  |
| Mark: double | text #selHalo |  |  |
| Mark: solid | text #selHalo |  |  |
| Mark: tint | text #selHalo |  |  |
| MARKS ✕ | text #btnMarksClear |  |  |
| MED | text #renderSeg |  |  |
| MIN pPERIODIC | text #btnMinPeriodic |  |  |
| MINIMIZE SELECTED | text #btnMinSel |  |  |
| MODEL | text #pauseView |  |  |
| Molecule of the day | text #motd |  |  |
| name | text #fragDlg |  |  |
| neon | text #selRepSel |  |  |
| Neon on black | text #moreLooks |  |  |
| never — run straight through | text #optPause |  |  |
| NO | text #askNo |  |  |
| not | text #findDlg |  |  |
| number | text #atomWin |  |  |
| NUMERIC | text #selListOrder |  |  |
| ON | text #energySw |  |  |
| On-screen keyboard | text #optDlg |  |  |
| One moment… | text #waitTitle |  |  |
| only when a tool needs it (automatic) | text #optKbd |  |  |
| OPTIMISATION | text #resTabs |  |  |
| OPTIONS | text #btnOptions |  |  |
| orange | text #selMarkColour |  |  |
| Outline v.slim | text #selOutline |  |  |
| Outline vv.slim | text #selOutline |  |  |
| PAUSED! | text #pauseBar |  |  |
| PAUSED! — inspect the intermediate | text #optDlg |  |  |
| pick 2 atoms | text #geoBondV |  |  |
| pick 3 atoms | text #geoAngV |  |  |
| pick 4 atoms | text #geoDihV |  |  |
| pick atoms | text #geoMoreV |  |  |
| Picked as… | text #selRepSel |  |  |
| Picked atoms | text #selListDlg |  |  |
| picked atoms list… | text #selPick |  |  |
| pMODEL | text #btnPModel |  |  |
| pMODEL / pREST caps | text #optDlg |  |  |
| pMODEL may cut | text #optDlg |  |  |
| POSCAR | text #saveMenu |  |  |
| pPBC | text #btnPPBC |  |  |
| pPBC gap between images | text #optDlg |  |  |
| pREST | text #btnPRest |  |  |
| pREST shell | text #optDlg |  |  |
| Proteins, DNA and RNA from the | text #findDlg |  |  |
| Publication (cartoon + ligands) | text #moreLooks |  |  |
| Quantum ESPRESSO | text #saveMenu |  |  |
| Quantum ESPRESSO .pwi | text #selNoteCoords |  |  |
| red | text #selNoteSpan |  |  |
| REORDER: PICKED FIRST | text #selListReorder |  |  |
| REPLACE | text #toolSeg |  |  |
| RESET ALL | text #btnResetAll |  |  |
| REST | text #pauseView |  |  |
| RESULTS | text #btnResults |  |  |
| RMB | text #modBar |  |  |
| SAVE PICKED AS SUBSTITUENT | text #fragFromPicked |  |  |
| SCHEMES ✕ | text #btnRepClear |  |  |
| SELECT | text #selExprGo |  |  |
| Select by expression | text #selDlg |  |  |
| Select… | text #selPick |  |  |
| Session file | text #optDlg |  |  |
| SHIFT | text #modBar |  |  |
| SIZE / COLOUR… | text #selNoteSpan |  |  |
| smaller | text #selNoteSpan |  |  |
| space filling | text #selRepSel |  |  |
| Space group | text #crysDlg |  |  |
| SPACES | text #selListSep |  |  |
| STOP | text #pauseStop |  |  |
| Supercell | text #crysDlg |  |  |
| TAIL CH3 | text #pauseTail |  |  |
| TAIL H | text #pauseTail |  |  |
| Technical illustration (ink) | text #moreLooks |  |  |
| TEXT 12 | text #selNoteSize |  |  |
| TEXT 14 | text #selNoteSize |  |  |
| TEXT 16 | text #selNoteSize |  |  |
| TEXT 18 | text #selNoteSize |  |  |
| TEXT 21 | text #selNoteSize |  |  |
| the whole rest | text #optRest |  |  |
| TO NOTE | text #atomWinNote |  |  |
| Tools 50% | text #selUiScale |  |  |
| Tools 75% | text #selUiScale |  |  |
| tubes | text #selRepSel |  |  |
| TWIST | text #moreLabel |  |  |
| UNIFORM | text #geoBar |  |  |
| USE THIS GEOMETRY | text #resUse |  |  |
| v0.20.0 build 28 | text #buildTag |  |  |
| VASP POSCAR | text #selNoteCoords |  |  |
| whole molecules of the picked | text #selPick |  |  |
| wireframe | text #selRepSel |  |  |
| xtb / Turbomole coord | text #selNoteCoords |  |  |
| yellow | text #selMarkColour |  |  |
| YES | text #askYes |  |  |
| Your substituents | text #fragDlg |  |  |
| Back to the edited structure | title #energyEnd |  |  |
| Back to what you picked | title #growZero |  |  |
| Back to where it was | title #geoBar |  |  |
| Both arms swing, equally | title #geoBar |  |  |
| Both ends turn, equally | title #geoBar |  |  |
| Both sides move, equally | title #moreRow |  |  |
| Close | title #atomWinClose |  |  |
| Give the 3D view the whole screen | title #btnSolo3d |  |  |
| Give the drawing the whole screen | title #btnSolo2d |  |  |
| Hold the first atom and its side still | title #geoBar |  |  |
| Hold the first atom's arm still | title #geoBar |  |  |
| Hold the first atom's end still | title #geoBar |  |  |
| Hold the first atom's side still | title #moreRow |  |  |
| Hold the fourth atom's end still | title #geoBar |  |  |
| Hold the last atom's side still | title #moreRow |  |  |
| Hold the second atom and its side still | title #geoBar |  |  |
| Hold the third atom's arm still | title #geoBar |  |  |
| In the order you clicked them | title #selListOrder |  |  |
| Ketcher chemical sketcher | title #ketcherFrame |  |  |
| Lowest number first | title #selListOrder |  |  |
| Not now | title #motdNo |  |  |
| Remove every kept mark | title #btnMarksClear |  |  |
| The energy after the last edit | title #energyAfter |  |  |
| The energy before the last edit | title #energyBefore |  |  |
| The next atom by number | title #atomWinNext |  |  |
| The previous atom by number | title #atomWinPrev |  |  |
| The step shown in the small viewer | title #resStep |  |  |
| Type the number of bonds and press Enter | title #growN |  |  |
| Type the value (%) and press Enter | title #geoBondN |  |  |
| Type the value (°) and press Enter | title #geoAngN |  |  |
| Type the value and press Enter | title #geoMoreN |  |  |
| x, in ångström; Enter applies it exactly | title #atomWin |  |  |
| y, in ångström; Enter applies it exactly | title #atomWin |  |  |
| z, in ångström; Enter applies it exactly | title #atomWin |  |  |
| 0 bonds · | tr() |  |  |
| about the bond | tr() |  |  |
| All databases | tr() |  |  |
| Atom | tr() |  |  |
| atoms | tr() |  |  |
| bonds | tr() |  |  |
| chain | tr() |  |  |
| Chain | tr() |  |  |
| charge | tr() |  |  |
| Copied. | tr() |  |  |
| ends only | tr() |  |  |
| isolated, without the images | tr() |  |  |
| Look at it, then CONTINUE or STOP. | tr() |  |  |
| no energy: | tr() |  |  |
| no parameters | tr() |  |  |
| no UFF parameters for | tr() |  |  |
| none | tr() |  |  |
| Nothing is picked. | tr() |  |  |
| Paused — | tr() |  |  |
| Pick the atoms of the group first. | tr() |  |  |
| residue | tr() |  |  |
| Type the atoms of the asymmetric unit. | tr() |  |  |
| UFF type | tr() |  |  |
| Storing the drawing on the server… | waitBox() |  |  |

## Sentences (tooltips, messages)

| English | where | हिन्दी | اردو |
|---|---|---|---|
| That atom has no neighbour to swing about. | editHint() |  |  |
| 5 key=CF3 name=trifluoromethyl group=custom X  0.00000  0.00000  0.00000 C  1.50000  0.00000  0.00000 F  2.00000  1.20000  0.00000 F  2.00000 -0.60000  1.05000 F  2.00000 -0.60000 -1.05000 | placeholder #fragText |  |  |
| A note about this structure. It travels inside the shared link, so whoever opens it reads what you meant. | placeholder #noteText |  |  |
| Build or open a 3D structure first — VR shows what is in the 3D panel. | say() |  |  |
| Nothing is in the 3D view to put in the note. | say() |  |  |
| The drawing engine is missing from this installation. | say() |  |  |
| The drawing engine is taking longer than usual to start… | say() |  |  |
| The field is too large to hand over — the structure goes to the headset without it. | say() |  |  |
| The molecule of the day could not be fetched: | say() |  |  |
| There is no room to hand the structure over (the browser refused session storage). | say() |  |  |
| This structure cannot be handed over — nothing to send. | say() |  |  |
| CELL EXTEND cancelled — nothing was built. | say3d() |  |  |
| Everything is drawn in the global scheme again. | say3d() |  |  |
| FROZEN — press FREEZE again before re-framing. | say3d() |  |  |
| No molecule is cut by this cell — every one of them is already whole. | say3d() |  |  |
| Nothing of the neighbouring cells comes near this one, so an ordinary MINIMIZE is the same calculation. | say3d() |  |  |
| Nothing to minimise – press MAKE 3D, or drop an .xyz / .pdb / .mol file on the 3D panel | say3d() |  |  |
| Pick some atoms first — this draws the picked ones differently from the rest. | say3d() |  |  |
| That cell has no volume, so there is no box to put anything back into. | say3d() |  |  |
| That cell has no volume, so there is nothing to extend it into. | say3d() |  |  |
| This structure carries no cell, so there are nothing around it to relax against. | say3d() |  |  |
| ) typed on its own goes       straight to that entry. | text #findDlg |  |  |
| A pseudo-periodic or model-system result depends on an intermediate the page builds and throws away. Paused, it is drawn on screen with a CONTINUE and a STOP; KILL still works. | text #optDlg |  |  |
| A search sends what you type, and your network address, to the RCSB PDB or to the       NCBI — this is the one place where 2D-WORM talks to somebody other than this server. What you       bring in is | text #findDlg |  |  |
| AGPL-3.0 (GNU Affero General Public License v3.0) | text #infoDlg |  |  |
| All at their defaults — nothing is added to a link. | text #optUrl |  |  |
| any bond — but name every cut that is not a single bond between light atoms | text #optCut |  |  |
| Atom numbers are 1-based and count atoms only: a PDB's TER lines do not count. Operators are read left to right; parentheses group. Names are not case-sensitive. | text #selDlg |  |  |
| copied into a shared link: the link carries the identifier, and whoever       opens it fetches the structure themselves. | text #findDlg |  |  |
| How much of the rest relaxes around the held model: the atoms within this distance of any model atom, cut from what lies beyond and capped there — or all of it, with nothing cut, which on a large structure is a long wait. | text #optDlg |  |  |
| Lengths in Å, angles in degrees. Fields the lattice system fixes are greyed and follow the free ones. | text #crysDlg |  |  |
| marks where the parent atom sits — the atom the group is bonded to; the real atom nearest X is the attachment atom. Without X the first atom attaches. Bonds are perceived from the distances. The same text in a file | text #fragDlg |  |  |
| methyl — a carbon where the cut atom was, three hydrogens staggered | text #optCap |  |  |
| Neither camera switches when labels come and go, so nothing jumps either way. The two projections do not frame a structure the same way, so changing this moves the picture once. | text #optDlg |  |  |
| never — the drawing tools do not raise it | text #optKbd |  |  |
| On a tablet or phone every Ketcher tool used to raise the keyboard, because a hidden text box takes focus. "Automatic" stops that on touch screens only. | text #optDlg |  |  |
| One atom per line: element, then x y z as fractions of the cell (0 to 1). The space group makes the rest. | text #crysDlg |  |  |
| One XYZ block each: the atom count, a comment line with | text #fragDlg |  |  |
| orthographic — the projection of a publication figure | text #optCam |  |  |
| pause and show it: the frozen shell of MIN pPERIODIC, the capped model of pMODEL | text #optPause |  |  |
| perspective — nearer atoms drawn larger, a depth cue while turning (default) | text #optCam |  |  |
| surfaces and the cube files themselves (large) | text #optSurf |  |  |
| The atoms you have picked, as numbers (1-based, atoms only — a PDB's TER lines do not count). Edit the list and APPLY, or paste a list from anywhere. | text #selListDlg |  |  |
| The box pPBC guesses is the molecule's van-der-Waals envelope plus this gap on every face. | text #optDlg |  |  |
| These are remembered on this device and travel as parameters in a link. | text #optDlg |  |  |
| What SAVE SESSION writes for a volumetric field. A frozen surface cannot be re-sliced; the cube can, and is tens of megabytes. | text #optDlg |  |  |
| What stands in for the bond that was cut: a hydrogen at the ONIOM distance, or a methyl that keeps the bulk. A cut through a double or triple bond is capped with hydrogens either way. TAIL at the PAUSED! breakpoint switches between the two on the spot. | text #optDlg |  |  |
| Where a model may be carved out of its surroundings. The cut is always made; the warning says where the model is weakest. The cap is as many hydrogens as the bond order. | text #optDlg |  |  |
| Whoever opens the link sees exactly what you see, can modify it and send you a new link back.       A stored drawing is public to anyone who has the ID, and it is kept only while it is used — | text #shareDlg |  |  |
| A different palette every press — generated, with the text and the chrome kept readable. The one place in this program where randomness is welcome. (DUSK, the old fourth theme, still opens from a link that names it.) | title #themeSeg |  |  |
| Bigger or smaller text, or one of five colours, for the words selected — written as {big}…{/} in the note, so it travels with it | title #selNoteSpan |  |  |
| Black and white for print – it applies to whichever representation is chosen | title #colourSeg |  |  |
| Both sides move, equally, about the midpoint | title #geoBar |  |  |
| Build a crystal: a lattice system, its cell parameters, a space group from the full table of 230, the atoms of the asymmetric unit in fractional coordinates, and a supercell — or take the structure on screen as a P1 cell and repeat it. | title #btnCrystal |  |  |
| Click a hydrogen, any terminal atom, or the first atom of a group (a methyl carbon, the oxygen of an OH): it is replaced by the substituent chosen on the right, turned to the clearest torsion | title #toolSeg |  |  |
| Click an atom: a hydrogen is added to it at the least crowded position, at the covalent distance | title #toolSeg |  |  |
| Complete every molecule the cell cut through, by bringing in the atoms of the neighbouring images it continues into. The result is a picture of the crystal, not a unit cell. | title #btnCellExtend |  |  |
| Compute the energies, or not. On by itself up to 2,000 atoms; above that the slider still scrubs the geometry and the energies wait for this switch, because a single point on a large structure takes seconds and would be paid for every edit. | title #energySw |  |  |
| Cut the picked region out of its surroundings, cap every cut bond with hydrogen, relax the region with UFF while the cut atoms and the caps are held, and put the relaxed coordinates back under their original numbers. A model-system guess of a local geometry inside something too large to relax whole. | title #btnPModel |  |  |
| DELETE: click an atom: it lights red for a moment, then it goes, with its hydrogens, and every bond it leaves behind on a heavy atom is capped with a hydrogen | title #toolSeg |  |  |
| Draw everything in the global scheme again | title #btnRepClear |  |  |
| Draw the picked atoms in a scheme of their own, leaving the rest as they are. A ligand in space filling inside a ribbon, or a reacting group in glass — one picture instead of two. | title #selRepSel |  |  |
| Draw the volumetric field that came with this .cube — an orbital, a density, an IGM or an NCI plot. The positive lobe is blue and the negative red. | title #selIso |  |  |
| Extend the picked atoms outwards through the bonds, this many bonds at a time. Zero is what you picked. | title #growR |  |  |
| Force field for MINIMIZE. Auto uses MMFF94s+ for ordinary organic molecules and UFF where MMFF has no parameters — transition metals, or more than 999 atoms. | title #selField |  |  |
| Guess an orthogonal periodic box for this molecule from its van-der-Waals envelope, turning it to the smallest box — a pseudo-periodic cell to relax it against its own images with MIN pPERIODIC. A guess, and undoable. | title #btnPPBC |  |  |
| HD draws everything you asked for whatever the size; MED withholds a surface or labels on a very large structure and says so; FAST draws less detail so a large structure stays smooth to rotate | title #renderSeg |  |  |
| Hide the controls and show the picture only (H — ESC leaves full screen) | title #barsBtn |  |  |
| Hold the molecule still: no rotation and no translation of the whole structure, by mouse or by touch. Zoom, picking and the tools still work; FIT, SPACE and ENTER wait. Press again to release. | title #btnFreeze |  |  |
| How a picked atom is marked. A solid ball is the most obvious but the outline draws over it; a cage keeps its colour whatever the outline is doing; a tint colours the atoms themselves and adds nothing to the picture. | title #selHalo |  |  |
| How far the colour scale runs either side of zero. Blue is negative, red positive — the convention every NCI and ESP figure uses. | title #selCRange |  |  |
| IR intensities — click a stick to see that mode | title #resSpec |  |  |
| Its element. Change it and the atom becomes that element where it is — nothing is added or removed, so a hydrogen count that no longer fits is yours to fix with +H or DEL. One undo. | title #atomWin |  |  |
| Its number in the structure. Change it and the atom takes that number; the others move along to make room, bonds and marks follow, one undo. | title #atomWin |  |  |
| Keep the picked atoms as a mark in the colour chosen, so a figure can be described by colour — the magenta atoms are the ligand, the yellow ones the active site. Marks travel in the link and the session file. | title #btnMark |  |  |
| LABELS ON THE PICKED ATOMS ONLY, and on nothing else. Press again for captions on every atom. The same switch is in the picked-atoms window. | title #btnLabelsPicked |  |  |
| Monospace — for a file name, a keyword, a value | title #panelNote |  |  |
| Move everything back inside the periodic cell. Nothing happens until you press it. | title #btnCellFix |  |  |
| Open or close the angle at the middle of the three picked atoms, in degrees from where it was | title #geoAngR |  |  |
| Open this structure in 2DWORM-VR, for a headset — the Mol* engine | title #btnVR |  |  |
| Outline thickness (cartoon-like edges). The two thinnest are for a figure that will be printed, where a line that looks right on screen comes out as a black band. | title #selOutline |  |  |
| Put the coordinates of the 3D structure into the note, as a block in the format chosen — so the note carries a structure somebody can copy straight into a program | title #selNoteCoords |  |  |
| Put this atom's line — number, element, name, residue, coordinates, charge, force-field type, bonds — into the note | title #atomWinNote |  |  |
| Relax only the atoms you have picked, holding the rest where they are (UFF) | title #btnMinSel |  |  |
| Relax the contents of the cell inside its own periodic surroundings: the neighbouring images are built, held still, and the cell's atoms are minimised against them. Pick atoms first to relax only those. | title #btnMinPeriodic |  |  |
| Renumber the structure so the picked atoms come first, in this order, and the rest follow — the way a constraint or a scan is written for Gaussian and ORCA. One whole-structure undo. | title #selListReorder |  |  |
| Scrub the structure between where it was before the last edit (left) and after it (right). The force-field energy of the geometry under the slider is printed; UNDO still takes the whole edit back. | title #energyR |  |  |
| Select atoms by rule: all, by element, by number, by an expression such as Fe(<2.4A) or M(Cl), or grow what is picked through the bonds. Atom numbers are 1-based and count atoms only — a PDB's TER lines do not count. | title #selPick |  |  |
| Settings that change how the page behaves. Each one is also a parameter in the address, so a setting can be sent along with a link. | title #btnOptions |  |  |
| Show one chain at a time – for finding a ligand or a subunit in a complex | title #selChain |  |  |
| Size of the Ketcher toolbars. Smaller gives the drawing more room on a laptop; larger is for a tablet, where the tools are the thing you have to hit. | title #selUiScale |  |  |
| Stretch or squeeze the distance between the two picked atoms, as a percentage of what it was when you picked them | title #geoBondR |  |  |
| Take the geometry shown into the page as the current structure | title #resUse |  |  |
| Take the structure on screen and its cell as a P1 asymmetric unit — then repeat it as a supercell | title #crysFromView |  |  |
| The atoms picked in the 3D view become a substituent: the one bonded to the rest is the attachment atom | title #fragFromPicked |  |  |
| The colour of the picked atoms, and of the next mark you keep. Magenta and cyan match no element; yellow is sulfur's colour, orange phosphorus's, green the halogens' — the double mark stays visible over any of them. | title #selMarkColour |  |  |
| The fourth quantity, which follows the selection: two atoms picked — twist about the bond; three — the A–B length; four — the B–C length | title #geoMoreR |  |  |
| The mirror of pMODEL: hold the picked atoms — the model — exactly where they are and relax the REST around them: the shell of it within the distance set in OPTIONS, cut from what lies further out and capped there. How the surroundings settle around a fixed piece. | title #btnPRest |  |  |
| The optimisation steps and the vibrational modes this output file contains: energy against step, a small viewer for any step, the frequencies animated, and USE THIS GEOMETRY to take a step into the page | title #btnResults |  |  |
| The size of the text in this panel, on this device — the note itself is not changed | title #selNoteSize |  |  |
| The substituent that REPLACE puts in place of the hydrogen you click. The built-in list is worm4's; LIBRARY… adds your own from XYZ text or a fragments_user.xyz file. | title #selFrag |  |  |
| Turn the two ends about the middle bond of the four picked atoms, in degrees from where it was | title #geoDihR |  |  |
| Undo everything: back to the structure as it was opened or made | title #btnResetAll |  |  |
| Undo the last change to the structure — a dragged atom, a bond, a minimisation, CELL EXTEND | title #btnUndo |  |  |
| What is drawn while paused: the model, the rest, or everything | title #pauseView |  |  |
| What stands in for a cut bond: a hydrogen, or a methyl (a carbon where the cut atom was, with three hydrogens). Rebuilt on the spot; CONTINUE runs with what is shown. | title #pauseTail |  |  |
| Whole molecules move together and a molecule on a face keeps a few atoms outside; or every atom is forced inside, which tears any molecule that crosses a face. | title #selCellFix |  |  |
| Your own substituents: edit them as XYZ text, import a fragments_user.xyz, save the picked atoms as one, download the library | title #btnFragLib |  |  |
| Closer than a bond: the new atom is crowded. MINIMIZE will push it out, or UNDO. | tr() |  |  |
| Move the picked atom along this axis, in ångström from where it was when you picked it | tr() |  |  |
| Nothing with a cell is on screen. Open a CIF or a POSCAR first. | tr() |  |  |
| scrubs the geometry; the energies wait for the switch | tr() |  |  |
| scrubs the geometry; too large for a live energy | tr() |  |  |
| The picked atoms must be joined to the rest by exactly one bond — that bond is where the group attaches. | tr() |  |  |
| Turn one side about the picked bond, in degrees | tr() |  |  |
| This service asks for a moment before a shared drawing opens. | waitBox() |  |  |
