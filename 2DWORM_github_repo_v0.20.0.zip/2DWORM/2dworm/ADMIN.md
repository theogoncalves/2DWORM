# Running the 2D-WORM sharing service

Everything on this page concerns `QRsharing/` — the optional PHP service behind **SHORT LINK**.
The drawing application itself needs no administration at all: it is a static page.

---

## Getting in

There are **two locks**, and the outer one is not a password.

**1. The file switch.** `QRsharing/admin.php` answers a plain **404** — exactly as a missing
file would — unless a file called `.admin-enabled` sits next to it. Create it with your host's
file manager when you want to log in, and **delete it when you have finished**. For most of the
year the door is not locked; it is not there. Nothing to find, nothing to probe, nothing to
brute-force.

**2. The password.** **There is no default password — you set one, once.** Until you do, the
login page says *"No administrator password is configured"* and nothing will let you in, which
is the correct behaviour for a fresh installation.

In a shell, in the `QRsharing` folder:

```
php set-password.php
```

It asks for a password, writes `config.php` with the bcrypt hash of it, and stops. **Delete
`set-password.php` afterwards**, like `setup-check.php`. It refuses to run from a browser — a
page that sets the administrator password must not be reachable over the web — and it refuses
to replace a password that is already set unless you add `--force`. An existing `config.php`
keeps all its other settings.

If you would rather do it by hand, generate the hash:

```
php -r '$p = rtrim(fgets(STDIN)); echo password_hash($p, PASSWORD_DEFAULT), "\n";'
```

and create `QRsharing/config.php` containing exactly:

```php
<?php return [
    'admin_hash' => '$2y$12$……the hash……',
];
```

**Single quotes around the hash, always.** A bcrypt hash is full of `$` characters; inside a
double-quoted PHP string they are read as variable names and the hash silently becomes
rubbish — the login then refuses a password that is correct, with nothing to say why.

The password itself is never stored, never in the repository, and never sent to the browser.

Three wrong answers in an hour and the door shuts for the rest of that hour. A session lasts
two hours and then asks again. Every button that changes something carries a CSRF token, so a
form left open in another tab cannot be used against you.

---

## What each part of the page tells you

### Stores

Three databases, and the difference between them is what gets deleted when space runs out.

| Store | Holds | When it is full |
|---|---|---|
| **Small** | ordinary drawings, up to 20 kB | the least recently **opened** entries go |
| **Large** | drawings with a pasted picture, to 500 kB | the same, at a much lower row limit |
| **Permanent** | whatever you put there by hand | **never pruned** |

Each card shows how many entries it holds and **what percentage of its limit** that is. An
entry not opened for two years is deleted wherever it lives except the permanent store.

### All time

Five figures that answer "how much has this been used, ever": links **made** and **opened**
since counting began, how many drawings are **held right now**, how many **countries** have
appeared, and how many **days** have any activity at all.

"Links made" counts every share ever, including ones long since pruned; "drawings held now" is
what is in the databases at this moment. The gap between the two is what the rotating stores
have dropped — which is the honest measure of how hard they are working.

### Per month

The same two series by month, up to two years back. Compare the bars, not the numbers: the
question a monthly chart answers is *is it growing*, and that is what decides whether the store
is big enough. The daily chart below answers a different question — *is it busy today*.

### Per year

The same two series again, one row per year, kept for as long as the service runs. A day
answers *is it busy today*, a month *is it growing*, a year *was last year bigger than the one
before* — and after a decade the year is the only one of the three still worth looking at.

### What is used

Which parts of the page people actually press: MAKE 3D, MINIMIZE, SHARE, the QR code, VR, and
so on. All time, a share of the total, and this month beside it. **This is the table that tells
you what to keep.** A feature at 0.2 % after a year is a feature you are maintaining for
nobody; one at 30 % is worth the next week of work.

Read it as *presses*, not *people*: one person who presses MAKE 3D forty times is forty. That
is the right unit for deciding what to maintain and the wrong one for saying how popular
something is, and there is deliberately no way to convert between the two.

How it gets there: the page adds up what was used and posts one small batch every couple of
minutes, and once more when the tab closes — never a request per action, which would both slow
the page and look like tracking. Only names from a fixed list are accepted (`DW_FEATURES` in
`count.php`); anything else is discarded, so the table cannot be used as a place to write
arbitrary text. Add a feature to that list and to `used(...)` in `index.html` and it starts
counting; nothing else is needed.

### Devices and headsets

Two more tables: the **platform** the page is running on (Windows, Mac, Android, iOS, Linux,
ChromeOS, "Android (headset)") and, for anyone who actually entered an immersive session, the
**headset** (Meta Quest, PICO, Vision Pro, Wolvic, "other headset").

Three things to hold on to when reading them:

- **The three tables cannot be joined, and that is the design, not an oversight.** There is a
  count of Quests today, a count of Androids today and a count of visits from a country today,
  and nothing relates them. A single row saying "this country, this headset, this platform,
  today, one" would be one identifiable person. That row does not exist and cannot be
  reconstructed from the rows that do.
- **A Quest is Android**, so it appears in both tables. Never add them together.
- **WebXR does not tell a page which headset it is on** — deliberately, to stop fingerprinting.
  The model comes from the user-agent string, which a headset can be told to disguise, so treat
  the headset figures as indicative. The user-agent string itself never reaches the database: it
  becomes one word from a short list at the moment it arrives, because a full one is close to a
  fingerprint.

`count_usage => false` in `config.php` switches every counter off, including the country one;
the endpoint then answers `{"ok":true,"counting":false}` and stores nothing at all.

### How busy can it get before the hosting has to grow?

This section deliberately refuses to print a number. No address and no session is stored, so
there is nobody to count; and a first visit is about 17 MB of static files served straight by
the web server without PHP ever running, so these figures see only the sharing endpoint and
would badly under-report the load that decides the hosting plan. For that, use the web server's
own statistics — cPanel ▸ Awstats or Webalizer — which count every request.

### Written per day — and the total

The two bars are links **made** and links **opened**; the third column is the **total for that
day**, which is what "how busy was it" actually asks. Made and opened separately answers a
different question — how much was *written* — and until now those were the only two numbers
here. The summary underneath gives both averages.

### Written per day

Two figures per day: **links made** (each writes a row) and **links opened** (costs nothing but
a read). Underneath, the average number of new rows a day, and — at that rate — roughly how long
until the small store starts dropping its oldest entries. That last figure is arithmetic on what
has actually happened, not a forecast; and because re-sharing an identical drawing reuses its
existing row, the real rate is lower than the number shown.

If the projection ever gets short, the options in order of preference are: raise
`small_max_rows` in `config.php` (rows are small — 100 000 of them is a few hundred megabytes at
most), or let it prune, which is what it is designed to do.

### Where the visits come from — including what is not a place

Everything below five, and every country with no position on the map, is folded into
**Other** — and Other is now drawn on the map as well, as a **square in the bottom-left
corner**, sized on the same scale as the circles. Before, it appeared only in the table
underneath, so a map showing four circles could be hiding a third of the visits and looked
complete.

It is a square rather than a circle exactly so that nobody reads it as a country.

### Where the visits come from

A circle for each country, placed where that country is, with the **area** of the circle
proportional to the number of visits — area, because that is what the eye actually compares.
Hover a circle for the exact figure. The table underneath gives every country with a count and
a percentage, and is the exact read; the map is for the shape of it.

**Nothing about this involves storing an address.** When a link is made or opened, the visitor's
address is turned into a country inside that one request and is then gone. What is written down
is a day, a country and a number. Countries with fewer than five actions, and any address the
table does not recognise, are shown as "Other", so a single visit from a small country never
becomes a fact about a person.

The country table is not shipped — the free ones come with their own licences. Download one
(see `QRsharing/geo/README.md`), put it at the path in `config.php`, and press **Rebuild the
country table**. Until you do, everything counts as "Other" and the map is empty. That is a
working state, not a broken one.

### The fifty most popular

The fifty entries with the most opens, all time, whichever store they are in — with the same
Keep / Delete / Block buttons as the list below, so nothing has to be looked up twice. Entries
nobody has opened are left out: a most-opened list padded with zeros would say nothing.

This is not a new counter. `hits` has been in the schema since it was written and the privacy
policy has always disclosed it (*"how many times it has been opened"*); the table is one
`ORDER BY` and no new promise. **Read it before you switch the retirement rule on** (below):
anything here that is a lecture, a paper or a poster you know about is a **Keep**.

### Drawings

The most recently opened 60, or a search by ID. For each one:

- **KEEP** moves it to the permanent store so it is never pruned — and never retired.
- **DELETE** removes it. The link stops working.
- **BLOCK** removes it *and* records a fingerprint of its contents, so **uploading the same
  drawing again will not bring it back**. This is what a takedown request should use.

When the retirement rule is on, both tables gain a **Retires** column with the date an armed
entry goes.

Drawings are never rendered inside the admin page. To look at one, open it in the application
in a new tab — that is the same sandbox everybody else's drawings run in, and it keeps somebody
else's content out of the page holding your session.

---

## Uploading a file

*Upload a file* takes a file from your disk — a `.2dworm.zip` session, or a plain structure
file — and stores it under a key the page makes up. Two destinations:

- **Molecule of the day** puts it in the featured list (next section), with the **title** you
  type (required — it is what visitors see) and an optional **credit**.
- **Permanent link** puts it in the permanent store of the ordinary shares database and answers
  with a short link and a key, exactly as any share has — so it gets a QR code like everything
  else. The title becomes its note. The same bytes uploaded twice are one row, promoted, not a
  second copy.

The limit is your own: `keep_max_bytes`, 50 MB by default, up to 500 MB, under Settings. The
public limits do not apply to your uploads and yours does not apply to the public. **PHP's own
`upload_max_filesize` and `post_max_size` must allow it too** — the page prints both beside the
form, and if PHP throws a body away for being over its limit the page says so in those words
rather than "that form was stale". Raise them in `php.ini`, or in a `.user.ini` in the
`QRsharing` folder if your host allows one.

**Two rules make an upload form on the most sensitive page of the site safe rather than merely
careful, and both are enforced by what the code does not contain:**

1. **The server never opens the file.** No `ZipArchive`, no unzipping, no parsing. The bytes
   are measured, the first two are looked at — `PK` means a session file, anything else is
   text — and they are stored as they are, for the page to open with the readers it already
   has. Zip-slip and zip bombs are not mitigated here; they are absent. A file over the limit
   is refused before a byte of it is read (PHP has already streamed it to a temporary file;
   the page checks the size and never touches it).
2. **The uploaded name is used for nothing.** Not as a path, not as a filename, not in a
   header — not even stored. The key is generated and the title is what is shown. When the
   page hands a featured file back, the download is named from the key and the kind.

A permanent upload is stored as `f=` followed by the bytes in base64, in the same `payload`
column as every other share. That was chosen over a new binary column because it touches
nothing: every query, the backup, block-by-fingerprint and one-row-per-drawing go on working
unchanged, at the cost of a third more space for those few rows. The page receives it through
`share.php?k=` as it receives everything else, with a `kind` field saying what it is.

---

## Molecule of the day

A **separate database** — `data/featured.sqlite`, beside the shares one — holding the entries
you upload for the page to offer to a visitor who arrives with nothing loaded. It is separate
on purpose: inside the shares database a featured entry would have needed three exemptions
(from pruning, from retirement, from the statistics); in a file of its own it needs none,
because none of those rules can reach it. It is never pruned, never retired and never counted.

The page fetches the list of offered entries from `featured.php?list=1` — cached for five
minutes — and **picks one at random itself**. Deliberately not a random endpoint: a cached
random endpoint would serve the whole world the same molecule all day. The public route opens
the database **read-only**, so a fault in the busiest path on the site cannot damage the one
database whose contents cannot be regenerated. Each entry keeps its own opens count, for
information only.

The table lists every entry, offered or not:

- **Rename** changes the title and the credit in place.
- **Disable** keeps an entry but stops offering it; **Enable** puts it back. A disabled key
  answers exactly as a missing one, so the disabled ones cannot be enumerated from outside.
- **Delete** removes it.
- **Export the featured list** downloads one JSON file — `{"version":1,"exported":…,
  "entries":[{fkey, title, credit, kind, created, enabled, blob_b64}]}` — with every file inside
  it. **This is the backup**, and the way the list moves to another server: it is the one thing
  here that cannot be regenerated. Keep it with your other backups.
- **Import a featured list** takes that file back and adds or replaces by key. A replaced entry
  keeps the opens it had. A damaged entry is skipped and named; the good ones beside it still
  go in. The file's `kind` is not believed — it is read off the bytes again.

The database is created by the first upload; until then the page says so and offers nothing,
which is a working state. `data/` is already excluded from every release archive and from the
repository, so a new build never overwrites it. Importing a large export needs roughly three
times its size in PHP memory — export in batches if that is ever a problem.

---

## Adding an entry by hand

Open the drawing in the application, press **SHARE**, choose **FULL LINK**, and copy the whole
thing. Paste it into *Add an entry by hand*, give it a name — `toluene`, `lecture`, `acs2026` —
and it is stored in the permanent store under that name.

That is how a teaching example, a figure for a paper or a demonstration gets an ID that will
still work in two years, when the rotating stores have dropped everything else. The name may be
4 to 24 letters and digits; leave it empty for a random one.

A **short link** (`?k=…`) cannot be used here — it has no drawing inside it, only a key. Open it
first, then share it as a full link.

If the drawing is already stored, that same row is promoted rather than a second copy being
made — one row per drawing, always, because a takedown blocks by content and two rows would
mean blocking only one of them.

---

## Removing an entry

- **One drawing:** find it by ID and press DELETE, or BLOCK if it should not come back.
- **Someone's own drawing, on request:** they send the ID; DELETE is enough.
- **Everything old:** press **Prune now** under Housekeeping. It applies the same rules the
  service applies by itself, immediately.
- **Everything, at once:** delete `QRsharing/data/shares.sqlite`. It is rebuilt empty on the
  next request. Take a backup first. The featured list is in `featured.sqlite` beside it and
  is untouched by this — export it before you delete that one.

---

## Keeping unwanted people out

What is already in place, and what is left to you.

**In place:**

- The admin page does not exist without `.admin-enabled`. This is the strongest control here,
  and it costs nothing — *delete the file when you are not using it.*
- A bcrypt password, an hourly lockout, a two-hour session, CSRF on every action, and a session
  cookie that is `HttpOnly`, `SameSite=Strict` and `Secure` over HTTPS.
- A strict `Content-Security-Policy` on the admin page: no scripts at all, no images from
  anywhere but this server, forms may only post back here, and the page cannot be framed.
- `QRsharing/data/` carries its own `.htaccess` denying direct access, so the database cannot be
  downloaded even if someone guesses its path.
- Rate limits per address per hour, without keeping the address (see the privacy policy).
- A payload that is not a 2D-WORM drawing is refused before it reaches the database, and every
  key is validated as plain letters and digits before it is used in a query.

**Left to you, in order of how much it matters:**

1. **Serve the site over HTTPS.** Without it the admin password crosses the network in the
   clear and everything else here is beside the point. Every host offers a free certificate.
2. **Delete `.admin-enabled` after each session.** A habit worth more than any password.
3. **Use a password you use nowhere else**, and change it if it was ever typed on a machine you
   do not control. If a hash was ever committed to the repository, **change the password** —
   deleting the file does not remove it from git history.
4. **Keep `config.php` out of the repository.** `.gitignore` already excludes it, `data/`,
   `*.sqlite*` and `.admin-enabled`. Do not add exceptions.
5. **Delete `QRsharing/setup-check.php`** once the service is working. It reports your PHP
   version and the path to the data folder, which is not information a stranger needs.
6. **Take the backup occasionally.** *Download a backup* under Housekeeping writes a consistent
   snapshot with `VACUUM INTO`, which is safe to run while the service is in use — copying the
   `.sqlite` file by hand is not, because it misses whatever is still in the write-ahead log.
7. **If something goes wrong, use the kill switch.** *Stop storing new drawings* under
   Housekeeping leaves every existing link working and refuses new ones, with a reason the page
   shows to visitors. It is the right response to abuse or to a full disk, and it is reversible.

**What no amount of configuration will protect you from:** the sharing service is open to
anyone who can reach the page, by design — there are no accounts. Somebody can therefore store
things you would rather they had not. That is what BLOCK, the banner, the kill switch and the
takedown address in `TERMS.md` are for, and why pasted pictures are re-encoded and size-limited
before they are ever stored.

---

## Housekeeping, briefly

| Control | What it does |
|---|---|
| **Banner** | a line shown to every visitor of the application — use it for planned downtime |
| **Stop storing new drawings** | existing links keep working; new ones are refused with your reason |
| **Prune now** | applies the size, age and retirement rules immediately instead of eventually |
| **Download a backup** | a consistent `.sqlite` snapshot of the shares database, safe while the service is running |
| **Export the featured list** | the featured database as one JSON file, files included — its backup |
| **Rebuild the country table** | re-imports the geo CSV named in `config.php` |

---

## Settings, from the page

There is a **Settings** section on the admin page with every limit and every wait in it. Two
things about it are worth understanding before you touch it.

**They live in the database, not in `config.php`.** A web page that can rewrite an executable
PHP file turns *somebody got into the admin page* into *somebody runs code on the server*, and
that is a different order of problem. The consequence you will meet in practice: **a value
saved on the page wins over `config.php`**, so if you edit that file afterwards and nothing
changes, this is why. Clear a box and save, and the setting goes back to `config.php`, or to
the shipped default if that file does not set it. The *Where it comes from* column tells you
which of the three is in force for every row, and **Forget all of these** clears the lot.

**Five settings are deliberately not on the page** and can only be changed by editing
`config.php` by hand: `admin_hash`, `db_path`, `geo_csv`, `page_url` and `short_base`. Anyone
who got into the admin page could otherwise change the password, point the service at another
database, read a file of their choosing, or send every link anybody shares to a site of their
own.

**Saving a smaller limit changes what is accepted from then on and nothing else.** Nothing
already stored is touched, because a mistyped figure in a number field must not delete
somebody's work. **PRUNE NOW**, further down, does the deletion — and says first how many
entries and how many megabytes it would remove.

### The two waits are not the same kind of thing

`small_wait` and `large_wait` are paid by whoever is *storing* a drawing, which is the point:
one person cannot fill the database faster than a person could draw.

`read_wait` would be paid by the colleague who was sent a link and by whoever is scanning your
poster with a phone. **It ships at zero and should usually stay there.** What actually stops
somebody copying the whole store by walking the key space is `read_per_hour` — a ceiling, which
that person hits and an ordinary reader never does. Turn the wait on only if you see abuse a
ceiling did not stop. Both waits are enforced with a signed ticket rather than by holding the
request open: a `sleep()` occupies a PHP worker for its whole duration, so a handful of
requests would take the service down far more cheaply than the abuse being prevented.

### Switching the store off

`store_on` is the switch. Turn it off and **no new short link or QR code can be made** — the
page tells whoever tried, in as many words, and points them at the FULL LINK instead.

What it deliberately does **not** do:

- **Everything already stored still opens.** A QR code printed on a poster or pressed into a
  slide cannot be recalled, and breaking those is not a thing you would ever want a switch to
  do quietly.
- **A FULL LINK is unaffected in either direction.** It carries the whole drawing inside
  itself and never reaches this server at all, so people can go on sharing while the store is
  shut.

Turn it off to take the service down for maintenance, to stop accepting new material while
you decide something, or simply because you would rather not run a store any more — without
breaking anything already out in the world. Before this existed the only way was to delete
the folder, and setting every limit to zero does the opposite: zero means *no limit* in three
of them.

### Retiring a popular code

Off by default. `retire_hits` (0 = never) and `retire_days` (1 to 3650, 30 by default).

A code opened two hundred times is no longer somebody sharing a drawing with a colleague; it is
a published resource, and publishing is a bigger commitment than this service makes for
nothing. You may decline to be its permanent host. That is legitimate **because it is
announced before the code is printed**: the page shows the QR sentence — *a QR code here is not
permanent … write to contact@dworm.org … FULL LINK and SAVE SESSION never expire* — beside every
code it makes, and `TERMS.md` says the same. The sentence is not decoration; it is what makes
the rule honest, and the suite holds the two to each other.

How it works, precisely:

- **The count never deletes anything.** When an entry's opens reach `retire_hits`, the next
  open **arms a timer**: `retire_at` is set to now plus `retire_days`. The entry goes on
  working. The two-hundredth scan of a poster is never the one that gets a blank screen.
- **The sweep removes it once the timer has run out** — the same sweep that prunes, so it
  runs by itself and under *Prune now*. An open after the date does the same without waiting.
- **The permanent store is exempt at every step**: never armed, never removed, and **Keep**
  on an armed entry cancels its timer. That is the whole of "arranged with the operator".
- **A retired code explains itself.** The key is remembered (a key and a time, nothing else)
  so that `share.php` can answer *retired*, with the contact address, instead of a bare 404.
- **Switching the rule off cancels every pending timer**, and the page says how many. A timer
  left over from when the rule was on means nothing while it is off.

Both tables gain a **Retires** column while the rule is on, and the *fifty most popular*
section says how many entries are scheduled. Read that list first: anything you know to be a
lecture, a paper or a poster is a Keep.

### The upload ceiling

`keep_max_bytes` — 50 MB by default, 1 kB to 500 MB — is the largest file **you** may upload
from this page, for the featured list or as a permanent link. It has nothing to do with the
public limits above, in either direction. PHP's own `upload_max_filesize` and `post_max_size`
have to allow it as well.

Every other setting now carries a sentence beside it on the page saying what it does. A page
of eighteen numbers with no explanation is a page nobody dares change anything on, which comes
to the same thing as not being able to change it.

### When the page warns you about TERMS.md

`TERMS.md` tells your visitors that a stored drawing is deleted after two years, that storing
one waits a few seconds and a large one longer, and it does *not* tell them that opening one
makes them wait. Change any of those settings and a red panel appears at the top of the
Settings section naming the sentence that has stopped being true. Change the setting back, or
edit `TERMS.md` — a privacy policy that has quietly stopped describing the service is worse
than none. The build fails if the shipped defaults and the policy ever disagree; the live
settings are yours, so there you get a warning rather than a refusal.

## Settings, from the file

Everything is optional; `QRsharing/config.example.php` lists them all with their defaults. The
ones worth knowing:

| Setting | Default | What it is |
|---|---|---|
| `admin_hash` | none | bcrypt hash of the admin password — **without it, nobody can log in** |
| `admin_max_tries` | 6 | failed attempts per hour before the door shuts |
| `small_max_rows` | 100000 | rows before the small store starts pruning |
| `large_max_rows` | 2000 | the same for the large store |
| `small_wait` | 10 | seconds the server makes an ordinary upload wait, enforced server-side |
| `large_wait` | 60 | the same for a large one — a drawing with a picture in it |
| `max_age_days` | 730 | delete anything not opened for this long |
| `rate_per_hour` | 60 | short links per address per hour |
| `read_per_hour` | 600 | opens per address per hour; 0 = no ceiling |
| `read_wait` | 0 | seconds before a stored drawing opens. Leave at 0 |
| `count_usage` | true | every counter on this page: day + label + number, never an address |
| `retire_hits` | 0 | opens after which a code arms its retirement timer; 0 = never |
| `retire_days` | 30 | days between reaching that count and removal |
| `keep_max_bytes` | 50 MB | the largest file you may upload from the admin page |
| `geo_csv` | `geo/ip2country.csv` | where the country table is read from |
| `db_path` | `data/shares.sqlite` | move it outside the web root if your host allows; `featured.sqlite` lives beside it |

---

Questions, and anything that looks wrong: **contact@dworm.org**.
