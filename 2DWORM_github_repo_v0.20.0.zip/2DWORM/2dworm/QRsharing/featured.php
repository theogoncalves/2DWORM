<?php
/* featured.php — the "molecule of the day": the public side of the featured database.
 * Copyright (C) 2026 Theo P. Goncalves
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * Two requests and nothing else:
 *
 *   GET featured.php?list=1     every ENABLED entry, as a JSON array —
 *                               [{fkey, title, credit, kind, bytes}, ...] — cacheable for
 *                               five minutes. The page picks one AT RANDOM from that list
 *                               itself. Deliberately not `ORDER BY RANDOM()` here: a cached
 *                               random endpoint would serve the whole world the same
 *                               molecule all day, while a cached LIST costs one request and
 *                               leaves the randomness where it is free.
 *   GET featured.php?key=<fkey> the entry's bytes, exactly as the operator uploaded them,
 *                               as application/octet-stream and an attachment. The page
 *                               opens them with its own readers — a session file if `kind`
 *                               said so, text otherwise. The filename in the header is made
 *                               from the KEY and the KIND and from nothing else: the name
 *                               of the file the operator uploaded was never stored.
 *
 * WHY THIS FILE IS NOT share.php WITH A PARAMETER. The featured entries live in a database
 * of their own (data/featured.sqlite), and a route of their own keeps the two key spaces
 * from ever touching, so a featured key and a share key cannot be confused for each other.
 * See lib/core.php, "the featured database", for why the file is separate at all.
 *
 * READ-ONLY, BY CONSTRUCTION. This is the busiest kind of path on the site and the file it
 * reads is the one whose contents cannot be regenerated. So the list and the entry are read
 * on a connection opened with SQLite's read-only flag: whatever this script did wrong, it
 * could not write. The one write — bumping `hits` and `seen` so the operator can see which
 * of his molecules people open — happens afterwards, on a second connection opened
 * read-write, best-effort, and never creating the file. When the database does not exist
 * yet the list is simply empty; this route never creates it.
 *
 * NOTHING ABOUT THE VISITOR. No counter here is per person, no address is looked at, and
 * this endpoint is not in the usage statistics at all — the featured list is the operator's
 * own material, and opening it says nothing about anybody.
 */

declare(strict_types=1);
require __DIR__ . '/lib/core.php';

$CFG = dw_config();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'OPTIONS') {
    http_response_code(204);
    header('Allow: GET, OPTIONS');
    dw_headers();
    exit;
}
if ($method !== 'GET' && $method !== 'HEAD') {
    dw_out(['ok' => false, 'error' => 'get_only'], 405, ['Allow: GET, OPTIONS', 'Cache-Control: no-store']);
}

/* --- the list --------------------------------------------------------------- */
if (isset($_GET['list'])) {
    $out = [];
    try {
        $db = dw_featured_db($CFG, 'ro');
        $q = $db->query('SELECT fkey, title, credit, kind, bytes FROM featured WHERE enabled = 1 ORDER BY created ASC, fkey ASC');
        foreach ($q as $r) {
            $out[] = ['fkey' => (string) $r['fkey'], 'title' => (string) $r['title'], 'credit' => (string) $r['credit'],
                      'kind' => (string) $r['kind'], 'bytes' => (int) $r['bytes']];
        }
    } catch (Throwable $e) {
        /* no featured database yet, or no table in it: an empty list, and nothing created.
           A visitor with nothing to draw is simply not offered anything. */
        $out = [];
    }
    http_response_code(200);
    header('Content-Type: application/json; charset=utf-8');
    dw_headers();
    header('Cache-Control: public, max-age=300');
    echo json_encode($out, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/* --- one entry -------------------------------------------------------------- */
if (isset($_GET['key'])) {
    $key = (string) $_GET['key'];
    if (!dw_valid_key($key)) { dw_fail('bad_key', 'This is not a valid key.', 400); }
    $row = null;
    try {
        $db = dw_featured_db($CFG, 'ro');
        /* a disabled entry answers exactly as a missing one, so the disabled ones cannot be
           enumerated from outside */
        $st = $db->prepare('SELECT blob, bytes, kind FROM featured WHERE fkey = ? AND enabled = 1');
        $st->execute([$key]);
        $row = $st->fetch();
        /* RELEASE THE READ before the write below. A fetched-but-not-finished statement
           keeps SQLite's shared lock on the file, and with the rollback journal that lock
           stops any writer — including our own second connection, which then waits out its
           busy timeout and gives up. Closing the cursor ends the read; found the hard way. */
        $st->closeCursor();
        unset($st);
    } catch (Throwable $e) {
        $row = null;
    }
    if (!$row) { dw_fail('not_found', 'There is no featured entry with this key.', 404); }

    /* The count, on a handle of its own, after the read. Best-effort: a hits figure that is
       occasionally one short is worth nothing next to a download that fails because a
       counter could not be written. */
    try {
        $rw = dw_featured_db($CFG, 'rw');
        $rw->prepare('UPDATE featured SET hits = hits + 1, seen = ? WHERE fkey = ?')->execute([time(), $key]);
    } catch (Throwable $e) { /* counting must never break the service */ }

    $bytes = (string) $row['blob'];
    $ext = ((string) $row['kind'] === 'session') ? '2dworm.zip' : 'txt';
    http_response_code(200);
    dw_headers();                                                // nosniff among them
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . strlen($bytes));
    /* the key and the kind only — both validated, neither ever typed by anybody */
    header('Content-Disposition: attachment; filename="' . $key . '.' . $ext . '"');
    header('Cache-Control: public, max-age=300');
    if ($method !== 'HEAD') { echo $bytes; }
    exit;
}

dw_fail('bad_request', 'Unknown request.', 400);
