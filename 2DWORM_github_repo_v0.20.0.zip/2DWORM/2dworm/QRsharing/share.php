<?php
declare(strict_types=1);
/**
 * 2D-WORM — short link / QR sharing service
 * ---------------------------------------------------------------------------
 * Stores the compressed drawing state that a self-contained link would otherwise
 * carry in its URL, and hands out a short random key instead, so the QR code stays
 * small enough to scan from a poster or a screen.
 *
 *   GET  share.php?status         what the service offers (the page asks before
 *                                 showing the SHORT LINK button at all)
 *   POST share.php                body = payload ("z=…" or "s=…"), returns {key, url}
 *                                 A large payload is answered once with a ticket and a
 *                                 wait; send it again with X-DW-Ticket when the wait
 *                                 is over.
 *   GET  share.php?k=<key>        returns {payload}; a payload starting `f=` is a file the
 *                                 operator uploaded (base64), and `kind` says what it is
 *
 * Every answer that hands out a link — the status, and a stored drawing — also carries
 * `notice`: the sentence the page shows beside a QR code, saying that a code is not
 * permanent and what to do about that. And a key that was RETIRED (opened more often than
 * the operator's rule allows, then removed after its notice) answers `retired`, 410, with
 * the contact address — never a bare 404, because a dead code on a poster that says who to
 * write to is a different thing from one that says nothing.
 *
 * The payload is opaque here: the server never decodes it, so it never has to
 * understand the drawing format, and a stored drawing reveals nothing to it.
 * See lib/core.php for the three stores and for what is and is not recorded.
 */

require __DIR__ . '/lib/core.php';

$CFG = dw_config();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'OPTIONS') {
    http_response_code(204);
    header('Allow: GET, POST, OPTIONS');
    dw_headers();
    exit;
}

/* --- what the service offers --------------------------------------------- */
if (isset($_GET['status'])) {
    $info = [
        'ok'         => true,
        'service'    => DW_SERVICE,
        'version'    => DW_VERSION,
        // the page shows the larger figure as the limit and asks for a ticket above the smaller one
        'max_bytes'  => $CFG['large_max_bytes'],
        'small_bytes'=> $CFG['small_max_bytes'],
        'wait'       => $CFG['large_wait'],
        'small_wait' => $CFG['small_wait'],
        'read_wait'  => $CFG['read_wait'],
        'notes'      => (bool) $CFG['allow_notes'],
        'short_base' => $CFG['short_base'],
        'page_url'   => dw_page_url($CFG),
        /* the QR sentence, and the figures behind it when the retirement rule is on
           (both zero when it is off, which is the shipped state) */
        'notice'     => DW_QR_NOTICE,
        'retire_hits'=> (int) $CFG['retire_hits'],
        'retire_days'=> (int) $CFG['retire_hits'] > 0 ? (int) $CFG['retire_days'] : 0,
    ];
    try {
        $db = dw_db($CFG);
        $off = dw_offline($db);
        if ($off !== '') { $info['offline'] = $off; }
        $banner = dw_meta($db, 'banner');
        if ($banner) { $info['banner'] = $banner; }
    } catch (Throwable $e) {
        dw_fail('storage', 'The sharing store is not available.', 503);
    }
    dw_out($info, 200, ['Cache-Control: no-store']);
}

/* --- store a drawing ------------------------------------------------------ */
if ($method === 'POST') {
    /* THE STORE CAN BE CLOSED. Checked before anything is read from the body, so a closed
       store costs nothing to refuse. Only NEW drawings are stopped: a GET below still hands
       back everything already stored, so every QR code already printed on a poster goes on
       working — which is the whole reason somebody made one. A FULL LINK never reaches here
       in either direction, and the message says so rather than leaving the person thinking
       they cannot share at all. */
    if (empty($CFG['store_on'])) {
        dw_fail('store_closed',
            'This service is not storing new drawings at the moment, so a short link and a QR code ' .
            'cannot be made. Use the FULL LINK instead — it carries the whole drawing inside itself ' .
            'and needs no server. Links already made still open normally.', 503);
    }
    $hard = (int) $CFG['large_max_bytes'] + 2048;
    if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > $hard) {
        dw_fail('too_large', 'This drawing is larger than the sharing service accepts.', 413);
    }
    $payload = trim((string) file_get_contents('php://input', false, null, 0, $hard));
    if ($payload === '')                  { dw_fail('empty', 'Nothing to store.', 400); }
    if (strlen($payload) > $CFG['large_max_bytes']) {
        dw_fail('too_large', 'This drawing is larger than the sharing service accepts.', 413);
    }
    if (!dw_valid_payload($payload))      { dw_fail('bad_payload', 'This does not look like a 2D-WORM drawing.', 400); }

    $db = dw_db($CFG);
    $off = dw_offline($db);
    if ($off !== '') { dw_fail('offline', $off, 503); }

    $bytes = strlen($payload);
    $store = $bytes <= $CFG['small_max_bytes'] ? 'small' : 'large';
    $hash  = hash('sha256', $payload);

    if (dw_blocked($db, $hash)) {
        dw_fail('blocked', 'This drawing cannot be shared. If you believe that is a mistake, please write to ' . DW_CONTACT . '.', 403);
    }

    // The same drawing shared twice keeps its key, and costs no wait the second time.
    $st = $db->prepare('SELECT skey FROM shares WHERE hash = ?');
    $st->execute([$hash]);
    $key = $st->fetchColumn();
    if ($key !== false && $key !== null) {
        $db->prepare('UPDATE shares SET seen = ? WHERE skey = ?')->execute([time(), $key]);
        dw_count($db, $CFG, 'create');
        dw_out(['ok' => true, 'key' => $key, 'url' => dw_short_url($CFG, (string) $key),
                'store' => $store, 'deduped' => true, 'notice' => DW_QR_NOTICE], 200, ['Cache-Control: no-store']);
    }

    if (!dw_rate_ok($db, $CFG, 'create', (int) $CFG['rate_per_hour'])) {
        dw_fail('rate_limited', 'Too many short links from this address in the last hour. Use the full link, or try again later.', 429);
    }

    /* Storing costs a wait, and the wait is enforced here rather than in the browser: the
       first attempt gets a signed ticket, and only a ticket that is old enough — and belongs
       to this exact drawing — is accepted. A large drawing costs a long one; an ordinary
       drawing costs a short one, which nobody notices but which makes a script that stores
       thousands of rows in a minute impossible. Set either to 0 to switch it off. */
    $wait = (int) ($store === 'large' ? $CFG['large_wait'] : $CFG['small_wait']);
    if ($store === 'large' && !dw_rate_ok($db, $CFG, 'large', (int) $CFG['large_per_hour'])) {
        dw_fail('rate_limited', 'Too many large drawings from this address in the last hour. Try again later, or use the full link.', 429);
    }
    if ($wait > 0) {
        $ticket = (string) ($_SERVER['HTTP_X_DW_TICKET'] ?? '');
        if ($ticket === '') {
            dw_out(['ok' => false, 'error' => 'wait', 'wait' => $wait,
                    'ticket' => dw_ticket_issue($db, $hash), 'bytes' => $bytes,
                    'message' => $store === 'large'
                        ? 'This drawing is a large one. Sharing it takes a moment.'
                        : 'Sharing takes a moment.'],
                   202, ['Cache-Control: no-store']);
        }
        $why = dw_ticket_check($db, $hash, $ticket, $wait);
        if ($why !== '') {
            dw_out(['ok' => false, 'error' => 'wait', 'wait' => $wait,
                    'ticket' => dw_ticket_issue($db, $hash), 'bytes' => $bytes,
                    'message' => 'Please try that again (' . $why . ').'],
                   202, ['Cache-Control: no-store']);
        }
    }

    $now = time();
    $ins = $db->prepare('INSERT INTO shares (skey, hash, payload, bytes, store, created, seen, hits)
                         VALUES (?, ?, ?, ?, ?, ?, ?, 0)');
    for ($try = 0; $try < 6; $try++) {
        $key = dw_key((int) $CFG['key_len'] + intdiv($try, 3));   // widen after a few collisions
        try {
            $ins->execute([$key, $hash, $payload, $bytes, $store, $now, $now]);
        } catch (PDOException $e) {
            $st->execute([$hash]);                               // someone stored it a moment ago
            $other = $st->fetchColumn();
            if ($other !== false && $other !== null) {
                dw_out(['ok' => true, 'key' => $other, 'url' => dw_short_url($CFG, (string) $other),
                        'store' => $store, 'deduped' => true, 'notice' => DW_QR_NOTICE], 200, ['Cache-Control: no-store']);
            }
            continue;                                            // key collision: try another
        }
        dw_retired_forget($db, $key);                            // this key now means this drawing
        if (random_int(1, 20) === 1) { dw_prune($db, $CFG); }
        dw_count($db, $CFG, 'create');
        dw_out(['ok' => true, 'key' => $key, 'url' => dw_short_url($CFG, $key),
                'store' => $store, 'deduped' => false, 'notice' => DW_QR_NOTICE], 201, ['Cache-Control: no-store']);
    }
    dw_fail('storage', 'Could not store the drawing, please try again.', 503);
}

/* --- read a drawing ------------------------------------------------------- */
if (isset($_GET['k'])) {
    $key = (string) $_GET['k'];
    if (!dw_valid_key($key)) { dw_fail('bad_key', 'This is not a valid sharing key.', 400); }
    $db = dw_db($CFG);
    /* A CEILING, NOT A DELAY. What this is for is somebody walking the key space to copy the
       store; seconds do not inconvenience that and a ceiling does. Meanwhile a delay would be
       paid entirely by the colleague who was sent the link and by whoever is scanning a poster
       with a phone, which is the thing the whole service exists to make easy. The address is
       never stored: dw_rate_ok keeps a salted hourly hash of it and nothing else. */
    if (!dw_rate_ok($db, $CFG, 'read', (int) $CFG['read_per_hour'])) {
        dw_fail('rate', 'Too many drawings opened from here in the last hour. Try again shortly.', 429);
    }
    /* And, only if the operator has switched it on, a wait. Never sleep(): a request held open
       for ten seconds occupies a PHP worker for ten seconds, so a handful of them would take
       the service down far more cheaply than the abuse the wait is meant to prevent. Same
       signed ticket as a large upload — the server issues one, the page comes back with it
       when enough time has genuinely passed, and nothing is held open in between. */
    $rwait = (int) $CFG['read_wait'];
    if ($rwait > 0) {
        $ticket = (string) ($_SERVER['HTTP_X_DW_TICKET'] ?? ($_GET['t'] ?? ''));
        if ($ticket === '') {
            dw_out(['ok' => false, 'error' => 'wait', 'wait' => $rwait, 'ticket' => dw_ticket_issue($db, 'r:' . $key),
                    'message' => 'This service asks you to wait ' . $rwait . ' seconds before a shared drawing opens.'],
                   202, ['Cache-Control: no-store']);
        }
        $why = dw_ticket_check($db, 'r:' . $key, $ticket, $rwait);
        if ($why !== '') {
            dw_out(['ok' => false, 'error' => 'wait', 'wait' => $rwait, 'ticket' => dw_ticket_issue($db, 'r:' . $key),
                    'message' => 'Not yet — ' . $why . '.'], 202, ['Cache-Control: no-store']);
        }
    }
    $st = $db->prepare('SELECT payload, hash, created, seen, store, hits, retire_at FROM shares WHERE skey = ?');
    $st->execute([$key]);
    $row = $st->fetch();
    if (!$row) {
        /* Gone — but WHY it is gone is the difference between a poster that says who to
           write to and one that says nothing. A retired key is remembered; a pruned one is
           not, because it went for lack of use and the page's own sentence covers that. */
        if (dw_retired($db, $key)) { dw_fail('retired', DW_RETIRED_MESSAGE, 410); }
        dw_fail('not_found', 'This shared drawing is not on the server any more.', 404);
    }
    if (dw_blocked($db, (string) $row['hash'])) {
        dw_fail('blocked', 'This drawing is no longer available.', 403);
    }
    $now = dw_now();
    /* A timer that has run out is honoured here as well as in the sweep, so that a code
       cannot go on working for a week after its date because nothing happened to prune. The
       rule is checked, not the column alone: a timer left over from when the rule was on
       means nothing while it is off, and the next sweep clears it. */
    $retireOn = (int) $CFG['retire_hits'] > 0 && $row['store'] !== 'keep';
    if ($retireOn && $row['retire_at'] !== null && (int) $row['retire_at'] <= $now) {
        dw_retire_now($db, $key, $now);
        dw_fail('retired', DW_RETIRED_MESSAGE, 410);
    }
    if ($now - (int) $row['seen'] > 3600) {      // one "seen" write per hour and key, not per view
        $db->prepare('UPDATE shares SET seen = ?, hits = hits + 1 WHERE skey = ?')->execute([$now, $key]);
    } else {
        $db->prepare('UPDATE shares SET hits = hits + 1 WHERE skey = ?')->execute([$key]);
    }
    $retireAt = $row['retire_at'] === null ? null : (int) $row['retire_at'];
    if ($retireOn && $retireAt === null && dw_retire_arm($db, $CFG, $key, $now)) {
        $retireAt = $now + (int) $CFG['retire_days'] * 86400;   // this open was the one that armed it
    }
    dw_count($db, $CFG, 'open');
    $out = ['ok' => true, 'key' => $key, 'store' => $row['store'], 'created' => (int) $row['created']];
    /* the date a retiring code goes, so the page can say so to whoever opened it */
    if ($retireOn && $retireAt !== null) { $out['retire_at'] = $retireAt; }
    /* an operator's upload: base64 after `f=`, and what it is — a session file or text —
       read off its first bytes, so the page need not sniff a megabyte of base64 to find out */
    $payload = (string) $row['payload'];
    if (substr($payload, 0, 2) === 'f=') { $out['kind'] = dw_file_kind((string) base64_decode(substr($payload, 2, 8))); }
    dw_out_payload($out, $payload, 200,
        /* a shared drawing never changes under its key, so it caches well — but not when the
           operator has asked for a wait, or the wait is served once and skipped for ever;
           and not once it is retiring, or a cache could serve it past its date */
        [($rwait > 0 || $retireAt !== null) ? 'Cache-Control: no-store' : 'Cache-Control: public, max-age=600']);
}

dw_fail('bad_request', 'Unknown request.', 400);
