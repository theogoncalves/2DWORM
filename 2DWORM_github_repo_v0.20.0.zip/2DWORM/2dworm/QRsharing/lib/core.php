<?php
declare(strict_types=1);
/**
 * 2D-WORM sharing service — shared core.
 * Used by share.php (the public endpoint) and admin.php (the private one).
 *
 * THREE STORES, because one set of limits cannot serve three purposes:
 *   small      up to  20 KB, 100,000 entries. The ordinary case: a drawing is 1–5 KB.
 *              Least recently opened are dropped first.
 *   large      20 KB to 500 KB, 2,000 entries. A drawing with a picture in it. Storing
 *              one costs a deliberate 20-second wait, enforced by the server, so that
 *              nobody fills the store by accident or on purpose.
 *   keep       permanent, no pruning, no size limit. Nothing lands here by itself: an
 *              entry is promoted from one of the other two by the administrator, or
 *              uploaded by him as a file.
 *
 * AND A FOURTH DATABASE, IN A FILE OF ITS OWN: data/featured.sqlite, the "molecule of the
 * day" — curated entries the operator uploads and the page offers to a visitor who arrives
 * with nothing to draw. It is a separate file on purpose. Inside the shares database a
 * featured entry would have needed three exemptions (from pruning, from retirement, from the
 * statistics); in a file of its own it needs none, because none of those rules can reach it.
 * The public route opens that file READ-ONLY (see dw_featured_db), so a fault in the busiest
 * path on the site cannot damage the one database whose contents cannot be regenerated.
 *
 * RETIREMENT, off unless the operator switches it on. A code opened more than `retire_hits`
 * times is not somebody sharing a drawing with a colleague any more; it is a published
 * resource, and publishing is a bigger commitment than this service makes for nothing. The
 * count never deletes anything on the spot: it ARMS A TIMER (`retire_at`), and the sweep
 * removes the entry `retire_days` later — so the two-hundredth scan of a poster is never the
 * one that gets a blank screen, and the poster gets its notice. The key itself is remembered
 * afterwards so that the code can say it was retired, and who to write to, rather than 404.
 * TERMS.md says all of this to visitors, and the page says it beside every QR code it makes.
 *
 * PRIVACY. No IP address is ever written to disk. The rate limiter stores a salted
 * hourly hash, and the usage counter resolves a country in memory and immediately
 * discards the address. There is no session table, no visitor record, nothing per person.
 */

const DW_SERVICE  = '2dworm-qrsharing';
const DW_VERSION  = '2.1';
/** The one address every user-facing sentence points at. Kept here, in one place, and NOT
    a setting: somebody who got into the admin page must not be able to redirect every
    "write to us" in the service to an address of their own. */
const DW_CONTACT  = 'contact@dworm.org';

/* THE QR SENTENCE. Shown by the page beside every QR code it makes, sent in `status` and
   with every stored link, and printed word for word in TERMS.md — `terms.mjs` holds the two
   to each other. It says nothing about WHY a code may go: server capacity is never a
   user-facing sentence in this project. It says what a person about to print a poster needs
   to know, and it says it BEFORE the poster is printed, which is what makes the retirement
   rule below honest rather than a trap. */
const DW_QR_NOTICE = 'A QR code here is not permanent. Codes are kept while they are in use and removed when '
    . 'they are not, so one printed on a poster may stop working later. If you need one to keep '
    . 'working — for a paper, a thesis, a poster that will be up for a year — write to '
    . DW_CONTACT . ' with what it is for, who you are, how long you need it and roughly how much '
    . 'use you expect. It can be made permanent. Two alternatives that never expire and need no '
    . 'permission: FULL LINK carries the drawing inside the link itself, and SAVE SESSION gives you '
    . 'a file. For anything large, SAVE SESSION is the better choice — a file has no size limit '
    . 'and does not depend on this server at all.';

/** What a retired code answers. Not a bare 404: a dead QR code on a poster that says who to
    write to is a different experience from one that says nothing. */
const DW_RETIRED_MESSAGE = 'This code has been retired: it was opened more times than this service keeps a '
    . 'code for, and the drawing is no longer on the server. If you need it back — for a paper, a '
    . 'thesis, a poster — write to ' . DW_CONTACT . ' and quote the code.';
/** Keys avoid characters that are easy to confuse when read off a poster. */
const DW_ALPHABET = '23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
const DW_STORES   = ['small', 'large', 'keep'];

/** The shipped defaults, on their own — what the admin page shows in its "default" column,
    and what `terms.mjs` asserts the privacy policy against. */
function dw_defaults(): array
{
    return [
        'db_path'          => dirname(__DIR__) . '/data/shares.sqlite',
        // --- the small store
        'small_max_bytes'  => 20 * 1024,
        'small_max_rows'   => 100000,
        'small_wait'       => 10,          // seconds, server-enforced, for an ordinary drawing
        // --- the large store
        'large_max_bytes'  => 500 * 1024,
        'large_max_rows'   => 2000,
        'large_wait'       => 60,          // seconds the visitor must wait, server-enforced
        // --- shared
        'max_total_bytes'  => 900 * 1024 * 1024,
        'max_age_days'     => 730,
        'rate_per_hour'    => 60,          // small links per address per hour
        'large_per_hour'   => 4,           // large ones are much more expensive
        /* READING is limited but NOT delayed. A wait before a stored drawing opens is paid by
           the colleague who was sent the link and by the person scanning a poster, while the
           thing it is meant to stop — somebody walking the key space to copy the store — is
           not inconvenienced by seconds, only by a ceiling. So the ceiling ships on and the
           wait ships off, and the operator can turn the wait on if abuse ever justifies it. */
        'read_per_hour'    => 600,         // opens per address per hour; 0 = no limit
        'read_wait'        => 0,           // seconds before a stored drawing is handed over
        /* Whether the page may put a NOTE inside a drawing it stores here. Off, because free
           text plus anonymity plus a clean URL on somebody else's domain is the recipe for a
           link shortener, and the damage would not be content sitting in a database — it
           would be dworm.org becoming the wrapper around somebody's phishing link and the
           whole domain being flagged. This is a REQUEST TO THE PAGE and is honest about that:
           a stored drawing is compressed and opaque here, so the server cannot check. What
           the server can and does refuse is a payload with no drawing in it, which is what
           removes the pastebin use altogether. FULL LINK carries a note in the fragment,
           which never reaches any server, and is unaffected. */
        'allow_notes'      => false,
        /* WHETHER NEW DRAWINGS ARE STORED AT ALL. There was no way to turn the service off
           short of deleting the folder, and "set every limit to zero" does not do it — zero
           means NO LIMIT in three of them, so it does the opposite.

           Off stops NEW short links and QR codes. It deliberately does NOT stop opens: every
           QR code already printed on a poster or a slide goes on working, which is the whole
           reason somebody made one. And a FULL LINK is unaffected in either direction — it
           carries the drawing inside itself and never reaches this server. So switching this
           off closes the store without breaking anything that has already been shared. */
        'store_on'         => true,
        /* RETIRING A POPULAR CODE. Off: zero means a code is never retired for being opened
           too often. Set it to, say, 200 and a code arms a timer when its opens reach that
           figure, and is removed `retire_days` later unless the operator has moved it to the
           permanent store. Arming rather than deleting is the whole design — see the header. */
        'retire_hits'      => 0,           // opens; 0 = never
        'retire_days'      => 30,          // days of notice after the count is reached
        /* The operator's own upload — a session file for the featured list, or a file for a
           permanent link. The public limits exist to stop the public filling the disk; this is
           him, and the point of it is the structure no public store will take. */
        'keep_max_bytes'   => 50 * 1024 * 1024,
        'key_len'          => 8,
        'short_base'       => '',
        'page_url'         => '',
        // --- admin
        'admin_hash'       => '',          // password_hash('...', PASSWORD_DEFAULT)
        'admin_max_tries'  => 6,           // failures per hour before the door is shut
        'admin_lock_min'   => 30,
        // --- usage
        'count_usage'      => true,
        'geo_csv'          => dirname(__DIR__) . '/geo/ip2country.csv',
    ];
}

/** Which keys `config.php` sets, so the admin page can say where a value came from. */
function dw_from_file(): array
{
    $file = dirname(__DIR__) . '/config.php';
    if (!is_file($file)) { return []; }
    /** @noinspection PhpIncludeInspection */
    $user = require $file;
    return is_array($user) ? $user : [];
}

/** @param bool $reload  re-read the administrator's settings, after one has just been saved. */
function dw_config(bool $reload = false): array
{
    $cfg = array_merge(dw_defaults(), dw_from_file());
    /* And last, whatever the administrator has set on the admin page. Those live in the
       DATABASE and not in this file, deliberately: a web page that can rewrite an executable
       PHP file turns "somebody got into the admin page" into "somebody runs code on the
       server", which is a different order of problem. DW_SETTABLE below says which keys can
       be reached that way at all. */
    static $over = null;                    // read once per request, not once per call
    if ($reload) { $over = null; }
    if ($over === null) {
        $over = [];
        try {
            $db = new PDO('sqlite:' . $cfg['db_path'], null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT]);
            $q = $db->query("SELECT k, v FROM meta WHERE k LIKE 'set.%'");
            if ($q) { foreach ($q as $r) { $over[substr((string) $r['k'], 4)] = (string) $r['v']; } }
        } catch (Throwable $e) { /* no database yet: the defaults are the settings */ }
    }
    foreach ($over as $k => $v) {
        if (!isset(DW_SETTABLE[$k])) { continue; }        // a stale row for a key we withdrew
        $cfg[$k] = DW_SETTABLE[$k][0] === 'bool' ? ($v === '1') : (int) $v;
    }
    return $cfg;
}

/* WHAT THE ADMIN PAGE MAY CHANGE, and the range it may change it to.
   [type, minimum, maximum, unit shown on the page, what it is]

   NOT IN THIS LIST, AND THAT IS THE POINT: `admin_hash`, `db_path`, `geo_csv`, `page_url` and
   `short_base`. The first three would let anyone who got into the admin page change the
   password, point the service at another database, or read a file of the operator's choosing;
   the last two would let them send every shared link somebody makes to a site of their own.
   Those five are settable in config.php and nowhere else, by hand, with a text editor. */
const DW_SETTABLE = [
    'small_max_bytes' => ['int',  1024, 1048576,     'bytes',   'Largest ordinary drawing'],
    'small_max_rows'  => ['int',    10, 10000000,    'rows',    'Ordinary drawings kept'],
    'small_wait'      => ['int',     0, 600,         'seconds', 'Wait before storing one'],
    'large_max_bytes' => ['int',  1024, 20971520,    'bytes',   'Largest drawing with a picture'],
    'large_max_rows'  => ['int',     0, 1000000,     'rows',    'Large drawings kept'],
    'large_wait'      => ['int',     0, 3600,        'seconds', 'Wait before storing a large one'],
    'max_total_bytes' => ['int', 1048576, 107374182400, 'bytes','Everything, all stores together'],
    'max_age_days'    => ['int',     0, 36500,       'days',    'Delete if not opened for'],
    'rate_per_hour'   => ['int',     0, 100000,      'per hour','Ordinary links per address'],
    'large_per_hour'  => ['int',     0, 100000,      'per hour','Large links per address'],
    'read_per_hour'   => ['int',     0, 1000000,     'per hour','Opens per address'],
    'read_wait'       => ['int',     0, 600,         'seconds', 'Wait before a drawing opens'],
    'count_usage'     => ['bool',    0, 1,           '',        'Count how much is used'],
    'allow_notes'     => ['bool',    0, 1,           '',        'Let a stored drawing carry a note'],
    'store_on'        => ['bool',    0, 1,           '',        'Store new drawings at all'],
    'retire_hits'     => ['int',     0, 100000,      'opens',   'Retire a code opened more than'],
    'retire_days'     => ['int',     1, 3650,        'days',    'Notice before a retired code goes'],
    'keep_max_bytes'  => ['int',  1024, 524288000,   'bytes',   'Largest file you may upload'],
];

/* WHAT EACH SWITCH ACTUALLY DOES, in one sentence, shown beside it on the admin page.
   A page of fifteen numbers with no explanation is a page nobody dares change anything on —
   which is the same as not being able to change it. Kept here rather than in the page so
   that the setting and its description cannot drift apart. */
const DW_SETTING_HELP = [
    'small_max_bytes' => 'An ordinary drawing bigger than this is refused; the person is told to use a FULL LINK instead.',
    'small_max_rows'  => 'How many ordinary drawings are kept. At the limit the least recently opened one is dropped.',
    'small_wait'      => 'Seconds the visitor waits before an ordinary drawing is stored. Enforced here, not in the page.',
    'large_max_bytes' => 'The ceiling for a drawing with a pasted picture in it. These are far more expensive to keep.',
    'large_max_rows'  => 'How many large drawings are kept. Zero refuses them altogether.',
    'large_wait'      => 'Seconds before a large drawing is stored. This is the one that pays for the disk.',
    'max_total_bytes' => 'Everything, all three stores together. Pruning runs when this is passed.',
    'max_age_days'    => 'A drawing nobody has opened for this long is deleted, whichever store it is in. Zero never deletes by age.',
    'rate_per_hour'   => 'Ordinary links one address may make in an hour. Zero means no limit.',
    'large_per_hour'  => 'Large links one address may make in an hour. Zero means no limit.',
    'read_per_hour'   => 'Times one address may open stored drawings in an hour. Zero means no limit. This is what stops the store being walked.',
    'read_wait'       => 'Seconds before a stored drawing is handed over. Ships OFF: the wait is paid by the person who was sent the link, and the ceiling above is what actually stops abuse.',
    'count_usage'     => 'Whether anything is counted at all. Off means no day, no country, no feature tally — nothing is written but the drawings themselves.',
    'allow_notes'     => 'Whether a drawing stored here may carry a note. Off by default: free text plus anonymity plus somebody else\'s domain is how a sharing service becomes a link shortener.',
    'store_on'        => 'Whether NEW drawings are stored. Off stops new short links and QR codes; everything already stored still opens, and a FULL LINK is unaffected because it never reaches this server.',
    'retire_hits'     => 'A code opened this many times is not a drawing shared with a colleague any more, it is a published resource: it arms a timer and goes after the notice below, unless you move it to the permanent store. Zero, the default, never retires anything. The permanent store is exempt, and switching this back to zero cancels every pending retirement.',
    'retire_days'     => 'Days between a code reaching the count above and its removal. The count never deletes on the spot: a poster on a wall gets this much notice, and the page says so beside every QR code it makes.',
    'keep_max_bytes'  => 'The largest file YOU may upload from this page, for the featured list or as a permanent link. The public limits above do not apply to your own uploads, and this one does not apply to the public. PHP\'s own upload_max_filesize and post_max_size must allow it too.',
];

/* WHAT TERMS.MD TELLS VISITORS, in numbers.
   A privacy policy is the one document that goes stale without anybody noticing, and making
   these settable from a web page is exactly the change that would do it: the operator lowers
   a retention period, the policy keeps promising the old one, and nobody finds out. So the
   numbers the policy states are written down HERE as well, and three things are locked to
   each other:

     · `terms.mjs` fails if this table stops matching the sentences in TERMS.md;
     · `terms.mjs` fails if this table stops matching the shipped defaults;
     · the admin page warns, in as many words, when the LIVE settings no longer match it.

   The first two are checks on us. The third is a check on the operator, and it is a warning
   rather than a refusal because it is his service and his policy to edit — but he is told. */
const DW_POLICY = [
    'max_age_days'  => [730, 'TERMS.md promises a stored drawing is deleted after two years; this service now says %s days.'],
    'small_wait'    => [10,  'TERMS.md says storing an ordinary drawing waits a few seconds; this service now waits %s.'],
    'large_wait'    => [60,  'TERMS.md says a large one waits rather longer; this service now waits %s.'],
    'read_wait'     => [0,   'TERMS.md does not tell visitors that OPENING a shared drawing makes them wait, and this service now makes them wait %s seconds.'],
];

/** The sentences in TERMS.md that are no longer true of this installation. Empty is good. */
function dw_policy_drift(array $cfg): array
{
    $out = [];
    foreach (DW_POLICY as $k => [$want, $msg]) {
        if ((int) $cfg[$k] !== (int) $want) { $out[] = sprintf($msg, (string) (int) $cfg[$k]); }
    }
    return $out;
}

/** Save one setting, or remove it so the config file (or the default) governs again.
    Returns '' when it was written, otherwise why it was not. */
function dw_set_setting(PDO $db, string $key, $value): string
{
    if (!isset(DW_SETTABLE[$key])) { return 'that setting cannot be changed from this page'; }
    if ($value === null || $value === '') {
        $db->prepare('DELETE FROM meta WHERE k = ?')->execute(['set.' . $key]);
        return '';
    }
    [$type, $min, $max] = DW_SETTABLE[$key];
    if ($type === 'bool') {
        $v = (in_array($value, ['1', 1, true, 'on', 'yes'], true)) ? '1' : '0';
    } else {
        if (!is_numeric($value)) { return 'that is not a number'; }
        $n = (int) $value;
        if ($n < $min || $n > $max) { return 'must be between ' . number_format($min) . ' and ' . number_format($max); }
        $v = (string) $n;
    }
    dw_meta($db, 'set.' . $key, $v);
    return '';
}

/** Every setting the administrator has actually set, as key => stored string. */
function dw_settings_set(PDO $db): array
{
    $out = [];
    try {
        foreach ($db->query("SELECT k, v FROM meta WHERE k LIKE 'set.%'") as $r) {
            $k = substr((string) $r['k'], 4);
            if (isset(DW_SETTABLE[$k])) { $out[$k] = (string) $r['v']; }
        }
    } catch (Throwable $e) { /* nothing set */ }
    return $out;
}

/* --------------------------------------------------------------------- time
   Everything that decides whether an entry LIVES OR DIES — the age prune, the retirement
   timer, the sweep — reads the clock through this one function, so that a test can move the
   clock instead of waiting thirty days. The override is honoured only in a plain command-line
   PHP (`php -r`, `php script.php`): the built-in web server reports `cli-server` and a real
   web server reports something else, so no environment variable on a host can ever back- or
   forward-date the service. The rate limiter and the signed tickets keep using time() —
   faking those would prove nothing and they are about real seconds. */
function dw_now(): int
{
    static $fake = -1;
    if ($fake === -1) {
        $env = PHP_SAPI === 'cli' ? getenv('DW_FAKE_NOW') : false;
        $fake = (is_string($env) && ctype_digit($env)) ? (int) $env : 0;
    }
    return $fake > 0 ? $fake : time();
}

/* ------------------------------------------------------------------- output */

function dw_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('X-Frame-Options: DENY');
    header('Cross-Origin-Resource-Policy: same-origin');
}

function dw_out(array $data, int $code = 200, array $headers = []): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    dw_headers();
    foreach ($headers as $h) { header($h); }
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function dw_fail(string $error, string $message, int $code): void
{
    dw_out(['ok' => false, 'error' => $error, 'message' => $message], $code, ['Cache-Control: no-store']);
}

/** dw_out for a stored drawing, where `payload` may be tens of megabytes.
    json_encode() copies the whole string once more while it escapes it, so a 50 MB upload
    served as `f=` base64 would cost twice its size in memory on a shared host that allows
    128 MB. A link payload is `[A-Za-z0-9_+\-$=]` and a file payload is base64 — neither holds
    a quote, a backslash or a control character, so nothing in them needs escaping and the
    string can be spliced into the JSON as it is. Checked, not assumed: anything else goes the
    ordinary way. */
function dw_out_payload(array $fields, string $payload, int $code, array $headers): void
{
    if (strspn($payload, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=_-$') !== strlen($payload)) {
        $fields['payload'] = $payload;
        dw_out($fields, $code, $headers);
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    dw_headers();
    foreach ($headers as $h) { header($h); }
    $head = json_encode($fields, JSON_UNESCAPED_SLASHES);        // "{...}" — never empty
    echo substr($head, 0, -1), ($fields ? ',' : ''), '"payload":"', $payload, '"}';
    exit;
}

/* ---------------------------------------------------------------- validation */

/** The payload is opaque to the server; it only has to look like one of our links.
    `z=` and `s=` only, deliberately: `f=` (a file the operator uploaded, base64) is written
    by admin.php and nowhere else, and accepting it here would turn the public endpoint into a
    file host, which is the one thing dw_valid_payload exists to refuse. */
function dw_valid_payload(string $p): bool
{
    return (bool) preg_match('/^(?:z|s)=[A-Za-z0-9_+\-$=]{8,}$/', $p);
}

/** What an uploaded file is, from its first two bytes and nothing else. A session file is a
    zip and a zip starts with "PK"; anything else is handed to the page as text. This is the
    whole of the server's inspection of an upload: it never opens, unzips or parses one. */
function dw_file_kind(string $head): string
{
    return substr($head, 0, 2) === 'PK' ? 'session' : 'text';
}

function dw_valid_key(string $k): bool
{
    /* Wider than DW_ALPHABET on purpose. The generator leaves out 0/O/1/l/I so that a RANDOM
       code read off a poster cannot be mistyped; but an administrator naming a permanent
       entry writes a WORD — "toluene", "lecture" — which is read as a word, and refusing it
       for containing an "o" would be pedantry with no reader to protect. Still strictly
       alphanumeric, which is all this guard is for: keeping anything else out of the query. */
    return strlen($k) >= 4 && strlen($k) <= 24 && strspn($k, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') === strlen($k);
}

function dw_key(int $len): string
{
    $max = strlen(DW_ALPHABET) - 1;
    $out = '';
    for ($i = 0; $i < $len; $i++) { $out .= DW_ALPHABET[random_int(0, $max)]; }
    return $out;
}

/* ------------------------------------------------------------------ database */

function dw_db(array $cfg): PDO
{
    static $db = null;
    if ($db instanceof PDO) { return $db; }
    $path = $cfg['db_path'];
    $dir  = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        dw_fail('storage', 'The sharing store is not available.', 503);
    }
    try {
        $db = new PDO('sqlite:' . $path, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (Throwable $e) {
        dw_fail('storage', 'The sharing store is not available.', 503);
    }
    $db->exec('PRAGMA journal_mode=WAL');
    $db->exec('PRAGMA synchronous=NORMAL');
    $db->exec('PRAGMA busy_timeout=5000');
    dw_schema($db);
    return $db;
}

function dw_schema(PDO $db): void
{
    /* `retire_at`: NULL for almost every row. Set — to a moment in the future — when the
       retirement rule is on and the row's opens reached `retire_hits`; the sweep removes the
       row once that moment has passed. Nothing else about the row changes when it is armed. */
    $db->exec('CREATE TABLE IF NOT EXISTS shares (
                 skey    TEXT PRIMARY KEY,
                 hash    TEXT NOT NULL UNIQUE,
                 payload TEXT NOT NULL,
                 bytes   INTEGER NOT NULL,
                 store   TEXT NOT NULL DEFAULT "small",
                 created INTEGER NOT NULL,
                 seen    INTEGER NOT NULL,
                 hits    INTEGER NOT NULL DEFAULT 0,
                 note    TEXT NOT NULL DEFAULT "",
                 retire_at INTEGER)');
    $db->exec('CREATE INDEX IF NOT EXISTS shares_seen  ON shares(store, seen)');
    /* The keys that were retired, and when. A retired code must not become a bare 404 on a
       poster, so the KEY is remembered after the drawing itself is gone — the key and a time,
       and nothing else: no drawing, no hash, nothing about anybody. A dozen bytes a row. */
    $db->exec('CREATE TABLE IF NOT EXISTS retired (skey TEXT PRIMARY KEY, t INTEGER NOT NULL)');
    $db->exec('CREATE TABLE IF NOT EXISTS meta  (k TEXT PRIMARY KEY, v TEXT NOT NULL)');
    $db->exec('CREATE TABLE IF NOT EXISTS rl    (bucket TEXT PRIMARY KEY, n INTEGER NOT NULL, t INTEGER NOT NULL)');
    /* Usage: a day, a country and a count. No address, no session, no row per visitor. */
    $db->exec('CREATE TABLE IF NOT EXISTS usage_day (
                 day TEXT NOT NULL, country TEXT NOT NULL, action TEXT NOT NULL,
                 n INTEGER NOT NULL DEFAULT 0,
                 PRIMARY KEY (day, country, action))');
    /* Feature counters, and the ONE RULE that makes them statistics rather than a profile:
       every tally stands on its own and none of them can be joined to another. There is no
       row anywhere saying "somebody in Saudi Arabia, on a PICO, on Android, today" — which
       in a small dataset would be one identifiable person. There is a count of PICOs today,
       a count of Androids today, and a count of visits from Saudi Arabia today, and nothing
       relates them. No address, no session, no visitor. */
    $db->exec('CREATE TABLE IF NOT EXISTS usage_tally (
                 day TEXT NOT NULL, kind TEXT NOT NULL, key TEXT NOT NULL,
                 n INTEGER NOT NULL DEFAULT 0,
                 PRIMARY KEY (day, kind, key))');
    $db->exec('CREATE INDEX IF NOT EXISTS usage_day_day ON usage_day(day)');
    $db->exec('CREATE TABLE IF NOT EXISTS geo (lo BLOB PRIMARY KEY, hi BLOB NOT NULL, cc TEXT NOT NULL)');
    /* Blocked content, by payload hash, so a takedown cannot be undone by re-uploading. */
    $db->exec('CREATE TABLE IF NOT EXISTS blocked (hash TEXT PRIMARY KEY, why TEXT NOT NULL, t INTEGER NOT NULL)');

    // --- migration from the single-store schema of version 1.0
    $cols = $db->query('PRAGMA table_info(shares)')->fetchAll();
    $names = array_column($cols, 'name');
    if (!in_array('store', $names, true)) { $db->exec('ALTER TABLE shares ADD COLUMN store TEXT NOT NULL DEFAULT "small"'); }
    if (!in_array('note', $names, true))  { $db->exec('ALTER TABLE shares ADD COLUMN note TEXT NOT NULL DEFAULT ""'); }
    // --- and from 2.0 to 2.1: the retirement timer, NULL on every existing row
    if (!in_array('retire_at', $names, true)) { $db->exec('ALTER TABLE shares ADD COLUMN retire_at INTEGER'); }
    // anything already stored that is bigger than the small limit belongs in the large store
    $db->exec('UPDATE shares SET store = "large" WHERE store = "small" AND bytes > ' . (20 * 1024));
}

/** A random per-installation salt, so nothing stored can be matched back to an address. */
function dw_salt(PDO $db): string
{
    $row = $db->query("SELECT v FROM meta WHERE k='salt'")->fetch();
    if ($row) { return $row['v']; }
    $salt = bin2hex(random_bytes(16));
    $db->prepare("INSERT OR IGNORE INTO meta (k, v) VALUES ('salt', ?)")->execute([$salt]);
    $row = $db->query("SELECT v FROM meta WHERE k='salt'")->fetch();
    return $row ? $row['v'] : $salt;
}

function dw_meta(PDO $db, string $k, ?string $v = null): ?string
{
    if ($v === null) {
        $st = $db->prepare('SELECT v FROM meta WHERE k = ?');
        $st->execute([$k]);
        $r = $st->fetchColumn();
        return $r === false ? null : (string) $r;
    }
    $db->prepare('INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v')
       ->execute([$k, $v]);
    return $v;
}

/* --------------------------------------------------------------- rate limits */

function dw_client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

/** true = allowed. Only a salted hourly hash is stored, never the address. */
function dw_rate_ok(PDO $db, array $cfg, string $what, int $limit): bool
{
    if ($limit <= 0) { return true; }
    $bucket = hash('sha256', dw_client_ip() . '|' . $what . '|' . dw_salt($db) . '|' . gmdate('YmdH'));
    $now = time();
    $db->prepare('INSERT INTO rl (bucket, n, t) VALUES (?, 0, ?) ON CONFLICT(bucket) DO NOTHING')
       ->execute([$bucket, $now]);
    $st = $db->prepare('SELECT n FROM rl WHERE bucket = ?');
    $st->execute([$bucket]);
    if ((int) ($st->fetchColumn() ?: 0) >= $limit) { return false; }
    $db->prepare('UPDATE rl SET n = n + 1, t = ? WHERE bucket = ?')->execute([$now, $bucket]);
    if (random_int(1, 50) === 1) { $db->prepare('DELETE FROM rl WHERE t < ?')->execute([$now - 7200]); }
    return true;
}

/* ------------------------------------------------------------------ geography
   The address is turned into a country here and then dropped. Nothing else about it
   is kept, and the counter below stores only (day, country, action, count).
   The lookup table is built from a CSV the administrator supplies; see geo/README.md.
   Addresses are compared as 16-byte binary strings — IPv4 mapped into IPv6 — so one
   table covers both and SQLite's own byte ordering does the range comparison. */

function dw_ip_key(string $ip): ?string
{
    $bin = @inet_pton($ip);
    if ($bin === false) { return null; }
    if (strlen($bin) === 4) { $bin = str_repeat("\0", 10) . "\xff\xff" . $bin; }   // ::ffff:a.b.c.d
    return $bin;
}

function dw_country(PDO $db, string $ip): string
{
    $key = dw_ip_key($ip);
    if ($key === null) { return 'ZZ'; }
    try {
        $st = $db->prepare('SELECT cc, hi FROM geo WHERE lo <= ? ORDER BY lo DESC LIMIT 1');
        $st->execute([$key]);
        $row = $st->fetch();
    } catch (Throwable $e) { return 'ZZ'; }
    if (!$row) { return 'ZZ'; }
    return ($row['hi'] >= $key) ? strtoupper(substr((string) $row['cc'], 0, 2)) : 'ZZ';
}

/** Count one action. The address exists only inside this call. */
function dw_count(PDO $db, array $cfg, string $action): void
{
    if (empty($cfg['count_usage'])) { return; }
    $country = dw_country($db, dw_client_ip());          // ... and the address is gone
    $day = gmdate('Y-m-d');
    try {
        $db->prepare('INSERT INTO usage_day (day, country, action, n) VALUES (?, ?, ?, 1)
                      ON CONFLICT(day, country, action) DO UPDATE SET n = n + 1')
           ->execute([$day, $country, $action]);
    } catch (Throwable $e) { /* counting must never break the service */ }
}

/* --------------------------------------------------------------- feature tallies */

/* What a user agent is allowed to become. A FULL user-agent string is close to a
   fingerprint, so it never reaches the database: it is reduced to one of these words at the
   moment it arrives and only the word is kept. The lists are short on purpose — a bucket
   nobody can be picked out of is the whole point. */
const DW_KINDS = ['action', 'headset', 'platform', 'feature'];

function dw_headset_bucket(string $ua): string
{
    if (preg_match('/OculusBrowser|Quest/i', $ua))   { return 'Meta Quest'; }
    if (preg_match('/Pico|PicoBrowser/i', $ua))      { return 'PICO'; }
    if (preg_match('/Vision ?Pro|visionOS/i', $ua))  { return 'Vision Pro'; }
    if (preg_match('/Wolvic|Firefox Reality/i', $ua)) { return 'Wolvic'; }
    return 'other headset';
}
function dw_platform_bucket(string $ua): string
{
    if (preg_match('/OculusBrowser|Quest|Pico/i', $ua)) { return 'Android (headset)'; }
    if (preg_match('/Android/i', $ua))       { return 'Android'; }
    if (preg_match('/iPhone|iPad|iPod/i', $ua)) { return 'iOS'; }
    if (preg_match('/Windows/i', $ua))       { return 'Windows'; }
    if (preg_match('/Macintosh|Mac OS X/i', $ua)) { return 'Mac'; }
    if (preg_match('/CrOS/i', $ua))          { return 'ChromeOS'; }
    if (preg_match('/Linux/i', $ua))         { return 'Linux'; }
    return 'other';
}

/** Add `n` to one tally. Never fails loudly: counting must not break the service. */
function dw_tally(PDO $db, array $cfg, string $kind, string $key, int $n = 1): void
{
    if (empty($cfg['count_usage'])) { return; }
    if (!in_array($kind, DW_KINDS, true)) { return; }
    $key = substr(preg_replace('/[^A-Za-z0-9 ()._-]/', '', $key), 0, 32);
    if ($key === '' || $n < 1 || $n > 10000) { return; }
    try {
        $db->prepare('INSERT INTO usage_tally (day, kind, key, n) VALUES (?, ?, ?, ?)
                      ON CONFLICT(day, kind, key) DO UPDATE SET n = n + excluded.n')
           ->execute([gmdate('Y-m-d'), $kind, $key, $n]);
    } catch (Throwable $e) { /* counting must never break the service */ }
}

/** How much is stored right now: rows and bytes, and the same split by store. Used to say
    what PRUNE NOW would remove BEFORE it removes it, and what it did afterwards. */
function dw_store_footprint(PDO $db): array
{
    $out = ['rows' => 0, 'bytes' => 0, 'by' => []];
    try {
        foreach ($db->query('SELECT store, COUNT(*) n, COALESCE(SUM(bytes), 0) b FROM shares GROUP BY store') as $r) {
            $out['by'][(string) $r['store']] = ['rows' => (int) $r['n'], 'bytes' => (int) $r['b']];
            $out['rows'] += (int) $r['n'];
            $out['bytes'] += (int) $r['b'];
        }
    } catch (Throwable $e) { /* no table yet */ }
    return $out;
}

/** What dw_prune() WOULD remove, without removing it. Same arithmetic, counted rather than
    executed, because a button that deletes should be able to say what it is about to delete. */
function dw_prune_preview(PDO $db, array $cfg): array
{
    $now = dw_now();
    $doomed = [];                         // skey => bytes, so nothing is counted twice
    $add = function (array $rows) use (&$doomed) { foreach ($rows as $r) { $doomed[$r['skey']] = (int) $r['bytes']; } };
    try {
        if ((int) $cfg['retire_hits'] > 0) {
            $st = $db->prepare('SELECT skey, bytes FROM shares WHERE store != "keep" AND retire_at IS NOT NULL AND retire_at <= ?');
            $st->execute([$now]);
            $add($st->fetchAll());
        }
        if ($cfg['max_age_days'] > 0) {
            $st = $db->prepare('SELECT skey, bytes FROM shares WHERE store != "keep" AND seen < ?');
            $st->execute([$now - $cfg['max_age_days'] * 86400]);
            $add($st->fetchAll());
        }
        foreach (['small' => 'small_max_rows', 'large' => 'large_max_rows'] as $store => $key) {
            $limit = (int) $cfg[$key];
            $c = $db->prepare('SELECT COUNT(*) FROM shares WHERE store = ?');
            $c->execute([$store]);
            $rows = (int) $c->fetchColumn();
            if ($rows <= $limit) { continue; }
            $st = $db->prepare('SELECT skey, bytes FROM shares WHERE store = ? ORDER BY seen ASC LIMIT ?');
            $st->execute([$store, $rows - (int) ($limit * 0.95)]);
            $add($st->fetchAll());
        }
        $total = (int) $db->query('SELECT COALESCE(SUM(bytes), 0) FROM shares')->fetchColumn();
        $left = $total - array_sum($doomed);
        if ($left > $cfg['max_total_bytes']) {
            foreach ($db->query('SELECT skey, bytes FROM shares WHERE store != "keep" ORDER BY seen ASC') as $r) {
                if ($left <= $cfg['max_total_bytes'] * 0.95) { break; }
                if (isset($doomed[$r['skey']])) { continue; }
                $doomed[$r['skey']] = (int) $r['bytes'];
                $left -= (int) $r['bytes'];
            }
        }
    } catch (Throwable $e) { /* no table yet */ }
    return ['rows' => count($doomed), 'bytes' => array_sum($doomed)];
}

/* ------------------------------------------------------------------- pruning */

/** Drop the least recently opened entries until a store is inside its limits.
    The permanent store is never touched. */
function dw_prune(PDO $db, array $cfg): void
{
    $now = dw_now();
    /* Retirement first. A timer that has run out removes the entry and remembers its key;
       and if the rule has been switched off — here, in config.php, anywhere — every timer
       still standing is cancelled, so an operator who turns the rule off and back on a week
       later starts clean rather than inheriting timers armed under the old figure. */
    if ((int) $cfg['retire_hits'] > 0) {
        $due = $db->prepare('SELECT skey FROM shares WHERE store != "keep" AND retire_at IS NOT NULL AND retire_at <= ?');
        $due->execute([$now]);
        foreach ($due->fetchAll() as $r) { dw_retire_now($db, (string) $r['skey'], $now); }
    } else {
        dw_retire_clear($db);
    }
    if ($cfg['max_age_days'] > 0) {
        $db->prepare('DELETE FROM shares WHERE store != "keep" AND seen < ?')
           ->execute([$now - $cfg['max_age_days'] * 86400]);
    }
    foreach (['small' => 'small_max_rows', 'large' => 'large_max_rows'] as $store => $key) {
        $limit = (int) $cfg[$key];
        $st = $db->prepare('SELECT COUNT(*) FROM shares WHERE store = ?');
        $st->execute([$store]);
        $rows = (int) $st->fetchColumn();
        if ($rows <= $limit) { continue; }
        // keep 95 % of the limit so pruning does not run on every write
        $db->prepare('DELETE FROM shares WHERE skey IN
                        (SELECT skey FROM shares WHERE store = ? ORDER BY seen ASC LIMIT ?)')
           ->execute([$store, $rows - (int) ($limit * 0.95)]);
    }
    $bytes = (int) $db->query('SELECT COALESCE(SUM(bytes), 0) FROM shares')->fetchColumn();
    while ($bytes > $cfg['max_total_bytes']) {
        $batch = $db->query('SELECT skey, bytes FROM shares WHERE store != "keep" ORDER BY seen ASC LIMIT 200')->fetchAll();
        if (!$batch) { break; }
        $del = $db->prepare('DELETE FROM shares WHERE skey = ?');
        foreach ($batch as $r) {
            $del->execute([$r['skey']]);
            $bytes -= (int) $r['bytes'];
            if ($bytes <= $cfg['max_total_bytes'] * 0.95) { break 2; }
        }
    }
}

/* ---------------------------------------------------------------- retirement
   The rule, in one place. `retire_hits` opens ARM a timer of `retire_days`; the sweep in
   dw_prune() — and the read path, if it gets there first — removes the entry once the timer
   has run out and remembers the key in `retired`. The permanent store is exempt at every
   step: never armed, never removed, and moving an entry there cancels its timer. Nothing
   here runs while the rule is off, and switching it off cancels every timer. */

/** Arm the timer for `key` if — and only if — the rule is on, the row is not permanent, it
    is not already armed and its opens have reached the figure. One UPDATE, all of those
    conditions in its WHERE, so two requests racing on the same key cannot arm it twice.
    Returns true when this call armed it. */
function dw_retire_arm(PDO $db, array $cfg, string $key, int $now): bool
{
    $hits = (int) $cfg['retire_hits'];
    if ($hits <= 0) { return false; }
    $st = $db->prepare('UPDATE shares SET retire_at = ?
                        WHERE skey = ? AND store != "keep" AND retire_at IS NULL AND hits >= ?');
    $st->execute([$now + (int) $cfg['retire_days'] * 86400, $key, $hits]);
    return $st->rowCount() > 0;
}

/** Retire `key` now: the drawing goes, the key is remembered. A permanent entry is left
    alone, and then nothing is remembered either — the key still answers with the drawing. */
function dw_retire_now(PDO $db, string $key, int $now): void
{
    $del = $db->prepare('DELETE FROM shares WHERE skey = ? AND store != "keep"');
    $del->execute([$key]);
    if ($del->rowCount() > 0) {
        $db->prepare('INSERT OR IGNORE INTO retired (skey, t) VALUES (?, ?)')->execute([$key, $now]);
    }
}

/** Was this key retired? Asked only after the row itself was not found. */
function dw_retired(PDO $db, string $key): bool
{
    $st = $db->prepare('SELECT 1 FROM retired WHERE skey = ?');
    $st->execute([$key]);
    return (bool) $st->fetchColumn();
}

/** A key that has just been given to a NEW drawing is no longer a retired one. The random
    generator will not land on a retired key in practice, but an administrator naming an
    entry by hand could choose one, and the answer for that name must then be the drawing. */
function dw_retired_forget(PDO $db, string $key): void
{
    $db->prepare('DELETE FROM retired WHERE skey = ?')->execute([$key]);
}

/** Cancel every pending retirement. Returns how many were pending. */
function dw_retire_clear(PDO $db): int
{
    $st = $db->prepare('UPDATE shares SET retire_at = NULL WHERE retire_at IS NOT NULL');
    $st->execute();
    return $st->rowCount();
}

/** How many entries are armed right now — for the admin page, so the rule is never silent. */
function dw_retire_pending(PDO $db): int
{
    try { return (int) $db->query('SELECT COUNT(*) FROM shares WHERE retire_at IS NOT NULL')->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}

/* ------------------------------------------------------- the featured database
   "Molecule of the day": entries the operator uploads and the page offers to somebody who
   arrives with nothing loaded. A SEPARATE FILE beside the shares database, and the reasons
   are in the header of this file. What is stored per entry is the uploaded bytes, opaque,
   under a key the server generated, with a title and a credit the operator typed; the name
   of the uploaded file is used for nothing at all and is not even kept. The server never
   opens the file: a session file is a zip, and a server that unzips what it is given
   inherits zip-slip and zip bombs, when every reader this project has lives in the browser
   already. Two bytes are looked at — "PK" says session, anything else says text — and that
   is the whole of the inspection.

   THREE WAYS TO OPEN IT, and which one a caller uses is the point:
     ro     read-only, and it does not create the file. The public list and the public read.
            A bug in the busiest path on the site then cannot damage the one database whose
            contents cannot be regenerated. When the file does not exist yet the open fails,
            and featured.php answers with an empty list rather than creating an empty file
            it would have had no business creating.
     rw     read-write but still never creates: the hits bump on a public read, done on a
            handle of its own after the entry was found on the read-only one. The file
            exists, because the row was just read from it.
     admin  read-write, creates the file and the table. admin.php only.
   Rollback journal rather than WAL, deliberately: a read-only connection to a WAL database
   needs the -shm file to exist or the folder to be writable, and this file is written a few
   times a year and read all day, which is exactly the case the ordinary journal is for. */

function dw_featured_path(array $cfg): string
{
    return dirname((string) $cfg['db_path']) . '/featured.sqlite';
}

/** @param string $mode  'ro' | 'rw' | 'admin' — see above. Throws PDOException when the
                         file cannot be opened in that mode; callers decide what that means. */
function dw_featured_db(array $cfg, string $mode = 'ro'): PDO
{
    static $open = [];
    if (isset($open[$mode])) { return $open[$mode]; }
    $flags = ['ro' => PDO::SQLITE_OPEN_READONLY, 'rw' => PDO::SQLITE_OPEN_READWRITE,
              'admin' => PDO::SQLITE_OPEN_READWRITE | PDO::SQLITE_OPEN_CREATE][$mode] ?? PDO::SQLITE_OPEN_READONLY;
    $path = dw_featured_path($cfg);
    if ($mode === 'admin') {
        $dir = dirname($path);
        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    }
    $db = new PDO('sqlite:' . $path, null, null, [
        PDO::SQLITE_ATTR_OPEN_FLAGS  => $flags,
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    /* The operator's handle waits for a lock, because his import is worth waiting for. The
       public hits bump does not: it is best-effort, and a visitor's download must not stall
       for seconds behind an import that happens to be running. */
    if ($mode !== 'ro') { $db->exec('PRAGMA busy_timeout=' . ($mode === 'admin' ? 5000 : 300)); }
    if ($mode === 'admin') { dw_featured_schema($db); }
    return $open[$mode] = $db;
}

function dw_featured_schema(PDO $db): void
{
    $db->exec('CREATE TABLE IF NOT EXISTS featured (
                 fkey    TEXT PRIMARY KEY,
                 title   TEXT NOT NULL,
                 credit  TEXT NOT NULL DEFAULT "",
                 blob    BLOB NOT NULL,
                 bytes   INTEGER NOT NULL,
                 kind    TEXT NOT NULL,
                 created INTEGER NOT NULL,
                 hits    INTEGER NOT NULL DEFAULT 0,
                 seen    INTEGER NOT NULL DEFAULT 0,
                 enabled INTEGER NOT NULL DEFAULT 1)');
}

/** Store one featured entry: a new row under `fkey`, or — on an import — the row that is
    already there, keeping its `hits` and `seen`, which the export does not carry and which
    an operator restoring his own backup would not want reset. The bytes are stored as they
    came; `kind` is read off their first two bytes and never trusted from anywhere else. */
function dw_featured_put(PDO $db, string $fkey, string $title, string $credit, string $bytes, int $created, bool $enabled): void
{
    $st = $db->prepare('INSERT INTO featured (fkey, title, credit, blob, bytes, kind, created, hits, seen, enabled)
                        VALUES (:k, :t, :c, :b, :n, :kind, :made, 0, 0, :on)
                        ON CONFLICT(fkey) DO UPDATE SET title = excluded.title, credit = excluded.credit,
                            blob = excluded.blob, bytes = excluded.bytes, kind = excluded.kind,
                            created = excluded.created, enabled = excluded.enabled');
    $st->bindValue(':k', $fkey);
    $st->bindValue(':t', $title);
    $st->bindValue(':c', $credit);
    $st->bindValue(':b', $bytes, PDO::PARAM_LOB);
    $st->bindValue(':n', strlen($bytes), PDO::PARAM_INT);
    $st->bindValue(':kind', dw_file_kind($bytes));
    $st->bindValue(':made', $created, PDO::PARAM_INT);
    $st->bindValue(':on', $enabled ? 1 : 0, PDO::PARAM_INT);
    $st->execute();
}

/* ----------------------------------------------------------------------- URLs */

function dw_page_url(array $cfg): string
{
    if ($cfg['page_url'] !== '') { return $cfg['page_url']; }
    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
              || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'] ?? '/QRsharing/share.php';
    $base   = str_replace('\\', '/', dirname(dirname($script)));
    if ($base === '/' || $base === '.') { $base = ''; }
    return ($https ? 'https://' : 'http://') . $host . $base . '/index.html';
}

function dw_short_url(array $cfg, string $key): string
{
    if ($cfg['short_base'] !== '') { return rtrim($cfg['short_base'], '/') . '/' . $key; }
    return dw_page_url($cfg) . '?k=' . $key;
}

/* ------------------------------------------------------ the large-store ticket
   A large drawing costs a wait. Rather than holding a PHP process open for twenty
   seconds — which would let a handful of requests exhaust the server — the first
   attempt is answered with a signed ticket, and the payload is accepted only when
   that ticket comes back and enough time has genuinely passed. The signature is an
   HMAC over the payload hash and the issue time, so it cannot be back-dated, reused
   for another drawing, or made up. Nothing is stored while the visitor waits. */

function dw_ticket_secret(PDO $db): string
{
    $s = dw_meta($db, 'ticket_secret');
    if ($s === null) { $s = bin2hex(random_bytes(32)); dw_meta($db, 'ticket_secret', $s); }
    return $s;
}

function dw_ticket_issue(PDO $db, string $hash): string
{
    $t = time();
    $sig = hash_hmac('sha256', $hash . '|' . $t, dw_ticket_secret($db));
    return $t . '.' . substr($sig, 0, 32);
}

/** '' when the ticket is good, otherwise the reason it is not. */
function dw_ticket_check(PDO $db, string $hash, string $ticket, int $wait): string
{
    if (!preg_match('/^(\d{10})\.([0-9a-f]{32})$/', $ticket, $m)) { return 'malformed'; }
    $t = (int) $m[1];
    $want = substr(hash_hmac('sha256', $hash . '|' . $t, dw_ticket_secret($db)), 0, 32);
    if (!hash_equals($want, $m[2])) { return 'not for this drawing'; }
    $age = time() - $t;
    if ($age < $wait) { return 'only ' . $age . ' of ' . $wait . ' seconds have passed'; }
    if ($age > 900)   { return 'expired'; }
    return '';
}

/* ------------------------------------------------------------------ blocklist */

function dw_blocked(PDO $db, string $hash): bool
{
    $st = $db->prepare('SELECT 1 FROM blocked WHERE hash = ?');
    $st->execute([$hash]);
    return (bool) $st->fetchColumn();
}

/** Is the whole service switched off? Returns the reason, or ''. */
function dw_offline(PDO $db): string
{
    return (string) (dw_meta($db, 'offline') ?? '');
}
