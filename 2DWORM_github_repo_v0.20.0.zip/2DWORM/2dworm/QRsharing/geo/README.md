# Counting where 2D-WORM is used

The admin page can show use by country. To do that it needs a table that turns an IP
address range into a country code. **None is shipped here**, for two reasons: the free
ones come with their own licences and attribution requirements, and they go out of date,
so it is better that you fetch a current one than that we freeze a stale copy into a
release.

## What is stored, and what is not

No IP address is ever written to disk. When a link is made or opened, the address is
turned into a country **in memory** and discarded in the same breath. What is written is
one row per day, country and action, holding a count:

    2026-09-09 | SA | create | 14

There is no visitor record, no session table and no log of addresses. Anything below five,
and anything the table does not recognise, is displayed as "Other", so a single visit from
a small country never becomes a fact about a person.

If you would rather not count at all, set `'count_usage' => false` in `config.php`.

## Getting a table

Any CSV in this shape will do — start address, end address, two-letter country code:

    1.0.0.0,1.0.0.255,AU
    2001:200::,2001:200:ffff:ffff:ffff:ffff:ffff:ffff,JP

Both IPv4 and IPv6 rows can be in the same file. Two free sources give exactly this:

- **DB-IP IP-to-Country Lite** — <https://db-ip.com/db/download/ip-to-country-lite>
  (CC BY 4.0: you must credit DB-IP where the map is shown)
- **IP2Location LITE DB1** — <https://lite.ip2location.com/database/ip-country>
  (CC BY-SA 4.0; the IPv4 file uses decimal numbers rather than dotted addresses, so
  convert it or take the "IPV6-COUNTRY" CSV, which is in the right shape)

Whichever you choose, **credit it wherever you show the map** — that is the whole of what
those licences ask.

## Loading it

Save the file as `geo/ip2country.csv`, open the admin page and press
**Rebuild the country table**. It is read once into SQLite and the CSV is not needed again
until you refresh it. Expect a few hundred thousand ranges and a few seconds.

Until you do this, every visit counts as "Other" and the rest of the service is unaffected.
