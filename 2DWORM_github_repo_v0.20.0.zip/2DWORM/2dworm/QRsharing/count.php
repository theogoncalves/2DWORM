<?php
/* count.php — the feature counters.
 * Copyright (C) 2026 Theo P. Goncalves
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * WHAT THIS IS, AND WHAT IT DELIBERATELY IS NOT.
 *
 * The page sends, at most once every couple of minutes and once more when it is closed, a
 * short list of things that were used — {"make3d":3,"minimize":1,"vr_launch":1}. Each name is
 * added to a per-day total. That is the whole of it:
 *
 *   · no address is stored, in any form. The country is worked out in memory from the request
 *     that carried it and the address is gone in the same breath, exactly as it is for a
 *     shared link;
 *   · no cookie, no session, no identifier of any kind. Two visits from the same person are
 *     indistinguishable from two visits by two people, which is the point;
 *   · no row is ever per-visitor. Everything is `day + kind + key -> a number`;
 *   · the tallies CANNOT BE JOINED. There is a count of Quests today, a count of Androids
 *     today and a count of visits from a country today, and nothing relates them. A single
 *     row saying "Saudi Arabia, PICO, Android, today, 1" would be one identifiable person,
 *     and that row does not exist and cannot be reconstructed.
 *
 * The user agent never reaches the database either: it is reduced to one word out of a short
 * list — "Meta Quest", "Android", "Windows" — before anything is written, because a full
 * user-agent string is close to a fingerprint.
 *
 * The operator can switch all of it off with `count_usage`, and then this endpoint stores
 * nothing at all.
 */

declare(strict_types=1);
require __DIR__ . '/lib/core.php';

dw_headers();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    dw_out(['ok' => false, 'error' => 'post_only'], 405);
}

$CFG = dw_config();
if (empty($CFG['count_usage'])) {
    // nothing is recorded, and the page is told so rather than left to guess
    dw_out(['ok' => true, 'counting' => false]);
}

$raw = file_get_contents('php://input', false, null, 0, 4096);
$in  = json_decode((string) $raw, true);
if (!is_array($in)) { dw_out(['ok' => false, 'error' => 'bad_json'], 400); }

try {
    $db = dw_db($CFG);
} catch (Throwable $e) {
    dw_out(['ok' => false, 'error' => 'unavailable'], 503);
}

/* A single visit cannot report more than this many different things, or send a bigger number
   than this for any of them. Counting is not worth a way to write arbitrarily to the file. */
const DW_COUNT_MAX_KEYS = 24;
const DW_COUNT_MAX_N    = 500;

$ua = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 400);

/* The features that were used. Unknown names are ignored rather than stored: the list of
   things worth counting is ours, not the caller's, or the table becomes a place to write
   whatever anybody likes. */
const DW_FEATURES = [
    'make3d', 'minimize', 'minimize_selected', 'best', 'find', 'open_file', 'save_file',
    'share_full', 'share_short', 'qr_png', 'jpg', 'select', 'notes', 'style', 'bw',
    'language', 'theme', 'solo', 'chain', 'vr_launch', 'vr_return',
    // EXTENSIONS: which of the hand-editing tools are worth keeping
    'extensions', 'drag', 'turn', 'bond_edit', 'undo',
    // what the captions are set to, whether the periodic box is wanted, and whether the
    // charges read out of a file are actually looked at
    'labels', 'charges', 'cell', 'halo', 'cell_fix', 'cell_extend', 'frame',
    // 2DWORM-VR: opened the page, came back from it, and actually entered a session
    'vr_open',
    // the volumetric grid a .cube came with: drawn here, and carried to the headset. The
    // camera lock coming BACK from the headset is counted too, because it is the half that
    // is new and the half that can quietly stop working.
    'field', 'vr_field', 'vr_lock',
    // the cell relaxed inside its own images, which is the expensive one and the one worth
    // knowing anybody uses
    'min_periodic',
    // the controls hidden in full screen — worth knowing whether anybody wants a bare
    // picture often enough for it to be the default one day
    'solo_bars',
    // the three sliders: setting a geometry by number rather than by eye
    'geo_bond', 'geo_angle', 'geo_dihedral', 'geo_keys',
    // one look for part of the structure, rather than one look for all of it
    'rep_sel',
];
$n = 0;
foreach ((array) ($in['f'] ?? []) as $key => $count) {
    if ($n++ >= DW_COUNT_MAX_KEYS) { break; }
    if (!in_array((string) $key, DW_FEATURES, true)) { continue; }
    $c = (int) $count;
    if ($c < 1) { continue; }
    dw_tally($db, $CFG, 'feature', (string) $key, min($c, DW_COUNT_MAX_N));
}

/* The platform, and the headset when this is one. Both are buckets derived here from the
   user agent of THIS request; neither is sent by the page and neither is stored raw. */
if (!empty($in['first'])) {
    dw_tally($db, $CFG, 'platform', dw_platform_bucket($ua));
}
/* `xr` is the page saying it entered an immersive session — which the user agent cannot tell
   us, because WebXR deliberately does not expose the headset model. The model comes from the
   user agent; the fact that VR was actually entered comes from the page. */
if (!empty($in['xr'])) {
    dw_tally($db, $CFG, 'headset', dw_headset_bucket($ua));
}

dw_out(['ok' => true, 'counting' => true]);
