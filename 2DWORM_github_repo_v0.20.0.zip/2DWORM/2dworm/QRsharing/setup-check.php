<?php
declare(strict_types=1);
/**
 * 2D-WORM sharing service – self test.
 * Open this page once after uploading (…/QRsharing/setup-check.php) to see whether
 * short links work on your host. Delete or rename it afterwards if you like.
 */
header('Content-Type: text/html; charset=utf-8');
$rows = [];
$ok = true;
function row(string $what, bool $good, string $detail): void {
    global $rows, $ok;
    $rows[] = [$what, $good, $detail];
    if (!$good) { $ok = false; }
}

row('PHP version', PHP_VERSION_ID >= 70400, PHP_VERSION . (PHP_VERSION_ID >= 70400 ? '' : ' – 7.4 or newer needed'));
row('pdo_sqlite extension', extension_loaded('pdo_sqlite'), extension_loaded('pdo_sqlite') ? 'available' : 'missing – ask your host to enable it');

$CFG = ['db_path' => __DIR__ . '/data/shares.sqlite', 'short_base' => '', 'page_url' => ''];
if (is_file(__DIR__ . '/config.php')) {
    $u = require __DIR__ . '/config.php';
    if (is_array($u)) { $CFG = array_merge($CFG, $u); }
    row('config.php', true, 'in use');
} else {
    row('config.php', true, 'not present – built-in defaults are used');
}

$dir = dirname($CFG['db_path']);
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
row('data folder', is_dir($dir) && is_writable($dir), $dir . (is_writable($dir) ? ' (writable)' : ' – not writable, chmod 755 or 775'));

$count = $bytes = 0;
if (extension_loaded('pdo_sqlite') && is_writable($dir)) {
    try {
        $db = new PDO('sqlite:' . $CFG['db_path'], null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $db->exec('PRAGMA journal_mode=WAL');
        $db->exec('CREATE TABLE IF NOT EXISTS selftest (a INTEGER)');
        $db->exec('INSERT INTO selftest (a) VALUES (1)');
        $db->exec('DROP TABLE selftest');
        row('database write test', true, $CFG['db_path']);
        $has = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='shares'")->fetchColumn();
        if ($has) {
            $count = (int) $db->query('SELECT COUNT(*) FROM shares')->fetchColumn();
            $bytes = (int) $db->query('SELECT COALESCE(SUM(bytes),0) FROM shares')->fetchColumn();
        }
        row('stored drawings', true, $has ? number_format($count) . ' drawings, ' . number_format($bytes / 1024, 1) . ' KB' : 'none yet (the table is created on the first share)');
    } catch (Throwable $e) {
        row('database write test', false, 'failed: ' . $e->getMessage());
    }
    /* The featured list — "molecule of the day" — is a second file in the same folder. It is
       optional and is created by the first upload from the admin page, so its absence is a
       working state, not a fault. Opened read-only here, as the public route opens it. */
    $featured = $dir . '/featured.sqlite';
    if (is_file($featured)) {
        try {
            $fdb = new PDO('sqlite:' . $featured, null, null,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::SQLITE_ATTR_OPEN_FLAGS => PDO::SQLITE_OPEN_READONLY]);
            $n = (int) $fdb->query('SELECT COUNT(*) FROM featured')->fetchColumn();
            $on = (int) $fdb->query('SELECT COUNT(*) FROM featured WHERE enabled = 1')->fetchColumn();
            row('featured list (molecule of the day)', true, $featured . ' – ' . number_format($n) . ' entries, ' . number_format($on) . ' offered');
        } catch (Throwable $e) {
            row('featured list (molecule of the day)', false, $featured . ' exists but cannot be read: ' . $e->getMessage());
        }
    } else {
        row('featured list (molecule of the day)', true, 'none yet – ' . $featured . ' is created by the first upload from admin.php');
    }
}
$dbUrl = 'data/' . basename($CFG['db_path']);
$featuredUrl = 'data/featured.sqlite';
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>2D-WORM sharing – setup check</title>
<style>
 body { font: 15px/1.45 system-ui, sans-serif; margin: 0; padding: 24px; background: #fff; color: #161616; }
 .box { max-width: 780px; margin: 0 auto; }
 h1 { font-size: 20px; } h1 span { color: #b36f00; }
 table { border-collapse: collapse; width: 100%; margin: 14px 0; }
 td { border-top: 1px solid #ddd; padding: 7px 6px; vertical-align: top; }
 td.s { width: 34px; font-weight: 700; }
 .good { color: #1f8f3a; } .bad { color: #c62828; } .warn { color: #b36f00; }
 code { background: #f2f2f2; padding: 1px 5px; border-radius: 4px; }
 p.verdict { padding: 10px 12px; border-radius: 6px; font-weight: 600; }
 p.verdict.good { background: #e8f6ec; } p.verdict.bad { background: #fdecec; }
</style></head><body><div class="box">
<h1>2D-WORM <span>sharing service</span> – setup check</h1>
<p class="verdict <?= $ok ? 'good' : 'bad' ?>"><?= $ok ? 'Short links and QR codes will work on this server.' : 'Short links will not work yet – see the red lines below. The page still works: it falls back to self-contained links.' ?></p>
<table>
<?php foreach ($rows as [$what, $good, $detail]): ?>
 <tr><td class="s <?= $good ? 'good' : 'bad' ?>"><?= $good ? '&check;' : '&times;' ?></td>
     <td><b><?= htmlspecialchars($what) ?></b><br><?= htmlspecialchars($detail) ?></td></tr>
<?php endforeach; ?>
 <tr><td class="s" id="epS">…</td><td><b>share.php answers</b><br><span id="ep">testing…</span></td></tr>
 <tr><td class="s" id="rtS">…</td><td><b>store and read back a test drawing</b><br><span id="rt">testing…</span></td></tr>
 <tr><td class="s" id="dbS">…</td><td><b>database not downloadable</b><br><span id="dbp">testing…</span></td></tr>
 <tr><td class="s" id="fdS">…</td><td><b>featured list not downloadable</b><br><span id="fdp">testing…</span></td></tr>
 <tr><td class="s" id="ftS">…</td><td><b>featured.php answers</b><br><span id="ft">testing…</span></td></tr>
 <tr><td class="s" id="swS">…</td><td><b>pretty links <code>/s/KEY</code></b><br><span id="sw">testing…</span></td></tr>
</table>
<p style="color:#666;font-size:13px">The store keeps the most recently opened drawings (by default 100,000 ordinary ones of up to 20 kB, 2,000 large ones of up to 500 kB, 900 MB in all) and drops the least recently opened. The featured list — the "molecule of the day" the admin page uploads — is a second file, <code>data/featured.sqlite</code>, in the same folder. Settings: <code>QRsharing/config.php</code> (see <code>config.example.php</code>). Delete this file when you are done.</p>
</div>
<script>
const set = (id, good, text) => { const s = document.getElementById(id + 'S'); s.textContent = good ? '✓' : (good === null ? '!' : '×'); s.className = 's ' + (good ? 'good' : (good === null ? 'warn' : 'bad')); };
(async () => {
  let status = null;
  try {
    const r = await fetch('share.php?status', { cache: 'no-store' });
    status = await r.json();
    set('ep', !!status.ok, '');
    document.getElementById('ep').textContent = status.ok
      ? `service ${status.service} ${status.version}, page ${status.page_url}`
      : ('error: ' + (status.message || r.status));
  } catch (e) {
    set('ep', false, ''); document.getElementById('ep').textContent = 'no answer: ' + e;
    return;
  }
  try {
    const payload = 'z=SETUPCHECK' + Math.random().toString(36).slice(2, 10).replace(/[^A-Za-z0-9]/g, 'a');
    const r = await fetch('share.php', { method: 'POST', body: payload });
    const j = await r.json();
    if (!j.ok) throw new Error(j.message || r.status);
    const r2 = await fetch('share.php?k=' + encodeURIComponent(j.key), { cache: 'no-store' });
    const j2 = await r2.json();
    const good = j2.ok && j2.payload === payload;
    set('rt', good, '');
    document.getElementById('rt').textContent = good ? `stored as key ${j.key} and read back correctly` : 'the drawing did not come back unchanged';
  } catch (e) { set('rt', false, ''); document.getElementById('rt').textContent = 'failed: ' + e.message; }
  try {
    const r = await fetch(<?= json_encode($dbUrl) ?>, { cache: 'no-store' });
    const blocked = !r.ok;
    set('db', blocked, '');
    document.getElementById('dbp').textContent = blocked
      ? 'the database cannot be downloaded (HTTP ' + r.status + ') – correct'
      : 'WARNING: the database can be downloaded. Move it outside public_html with db_path in config.php.';
  } catch (e) { set('db', true, ''); document.getElementById('dbp').textContent = 'the database cannot be downloaded – correct'; }
  /* the same .htaccess covers the featured list; checked on its own because it is the file
     that cannot be regenerated, and a 404 (not created yet) is as good as a 403 here */
  try {
    const r = await fetch(<?= json_encode($featuredUrl) ?>, { cache: 'no-store' });
    const blocked = !r.ok;
    set('fd', blocked, '');
    document.getElementById('fdp').textContent = blocked
      ? 'the featured list cannot be downloaded (HTTP ' + r.status + ') – correct'
      : 'WARNING: data/featured.sqlite can be downloaded. Move the data folder outside public_html with db_path in config.php.';
  } catch (e) { set('fd', true, ''); document.getElementById('fdp').textContent = 'the featured list cannot be downloaded – correct'; }
  try {
    const r = await fetch('featured.php?list=1', { cache: 'no-store' });
    const list = await r.json();
    const good = r.ok && Array.isArray(list);
    set('ft', good, '');
    document.getElementById('ft').textContent = good
      ? (list.length ? list.length + ' entr' + (list.length === 1 ? 'y' : 'ies') + ' offered as molecule of the day' : 'answers with an empty list – nothing featured yet, which is fine')
      : 'error: HTTP ' + r.status;
  } catch (e) { set('ft', false, ''); document.getElementById('ft').textContent = 'no answer: ' + e; }
  try {
    const base = (status.page_url || '').replace(/\/[^\/]*$/, '');
    const r = await fetch(base + '/s/testtest', { redirect: 'follow' });
    const txt = await r.text();
    const works = r.ok && /2D-WORM/.test(txt);
    set('sw', works ? true : null, '');
    document.getElementById('sw').textContent = works
      ? 'the rewrite works – you may set short_base in config.php to ' + base + '/s/'
      : 'not active (optional). Links then look like index.html?k=KEY, which works everywhere.';
  } catch (e) { set('sw', null, ''); document.getElementById('sw').textContent = 'not active (optional)'; }
})();
</script>
</body></html>
