<?php
/**
 * 2D-WORM sharing service — settings.
 *
 * Copy this file to config.php and change what you need; every key is optional.
 * config.php is excluded from the repository by .gitignore and MUST STAY THAT WAY:
 * it holds the administrator password hash. If one is ever committed by accident,
 * change the password — git history is permanent, and deleting the file does not
 * remove it from the history.
 */
return [
    // Keep the database outside the web root if your hosting allows it. The featured list
    // (featured.sqlite) is created in the same folder, so one setting moves both:
    // 'db_path' => '/home/USER/2dworm-data/shares.sqlite',

    /* ------------------------------------------------------------ administration
     * The page at admin.php is invisible until a file called .admin-enabled exists
     * next to it — create it when you want to log in, delete it afterwards. This
     * hash is the second lock. Make one with:
     *
     *   php -r 'echo password_hash("your password here", PASSWORD_DEFAULT), "\n";'
     *
     * Paste the result below. The password itself is never stored anywhere.
     */
    // 'admin_hash'      => '$2y$10$....................................................',
    // 'admin_max_tries' => 6,     // failed attempts per hour before the door shuts

    /* ------------------------------------------------------------------- stores */
    // 'small_max_bytes' => 20 * 1024,          // the ordinary case: 1-5 kB
    // 'small_max_rows'  => 100000,
    // 'small_wait'      => 10,                 // seconds, enforced by the server
    // 'large_max_bytes' => 500 * 1024,         // a drawing with a picture in it
    // 'large_max_rows'  => 2000,
    // 'large_wait'      => 60,                 // the same, for a large one
    // 'max_total_bytes' => 900 * 1024 * 1024,
    // 'max_age_days'    => 730,

    /* ------------------------------------------------- retiring a popular code
     * OFF by default. A code opened more than retire_hits times is a published resource
     * rather than a drawing shared with a colleague, and you may decline to be its permanent
     * host: reaching the count ARMS A TIMER — nothing is deleted on the spot — and the entry
     * is removed retire_days later unless you have moved it to the permanent store. A retired
     * code answers with a sentence and the contact address, never a bare 404. TERMS.md says
     * so, and the page says so beside every QR code it makes. */
    // 'retire_hits'     => 0,      // opens; 0 = never retire anything
    // 'retire_days'     => 30,     // days of notice after the count is reached (1 to 3650)

    /* ------------------------------------------------------- your own uploads
     * The largest file YOU may upload from the admin page — a .2dworm.zip session for the
     * featured list ("molecule of the day"), or a file for a permanent link. The public limits
     * above do not apply to your uploads and this one does not apply to the public. PHP's own
     * upload_max_filesize and post_max_size must allow it too. The featured list lives in
     * data/featured.sqlite, beside the shares database, and follows db_path's folder. */
    // 'keep_max_bytes'  => 50 * 1024 * 1024,   // up to 500 MB

    /* -------------------------------------------------------------- rate limits
     * Most of these can also be set from the admin page, which stores them in the DATABASE
     * and OVERRIDES whatever is here. If you change a value in this file and nothing happens,
     * that is why — clear the box on the page and save, and this file governs again. */
    // 'rate_per_hour'   => 60,     // short links per address per hour
    // 'large_per_hour'  => 4,      // large ones are far more expensive
    /* Reading is limited but not delayed. A wait before a stored drawing opens is paid by the
       colleague who was sent the link; a ceiling is paid by whoever is walking the key space
       to copy the store. So the ceiling is on and the wait is off. */
    // 'read_per_hour'   => 600,    // opens per address per hour; 0 = no ceiling
    // 'read_wait'       => 0,      // seconds before a stored drawing opens

    /* -------------------------------------------------------------------- usage */
    /* false switches off EVERY counter — the country one, the feature tallies and the
       platform and headset buckets. The endpoint then stores nothing and says so. */
    // 'count_usage'     => true,   // day + label + count only; never an address
    // 'geo_csv'         => __DIR__ . '/geo/ip2country.csv',

    /* --------------------------------------------------------------------- URLs */
    // Pretty short links. Needs the RewriteRule from the .htaccess next to index.html:
    // 'short_base' => 'https://dworm.org/s/',
    // If the page is not index.html one folder up:
    // 'page_url'   => 'https://dworm.org/2d/index.html',
];
