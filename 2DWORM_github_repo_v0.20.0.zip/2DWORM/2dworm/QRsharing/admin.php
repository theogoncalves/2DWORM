<?php
declare(strict_types=1);
/**
 * 2D-WORM sharing service — administration.
 * ---------------------------------------------------------------------------
 * TWO LOCKS, and the outer one is not a password.
 *
 * 1. THE FILE SWITCH. This page does not exist unless a file called `.admin-enabled`
 *    sits next to it. Create it (cPanel's file manager will do) when you want to log
 *    in, delete it when you are finished. While it is absent this script answers 404
 *    exactly as a missing file would, so there is nothing to find, nothing to probe
 *    and nothing to brute-force — for most of the year the door is not locked, it is
 *    not there.
 *
 * 2. THE PASSWORD, verified here and only here, against a bcrypt hash in config.php.
 *    The password itself is never in this file, never in the database, and never
 *    reaches the browser. config.php is excluded from the repository by .gitignore.
 *    Make the hash with:   php -r 'echo password_hash("your password", PASSWORD_DEFAULT), "\n";'
 *
 * Failed attempts are counted per hour and the door shuts for a while after a few.
 * Every action that changes something carries a CSRF token.
 *
 * Drawings are never rendered inside this page. To look at one, open it in the app
 * itself in a new tab — that is the same sandbox everybody else's drawings run in,
 * and it keeps somebody else's content out of the page that holds your session.
 *
 * UPLOADS, and the two rules that make an upload form on the most sensitive page of the
 * site safe rather than merely careful. (1) THE SERVER NEVER OPENS THE FILE. No ZipArchive,
 * no temporary folder, no parsing: the bytes are checked against a size and stored as an
 * opaque blob, and the page opens them with the readers it already has. Zip-slip and zip
 * bombs are not mitigated here; they are absent. (2) THE UPLOADED NAME IS NEVER USED — not
 * as a path, not as a filename, not in a header, not even stored. The key is generated, and
 * the title is what is shown. Two bytes are looked at, "PK" or not, and that is the whole
 * of the inspection.
 */

require __DIR__ . '/lib/core.php';

/* ---------------------------------------------------------- lock one: the file */
if (!is_file(__DIR__ . '/.admin-enabled')) {
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo "<!doctype html><title>404 Not Found</title><h1>Not Found</h1>";
    exit;
}

$CFG = dw_config();
$DB  = dw_db($CFG);
dw_headers();
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
header('Cache-Control: no-store');

session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Strict',
    'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'path'     => strtok($_SERVER['REQUEST_URI'] ?? '/', '?'),
]);
session_name('dworm_admin');
session_start();

/* ------------------------------------------------------------------- helpers */
function h(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }
function kb(int $b): string { return $b < 1024 ? $b . ' B' : ($b < 1048576 ? round($b / 1024) . ' kB' : round($b / 1048576, 1) . ' MB'); }
function when(int $t): string { return $t ? gmdate('Y-m-d H:i', $t) : '—'; }

function csrf(): string
{
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
    return $_SESSION['csrf'];
}
function csrf_ok(): bool
{
    return !empty($_SESSION['csrf']) && is_string($_POST['csrf'] ?? null)
        && hash_equals($_SESSION['csrf'], (string) $_POST['csrf']);
}
function tries_key(): string { return 'admin_tries_' . gmdate('YmdH'); }

/* ---------------------------------------------------- lock two: the password */
$notice = '';
$locked = false;
$tries  = (int) (dw_meta($DB, tries_key()) ?? 0);
if ($tries >= (int) $CFG['admin_max_tries']) { $locked = true; }

if (($_POST['do'] ?? '') === 'logout') {
    $_SESSION = [];
    session_destroy();
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

if (($_POST['do'] ?? '') === 'login' && !$locked) {
    $hash = (string) $CFG['admin_hash'];
    $pw   = (string) ($_POST['pw'] ?? '');
    // A deliberate pause makes guessing slow even before the counter notices.
    usleep(400000);
    if ($hash === '') {
        $notice = 'No administrator password is configured. Put an admin_hash into config.php first.';
    } elseif (password_verify($pw, $hash)) {
        session_regenerate_id(true);
        $_SESSION['in'] = true;
        $_SESSION['at'] = time();
        dw_meta($DB, tries_key(), '0');
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    } else {
        dw_meta($DB, tries_key(), (string) ($tries + 1));
        $left = max(0, (int) $CFG['admin_max_tries'] - $tries - 1);
        $notice = 'That is not the password. ' . ($left > 0 ? $left . ' attempt' . ($left === 1 ? '' : 's') . ' left this hour.' : 'The door is now shut for this hour.');
        $locked = $left <= 0;
    }
}

$in = !empty($_SESSION['in']) && (time() - (int) ($_SESSION['at'] ?? 0) < 7200);
if (!$in && !empty($_SESSION['in'])) { $_SESSION = []; $notice = $notice ?: 'The session timed out.'; }

/* ----------------------------------------------------------------- backup
   Must happen before a single byte of the page is sent. VACUUM INTO makes a consistent
   snapshot even while the service is being written to — copying the .sqlite file alone
   would miss whatever is still in the write-ahead log. */
if ($in && isset($_GET['backup'])) {
    $tmp = sys_get_temp_dir() . '/dworm-backup-' . bin2hex(random_bytes(6)) . '.sqlite';
    $okBackup = false;
    try { $DB->exec("VACUUM INTO " . $DB->quote($tmp)); $okBackup = is_file($tmp); }
    catch (Throwable $e) { $okBackup = false; }
    if (!$okBackup) { @copy((string) $CFG['db_path'], $tmp); $okBackup = is_file($tmp); }
    if (!$okBackup) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo "The backup could not be made.\n";
        exit;
    }
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . filesize($tmp));
    header('Content-Disposition: attachment; filename="2dworm-shares-' . gmdate('Ymd-Hi') . '.sqlite"');
    readfile($tmp);
    @unlink($tmp);
    exit;
}

/* ------------------------------------------------------------ featured export
   The featured list as one JSON file — the backup of the only database whose contents
   cannot be regenerated, and the way it survives a move to another host: IMPORT below
   takes the same file back. Streamed one entry at a time, because the blobs are base64 of
   whole session files and building the document in memory first would cost their sum. The
   format carries a version so a later build can migrate it rather than guess at it. */
if ($in && isset($_GET['fexport'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="2dworm-featured-' . gmdate('Ymd-Hi') . '.json"');
    header('Cache-Control: no-store');
    echo '{"version":1,"exported":', time(), ',"entries":[';
    try {
        $fdb = dw_featured_db($CFG, 'ro');
        $first = true;
        foreach ($fdb->query('SELECT fkey, title, credit, kind, created, enabled, blob FROM featured ORDER BY created ASC, fkey ASC') as $r) {
            echo $first ? '' : ',', json_encode([
                'fkey' => (string) $r['fkey'], 'title' => (string) $r['title'], 'credit' => (string) $r['credit'],
                'kind' => (string) $r['kind'], 'created' => (int) $r['created'], 'enabled' => (int) $r['enabled'] === 1,
                'blob_b64' => base64_encode((string) $r['blob']),
            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $first = false;
        }
    } catch (Throwable $e) { /* no featured database yet: an export with no entries */ }
    echo ']}';
    exit;
}

/* ------------------------------------------------------------------- actions */
$done = '';
/* AN UPLOAD PHP THREW AWAY. When a request body is larger than post_max_size, PHP discards
   the whole of it before this script runs: $_POST and $_FILES arrive empty, the CSRF token
   with them, and the honest message — "that was too big for PHP" — would otherwise come out
   as "that form was stale", which sends the operator looking in the wrong place. Nothing is
   changed by this branch; it only explains. */
if ($in && $_SERVER['REQUEST_METHOD'] === 'POST' && !$_POST && !$_FILES && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $done = 'That upload was bigger than PHP on this server accepts: post_max_size is ' . ini_get('post_max_size')
          . ' and upload_max_filesize is ' . ini_get('upload_max_filesize')
          . '. Raise both (php.ini, or a .user.ini in this folder) and try again. Nothing was stored.';
}
if ($in && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') !== 'login' && $done === '') {
    if (!csrf_ok()) {
        $done = 'That form was stale — nothing was changed. Please try again.';
    } else {
        $act = (string) ($_POST['do'] ?? '');
        $key = (string) ($_POST['key'] ?? '');
        if ($act === 'delete' && dw_valid_key($key)) {
            $DB->prepare('DELETE FROM shares WHERE skey = ?')->execute([$key]);
            $done = 'Deleted ' . $key . '.';
        } elseif ($act === 'block' && dw_valid_key($key)) {
            $st = $DB->prepare('SELECT hash FROM shares WHERE skey = ?');
            $st->execute([$key]);
            $hash = (string) $st->fetchColumn();
            if ($hash !== '') {
                $DB->prepare('INSERT OR REPLACE INTO blocked (hash, why, t) VALUES (?, ?, ?)')
                   ->execute([$hash, (string) ($_POST['why'] ?? 'reported'), time()]);
                $DB->prepare('DELETE FROM shares WHERE skey = ?')->execute([$key]);
                $done = 'Deleted ' . $key . ' and blocked it, so re-uploading the same drawing will not bring it back.';
            }
        } elseif ($act === 'keep' && dw_valid_key($key)) {
            /* permanent, and therefore not retiring either: a timer armed before the
               promotion is cancelled here, not left to be ignored */
            $DB->prepare('UPDATE shares SET store = "keep", retire_at = NULL, note = ? WHERE skey = ?')
               ->execute([substr((string) ($_POST['note'] ?? ''), 0, 200), $key]);
            $done = $key . ' is now permanent and will never be pruned or retired.';
        } elseif ($act === 'add') {
            /* Put an entry in by hand, in the permanent store, under a name you choose —
               "benzene", "lecture3", "acs2026". That is how a teaching example or a figure
               for a paper gets a stable ID that will still work in two years, when the
               rotating stores have long since dropped everything else.
               Accepts either a whole 2D-WORM link or the payload out of one. */
            $raw = trim((string) ($_POST['payload'] ?? ''));
            if (preg_match('/[#?&](z|s)=([^&\s]+)/', $raw, $m)) { $raw = $m[1] . '=' . $m[2]; }
            $want = trim((string) ($_POST['newkey'] ?? ''));
            if (!dw_valid_payload($raw)) {
                $done = 'That is not a 2D-WORM link. Copy a FULL LINK out of the SHARE window and paste the whole thing.';
            } elseif ($want !== '' && !dw_valid_key($want)) {
                $done = 'An ID may only be letters and digits, between 4 and 24 of them. Leave it empty for a random one.';
            } else {
                /* One row per drawing, always: `hash` is unique and is what a takedown blocks,
                   so a curated copy must never be a second row with a doctored hash. If the
                   drawing is already here, promote that row — and rename it if a name was
                   asked for, saying plainly what renaming costs. */
                $hash = hash('sha256', $raw);
                $note = substr((string) ($_POST['note'] ?? ''), 0, 200);
                $st = $DB->prepare('SELECT skey FROM shares WHERE hash = ?');
                $st->execute([$hash]);
                $already = (string) $st->fetchColumn();
                $taken = null;
                if ($want !== '' && $want !== $already) {
                    $ex = $DB->prepare('SELECT 1 FROM shares WHERE skey = ?');
                    $ex->execute([$want]);
                    $taken = (bool) $ex->fetchColumn();
                }
                if ($taken) {
                    $done = $want . ' is already taken. Choose another ID.';
                } elseif ($already !== '') {
                    if ($want !== '' && $want !== $already) {
                        $DB->prepare('UPDATE shares SET skey = ?, store = "keep", retire_at = NULL, note = ? WHERE skey = ?')
                           ->execute([$want, $note, $already]);
                        dw_retired_forget($DB, $want);
                        $done = 'That drawing was already stored as ' . $already . '. It is now permanent and called '
                              . $want . ' — ' . dw_short_url($CFG, $want)
                              . '. Any link already handed out with ' . $already . ' has stopped working.';
                    } else {
                        $DB->prepare('UPDATE shares SET store = "keep", retire_at = NULL, note = ? WHERE skey = ?')->execute([$note, $already]);
                        $done = 'That drawing was already stored as ' . $already . '; it is now permanent — ' . dw_short_url($CFG, $already);
                    }
                } else {
                    $newKey = $want !== '' ? $want : dw_key(8);
                    $now = time();
                    $DB->prepare('INSERT INTO shares (skey, hash, payload, bytes, store, created, seen, hits, note)
                                  VALUES (?, ?, ?, ?, "keep", ?, ?, 0, ?)')
                       ->execute([$newKey, $hash, $raw, strlen($raw), $now, $now, $note]);
                    dw_retired_forget($DB, $newKey);
                    $done = 'Stored permanently as ' . $newKey . ' — ' . dw_short_url($CFG, $newKey);
                }
            }
        } elseif ($act === 'upload') {
            $done = dw_admin_upload($DB, $CFG);
        } elseif ($act === 'f_toggle' && dw_valid_key((string) ($_POST['fkey'] ?? ''))) {
            $fdb = dw_featured_db($CFG, 'admin');
            $st = $fdb->prepare('UPDATE featured SET enabled = 1 - enabled WHERE fkey = ?');
            $st->execute([(string) $_POST['fkey']]);
            $on = $fdb->prepare('SELECT enabled FROM featured WHERE fkey = ?');
            $on->execute([(string) $_POST['fkey']]);
            $v = $on->fetchColumn();
            $done = $st->rowCount() === 0 ? 'No featured entry called ' . $_POST['fkey'] . '.'
                  : ($_POST['fkey'] . ((int) $v === 1 ? ' is offered to visitors again.' : ' is kept but no longer offered to visitors.'));
        } elseif ($act === 'f_delete' && dw_valid_key((string) ($_POST['fkey'] ?? ''))) {
            $st = dw_featured_db($CFG, 'admin')->prepare('DELETE FROM featured WHERE fkey = ?');
            $st->execute([(string) $_POST['fkey']]);
            $done = $st->rowCount() ? 'Removed ' . $_POST['fkey'] . ' from the featured list.' : 'No featured entry called ' . $_POST['fkey'] . '.';
        } elseif ($act === 'f_edit' && dw_valid_key((string) ($_POST['fkey'] ?? ''))) {
            $title = trim(substr((string) ($_POST['title'] ?? ''), 0, 200));
            if ($title === '') {
                $done = 'A featured entry needs a title — that is what visitors see.';
            } else {
                $st = dw_featured_db($CFG, 'admin')->prepare('UPDATE featured SET title = ?, credit = ? WHERE fkey = ?');
                $st->execute([$title, trim(substr((string) ($_POST['credit'] ?? ''), 0, 200)), (string) $_POST['fkey']]);
                $done = $st->rowCount() ? 'Renamed ' . $_POST['fkey'] . '.' : 'No featured entry called ' . $_POST['fkey'] . '.';
            }
        } elseif ($act === 'f_import') {
            $done = dw_admin_import($CFG);
        } elseif ($act === 'release' && dw_valid_key($key)) {
            $st = $DB->prepare('SELECT bytes FROM shares WHERE skey = ?');
            $st->execute([$key]);
            $b = (int) $st->fetchColumn();
            $DB->prepare('UPDATE shares SET store = ? WHERE skey = ?')
               ->execute([$b <= (int) $CFG['small_max_bytes'] ? 'small' : 'large', $key]);
            $done = $key . ' is back in the ordinary store and may be pruned again.';
        } elseif ($act === 'unblock') {
            $DB->prepare('DELETE FROM blocked WHERE hash = ?')->execute([(string) ($_POST['hash'] ?? '')]);
            $done = 'Unblocked.';
        } elseif ($act === 'offline') {
            dw_meta($DB, 'offline', substr((string) ($_POST['reason'] ?? ''), 0, 300));
            $done = ($_POST['reason'] ?? '') === '' ? 'Sharing is on again.' : 'Sharing is switched off.';
        } elseif ($act === 'banner') {
            dw_meta($DB, 'banner', substr((string) ($_POST['text'] ?? ''), 0, 300));
            $done = 'Announcement saved.';
        } elseif ($act === 'prune') {
            $before = dw_store_footprint($DB);
            dw_prune($DB, $CFG);
            $after = dw_store_footprint($DB);
            $done = 'Pruned: ' . number_format($before['rows'] - $after['rows']) . ' entries and '
                  . kb($before['bytes'] - $after['bytes']) . ' removed. '
                  . number_format($after['rows']) . ' left.';
        } elseif ($act === 'settings') {
            /* SAVING A LIMIT CHANGES WHAT IS ACCEPTED FROM NOW ON AND NOTHING ELSE. Nothing
               already stored is touched — a mistyped figure in a number field must not delete
               anybody's work, and PRUNE NOW is a separate, deliberate press that says first
               what it would remove. */
            $bad = [];
            /* What the value would be if nothing were saved here: the shipped default, then
               whatever config.php says. A submitted value EQUAL to that is not stored — the
               form posts every field whether or not it was touched, and storing them all would
               silently take config.php out of the loop for settings the operator never
               changed, and quietly break the "clear a box to hand it back" instruction. */
            $base = array_merge(dw_defaults(), dw_from_file());
            foreach (DW_SETTABLE as $k => $spec) {
                if ($spec[0] === 'bool') {
                    /* An unticked checkbox sends NOTHING, so "absent" and "off" look identical
                       — and a form that posted only some fields would silently switch this one
                       off. The hidden marker beside it says the checkbox was on the form at
                       all; without the marker the setting is left alone. */
                    if (!isset($_POST['s_' . $k . '_sent'])) { continue; }
                    $v = isset($_POST['s_' . $k]) ? '1' : '0';
                    $same = ((bool) $base[$k]) === ($v === '1');
                } else {
                    if (!array_key_exists('s_' . $k, $_POST)) { continue; }
                    $v = trim((string) $_POST['s_' . $k]);
                    $same = $v !== '' && is_numeric($v) && (int) $v === (int) $base[$k];
                }
                $why = dw_set_setting($DB, $k, ($v === '' || $same) ? null : $v);
                if ($why !== '') { $bad[] = $spec[4] . ': ' . $why; }
            }
            $CFG = dw_config(true);            // so the page below shows what is now in force
            $done = $bad ? 'Not saved — ' . implode('; ', $bad) : 'Settings saved. Nothing already stored was touched.';
            /* THE ONE EXCEPTION to "nothing already stored is touched", and it removes nothing:
               switching the retirement rule off cancels every timer it had armed, so that no
               entry goes on to be deleted under a rule that no longer exists. */
            if (!$bad && (int) $CFG['retire_hits'] <= 0) {
                $n = dw_retire_clear($DB);
                if ($n > 0) { $done .= ' The retirement rule is off, so ' . number_format($n) . ' pending retirement' . ($n === 1 ? ' was' : 's were') . ' cancelled.'; }
            }
        } elseif ($act === 'settings_reset') {
            foreach (array_keys(DW_SETTABLE) as $k) { dw_set_setting($DB, $k, null); }
            $CFG = dw_config(true);
            $done = 'Back to the shipped defaults, and to whatever config.php sets.';
            if ((int) $CFG['retire_hits'] <= 0) {
                $n = dw_retire_clear($DB);
                if ($n > 0) { $done .= ' ' . number_format($n) . ' pending retirement' . ($n === 1 ? ' was' : 's were') . ' cancelled with the rule.'; }
            }
        } elseif ($act === 'geo') {
            $done = dw_import_geo($DB, (string) $CFG['geo_csv']);
        }
    }
}

/* --------------------------------------------------------------- geo importer
   The country table is built from a CSV the administrator supplies; none is shipped,
   because the free ones come with their own licences and attribution. See geo/README.md.
   Format: start_ip,end_ip,country_code — which is what db-ip and IP2Location LITE give. */
function dw_import_geo(PDO $db, string $csv): string
{
    if (!is_file($csv)) { return 'No file at ' . $csv . ' — see geo/README.md for where to get one.'; }
    $fh = @fopen($csv, 'r');
    if (!$fh) { return 'Could not read ' . $csv . '.'; }
    $db->exec('DELETE FROM geo');
    $ins = $db->prepare('INSERT OR REPLACE INTO geo (lo, hi, cc) VALUES (?, ?, ?)');
    $db->beginTransaction();
    $n = 0; $bad = 0;
    while (($row = fgetcsv($fh)) !== false) {
        if (count($row) < 3) { $bad++; continue; }
        $lo = dw_ip_key(trim((string) $row[0]));
        $hi = dw_ip_key(trim((string) $row[1]));
        $cc = strtoupper(substr(trim((string) $row[2]), 0, 2));
        if ($lo === null || $hi === null || !preg_match('/^[A-Z]{2}$/', $cc)) { $bad++; continue; }
        $ins->execute([$lo, $hi, $cc]);
        $n++;
        if ($n % 50000 === 0) { $db->commit(); $db->beginTransaction(); }
    }
    $db->commit();
    fclose($fh);
    return "Country table rebuilt: $n ranges" . ($bad ? ", $bad lines skipped" : '') . '.';
}

/* ----------------------------------------------------------------- uploads
   One form, two destinations. FEATURED puts the file in the featured database under a
   generated key, with the title and credit typed on the form; PERMANENT puts it in the
   ordinary `shares` table, in the permanent store, as `f=` followed by the bytes in base64
   — so the operator gets a short link and a QR code exactly as any share has, and the page
   opens it through the same route as everything else. Base64 in the existing `payload`
   column rather than a new BLOB column, because that touches nothing: every query, the
   backup, the block-by-hash and the one-row-per-drawing rule all go on working unchanged,
   and the page receives it as JSON as it receives every other payload. The cost is a third
   more storage for those few entries, which is nothing next to a second column in every
   query. What the server does to the bytes: measures them, looks at the first two, stores
   them. Nothing else, ever — see the header of this file.

   The size is checked BEFORE the file is read. PHP has already streamed the upload to a
   temporary file by the time this runs — it never holds an upload in memory on its own —
   so a file over the limit is refused without a byte of it ever being read into PHP. */
function dw_admin_upload(PDO $db, array $cfg): string
{
    $f = $_FILES['file'] ?? null;
    if (!is_array($f) || (int) ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return 'Choose a file first.';
    }
    $err = (int) $f['error'];
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        return 'That file is bigger than PHP on this server accepts (upload_max_filesize is ' . ini_get('upload_max_filesize')
             . ', post_max_size is ' . ini_get('post_max_size') . '). Raise both in php.ini or a .user.ini and try again. Nothing was stored.';
    }
    if ($err !== UPLOAD_ERR_OK) { return 'The upload did not arrive whole (PHP error ' . $err . '). Nothing was stored.'; }
    $max = (int) $cfg['keep_max_bytes'];
    $size = (int) $f['size'];
    if ($size > $max) {
        return 'That file is ' . kb($size) . ', and the most this page stores is ' . kb($max)
             . ' (keep_max_bytes, under Settings). Nothing was stored, and the file was not read.';
    }
    if ($size <= 0) { return 'That file is empty. Nothing was stored.'; }
    if (!is_uploaded_file((string) $f['tmp_name'])) { return 'That was not an upload. Nothing was stored.'; }
    $bytes = (string) file_get_contents((string) $f['tmp_name']);
    if ($bytes === '' || strlen($bytes) !== $size) { return 'The upload could not be read back whole. Nothing was stored.'; }
    $dest   = (string) ($_POST['dest'] ?? 'featured');
    $title  = trim(substr((string) ($_POST['title'] ?? ''), 0, 200));
    $credit = trim(substr((string) ($_POST['credit'] ?? ''), 0, 200));
    $kind   = dw_file_kind($bytes);
    $now    = time();

    if ($dest === 'keep') {
        /* one row per drawing, always — the same bytes uploaded twice promote the row that
           is already there, exactly as "add an entry by hand" does */
        $payload = 'f=' . base64_encode($bytes);
        $hash = hash('sha256', $payload);
        if (dw_blocked($db, $hash)) { return 'Those exact bytes were blocked by a takedown. Unblock them first if that was a mistake.'; }
        $st = $db->prepare('SELECT skey FROM shares WHERE hash = ?');
        $st->execute([$hash]);
        $already = (string) $st->fetchColumn();
        if ($already !== '') {
            $db->prepare('UPDATE shares SET store = "keep", retire_at = NULL, note = ? WHERE skey = ?')->execute([$title, $already]);
            return 'That file was already stored as ' . $already . '; it is now permanent — ' . dw_short_url($cfg, $already);
        }
        $ins = $db->prepare('INSERT INTO shares (skey, hash, payload, bytes, store, created, seen, hits, note)
                             VALUES (?, ?, ?, ?, "keep", ?, ?, 0, ?)');
        for ($try = 0; $try < 6; $try++) {
            $key = dw_key(8 + intdiv($try, 3));
            try { $ins->execute([$key, $hash, $payload, strlen($payload), $now, $now, $title]); }
            catch (PDOException $e) { continue; }               // key collision: another
            dw_retired_forget($db, $key);
            return 'Stored permanently as ' . $key . ' — ' . dw_short_url($cfg, $key) . ' (' . kb($size) . ', ' . $kind . ')';
        }
        return 'Could not find a free key, which should not happen. Try again.';
    }

    if ($title === '') { return 'A featured entry needs a title — that is what visitors see. Nothing was stored.'; }
    $fdb = dw_featured_db($cfg, 'admin');
    for ($try = 0; $try < 6; $try++) {
        $fkey = dw_key(8 + intdiv($try, 3));
        $ex = $fdb->prepare('SELECT 1 FROM featured WHERE fkey = ?');
        $ex->execute([$fkey]);
        if ($ex->fetchColumn()) { continue; }
        dw_featured_put($fdb, $fkey, $title, $credit, $bytes, $now, true);
        return 'Featured as ' . $fkey . ' — "' . $title . '" (' . kb($size) . ', ' . $kind . '). It is offered to visitors from now on.';
    }
    return 'Could not find a free key, which should not happen. Try again.';
}

/* Import the file EXPORT wrote: add or replace by key. The document is parsed, because it
   is our own format; the blobs inside it are not — they are base64, decoded and stored as
   the opaque bytes they were, with `kind` read off the bytes rather than believed from the
   file. Each entry is checked on its own and a bad one is skipped and counted, so one
   damaged entry does not refuse the other forty. `hits` and `seen` of an entry that is
   replaced are kept: the export does not carry them, and a restore should not zero them. */
function dw_admin_import(array $cfg): string
{
    $f = $_FILES['json'] ?? null;
    if (!is_array($f) || (int) ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) { return 'Choose the exported .json file first.'; }
    $err = (int) $f['error'];
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        return 'That file is bigger than PHP on this server accepts (upload_max_filesize is ' . ini_get('upload_max_filesize')
             . ', post_max_size is ' . ini_get('post_max_size') . '). Nothing was imported.';
    }
    if ($err !== UPLOAD_ERR_OK || !is_uploaded_file((string) $f['tmp_name'])) { return 'The upload did not arrive whole. Nothing was imported.'; }
    $doc = json_decode((string) file_get_contents((string) $f['tmp_name']), true);
    if (!is_array($doc) || (int) ($doc['version'] ?? 0) !== 1 || !isset($doc['entries']) || !is_array($doc['entries'])) {
        return 'That is not a featured-list export (expected {"version":1,"entries":[...]}). Nothing was imported.';
    }
    $max = (int) $cfg['keep_max_bytes'];
    $fdb = dw_featured_db($cfg, 'admin');
    $added = 0; $replaced = 0; $skipped = [];
    $fdb->beginTransaction();
    foreach ($doc['entries'] as $i => $e) {
        $label = is_array($e) && isset($e['fkey']) ? (string) $e['fkey'] : ('#' . ($i + 1));
        if (!is_array($e) || !isset($e['fkey'], $e['title'], $e['blob_b64'])
            || !is_string($e['fkey']) || !dw_valid_key($e['fkey'])
            || !is_string($e['title']) || trim($e['title']) === '' || !is_string($e['blob_b64'])) {
            $skipped[] = $label; continue;
        }
        $bytes = base64_decode($e['blob_b64'], true);
        if ($bytes === false || $bytes === '' || strlen($bytes) > $max) { $skipped[] = $label; continue; }
        $ex = $fdb->prepare('SELECT 1 FROM featured WHERE fkey = ?');
        $ex->execute([$e['fkey']]);
        $was = (bool) $ex->fetchColumn();
        dw_featured_put($fdb, $e['fkey'], trim(substr($e['title'], 0, 200)),
            trim(substr((string) ($e['credit'] ?? ''), 0, 200)), $bytes,
            (int) ($e['created'] ?? time()) ?: time(), !isset($e['enabled']) || (bool) $e['enabled']);
        if ($was) { $replaced++; } else { $added++; }
    }
    $fdb->commit();
    return 'Imported: ' . $added . ' added, ' . $replaced . ' replaced'
         . ($skipped ? ', ' . count($skipped) . ' skipped (' . implode(', ', array_slice($skipped, 0, 8)) . (count($skipped) > 8 ? ', …' : '') . ')' : '') . '.';
}

/* ------------------------------------------------------------------- the map
   A proportional-symbol map: one circle per country, placed at its position on an
   equirectangular grid, with area — not radius — proportional to the count, because area is
   what the eye reads. Deliberately NOT a choropleth: filling country shapes would need
   boundary data, every free set of which arrives with its own licence and attribution, and
   this project does not take on a licence it does not need. It would also read badly, since
   a large country with two visits would shout louder than a small one with two hundred.

   These are approximate country centroids, in degrees. They are geographic facts, not data
   from anywhere. A country with usage but no entry here is not silently dropped — it appears
   in the table underneath, which is the exact read in any case. */
const DW_CENTROIDS = [
  'AE' => [54.0, 24.0],  'AR' => [-64.0, -34.0], 'AT' => [14.5, 47.5],  'AU' => [134.0, -25.0],
  'BD' => [90.0, 24.0],  'BE' => [4.5, 50.8],    'BG' => [25.5, 42.7],  'BR' => [-51.0, -10.0],
  'BY' => [28.0, 53.7],  'CA' => [-106.0, 56.0], 'CH' => [8.2, 46.8],   'CL' => [-71.0, -33.0],
  'CN' => [104.0, 35.0], 'CO' => [-74.0, 4.5],   'CZ' => [15.5, 49.8],  'DE' => [10.4, 51.2],
  'DK' => [10.0, 56.0],  'DZ' => [3.0, 28.0],    'EG' => [30.0, 26.8],  'ES' => [-3.7, 40.4],
  'ET' => [40.0, 9.0],   'FI' => [26.0, 64.0],   'FR' => [2.2, 46.6],   'GB' => [-2.0, 54.0],
  'GH' => [-1.0, 8.0],   'GR' => [22.0, 39.0],   'HK' => [114.2, 22.3], 'HR' => [15.5, 45.1],
  'HU' => [19.5, 47.2],  'ID' => [113.0, -2.5],  'IE' => [-8.0, 53.3],  'IL' => [35.0, 31.5],
  'IN' => [79.0, 22.0],  'IQ' => [43.7, 33.2],   'IR' => [53.7, 32.4],  'IS' => [-19.0, 65.0],
  'IT' => [12.5, 42.8],  'JO' => [36.2, 31.2],   'JP' => [138.0, 36.2], 'KE' => [37.9, 0.2],
  'KR' => [127.8, 36.5], 'KW' => [47.5, 29.3],   'KZ' => [66.9, 48.0],  'LB' => [35.9, 33.9],
  'LK' => [80.8, 7.9],   'LT' => [24.0, 55.2],   'LV' => [24.6, 56.9],  'MA' => [-6.0, 32.0],
  'MX' => [-102.0, 23.6],'MY' => [102.0, 4.2],   'NG' => [8.7, 9.1],    'NL' => [5.3, 52.1],
  'NO' => [10.0, 61.0],  'NZ' => [172.0, -41.0], 'OM' => [56.0, 21.0],  'PE' => [-75.0, -9.2],
  'PH' => [122.0, 12.9], 'PK' => [69.3, 30.4],   'PL' => [19.1, 52.0],  'PT' => [-8.2, 39.4],
  'QA' => [51.2, 25.3],  'RO' => [25.0, 45.9],   'RS' => [21.0, 44.0],  'RU' => [90.0, 60.0],
  'SA' => [45.1, 23.9],  'SE' => [15.0, 62.0],   'SG' => [103.8, 1.35], 'SI' => [14.8, 46.1],
  'SK' => [19.5, 48.7],  'TH' => [101.0, 15.9],  'TN' => [9.5, 34.0],   'TR' => [35.2, 39.0],
  'TW' => [121.0, 23.7], 'UA' => [31.2, 48.4],   'US' => [-98.0, 39.5], 'UY' => [-56.0, -33.0],
  'UZ' => [64.6, 41.4],  'VN' => [108.3, 14.1],  'ZA' => [24.0, -29.0], 'SD' => [30.2, 15.6],
  'SY' => [38.0, 35.0],  'YE' => [47.5, 15.5],   'AZ' => [47.6, 40.1],  'GE' => [43.4, 42.3],
  'AM' => [45.0, 40.1],  'NP' => [84.1, 28.4],   'MM' => [96.0, 21.9],  'KH' => [105.0, 12.6],
  'BH' => [50.6, 26.1],  'CY' => [33.4, 35.1],   'EE' => [25.0, 58.6],  'LU' => [6.1, 49.8],
  'MT' => [14.4, 35.9],  'AL' => [20.2, 41.2],   'MD' => [28.4, 47.0],  'BA' => [17.8, 44.0],
  'MK' => [21.7, 41.6],  'LY' => [17.2, 26.3],   'TZ' => [34.9, -6.4],  'UG' => [32.3, 1.4],
  'ZW' => [29.2, -19.0], 'ZM' => [27.8, -13.1],  'SN' => [-14.5, 14.5], 'CI' => [-5.5, 7.5],
  'CM' => [12.4, 5.7],   'AO' => [17.9, -11.2],  'MZ' => [35.5, -18.7], 'EC' => [-78.2, -1.8],
  'BO' => [-63.6, -16.3],'PY' => [-58.4, -23.4], 'CR' => [-84.1, 9.7],  'PA' => [-80.8, 8.5],
  'GT' => [-90.2, 15.8], 'CU' => [-77.8, 21.5],  'DO' => [-70.2, 18.7], 'JM' => [-77.3, 18.1],
];


/* The coastlines are Natural Earth 1:110m — public domain, no attribution required and no
   licence to inherit, which is exactly why it is that dataset. Decoded from TopoJSON into
   plain longitude/latitude by 2dworm-test/make-coastlines.mjs, so this page needs no reader
   for it. Still NO BORDERS: what the map has to show is where the circles are, and a border
   would only invite somebody to read a disputed line off a 110-million-scale outline. */
require_once __DIR__ . '/lib/coastlines.php';

/** The map, as inline SVG. `$counts` is country code => number; `$total` its sum. */
function dw_world_map(array $counts, int $total): string
{
    $W = 1040; $H = 440; $LAT0 = 82; $LAT1 = -58;      // clipped: nobody lives at the poles
    $x = fn(float $lon) => ($lon + 180) / 360 * $W;
    $y = fn(float $lat) => ($LAT0 - $lat) / ($LAT0 - $LAT1) * $H;
    $max = max(1, max($counts ?: [1]));
    $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" width="100%" role="img" aria-label="Visits by country" '
         . 'font-family="system-ui, sans-serif" class="worldmap">';
    $svg .= '<rect width="' . $W . '" height="' . $H . '" fill="var(--mapbg)" rx="6"/>';
    /* A coarse land outline, so the circles sit on something recognisable instead of floating
       on an empty grid. Deliberately coarse — a dozen or so points per landmass, in degrees of
       longitude and latitude — because this is a backdrop for reading circle sizes against,
       not a chart anybody should navigate by. No boundary data is bundled and none is needed:
       these are a handful of coordinates, and no country borders are drawn at all. */
    foreach (DW_COAST as $ring) {
        $pts = []; $clamped = 0;
        foreach (explode(' ', $ring) as $pair) {
            [$lon, $lat] = explode(',', $pair);
            $lat = (float) $lat;
            /* CLAMPED to the drawn band, not dropped. Dropping the points outside it leaves
               the ring open and the remaining ends join straight across the map. Clamping
               flattens the ring against the edge instead, which is what a cut-off map should
               look like. */
            if ($lat > $LAT0) { $lat = $LAT0; $clamped++; }
            elseif ($lat < $LAT1) { $lat = $LAT1; $clamped++; }
            $pts[] = round($x((float) $lon), 1) . ',' . round($y($lat), 1);
        }
        /* A ring that is MOSTLY outside the band — the polar ice, Antarctica — flattens into a
           bar the full width of the map, which is worse than not drawing it. Nobody shares a
           molecule from there. */
        if (count($pts) >= 3 && $clamped < 0.5 * count($pts)) {
            $svg .= '<polygon points="' . implode(' ', $pts) . '" fill="var(--mapland)" stroke="none"/>';
        }
    }
    for ($lon = -150; $lon <= 150; $lon += 30) {
        $svg .= '<line x1="' . round($x($lon), 1) . '" y1="0" x2="' . round($x($lon), 1) . '" y2="' . $H . '" stroke="var(--mapgrid)" stroke-width="1"/>';
    }
    for ($lat = 60; $lat >= -40; $lat -= 20) {
        $t = round($y($lat), 1);
        $svg .= '<line x1="0" y1="' . $t . '" x2="' . $W . '" y2="' . $t . '" stroke="var(--mapgrid)" stroke-width="' . ($lat === 0 ? 2 : 1) . '"/>';
    }
    $missing = [];
    // biggest first, so a large circle never hides a small one it overlaps
    arsort($counts);
    $body = '';
    foreach ($counts as $cc => $n) {
        if ($cc === 'Other' || !isset(DW_CENTROIDS[$cc])) { $missing[] = $cc; continue; }
        [$lon, $lat] = DW_CENTROIDS[$cc];
        $r = 5 + 26 * sqrt($n / $max);                 // AREA proportional to the count
        $cx = round($x($lon), 1); $cy = round($y($lat), 1);
        $pc = $total > 0 ? round(100 * $n / $total, 1) : 0;
        $body .= '<g><title>' . h((string) $cc) . ' — ' . number_format($n) . ' (' . $pc . '%)</title>'
              . '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . round($r, 1) . '" fill="var(--mapdot)" '
              . 'fill-opacity=".62" stroke="var(--mapbg)" stroke-width="2"/>'
              . ($r > 13 ? '<text x="' . $cx . '" y="' . ($cy + 4) . '" text-anchor="middle" font-size="11" '
                          . 'font-weight="700" fill="#fff">' . h((string) $cc) . '</text>' : '')
              . '</g>';
    }
    $svg .= $body;
    /* OTHER, DRAWN ON THE MAP RATHER THAN ONLY UNDER IT. Every count below five and every
       country with no centroid is folded into "Other", and until now that bucket appeared
       only in the table — so a map showing four circles could be hiding a third of the
       visits and looked complete. It has no position, because it is not a place; it is
       drawn as a square in the bottom-left corner, sized on the same scale as the circles,
       so its size can be compared with them at a glance and it cannot be read as a country.

       A square, not a circle, precisely so that nobody takes it for one. */
    $other = 0;
    foreach ($counts as $cc => $n) { if ($cc === 'Other' || !isset(DW_CENTROIDS[$cc])) { $other += $n; } }
    if ($other > 0) {
        $r = 5 + 26 * sqrt($other / $max);
        $side = round(2 * $r * 0.886, 1);                 // the same AREA as a circle of radius r
        $bx = 16; $by = $H - 16 - $side;
        $pc = $total > 0 ? round(100 * $other / $total, 1) : 0;
        $svg .= '<g><title>Other — ' . number_format($other) . ' (' . $pc . '%): every country below five, '
              . 'and every one with no place on this map</title>'
              . '<rect x="' . $bx . '" y="' . round($by, 1) . '" width="' . $side . '" height="' . $side . '" rx="3" '
              . 'fill="var(--mapdot)" fill-opacity=".62" stroke="var(--mapbg)" stroke-width="2"/>'
              . ($side > 26 ? '<text x="' . round($bx + $side / 2, 1) . '" y="' . round($by + $side / 2 + 4, 1) . '" '
                             . 'text-anchor="middle" font-size="11" font-weight="700" fill="#fff">OTHER</text>' : '')
              . '<text x="' . $bx . '" y="' . ($H - 5) . '" font-size="10" fill="var(--mapgrid)">OTHER '
              . number_format($other) . '</text></g>';
    }
    $svg .= '</svg>';
    if ($missing) {
        $svg .= '<p class="muted">Folded into the square at the bottom left: ' . h(implode(', ', $missing))
              . ' — the table below has every country.</p>';
    }
    return $svg;
}

/* ------------------------------------------------------------------ read-outs */
$stats = [];
foreach (DW_STORES as $s) {
    $st = $DB->prepare('SELECT COUNT(*) c, COALESCE(SUM(bytes),0) b, COALESCE(SUM(hits),0) h FROM shares WHERE store = ?');
    $st->execute([$s]);
    $stats[$s] = $st->fetch() ?: ['c' => 0, 'b' => 0, 'h' => 0];
}
$offline = $in ? dw_offline($DB) : '';
$banner  = $in ? (string) (dw_meta($DB, 'banner') ?? '') : '';

$q = trim((string) ($_GET['q'] ?? ''));
$storeFilter = in_array($_GET['store'] ?? '', DW_STORES, true) ? (string) $_GET['store'] : '';
$rows = [];
if ($in) {
    $sql = 'SELECT skey, bytes, store, created, seen, hits, note, hash, retire_at FROM shares';
    $wh = []; $args = [];
    if ($q !== '' && dw_valid_key($q)) { $wh[] = 'skey = ?'; $args[] = $q; }
    if ($storeFilter !== '')           { $wh[] = 'store = ?'; $args[] = $storeFilter; }
    if ($wh) { $sql .= ' WHERE ' . implode(' AND ', $wh); }
    $sql .= ' ORDER BY seen DESC LIMIT 60';
    $st = $DB->prepare($sql);
    $st->execute($args);
    $rows = $st->fetchAll();
}
/* THE FIFTY MOST POPULAR. `hits` has been in the schema since it was written and TERMS.md
   has always disclosed it, so this is one ORDER BY and no new counter, no new promise.
   Entries nobody has opened are left out: a list of the most opened padded with the never
   opened would say nothing. Ties go to the most recently opened. */
$popular = [];
$retireOn = $in && (int) $CFG['retire_hits'] > 0;
$retirePending = $in ? dw_retire_pending($DB) : 0;
if ($in) {
    $popular = $DB->query('SELECT skey, bytes, store, created, seen, hits, note, hash, retire_at FROM shares
                           WHERE hits > 0 ORDER BY hits DESC, seen DESC LIMIT 50')->fetchAll();
}
/* The featured list, whole — disabled entries included, since this is where they are
   switched back on. Read on the read-only handle: merely LOOKING at this page must not
   create a database; the first upload does that. */
$featuredRows = []; $featuredDb = false;
if ($in) {
    try {
        $fdb = dw_featured_db($CFG, 'ro');
        $featuredRows = $fdb->query('SELECT fkey, title, credit, bytes, kind, created, hits, seen, enabled FROM featured ORDER BY created DESC, fkey ASC')->fetchAll();
        $featuredDb = true;
    } catch (Throwable $e) { $featuredDb = false; }
}
/** One row of a drawings table, with its buttons. Shared by the recent list and the most
    popular, so the two cannot drift apart. */
function dw_share_row(array $r, string $pageUrl, bool $retireOn): string
{
    $t = h(csrf()); $k = h((string) $r['skey']);
    $retire = '';
    if ($retireOn) {
        $retire = '<td class="muted">' . ($r['retire_at'] !== null ? when((int) $r['retire_at']) : '') . '</td>';
    }
    $out = '<tr><td><a href="' . h($pageUrl) . '?k=' . $k . '" target="_blank" rel="noopener noreferrer">' . $k . '</a></td>'
         . '<td>' . h((string) $r['store']) . '</td>'
         . '<td class="num">' . kb((int) $r['bytes']) . '</td>'
         . '<td class="num">' . (int) $r['hits'] . '</td>'
         . '<td>' . when((int) $r['created']) . '</td>'
         . '<td>' . when((int) $r['seen']) . '</td>'
         . $retire
         . '<td class="muted">' . h((string) $r['note']) . '</td>'
         . '<td style="white-space:nowrap">';
    if ($r['store'] !== 'keep') {
        $out .= '<form method="post" class="inline"><input type="hidden" name="csrf" value="' . $t . '">'
              . '<input type="hidden" name="do" value="keep"><input type="hidden" name="key" value="' . $k . '">'
              . '<button title="Never prune or retire this one">Keep</button></form>';
    } else {
        $out .= '<form method="post" class="inline"><input type="hidden" name="csrf" value="' . $t . '">'
              . '<input type="hidden" name="do" value="release"><input type="hidden" name="key" value="' . $k . '">'
              . '<button title="Allow pruning again">Release</button></form>';
    }
    $out .= '<form method="post" class="inline"><input type="hidden" name="csrf" value="' . $t . '">'
          . '<input type="hidden" name="do" value="delete"><input type="hidden" name="key" value="' . $k . '">'
          . '<button class="d">Delete</button></form>'
          . '<form method="post" class="inline"><input type="hidden" name="csrf" value="' . $t . '">'
          . '<input type="hidden" name="do" value="block"><input type="hidden" name="key" value="' . $k . '">'
          . '<button class="d" title="Delete and refuse the same drawing in future">Block</button></form>'
          . '</td></tr>';
    return $out;
}
function dw_share_head(bool $retireOn): string
{
    return '<thead><tr><th>ID</th><th>Store</th><th class="num">Size</th><th class="num">Opens</th>'
         . '<th>Made</th><th>Last opened</th>' . ($retireOn ? '<th>Retires</th>' : '') . '<th>Note</th><th></th></tr></thead>';
}

/* Usage. Counts below five are folded into "Other" before they are ever shown, so a
   single visit from a small country never becomes a fact about a person. */
$byCountry = []; $byDay = []; $totals = [];
if ($in) {
    foreach ($DB->query('SELECT country, action, SUM(n) n FROM usage_day GROUP BY country, action')->fetchAll() as $r) {
        $byCountry[$r['country']] = ($byCountry[$r['country']] ?? 0) + (int) $r['n'];
        $totals[$r['action']] = ($totals[$r['action']] ?? 0) + (int) $r['n'];
    }
    arsort($byCountry);
    $folded = 0;
    foreach ($byCountry as $cc => $n) { if ($n < 5 || $cc === 'ZZ') { $folded += $n; unset($byCountry[$cc]); } }
    if ($folded) { $byCountry['Other'] = $folded; }
    /* Split by action, because "how much is it used" and "how fast is the database filling
       up" are different questions with different answers: an opened link costs nothing,
       a created one costs a row. */
    foreach ($DB->query('SELECT day, action, SUM(n) n FROM usage_day GROUP BY day, action ORDER BY day DESC')->fetchAll() as $r) {
        $d = (string) $r['day'];
        if (!isset($byDay[$d])) {
            if (count($byDay) >= 30) { continue; }
            $byDay[$d] = ['create' => 0, 'open' => 0];
        }
        $k = ((string) $r['action'] === 'create') ? 'create' : 'open';
        $byDay[$d][$k] += (int) $r['n'];
    }
    $byDay = array_reverse($byDay, true);
}
/* By month, and all time. A day chart answers "is it busy today"; a month chart answers
   "is it growing", which is the question that decides whether the store is big enough. */
$byMonth = []; $allTime = ['create' => 0, 'open' => 0];
if ($in) {
    foreach ($DB->query('SELECT substr(day,1,7) m, action, SUM(n) n FROM usage_day GROUP BY m, action ORDER BY m')->fetchAll() as $r) {
        $m = (string) $r['m'];
        if (!isset($byMonth[$m])) { $byMonth[$m] = ['create' => 0, 'open' => 0]; }
        $k = ((string) $r['action'] === 'create') ? 'create' : 'open';
        $byMonth[$m][$k] += (int) $r['n'];
        $allTime[$k] += (int) $r['n'];
    }
    if (count($byMonth) > 24) { $byMonth = array_slice($byMonth, -24, null, true); }
}
$maxMonth = 1;
foreach ($byMonth as $v) { $maxMonth = max($maxMonth, $v['create'] + $v['open']); }
/* By year as well. A day answers "is it busy today", a month "is it growing", a year "was
   last year bigger than the one before" — which is the only one of the three that still
   means anything after a decade, and this is meant to run for one. */
$byYear = [];
if ($in) {
    foreach ($DB->query('SELECT substr(day,1,4) y, action, SUM(n) n FROM usage_day GROUP BY y, action ORDER BY y')->fetchAll() as $r) {
        $y = (string) $r['y'];
        if (!isset($byYear[$y])) { $byYear[$y] = ['create' => 0, 'open' => 0]; }
        $byYear[$y][((string) $r['action'] === 'create') ? 'create' : 'open'] += (int) $r['n'];
    }
}
$maxYear = 1;
foreach ($byYear as $v) { $maxYear = max($maxYear, $v['create'] + $v['open']); }

/* The feature tallies. Read one kind at a time and NEVER joined to each other or to the
   country table — see count.php for why that is the whole design and not an oversight. */
$tally = ['feature' => [], 'platform' => [], 'headset' => []];
$tallyMonth = ['feature' => [], 'platform' => [], 'headset' => []];
$thisMonth = gmdate('Y-m');
if ($in) {
    foreach ($DB->query('SELECT kind, key, SUM(n) n FROM usage_tally GROUP BY kind, key ORDER BY n DESC')->fetchAll() as $r) {
        if (isset($tally[$r['kind']])) { $tally[$r['kind']][(string) $r['key']] = (int) $r['n']; }
    }
    $st = $DB->prepare('SELECT kind, key, SUM(n) n FROM usage_tally WHERE substr(day,1,7) = ? GROUP BY kind, key ORDER BY n DESC');
    $st->execute([$thisMonth]);
    foreach ($st->fetchAll() as $r) {
        if (isset($tallyMonth[$r['kind']])) { $tallyMonth[$r['kind']][(string) $r['key']] = (int) $r['n']; }
    }
}
/** A tally as a table: the count and its share, which is what "and percentage" means. */
function dw_tally_table(array $all, array $month, string $what): string
{
    if (!$all) {
        return '<p class="muted">Nothing counted yet' . ($what ? ' for ' . h($what) : '') . '.</p>';
    }
    $sum = array_sum($all) ?: 1;
    $max = max($all);
    $out = '<table style="margin-top:8px"><thead><tr><th>' . h($what) . '</th><th></th>'
         . '<th class="num" style="width:90px">All time</th><th class="num" style="width:70px">Share</th>'
         . '<th class="num" style="width:90px">This month</th></tr></thead><tbody>';
    foreach ($all as $k => $n) {
        $out .= '<tr><td>' . h((string) $k) . '</td>'
              . '<td><div class="bar" style="width:' . max(2, (int) round(100 * $n / $max)) . '%"></div></td>'
              . '<td class="num">' . number_format($n) . '</td>'
              . '<td class="num">' . number_format(100 * $n / $sum, 1) . '%</td>'
              . '<td class="num">' . number_format($month[$k] ?? 0) . '</td></tr>';
    }
    $out .= '</tbody><tfoot><tr><td><b>Total</b></td><td></td><td class="num"><b>' . number_format($sum) . '</b></td>'
          . '<td class="num">100%</td><td class="num">' . number_format(array_sum($month)) . '</td></tr></tfoot></table>';
    return $out;
}
$firstDay = $in ? (string) ($DB->query('SELECT MIN(day) FROM usage_day')->fetchColumn() ?: '') : '';
$daysRecorded = $in ? (int) $DB->query('SELECT COUNT(DISTINCT day) FROM usage_day')->fetchColumn() : 0;
$countriesSeen = $in ? (int) $DB->query("SELECT COUNT(DISTINCT country) FROM usage_day WHERE country <> 'ZZ'")->fetchColumn() : 0;
$storedNow = 0; $bytesNow = 0; $opensNow = 0;
foreach (DW_STORES as $s) { $storedNow += (int) $stats[$s]['c']; $bytesNow += (int) $stats[$s]['b']; $opensNow += (int) $stats[$s]['h']; }

$daysSeen  = max(1, count($byDay));
$madeSum   = array_sum(array_column($byDay, 'create'));
$openSum   = array_sum(array_column($byDay, 'open'));
$writesDay = $madeSum / $daysSeen;
/* At this rate, when does the small store start dropping its oldest entries? Not a
   prediction — arithmetic on what has actually happened, which is what a capacity question
   deserves. Deduplicated re-shares make the true rate lower, so this is the pessimistic end. */
$smallLeft = max(0, (int) $CFG['small_max_rows'] - (int) ($stats['small']['c'] ?? 0));
$daysLeft  = $writesDay > 0 ? $smallLeft / $writesDay : null;
$geoRanges = $in ? (int) $DB->query('SELECT COUNT(*) FROM geo')->fetchColumn() : 0;
$blockedRows = $in ? $DB->query('SELECT hash, why, t FROM blocked ORDER BY t DESC LIMIT 30')->fetchAll() : [];
$maxDay = 1;
foreach ($byDay as $v) { $maxDay = max($maxDay, $v['create'] + $v['open']); }
$countryTotal = array_sum($byCountry);
$pageUrl = dw_page_url($CFG);
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>2D-WORM — sharing service</title>
<style>
  /* Two chart colours, validated for colour-blind separation against both surfaces:
     blue = links made, orange = links opened. They also carry text labels, so identity is
     never colour alone. */
  :root { --bg:#fff; --bg2:#f4f4f4; --line:#d8d8d8; --fg:#161616; --dim:#6a6a6a; --accent:#ffb100; --err:#c62828; --ok:#1f8f3a;
          --s1:#2a78d6; --s2:#eb6834; --mapbg:#eef2f6; --mapgrid:#dbe2e8; --mapland:#dfe5da; --mapdot:#2a78d6; --field:#fff; --warnbg:#fdf0ef;
          color-scheme: light; }
  @media (prefers-color-scheme: dark) {
    :root { --bg:#151514; --bg2:#232320; --line:#3a3a36; --fg:#f2f2ee; --dim:#a3a29a; --err:#ff6b6b; --ok:#6fd36f;
            --s1:#3987e5; --s2:#d95926; --mapbg:#18202a; --mapgrid:#2b3540; --mapland:#26302a; --mapdot:#3987e5; --field:#1f1f1d; --warnbg:#33201f;
            color-scheme: dark; }
    .msg.e { background:#3a1f1f; }
    .msg.o { background:#1c3222; }
  }
  * { box-sizing: border-box; }
  body { margin:0; font:14px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif; color:var(--fg); background:var(--bg); }
  header { background:#000; color:#fff; padding:10px 16px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
  header b { color:var(--accent); letter-spacing:.5px; }
  main { padding:16px; max-width:1100px; margin:0 auto; }
  h2 { font-size:15px; text-transform:uppercase; letter-spacing:.6px; margin:26px 0 8px; border-bottom:1px solid var(--line); padding-bottom:5px; }
  table { border-collapse:collapse; width:100%; font-size:13px; }
  th, td { text-align:left; padding:5px 8px; border-bottom:1px solid var(--line); vertical-align:middle; }
  th { color:var(--dim); font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.4px; }
  td.num, th.num { text-align:right; font-variant-numeric:tabular-nums; }
  button, input[type=text], input[type=password], input[type=search], textarea { font:inherit; padding:5px 9px; border:1px solid var(--line); border-radius:5px; background:var(--field); color:var(--fg); }
  button { background:var(--bg2); cursor:pointer; }
  button.p { background:var(--accent); border-color:var(--accent); font-weight:700; }
  button.d { color:var(--err); }
  .cards { display:flex; gap:10px; flex-wrap:wrap; }
  .card { border:1px solid var(--line); border-radius:8px; padding:10px 14px; min-width:150px; }
  .card b { display:block; font-size:22px; font-variant-numeric:tabular-nums; }
  .card span { color:var(--dim); font-size:12px; text-transform:uppercase; letter-spacing:.4px; }
  .msg { padding:8px 12px; border-radius:6px; margin:12px 0; }
  .msg.e { background:#fdecea; color:var(--err); }
  .msg.o { background:#e9f7ee; color:var(--ok); }
  .bar { background:var(--accent); height:12px; border-radius:2px 4px 4px 2px; }
  /* two series side by side, with a 2px gap of surface between them so the boundary is
     never ambiguous */
  .stack { display:flex; height:12px; }
  .seg { height:12px; border-radius:2px 4px 4px 2px; }
  .seg + .seg { margin-left:2px; }
  .seg.s1 { background:var(--s1); }
  .seg.s2 { background:var(--s2); }
  .legend { display:flex; gap:18px; flex-wrap:wrap; font-size:12px; color:var(--dim); margin:2px 0 8px; }
  .legend i { display:inline-block; width:11px; height:11px; border-radius:3px; margin-right:6px; vertical-align:-1px; }
  .worldmap { display:block; max-width:100%; height:auto; margin:4px 0 2px; }
  .cap { height:5px; background:var(--line); border-radius:3px; margin-top:6px; overflow:hidden; }
  .cap i { display:block; height:5px; background:var(--accent); }
  .muted { color:var(--dim); }
  /* A warning, not an error: it is the operator's own service and his own policy to edit —
     but he is told, in the place where he changed the thing that made it untrue. */
  .warn { background: var(--warnbg); border-inline-start: 4px solid var(--err); padding: 10px 12px;
          border-radius: 6px; margin: 10px 0; }
  form.inline { display:inline; }
  .login { max-width:340px; margin:80px auto; }
  .row { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:8px 0; }
  code { background:var(--bg2); padding:1px 5px; border-radius:4px; font-size:12px; }
</style>
</head><body>
<header><b>2D-WORM</b> sharing service<?= $in ? ' — administration' : '' ?>
<?php if ($in): ?>
  <span style="margin-left:auto"></span>
  <form method="post" class="inline"><input type="hidden" name="do" value="logout"><button>Log out</button></form>
<?php endif; ?>
</header>
<main>

<?php if (!$in): ?>
  <div class="login">
    <h2>Administration</h2>
    <?php if ($notice): ?><div class="msg e"><?= h($notice) ?></div><?php endif; ?>
    <?php if ($locked): ?>
      <p>Too many failed attempts this hour. Try again after the hour turns.</p>
    <?php else: ?>
      <form method="post">
        <input type="hidden" name="do" value="login">
        <div class="row"><input type="password" name="pw" placeholder="Password" autocomplete="current-password" autofocus style="flex:1"></div>
        <div class="row"><button class="p" type="submit">Log in</button></div>
      </form>
      <p class="muted">This page is reachable only while <code>.admin-enabled</code> exists in
      the QRsharing folder. Delete that file when you are finished and the page returns 404.</p>
    <?php endif; ?>
  </div>
<?php else: ?>

  <?php if ($done): ?><div class="msg o"><?= h($done) ?></div><?php endif; ?>
  <?php if ($offline !== ''): ?><div class="msg e">Sharing is switched off: <?= h($offline) ?></div><?php endif; ?>

  <h2>Stores</h2>
  <div class="cards">
    <?php foreach (DW_STORES as $s):
      $lbl = ['small' => 'Small (≤ ' . kb((int) $CFG['small_max_bytes']) . ')',
              'large' => 'Large (to ' . kb((int) $CFG['large_max_bytes']) . ')',
              'keep'  => 'Permanent'][$s]; ?>
      <?php
        $cap = ['small' => (int) $CFG['small_max_rows'], 'large' => (int) $CFG['large_max_rows'], 'keep' => 0][$s];
        $used = (int) $stats[$s]['c'];
        $pc = $cap > 0 ? min(100, 100 * $used / $cap) : null;
      ?>
      <div class="card"><span><?= h($lbl) ?></span><b><?= number_format($used) ?></b>
        <span><?= kb((int) $stats[$s]['b']) ?> · <?= number_format((int) $stats[$s]['h']) ?> opens</span>
        <?php if ($pc !== null): ?>
          <div class="cap"><i style="width:<?= round($pc, 2) ?>%"></i></div>
          <span><?= number_format($pc, 1) ?>% of <?= number_format($cap) ?></span>
        <?php else: ?>
          <span>never pruned</span>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <div class="card"><span>Links made</span><b><?= (int) ($totals['create'] ?? 0) ?></b><span>all time</span></div>
    <div class="card"><span>Links opened</span><b><?= (int) ($totals['open'] ?? 0) ?></b><span>all time</span></div>
  </div>
  <p class="muted">The small and large stores drop their least recently opened entries when
  they reach their limits. The permanent store is never pruned — put anything there that must
  survive.</p>

  <h2>All time</h2>
  <div class="cards">
    <div class="card"><span>Links made</span><b><?= number_format($allTime['create']) ?></b>
      <span><?= $firstDay ? 'since ' . h($firstDay) : 'nothing counted yet' ?></span></div>
    <div class="card"><span>Links opened</span><b><?= number_format($allTime['open']) ?></b>
      <span><?= $allTime['create'] ? number_format($allTime['open'] / max(1, $allTime['create']), 1) . '× per link made' : '—' ?></span></div>
    <div class="card"><span>Drawings held now</span><b><?= number_format($storedNow) ?></b>
      <span><?= kb($bytesNow) ?> · <?= number_format($opensNow) ?> opens</span></div>
    <div class="card"><span>Countries</span><b><?= number_format($countriesSeen) ?></b>
      <span><?= $geoRanges ? 'seen so far' : 'no country table loaded' ?></span></div>
    <div class="card"><span>Days recorded</span><b><?= number_format($daysRecorded) ?></b>
      <span>with any activity</span></div>
  </div>
  <p class="muted">“Links made” counts every share since counting began, including ones long
  since pruned; “drawings held now” is what is in the databases at this moment. The gap between
  them is what the rotating stores have dropped.</p>

  <h2>Per month</h2>
  <?php if (!$byMonth): ?><p class="muted">Nothing counted yet.</p><?php else: ?>
    <p class="legend">
      <span><i style="background:var(--s1)"></i>links made</span>
      <span><i style="background:var(--s2)"></i>links opened</span>
    </p>
    <table>
    <thead><tr><th style="width:110px">Month</th><th></th><th class="num" style="width:80px">Made</th><th class="num" style="width:80px">Opened</th></tr></thead>
    <tbody>
    <?php foreach ($byMonth as $m => $v): ?>
      <tr><td><?= h($m) ?></td>
          <td><div class="stack">
            <div class="seg s1" style="width:<?= 100 * $v['create'] / $maxMonth ?>%"></div>
            <div class="seg s2" style="width:<?= 100 * $v['open'] / $maxMonth ?>%"></div>
          </div></td>
          <td class="num"><b><?= number_format($v['create']) ?></b></td>
          <td class="num"><?= number_format($v['open']) ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    <p class="muted">The last <?= count($byMonth) ?> month<?= count($byMonth) === 1 ? '' : 's' ?>.
    Compare the bars rather than the numbers: what matters here is whether it is growing.</p>
  <?php endif; ?>

  <h2>Per year</h2>
  <?php if (!$byYear): ?><p class="muted">Nothing counted yet.</p><?php else: ?>
    <table>
    <thead><tr><th style="width:110px">Year</th><th></th><th class="num" style="width:90px">Made</th><th class="num" style="width:90px">Opened</th></tr></thead>
    <tbody>
    <?php foreach ($byYear as $y => $v): ?>
      <tr><td><?= h((string) $y) ?></td>
          <td><div class="stack">
            <div class="seg s1" style="width:<?= 100 * $v['create'] / $maxYear ?>%"></div>
            <div class="seg s2" style="width:<?= 100 * $v['open'] / $maxYear ?>%"></div>
          </div></td>
          <td class="num"><b><?= number_format($v['create']) ?></b></td>
          <td class="num"><?= number_format($v['open']) ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    <p class="muted">Kept for as long as the service runs. A day answers “is it busy today”, a
    month “is it growing”, a year “was last year bigger than the one before” — and after a
    decade the year is the only one of the three still worth looking at.</p>
  <?php endif; ?>

  <h2>What is used</h2>
  <?= dw_tally_table($tally['feature'], $tallyMonth['feature'], 'Feature') ?>
  <p class="muted">Counted in the page and posted as one small batch every couple of minutes,
  and once more when the tab closes — never one request per action. There is no cookie, no
  session and no identifier of any kind: two visits by one person are indistinguishable from
  two people, which is deliberate. Switch it all off with <code>count_usage</code>.</p>

  <h2>Devices and headsets</h2>
  <?= dw_tally_table($tally['platform'], $tallyMonth['platform'], 'Platform') ?>
  <?= dw_tally_table($tally['headset'], $tallyMonth['headset'], 'Headset') ?>
  <p class="muted"><b>These three tables cannot be joined, and that is the design.</b> There is
  a count of Quests today, a count of Androids today and a count of visits from a country
  today, and nothing relates them — a single row saying “this country, this headset, this
  platform, today, one” would be one identifiable person. The user agent never reaches the
  database either: it becomes one word from a short list before anything is written.</p>
  <p class="muted">Two things to read these with. A Quest <i>is</i> Android, so it is counted in
  both tables and they must not be added together. And WebXR does not tell a page which
  headset it is on — deliberately, to stop fingerprinting — so the model comes from the user
  agent, which a headset can be told to disguise. Treat the headset figures as indicative.</p>

  <h2>How busy can it get before the hosting has to grow?</h2>
  <p class="muted"><b>This page cannot tell you how many people are on the site at once, and it
  would be dishonest to print a number that looked as though it could.</b> No address and no
  session is stored, so there is nobody to count; and a first visit is about 17 MB of static
  files served straight by the web server, which never reaches PHP at all — so the figures
  here see only the sharing endpoint and would badly under-report the load that actually
  decides the hosting plan. For that, use the web server's own statistics (cPanel ▸ Awstats or
  Webalizer), which count every request including the ones that never touch this code.</p>

  <h2>Written per day</h2>
  <?php if (!$byDay): ?><p class="muted">Nothing counted yet.</p><?php else: ?>
    <p class="legend">
      <span><i style="background:var(--s1)"></i>links made — each one writes a row</span>
      <span><i style="background:var(--s2)"></i>links opened — costs nothing but a read</span>
    </p>
    <table>
    <thead><tr><th style="width:110px">Day</th><th></th><th class="num" style="width:120px">made / opened</th><th class="num" style="width:80px">total</th></tr></thead>
    <tbody>
    <?php foreach ($byDay as $d => $v): $tot = $v['create'] + $v['open']; ?>
      <tr><td style="width:110px"><?= h($d) ?></td>
          <td><div class="stack">
            <div class="seg s1" style="width:<?= $maxDay ? 100 * $v['create'] / $maxDay : 0 ?>%"></div>
            <div class="seg s2" style="width:<?= $maxDay ? 100 * $v['open'] / $maxDay : 0 ?>%"></div>
          </div></td>
          <td class="num" style="width:120px"><b><?= number_format($v['create']) ?></b> / <?= number_format($v['open']) ?></td>
          <!-- THE TOTAL, which is what "how busy was that day" actually asks. Made and opened
               separately answers a different question — how much was WRITTEN — and the two
               were the only numbers here. -->
          <td class="num" style="width:80px"><?= number_format($tot) ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    <p class="muted">
      Over the last <?= (int) $daysSeen ?> day<?= $daysSeen === 1 ? '' : 's' ?> with any activity:
      <b><?= number_format($madeSum) ?></b> links made and <b><?= number_format($openSum) ?></b> opened,
      an average of <b><?= number_format($writesDay, 1) ?> new rows a day</b> and
      <b><?= number_format(($madeSum + $openSum) / max(1, $daysSeen), 1) ?> requests a day</b> in all.
      <?php if ($daysLeft !== null && $smallLeft > 0): ?>
        The small store has room for <?= number_format($smallLeft) ?> more, so at this rate it would
        begin dropping its oldest entries in about <b><?= $daysLeft > 3650 ? 'ten years or more' : number_format($daysLeft, 0) . ' days' ?></b>.
        Re-sharing an identical drawing reuses its row, so the real rate is lower than this.
      <?php endif; ?>
    </p>
  <?php endif; ?>

  <h2>Where the visits come from</h2>
  <?php if ($byCountry): ?>
    <?= dw_world_map($byCountry, $countryTotal) ?>
    <p class="muted">One circle per country, placed at its position on the globe, with the
    <b>area</b> of the circle proportional to the number of visits. Hover a circle for its
    figure. The equator is the heavier horizontal line.</p>
  <?php endif; ?>

  <h2>Use by country</h2>
  <?php if ($geoRanges === 0): ?>
    <p class="muted">No country table is loaded, so everything counts as “Other”. Put a CSV at
    <code><?= h((string) $CFG['geo_csv']) ?></code> and press the button — see
    <code>geo/README.md</code> for a free one and what it must contain.</p>
  <?php endif; ?>
  <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
    <input type="hidden" name="do" value="geo"><button>Rebuild the country table</button>
    <span class="muted"><?= $geoRanges ? number_format($geoRanges) . ' ranges loaded' : 'none loaded' ?></span>
  </form>
  <?php if ($byCountry): $maxC = max($byCountry); ?>
    <table style="margin-top:10px">
    <thead><tr><th style="width:90px">Country</th><th></th><th class="num" style="width:80px">Visits</th><th class="num" style="width:70px">Share</th></tr></thead>
    <tbody>
    <?php foreach ($byCountry as $cc => $n): ?>
      <tr><td><?= h((string) $cc) ?></td>
          <td><div class="bar" style="width:<?= max(2, (int) round(100 * $n / $maxC)) ?>%"></div></td>
          <td class="num"><?= number_format($n) ?></td>
          <td class="num"><?= $countryTotal ? number_format(100 * $n / $countryTotal, 1) : '0.0' ?>%</td></tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><td><b>Total</b></td><td></td><td class="num"><b><?= number_format($countryTotal) ?></b></td><td class="num">100%</td></tr></tfoot>
    </table>
  <?php endif; ?>
  <p class="muted">No address is ever stored. A country is worked out in memory when a link is
  made or opened and the address is discarded in the same breath; only the day, the country and
  a count are written down. Anything below five, and anything unrecognised, is shown as “Other”.</p>

  <h2>Add an entry by hand</h2>
  <p class="muted">Paste a <b>FULL LINK</b> from the SHARE window — the long one — and it is stored
  in the permanent store under a name you choose. That is how a teaching example, a figure for a
  paper or a demonstration gets an ID that still works in two years, when the rotating stores
  have dropped everything else. A short link (<code>?k=…</code>) has no drawing in it and cannot
  be used here; open it first, then press SHARE and copy the full link.</p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= h(csrf()) ?>"><input type="hidden" name="do" value="add">
    <div class="row">
      <input type="text" name="newkey" placeholder="ID, e.g. toluene (optional)" maxlength="24" style="width:220px"
             pattern="[A-Za-z0-9]{4,24}" title="4 to 24 letters and digits">
      <input type="text" name="note" placeholder="Note for yourself (optional)" maxlength="200" style="flex:1;min-width:200px">
    </div>
    <div class="row">
      <textarea name="payload" rows="3" style="width:100%" placeholder="Paste the whole link here…"></textarea>
    </div>
    <div class="row"><button class="p">Store it permanently</button></div>
  </form>

  <h2>Upload a file</h2>
  <p class="muted">A file from your disk — a <code>.2dworm.zip</code> session, or a structure
  file — stored under a key this page makes up. <b>Molecule of the day</b> puts it in the
  featured list, which the page offers to a visitor who arrives with nothing loaded; a
  <b>permanent link</b> puts it in the permanent store and gives you a short link and a QR
  code exactly as any share has. Up to <?= kb((int) $CFG['keep_max_bytes']) ?>
  (<code>keep_max_bytes</code>, under Settings); PHP's own limits on this server are
  <?= h((string) ini_get('upload_max_filesize')) ?> a file and <?= h((string) ini_get('post_max_size')) ?> a request.</p>
  <p class="muted"><b>The server never opens what you upload.</b> No unzipping, no parsing:
  the bytes are measured, the first two are looked at — <code>PK</code> means a session file,
  anything else is text — and they are stored as they are, for the page to open with the readers
  it already has. The name of the file is used for nothing and is not kept; the title is what
  is shown.</p>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf" value="<?= h(csrf()) ?>"><input type="hidden" name="do" value="upload">
    <div class="row">
      <input type="file" name="file" required>
      <label><input type="radio" name="dest" value="featured" checked> Molecule of the day</label>
      <label><input type="radio" name="dest" value="keep"> Permanent link</label>
    </div>
    <div class="row">
      <input type="text" name="title" placeholder="Title — required for the featured list, the note for a permanent link" maxlength="200" style="flex:1;min-width:260px">
      <input type="text" name="credit" placeholder="Credit, e.g. a citation or a name (optional)" maxlength="200" style="flex:1;min-width:200px">
    </div>
    <div class="row"><button class="p">Upload</button></div>
  </form>

  <h2>Molecule of the day</h2>
  <?php if (!$featuredDb): ?>
    <p class="muted">No featured database yet — <code><?= h(dw_featured_path($CFG)) ?></code> is
    created by the first upload above. Until then the page offers nothing, which is a working state.</p>
  <?php else: ?>
    <table>
      <thead><tr><th>Key</th><th>Title and credit</th><th>Kind</th><th class="num">Size</th>
        <th class="num">Opens</th><th>Added</th><th>Last opened</th><th>Offered</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($featuredRows as $fr): $fk = h((string) $fr['fkey']); $t = h(csrf()); ?>
        <tr>
          <td><a href="featured.php?key=<?= $fk ?>"><?= $fk ?></a></td>
          <td><form method="post" class="inline"><input type="hidden" name="csrf" value="<?= $t ?>">
            <input type="hidden" name="do" value="f_edit"><input type="hidden" name="fkey" value="<?= $fk ?>">
            <input type="text" name="title" value="<?= h((string) $fr['title']) ?>" maxlength="200" style="width:180px">
            <input type="text" name="credit" value="<?= h((string) $fr['credit']) ?>" maxlength="200" placeholder="credit" style="width:150px">
            <button>Rename</button></form></td>
          <td><?= h((string) $fr['kind']) ?></td>
          <td class="num"><?= kb((int) $fr['bytes']) ?></td>
          <td class="num"><?= (int) $fr['hits'] ?></td>
          <td><?= when((int) $fr['created']) ?></td>
          <td><?= when((int) $fr['seen']) ?></td>
          <td><?= (int) $fr['enabled'] === 1 ? 'yes' : '<b>no</b>' ?></td>
          <td style="white-space:nowrap">
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= $t ?>">
              <input type="hidden" name="do" value="f_toggle"><input type="hidden" name="fkey" value="<?= $fk ?>">
              <button><?= (int) $fr['enabled'] === 1 ? 'Disable' : 'Enable' ?></button></form>
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= $t ?>">
              <input type="hidden" name="do" value="f_delete"><input type="hidden" name="fkey" value="<?= $fk ?>">
              <button class="d">Delete</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$featuredRows): ?><tr><td colspan="9" class="muted">Nothing featured yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  <?php endif; ?>
  <p class="muted">A separate database, <code>featured.sqlite</code> beside the shares one, and
  the only one whose contents cannot be regenerated: never pruned, never retired, never counted
  in the figures above. The page fetches the list of offered entries once, cached, and picks one
  at random itself. <b>Disable</b> keeps an entry but stops offering it; <b>Delete</b> removes it.</p>
  <div class="row">
    <a href="?fexport=1"><button type="button">Export the featured list</button></a>
    <span class="muted">One JSON file with every entry, files included — the backup, and the way
    the list moves to another server. Import the same file below to add or replace by key.</span>
  </div>
  <form method="post" enctype="multipart/form-data" class="row">
    <input type="hidden" name="csrf" value="<?= h(csrf()) ?>"><input type="hidden" name="do" value="f_import">
    <input type="file" name="json" accept=".json,application/json" required>
    <button>Import a featured list</button>
  </form>

  <h2>The fifty most popular</h2>
  <?php if ($retireOn): ?>
    <p class="muted">The retirement rule is on: a code opened more than
    <b><?= number_format((int) $CFG['retire_hits']) ?></b> times is retired
    <b><?= (int) $CFG['retire_days'] ?> day<?= (int) $CFG['retire_days'] === 1 ? '' : 's' ?></b> after it gets there,
    unless you press <b>Keep</b> first. <b><?= number_format($retirePending) ?></b>
    <?= $retirePending === 1 ? 'entry is' : 'entries are' ?> scheduled to retire; the date is in the
    <i>Retires</i> column. Set <code>retire_hits</code> to zero under Settings to cancel them all.</p>
  <?php endif; ?>
  <table>
    <?= dw_share_head($retireOn) ?>
    <tbody>
    <?php foreach ($popular as $r) { echo dw_share_row($r, $pageUrl, $retireOn); } ?>
    <?php if (!$popular): ?><tr><td colspan="<?= $retireOn ? 9 : 8 ?>" class="muted">Nothing has been opened yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <p class="muted">By opens, all time, whichever store they are in. This is the list to read
  before switching the retirement rule on, and the one to read afterwards: anything here that
  is a lecture, a paper or a poster you know about is a <b>Keep</b>.</p>

  <h2>Drawings</h2>
  <form method="get" class="row">
    <input type="search" name="q" value="<?= h($q) ?>" placeholder="Find by ID">
    <?php foreach (['' => 'all stores', 'small' => 'small', 'large' => 'large', 'keep' => 'permanent'] as $v => $lbl): ?>
      <button name="store" value="<?= h($v) ?>"<?= $storeFilter === $v ? ' class="p"' : '' ?>><?= h($lbl) ?></button>
    <?php endforeach; ?>
  </form>
  <table>
    <?= dw_share_head($retireOn) ?>
    <tbody>
    <?php foreach ($rows as $r) { echo dw_share_row($r, $pageUrl, $retireOn); } ?>
    <?php if (!$rows): ?><tr><td colspan="<?= $retireOn ? 9 : 8 ?>" class="muted">Nothing here.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <p class="muted">An ID opens in the app itself, in a new tab. Drawings are deliberately not
  rendered inside this page: somebody else's content has no business in the page that holds
  your session. <b>Block</b> deletes the drawing and remembers its fingerprint, so uploading
  the same thing again will not bring it back.</p>

  <?php if ($blockedRows): ?>
    <h2>Blocked</h2>
    <table><thead><tr><th>Fingerprint</th><th>Why</th><th>When</th><th></th></tr></thead><tbody>
      <?php foreach ($blockedRows as $b): ?>
        <tr><td><code><?= h(substr((string) $b['hash'], 0, 16)) ?>…</code></td>
            <td><?= h($b['why']) ?></td><td><?= when((int) $b['t']) ?></td>
            <td><form method="post" class="inline"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
              <input type="hidden" name="do" value="unblock"><input type="hidden" name="hash" value="<?= h($b['hash']) ?>">
              <button>Unblock</button></form></td></tr>
      <?php endforeach; ?>
    </tbody></table>
  <?php endif; ?>

  <h2>Settings</h2>
  <?php if (empty($CFG['store_on'])): ?>
    <p class="warn"><b>New drawings are not being stored.</b> Short links and QR codes cannot be
    made while this is off. <b>Everything already stored still opens</b>, and a FULL LINK still
    works and always will — it carries the whole drawing and never touches this server at all.</p>
  <?php endif; ?>
  <p class="muted">These live in the <b>database</b>, not in <code>config.php</code>. That is
  deliberate: a web page that can rewrite an executable PHP file turns "somebody got into the
  admin page" into "somebody runs code on the server". It also means a value saved here
  <b>wins over <code>config.php</code></b> — so if you edit that file afterwards and nothing
  changes, this is why. Clear a box to hand the setting back to <code>config.php</code>.</p>
  <p class="muted"><b>Five settings are not here on purpose.</b> The administrator password, the
  database path, the country-table path, and the two URL settings can only be changed by
  editing <code>config.php</code> by hand. Anyone who got into this page could otherwise change
  the password, point the service at another database, or send every link somebody shares to a
  site of their own.</p>
  <?php $setNow = dw_settings_set($DB); $drift = dw_policy_drift($CFG); $DEF = dw_defaults(); $FROMFILE = dw_from_file(); ?>
  <?php if ($drift): ?>
    <p class="warn"><b>Your settings no longer match what TERMS.md tells your visitors.</b>
      <?= h(implode(' ', $drift)) ?>
      Change the setting back, or edit <code>TERMS.md</code> so the policy is true again — a
      privacy policy that has quietly stopped describing the service is worse than none.</p>
  <?php endif; ?>
  <form method="post"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
    <input type="hidden" name="do" value="settings">
    <table>
      <thead><tr><th style="width:320px">Setting</th><th style="width:150px">Value</th>
        <th style="width:90px">Unit</th><th style="width:110px" class="num">Default</th><th>Where it comes from</th></tr></thead>
      <tbody>
      <?php foreach (DW_SETTABLE as $k => $spec): [$type, $min, $max, $unit, $label] = $spec; ?>
        <tr>
          <!-- WHAT IT DOES, beside it. A page of fifteen numbers with no explanation is a
               page nobody dares change anything on, which is the same as not being able to. -->
          <td><?= h($label) ?><br><code class="muted"><?= h($k) ?></code>
              <?php if (isset(DW_SETTING_HELP[$k])): ?>
                <br><span class="muted" style="font-size:11px"><?= h(DW_SETTING_HELP[$k]) ?></span>
              <?php endif; ?></td>
          <td><?php if ($type === 'bool'): ?>
                <input type="hidden" name="s_<?= h($k) ?>_sent" value="1">
                <input type="checkbox" name="s_<?= h($k) ?>" <?= !empty($CFG[$k]) ? 'checked' : '' ?>>
              <?php else: ?>
                <input type="text" inputmode="numeric" name="s_<?= h($k) ?>" style="width:130px"
                       value="<?= h((string) $CFG[$k]) ?>">
              <?php endif; ?></td>
          <td class="muted"><?= h($unit) ?></td>
          <td class="num muted"><?= $type === 'bool' ? ($DEF[$k] ? 'on' : 'off') : number_format((int) $DEF[$k]) ?></td>
          <td class="muted">
            <?php if (isset($setNow[$k])): ?>set here<?php elseif (isset($FROMFILE[$k])): ?>config.php<?php else: ?>the shipped default<?php endif; ?>
            <?php if ($type !== 'bool'): ?> · <?= number_format($min) ?>–<?= number_format($max) ?><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <div class="row" style="margin-top:8px">
      <button>Save settings</button>
      <span class="muted">Saving changes what is accepted from now on. Nothing already stored is
      touched — that is what PRUNE NOW, below, is for.</span>
    </div>
  </form>
  <form method="post" class="row"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
    <input type="hidden" name="do" value="settings_reset">
    <button class="d">Forget all of these</button>
    <span class="muted">Removes every value saved here, so <code>config.php</code> and the
    shipped defaults govern again.</span>
  </form>
  <p class="muted"><b>The two waits are not the same kind of thing.</b> A wait before
  <i>storing</i> is paid by whoever is filling the database, which is the point. A wait before
  <i>opening</i> is paid by the colleague who was sent the link and by whoever is scanning a
  poster with a phone — so it ships at zero, and what actually stops somebody copying the whole
  store by walking the key space is <code>read_per_hour</code>, a ceiling rather than a delay.
  Turn the wait on only if you see abuse that a ceiling did not stop.</p>

  <h2>Housekeeping</h2>
  <form method="post" class="row"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
    <input type="hidden" name="do" value="banner">
    <input type="text" name="text" value="<?= h($banner) ?>" placeholder="Announcement shown in the app (empty = none)" style="flex:1;min-width:260px">
    <button>Save announcement</button>
  </form>
  <form method="post" class="row"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
    <input type="hidden" name="do" value="offline">
    <input type="text" name="reason" value="<?= h($offline) ?>" placeholder="Switch sharing off, with a reason (empty = on)" style="flex:1;min-width:260px">
    <button class="d">Save</button>
  </form>
  <form method="post" class="row"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
    <input type="hidden" name="do" value="prune"><button class="d">PRUNE NOW</button>
    <span class="muted">
      <?php $pv = dw_prune_preview($DB, $CFG); $fp = dw_store_footprint($DB); ?>
      <?php if (!$pv['rows']): ?>
        Nothing to remove: everything stored is inside the limits above.
      <?php else: ?>
        <b>Would remove <?= number_format($pv['rows']) ?> entries and <?= kb($pv['bytes']) ?></b>,
        leaving <?= number_format($fp['rows'] - $pv['rows']) ?> and <?= kb($fp['bytes'] - $pv['bytes']) ?>.
        The least recently opened go first; the permanent store is never touched.
      <?php endif; ?>
    </span>
  </form>
  <div class="row">
    <a href="?backup=1"><button type="button">Download a backup</button></a>
    <span class="muted">The whole SQLite file, drawings included. Keep it somewhere safe.</span>
  </div>
<?php endif; ?>
</main>
</body></html>
