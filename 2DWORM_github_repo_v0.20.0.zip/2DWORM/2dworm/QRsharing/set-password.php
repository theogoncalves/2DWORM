<?php
declare(strict_types=1);
/**
 * 2D-WORM sharing service — set the administrator password.
 *
 * Run it ONCE from a shell, in this folder:
 *
 *     php set-password.php
 *
 * It asks for a password, writes `config.php` with the bcrypt hash of it, and stops. The
 * password itself is never written anywhere.
 *
 * WHY THIS FILE EXISTS. The hash is full of `$` characters. Pasted into a double-quoted PHP
 * string they are read as variable names and the hash silently becomes rubbish — the login
 * then refuses a password that is correct, with no clue as to why. This writes the file with
 * single quotes so that cannot happen.
 *
 * IT WILL NOT RUN FROM A BROWSER. A page that sets the administrator password must not be
 * reachable over the web, so it refuses anything but the command line. That check is on the
 * PHP interpreter's own SAPI name, which a request cannot influence.
 *
 * Delete it when you are finished, like setup-check.php.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo "<!doctype html><title>404 Not Found</title><h1>Not Found</h1>";
    exit;
}

$dir  = __DIR__;
$file = $dir . '/config.php';
$args = array_slice($argv ?? [], 1);
$force = in_array('--force', $args, true);

/* An existing config.php may hold settings that are nothing to do with the password —
   store sizes, the geo path, the page URL. Never throw those away. */
$existing = [];
if (is_file($file)) {
    $loaded = @require $file;
    if (is_array($loaded)) { $existing = $loaded; }
    else {
        fwrite(STDERR, "config.php exists but does not return an array. Move it aside and run this again.\n");
        exit(1);
    }
    if (!empty($existing['admin_hash']) && !$force) {
        fwrite(STDERR, "A password is already set in config.php.\n"
                     . "Run  php set-password.php --force  to replace it.\n");
        exit(1);
    }
}

fwrite(STDOUT, "New administrator password (it will be visible as you type): ");
$pw = fgets(STDIN);
if ($pw === false) { fwrite(STDERR, "\nNothing read. Nothing written.\n"); exit(1); }
$pw = rtrim($pw, "\r\n");

if (strlen($pw) < 8) {
    fwrite(STDERR, "That is shorter than eight characters. Nothing written.\n");
    exit(1);
}

$existing['admin_hash'] = password_hash($pw, PASSWORD_DEFAULT);
if (!is_string($existing['admin_hash'])) {
    fwrite(STDERR, "This PHP could not hash the password. Nothing written.\n");
    exit(1);
}

/* Written by hand rather than with var_export, so every string is single-quoted and the
   result is a file a person can read and edit afterwards. */
$q = chr(39);
$out = "<?php\n/* 2D-WORM sharing service — settings. Written by set-password.php.\n"
     . "   Keep this file OUT of any repository: it holds the administrator password hash.\n"
     . "   Every key is optional; see config.example.php for the full list. */\nreturn [\n";
foreach ($existing as $k => $v) {
    $key = $q . str_replace($q, '\\' . $q, (string) $k) . $q;
    if (is_bool($v))        { $val = $v ? 'true' : 'false'; }
    elseif (is_int($v))     { $val = (string) $v; }
    elseif (is_float($v))   { $val = (string) $v; }
    elseif (is_string($v))  { $val = $q . str_replace(['\\', $q], ['\\\\', '\\' . $q], $v) . $q; }
    else                    { continue; }                 // arrays are not used here
    $out .= "    $key => $val,\n";
}
$out .= "];\n";

if (file_put_contents($file, $out) === false) {
    fwrite(STDERR, "Could not write $file — check the folder is writable.\n");
    exit(1);
}
@chmod($file, 0600);

fwrite(STDOUT, "\nWritten: $file\n");
fwrite(STDOUT, "The password is set. Now:\n");
fwrite(STDOUT, "  1. open QRsharing/admin.php and log in;\n");
fwrite(STDOUT, "  2. delete this file and .admin-enabled when you have finished.\n");
