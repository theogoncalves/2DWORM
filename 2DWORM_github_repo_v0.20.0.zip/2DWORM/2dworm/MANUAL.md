# 2D-WORM — manual

A single web page for drawing chemical structures, turning them into 3D, making
publication images, and sharing exactly what you see. Nothing to install, nothing to
sign up for. This is an untested alpha version — please report anything that misbehaves
to contact@dworm.org.

---

## Language

Ten buttons at the top: **EN**, **عربي**, **中文**, **PT**, **ES**, **PL**, **DE**, **IT**,
**हिन्दी**, **اردو**. Each one is written in its own script and is never translated, so whatever
language the page is currently in, you can always find your own — including your way back out
of one you cannot read. Your choice is remembered by your browser.

**Changing the language changes the words and nothing else.** Arabic and Urdu read
right-to-left inside every button and paragraph, but no panel and no control moves: the page is
an instrument, and the drawing area must not shift under your hand because you changed
language.

**Ketcher's own drawing toolbars stay in English.** They belong to a separate program running
inside the page, and translating them is not ours to do.

Chemical formulas, element symbols and bond lengths are always shown left-to-right, so a
formula reads the same in every language.

A translation that is incomplete is not a broken page: anything not yet translated simply stays
in English. The files are `lang/ar.json`, `lang/zh.json`, `lang/pt.json`, `lang/es.json`,
`lang/pl.json`, `lang/de.json`, `lang/it.json`, `lang/hi.json` and `lang/ur.json` — plain lists
of English sentences and their translations, which a colleague can correct and send back without
touching any code. The Hindi and Urdu files are new in this build and are waiting for a native
reader; the sentences added in this build are still English in every file.

---

## The two panels

**KETCHER** is the drawing panel and **3DMOL** is the 3D panel. The two buttons at the top
switch them on and off; on a phone you see one at a time. (MacMolPlt is not a panel — it is
the name of the first rendering scheme, in the representation list inside the 3D panel.)

**WHITE / BLACK / WORM / BUG / PINK** set the background of everything at once — the page, the
drawing canvas, the Ketcher toolbars and the 3D view. Your choice is remembered by your
browser. **BUG** is a different palette every time you press it — a hue and a light or a dark
ground chosen at random, with the text, the chrome and the accent placed in fixed bands of
lightness around them so that whatever the hue, the words stay readable. It is the one place
in this program where randomness is welcome. DUSK, the fourth theme of earlier builds, still
opens from a link that names it.

**⛶ on either panel has three positions.** The first press gives the panel the whole window —
the header, the footer and the other panel get out of the way. The second press is **MAX**: the
panel's own control bars go too, and the only thing left on screen apart from the picture is a
small button to come back with. The third press puts everything back, and so does Escape. It is
meant for a phone or a tablet, where the panel is the only thing you can afford to show. It is
deliberately **not** the browser's full-screen mode, which the iPhone does not offer to web
pages: one behaviour on every device, rather than a better one on some. For a page without the
browser's own bars at all, use **Add to Home Screen** (Safari's share sheet, or Chrome's menu) —
2D-WORM then opens as an app of its own, standing alone.

The top row runs left to right in the order the work does: the two panels, **NOTES**,
**MolStar-VR** and **FIND**, then the ten languages, then the backgrounds, then the box for a
shared ID, then **OPEN · SAVE · SHARE**, and **OPTIONS** and **INFO** at the end. Changing the
language changes the words only — nothing moves, in any of the ten.

### OPTIONS

A small window of settings that change how the page behaves. Each one is remembered on the
device, and each one is also a **parameter in the address**, so a setting can be sent along
with a link and arrives set on the other side.

- **On-screen keyboard.** On a tablet or a phone every Ketcher tool used to raise the keyboard,
  because a hidden text box inside Ketcher takes the focus and the device answers focus with a
  keyboard. *Automatic* (the default) stops that on touch screens and leaves a computer alone;
  *never* stops it everywhere; *leave the browser to decide* is the old behaviour, for the rare
  tool that really wants to type.
- **Session file.** What SAVE SESSION writes for a volumetric field — the frozen surfaces only
  (small), or the surfaces and the cube files themselves (large). See *Saving*.
- **3D camera.** *Perspective* (the default: nearer atoms drawn larger, a depth cue while
  turning) or *orthographic* (the projection of a publication figure). Neither switches when
  labels come and go, so nothing jumps either way; the two projections do not frame a
  structure the same way, so changing this moves the picture once.
- **PAUSED!** Whether a procedure that builds an intermediate — the frozen shell of MIN
  pPERIODIC, the capped model of pMODEL — stops there and shows it to you. See *PAUSED!*.
- **pMODEL may cut.** Whether the cuts that make a model system weakest are named. See
  *pMODEL*.
- **pMODEL / pREST caps.** Hydrogen or methyl in place of a cut bond. See *pMODEL*.
- **pREST shell.** How much of the rest relaxes around a held model — 3, 5 or 8 Å, or all of
  it. See *pREST*.
- **pPBC gap between images.** How far apart the images are in the box pPBC guesses. See
  *pPBC*.

The line at the bottom of the window shows what would go on a link, and is empty while
everything is at its default. The choices also cross to 2DWORM-VR and come back with RETURN.

### The p-methods, and PAUSED!

Four tools carry a small **p** in their name — **MIN pPERIODIC**, **pPBC**, **pMODEL**,
**pREST** — and the p means the same thing in each: *para-*, a deliberate approximation. They are fast ways of
guessing a geometry, good enough to start a real calculation from and not good enough to quote.
Every energy they report is printed **in brackets, in yellow**, and the same brackets follow it
into the note and the exports, so a pseudo-periodic UFF number can never be read as a result.
The geometry is the point; the energy is meaningless.

Each of them builds an **intermediate** and throws it away — the frozen shell, the guessed box,
the capped model — and the result depends on that intermediate, which is why you may want to
look at it. **OPTIONS ▸ PAUSED!** makes the procedure stop at that point: the intermediate is
drawn on screen, the job button turns red and reads **PAUSED!**, a bar under the view offers
**CONTINUE** and **STOP**, and the status line says *paused* rather than going quiet. Pressing
the red button continues; STOP, or KILL on any other job, abandons it and nothing is changed.
A forgotten pause therefore never looks like a hang.

While it is paused the bar offers **MODEL**, **REST** and **ALL** — draw the model system on
its own, its surroundings on their own, or both — and, for pMODEL and pREST, **TAIL H** and
**TAIL CH3**: what stands in for a cut bond, a hydrogen or a methyl, switched on the spot and
rebuilt before your eyes. CONTINUE runs with whatever is showing.

---

## Drawing

The drawing panel is Ketcher, made by EPAM. Its full manual, with every tool and keyboard
shortcut, is at
<https://github.com/epam/ketcher/blob/master/documentation/help.md>.

**CLEAR** empties the canvas. **CLEAN UP** re-draws the structure tidily.

**Tools 100 % / 125 % / 150 % / 175 %** makes the Ketcher toolbars larger without changing
the drawing itself — useful on a large tablet, where the default buttons are small. On a
touch screen a larger size is chosen for you.

### RMB, ALT, CTRL, SHIFT on a tablet

Several Ketcher tools need a keyboard key or a right mouse click, which a tablet does not
have. The four buttons next to the KETCHER title supply them:

- press one and it turns **red** — the key now counts as held down;
- press it again to release it;
- **RMB** releases itself after the next tap, because a permanently held right button would
  make ordinary drawing impossible.

---

## Opening files

**OPEN**, or simply drag a file onto the page:

| File | Goes to |
|---|---|
| `.cdx`, `.cdxml` (ChemDraw), `.mol`, `.sdf`, `.ket`, `.smi`, `.rxn` | the drawing |
| `.xyz`, `.pdb`, `.cif`, `.mmcif`, `.mol2`, `.pqr`, `.pdbqt`, `.gro`, `.cube`, `.lammpstrj`, `.mmtf`, `.bcif`, `POSCAR` / `CONTCAR` | straight to the 3D view |
| `.mol` that already contains 3D coordinates | both |
| a calculation's output or input — see below | straight to the 3D view |
| a molecular-dynamics set — AMBER, NAMD, CHARMM, LAMMPS; see below | straight to the 3D view |
| `.2dworm.zip` — a session saved with **SAVE ▸ 2DWORM session** | everything, as it was |

A Tripos `.mol2` that carries **lone-pair centres** (SYBYL type `LP`) opens without them —
they are a force-field convention, not atoms — and the footer says how many were left out.

**Several files at once.** Drop them together and each goes where it belongs; the ones that
only make sense as a pair — an AMBER restart with its topology, a NAMD `.coor` with its `.psf`,
a density cube with the ESP cube that colours it — are matched up by what they are, not by the
order you dropped them in.

### Molecular-dynamics files

A simulation's coordinates usually come in two files, one with the positions and one with the
names, and neither is much use alone. Dropped together they make one structure:

| Program | Coordinates | Names and bonds |
|---|---|---|
| **AMBER** | `.rst7`, `.inpcrd`, `.restrt`, `.rst`, `.crd` | `.parm7`, `.prmtop` |
| **NAMD** | `.coor` (text or binary), with `.xsc` / `.xst` for the box | `.psf` |
| **CHARMM** | `.crd`, `.cor` | `.psf` |
| **LAMMPS** | `.data`, `.lmp`, a `.lammpstrj` or `.dump` (the last frame) | the data file's own types and masses |

Coordinates dropped **without** their topology still open — as elements guessed from the masses
or the names, with the bonds worked out from the distances, and the footer saying that is what
happened. A box in any of them is read as a cell.

### Finding a structure by name

**FIND** searches public databases and brings the structure straight in:

| Database | What is in it | Asked by a plain name? |
|---|---|---|
| **RCSB PDB** | proteins, DNA, RNA and their complexes | yes |
| **PDBe** | the same entries, from EMBL-EBI — a second door to the archive | by identifier only |
| **PubChem** | small molecules, with a computed 3D conformer for most | yes |
| **COD** | experimental crystal structures (Crystallography Open Database) | yes |
| **TCOD** | computed crystal structures, the same project | by identifier only |
| **Wikidata** | the SMILES and InChI of well-known compounds | yes |
| **CACTUS** | the NCI resolver: a name, a CAS number or an InChI to a structure | when chosen |
| **Zenodo** | the files of a published record, by record number or DOI | by identifier only |

Type a name — *aspirin*, *haemoglobin*, *caffeine* — and click a result. A PDB identifier
(`1CRN`), a PubChem CID (`2244`), a COD number (`1000041`) or a Zenodo record or DOI typed on
its own goes straight to that entry. A small molecule arrives in the drawing **and** in the 3D
view; if the database has no 3D conformer for it, only the drawing is filled in and **MAKE 3D**
builds the rest. Sixty-odd common names — *water*, *benzene*, *caffeine*, *ibuprofen* — are
known to the page itself and are offered last, after the databases have answered, so a search
that reaches nobody still finds the everyday things.

The menu beside the box chooses **one database or all of them**; *all* asks the ones marked
*yes* above at once and lists whatever comes back. Every one of these is in the **public
domain** or free to use without a credit line. A database whose licence asks for attribution —
the AlphaFold database, CC-BY — is in the list but **switched off**; when an operator switches
it on, the credit line arrives with every structure and is shown, so the attribution is never
yours to remember.

A large entry — a virus capsid, a ribosome, a Zenodo record with a cube file in it — takes a
while, and the page shows **how much has arrived** while it does, with a button to stop.

All of these answer the browser directly, so nothing passes through this server. **A search
sends what you type, and your network address, to the database you asked** — it is the one
place where 2D-WORM talks to somebody other than the server the page came from. TERMS.md lists
every host.

Nothing fetched this way is ever copied into the sharing database. A link you share carries
the **identifier** — `rcsb:1CRN` — and whoever opens it fetches the entry themselves. So the
link stays short whatever the size of the protein, somebody else's data never lands on your
server, and the recipient sees the current revision rather than a copy frozen on the day you
made the link. They do have to be online, and if the database cannot be reached the page says
so rather than showing an empty panel. The moment you change the structure — MINIMIZE, a
conformer search, MAKE 3D — it stops being theirs and the coordinates travel in the link as
usual.

### The molecule of the day

An empty 3D panel offers one structure from a small list the operator keeps — something worth
looking at, with a line saying where it came from. Nothing is fetched until you press **OPEN**;
**×** puts it away. It is a list of the operator's own choosing, kept in a database of its own,
apart from everything anybody shares.

### Crystals keep their cell — and it is drawn

When a file describes a repeating cell, the three lattice vectors are read and **kept**, not
just noted. The box is drawn round the structure with **a**, **b** and **c** marked in red,
green and blue at the origin, and a **cell** checkbox appears beside the label menu to turn it
off. The six numbers — the three lengths and the three angles — are in the footer.

The cell is read from a VASP `OUTCAR` or `POSCAR`/`CONTCAR`, a CP2K output or input, Gaussian
`TV` lines, a `.cif`, a `.gro` box, a PDB `CRYST1` line, an XSF `PRIMVEC` block, a Turbomole
`$lattice`, a CASTEP `.cell`, a Quantum ESPRESSO or ABINIT input or output, and the box of an
MD file. It travels in a shared link, so what the QR code reproduces is the crystal and not a
cluster of atoms in vacuum, and it is written into every format under **SAVE ▸ 3D, other
programs**.

### A CIF is expanded by its symmetry

A crystallographic `.cif` lists the **asymmetric unit** — the few atoms from which the rest of
the cell follows by symmetry — and a viewer that draws only those shows a fragment of a crystal
with most of it missing. The symmetry operators are now applied: the ones listed in the file,
or, when the file names its space group and lists none, the operators from a built-in table of
all 230 groups. Urea's five atoms become the sixteen of its cell; the footer says how many
became how many, and which group did it. The identity is never applied twice, so an atom on a
special position is not doubled. A file with no symmetry in it at all is `P1` and is shown as
listed, and the footer says that too. A structural-biology mmCIF is a different thing — a
deposited model, whole — and goes through the protein reader untouched.

### CELL FIX — putting things back in the box

When a structure has a cell, **CELL FIX** appears in the EXPERT row. A periodic structure
does not stop being itself when an atom leaves the cell — the cell repeats, so the atom
outside *is* the atom inside, and putting it back changes nothing physical. What it changes is
the picture: a molecule that has drifted out of the box looks like one that has fallen off the
crystal, and in a figure that is simply wrong.

**Whole molecules move, not atoms.** Wrapping a single atom of a molecule tears the molecule
in half and leaves one bond stretched right across the cell — an image that is arithmetically
correct and unreadable. So a molecule's *middle* decides which copy of the cell it belongs in,
and the whole molecule moves by that one lattice vector. A molecule sitting on a face will
therefore still have a few atoms reaching past it, and that is right: they belong to a
molecule whose middle is inside. The footer says how many.

A framework has no separate molecules to move — it is one connected thing — so it is placed
as a whole and the footer says so rather than pretending otherwise.

There are two ways to do it, chosen beside the button:

- **Fix: molecules** — whole molecules move, as above. A few atoms may still reach past a
  face, and the footer says how many.
- **Fix: atoms** — every atom is forced inside, which is what a program reading fractional
  coordinates in [0, 1) wants. It necessarily **tears any molecule that crosses a face**: one
  of its atoms goes to the far corner and the bond between them is then drawn right across
  the box. The footer says how many bonds that happened to, so it is not something you have
  to spot in the picture.

It is an edit like any other: **UNDO** takes it back. Nothing happens until you press the
button — no file is ever tidied up on opening.

### CELL EXTEND — putting back what the cell cut off

A crystallographic file lists the contents of **one cell**, so a molecule that happens to
straddle a face is listed as two pieces at opposite corners of the box. Both pieces are there,
neither is bonded to the other, and what you see is fragments. It is the commonest reason a
CIF looks wrong when you open it, and it is not wrong — it is the cell.

**CELL EXTEND** completes those molecules by bringing in the atoms of the neighbouring images
they continue into. Whether two atoms are bonded is judged by the **nearest image**, so the
walk crosses cell faces the way the crystal does.

Two things it does that are worth knowing:

- **One copy of each molecule.** Completing the molecule from each listed fragment would give
  two whole molecules, one lattice vector apart — both really in the crystal, and both still
  wrong, because the cell held one. Two molecules that are a pure lattice translation of each
  other are recognised as the same molecule and only the one nearest the middle of the box is
  kept. The footer says how many duplicates were left out.
- **The walk stops.** In a framework, a zeolite or a coordination polymer the molecule never
  terminates: follow its bonds and you walk out of the crystal for ever. The walk is capped at
  **four lattice translations**, which a discrete molecule never reaches and which turns a
  framework into a finite block. The footer says when the cap was what stopped it.

**What comes out is not a unit cell.** Atoms have been added and the contents no longer repeat
with the lattice, so it is the right thing to look at and to put in a figure, and the wrong
thing to hand back to VASP. The footer says so every time.

**Above 1,500 added atoms it asks first**, with the numbers — a zeolite cell of 216 atoms
becomes a block of 60,000 — because a picture that size is slow to turn and should be chosen,
not stumbled into. And **UNDO takes the whole thing back**, whichever way you answered.

### CRYSTAL — building one from scratch

**CRYSTAL**, in the EXPERT row, builds a crystal from the numbers a paper gives: a lattice
system, its cell parameters, a space group, and the atoms of the asymmetric unit in fractional
coordinates.

- The **lattice system** greys the parameters it fixes and makes them follow the free ones —
  choose *cubic* and b, c and the three angles are no longer yours to type.
- The **space group** menu holds all 230, numbered and in Hermann–Mauguin notation, filtered to
  the system you chose; choosing a group from another system moves the system to match.
- The **atoms** are one per line, `Na 0 0 0`, `Cl 0.5 0.5 0.5`.
- A **supercell**, up to 8 × 8 × 8.

The line under the form counts as you type — *F m -3 m: 2 atoms → 8 in the cell → 64 in the
2×2×2 supercell* — so you know what BUILD will make before it makes it. What it makes has its
cell, is periodic, and saves as a CIF or a POSCAR like any other crystal.

**FROM THE 3D VIEW (P1)** goes the other way: whatever is on screen with a cell is turned into
fractional coordinates as a P1 asymmetric unit, so a cell you opened from a file can be repeated
into a supercell with the same form.

### Crystals are shown, but not minimised

A VASP `POSCAR`, `CONTCAR` or `OUTCAR`, a GROMACS box, a crystallographic `.cif` or a periodic
CP2K run describes a **repeating cell**, not an isolated molecule: the atoms at a face of the
cell are bonded to their own periodic images. Neither force field here implements periodic
boundary conditions, so relaxing such a structure would pull every surface atom inwards
against vacuum and give you something tidy and meaningless. **MINIMIZE and BEST CONFORMATION
refuse**, and say so. Viewing, measuring, labelling, exporting and sharing all work normally.

If you really did mean to relax an isolated cluster you cut out of a cell, save it with
**SAVE ▸ Coordinates .xyz** and open that file — then it is a molecule and it behaves like one.

### MIN pPERIODIC — relaxing the cell inside its own surroundings

There is a third answer, in **EXPERT**, and it is usually the one you want. **MIN pPERIODIC**
builds the cell's neighbours as real atoms, freezes them, and relaxes the cell against them.
The small **p** in the name is deliberate: it is a *pseudo*-periodic relaxation, and the
energy it reports is printed **in brackets**, `[−124.3 kcal/mol]`, in a colour of its own — the
mark this page puts on any number that is an approximation, so that a UFF energy from a
truncated shell is never read as a number that means something on its own.

Around the cell are its 26 images. The shell is seeded from the cell's own atoms **and from
every image atom lying within 2 Å of the outside of a face** — a molecule can sit against the
wall without being bonded through it, and a shell grown along bonds alone would leave it out,
so the cell would relax into a space that is not empty. From that seed the shell reaches
**four bonds** out. Then UFF moves the cell's atoms and nothing else; afterwards the shell is
thrown away and anything that drifted out of the box is brought back by a lattice vector,
whole molecules at a time.

**Pick atoms first and only those move.** That is how you relax hydrogens you have just added
to a structure from diffraction, or a defect, or an adsorbate, while everything else stays
exactly where the experiment put it.

The status line says how many atoms were free, how many were frozen, how many of the frozen
ones were touching a face without a bond through it, and what the energy did.

It is **not** a periodic force field. The shell is held still, so the cell relaxes against its
surroundings but the surroundings do not relax back, and the cell parameters never change. For
a measured crystal structure that is the right question anyway: the cell is measured, the
hydrogen positions are not.

A protein is not affected. A `.pdb` almost always carries a `CRYST1` line and an mmCIF carries
a cell, but the deposited coordinates are whole molecules, so they minimise as usual.

### pPBC — a box for a molecule that has none

**MIN pPERIODIC** needs a cell, and a molecule from a file or from MAKE 3D has none. **pPBC**,
in the EXPERT row, guesses one: the molecule's van-der-Waals envelope is measured, the molecule
is turned until the orthogonal box around that envelope is smallest — principal axes first,
then a bounded refinement that only ever makes the box smaller — and the box becomes the
structure's cell, with the molecule inside it and its images touching it on every side. The
**gap** between the images is an OPTIONS choice (0 to 3 Å). The status line says the box, its
volume and how many cycles it took, in the approximation brackets, and it is one **UNDO**.

What it is: a pseudo-periodic cell to relax the molecule against copies of itself, for the
kind of question MIN pPERIODIC answers. What it is not: a crystal structure. Nothing about a
real packing is guessed here — only the box that just contains the molecule.

### pMODEL — a model system cut out of its surroundings

Relaxing a whole protein to look at one residue is the wrong tool. **pMODEL** cuts the region
you picked free of everything around it, caps every cut bond with hydrogen, relaxes the region
with UFF while the atoms at the cuts and the caps are held still, and puts the relaxed
coordinates back under their original numbers. It is a link-atom model system, made
geometrically, for guessing a local geometry inside something too large to relax whole — a
residue, an adsorbate on a slab, the first shell of an iron–sulfur cluster.

- **Pick the region** — the atoms that may move — then **pMODEL**.
- **The cap** sits along the original bond, at the ONIOM-scaled link-atom distance (the bond
  length scaled by the covalent radii of the atom kept and the atom removed), so the boundary
  is not distorted; a double bond gets two hydrogens, a triple three, so the valence is
  satisfied.
- **The atoms at the cuts and the caps are held still**; everything else in the region moves.
- **The region grows a little before it is cut.** An outside hydrogen bonded to a region
  atom joins the region — an X–H bond is never cut, because a link hydrogen in place of a
  real one gains nothing — and so does any outside atom bonded to two or more region atoms,
  which would otherwise get two caps on top of each other. The status line says how many
  atoms were drawn in.
- **You may cut anywhere.** A cut that is not a single bond between light atoms — a double
  bond, a bond to a metal — is named in the status line, in the brackets, so you know where
  the model is weakest; **OPTIONS ▸ pMODEL may cut** turns those warnings off. Nothing is
  refused except an empty region, a region that is the whole structure, and a region whose
  every atom sits at a cut (nothing would move).
- **Hydrogen or methyl caps.** **OPTIONS ▸ pMODEL / pREST caps** chooses between a link
  hydrogen and a **methyl** — a carbon where the cut atom was, with three hydrogens staggered
  against what the linker carries — which keeps the bulk and the sp³ surroundings a hydrogen
  does not. A cut through a double or triple bond is capped with hydrogens either way. At the
  PAUSED! breakpoint **TAIL H / TAIL CH3** switches between the two and rebuilds the model in
  front of you.
- **The numbering survives.** The result is the same structure with some coordinates changed;
  nothing is renumbered, and **UNDO** takes it back.

Cutting a charged group off changes the model's charge. For UFF that matters much less than it
would for a quantum method, because there are no electrostatics in play — the status line
says so. And the warning that matters most: the result *looks* like an optimised structure and
is a model-system guess; its energy is in the brackets and is not comparable to anything.

With **OPTIONS ▸ PAUSED!** on, pMODEL stops before relaxing and shows the capped model — the
caps in yellow, the held atoms caged — and MIN pPERIODIC shows its frozen shell as thick grey
tubes around the cell. **MODEL / REST / ALL** on the bar draw one side or both.

### pREST — relaxing the surroundings of a held model

The mirror of pMODEL. The atoms you picked are the **model** and are **held exactly where
they are**; what relaxes is the **rest** around them — the shell of it within the distance
set in **OPTIONS ▸ pREST shell** (3, 5 or 8 Å of any model atom, or the whole rest), cut from
what lies further out and capped there just as a model is, so that a shell inside a
forty-thousand-atom protein costs a few hundred atoms and not the protein. How a pocket
settles around a ligand you have placed; how a lattice relaxes around a defect you have
made.

- **Pick the model** — the atoms to hold — then **pREST**.
- The shell grows a little the way a region does: hydrogens come along, an atom bonded twice
  to the shell joins it. The atoms at the outer cuts are held, with their caps; the model is
  held; everything else in the shell moves.
- **The whole rest** (OPTIONS) cuts nothing and relaxes every atom that is not the model —
  right for a small structure, a long wait for a large one.
- The energy is the shell's, in brackets, and comparable to nothing. **UNDO** takes it back.

### Opening a calculation

Drop the output of a finished job on the page and the structure appears:

| Program | Files |
|---|---|
| **ORCA** | `.out`, `.log`, and `.inp` inputs |
| **Gaussian** | `.out`, `.log`, and `.gjf` / `.com` inputs |
| **CP2K** | `.out`, and inputs or `.restart` files with a `&COORD` block |
| **MOPAC** | `.out` and `.arc` |
| **xTB** | `.out`, and `coord` / `xtbopt.coord` files |
| **VASP** | `OUTCAR`, `POSCAR`, `CONTCAR` |
| **GAMESS-US** | `.out`, `.log`, and `.inp` inputs with a `$DATA` group |
| **NWChem** | `.out`, and `.nw` inputs |
| **CASTEP** | `.castep` outputs, and `.cell` inputs |
| **Q-Chem** | `.out`, and `.in` inputs |
| **Molpro** | `.out`, and `.inp` inputs |
| **Psi4** | `.out`, and `.in` / `.dat` inputs |
| **Turbomole** | `coord`, `gradient` and `energy` files, and a job's output |
| **Quantum ESPRESSO** | `.pwi` inputs, `.pwo` / `.out` outputs |
| **ABINIT** | `.abi` inputs, `.abo` / `.out` outputs |
| **ADF / AMS** | `.out`, and `.run` / `.in` inputs |
| **Jaguar** | `.out`, and `.in` inputs |
| **Grids and wavefunctions** | `.cube`, `.cub`, `.fchk`, `.wfn`, `.molden`, `.mwfn`, NBO `.47` — **the geometry only** (and a `.cube`'s grid, below) |

**The geometry is the last one in the file.** Where a program prints an energy beside it —
Turbomole's `gradient`, AMS, Jaguar — that number is quoted in the footer. For a Gaussian,
ORCA, xTB or MOPAC output the whole optimisation and the vibrational modes are read too — see
**RESULTS**, below. The orbitals are not: turning a wavefunction into something you can look at
is the full D-WORM's job.

Because `.out` and `.log` are used by half of computational chemistry, the program is
worked out from what is inside the file, not from the extension. Units are converted where
a program uses bohr (xTB and Turbomole `coord` files always do), so a structure never comes
out at half its real size. A Gaussian Z-matrix is refused rather than misread — supply
cartesians. A CP2K geometry optimisation says so, because CP2K writes the optimised
structure to its `-pos-1.xyz` or `.restart` file rather than back into the output.

A very large output is read from the end first, so a multi-gigabyte log does not have to be
loaded whole. A cube, an `.fchk` or a `.wfn` is read from the **start**, because that is where
those name their atoms — the volume or the wavefunction that follows can be hundreds of
megabytes and is never fetched. Turning a wavefunction into something you can look at is a
calculation, and that is D-WORM's job, not this page's.

### RESULTS — what the output holds besides its last geometry

When an output file has been opened, **RESULTS** appears beside the 3D title. It opens a
window with two tabs:

- **OPTIMISATION** — the energy against the step, relative to the lowest and in kcal/mol when
  the file is in hartree; a slider, or a click on the plot, shows any step in a small viewer of
  its own, with the four convergence tests of that step marked ✓ or ✗ against their thresholds.
  An IRC is plotted against its reaction coordinate.
- **FREQUENCIES** — every mode, lowest first, imaginary ones first of all and in red, with
  its IR intensity (and Raman activity where the file has it) and a stick spectrum drawn high
  wavenumbers to the left, as in print. Click a mode, or a stick, and it **animates** in the
  small viewer; the amplitude slider is for the eye, not for physics.

**USE THIS GEOMETRY** takes the step, or the geometry the modes belong to, into the page as the
current structure — the transition state at the top of an IRC, an intermediate along the path
— which is what makes this a step in a workflow rather than a picture. It is a change **UNDO**
takes back.

The window reads Gaussian, ORCA, xTB and MOPAC outputs; for the others the last geometry and
energy are read, and RESULTS says what it found and what it did not.

---

### The volume a `.cube` came with

A cube file is a molecule and a grid. The molecule has always been read out of the header;
now the grid is drawn too, and a **FIELD** menu appears beside the cell checkbox.

An orbital, an IGM or an NCI plot has values of both signs, and is drawn as two surfaces —
**blue for positive, red for negative**. An electron density has only one sign and is drawn as
one: asking for a surface at a level the data never reaches would be an empty picture, so the
grid's own values decide.

The isovalues on the menu are built **from this grid's largest value**, so every entry on it
draws something. That matters more than it sounds: a fixed list of isovalues is what makes
somebody type 0.02 into a density in atomic units, see nothing, and conclude the file is
broken. The one chosen for you when the file opens is usually the one that looks like the
picture in the paper; the rest of the menu is there to try.

The surface is drawn over whatever representation is in force, and it goes with the structure:
build or open something else and it is gone, because a surface computed for one molecule drawn
over another is not a mistake anybody catches by eye. A cube holding several data sets is
read, the first is drawn, and the footer says how many there were.

A very fine grid — more than one and a half million points — is **thinned** before it is drawn,
by taking every second (or third) point along each axis; the surface is the same to the eye and
the page stays usable on a phone. The footer says when that happened. If the file is enormous
even so, the atoms still open and the grid is left behind — the footer says so.

A surface that came from a **session file** (below) is a different thing: a picture frozen at
the isovalue it was saved with, not a field. The isovalue menu is greyed with the reason, and
dropping the original cube on the page brings the live field back.

#### Two grids: ESP, NCI and IGM

An ESP map, an NCI plot and an IGM picture are all the same shape of thing — **a surface taken
from one quantity and painted with the values of another** — and the only reason they need
different software is the quantity, not the drawing. NCIPLOT, Multiwfn and every ESP workflow
hand them over the same way: two cubes from one run, on the same grid.

So **open the second cube and it colours the first** rather than replacing it. A second menu
appears for the colour range; blue is negative, red positive, as in every such figure in
print. Only one surface is drawn, because the sign is what the colour is carrying now.

A cube on a *different* grid is a different calculation, and that one does replace.

## Saving

**SAVE** offers the drawing as ChemDraw `.cdx` and `.cdxml`, molfile V2000 and V3000,
Ketcher `.ket`, SMILES, PNG and SVG; and the 3D structure as JPG, PNG, `.xyz`, `.pdb` and a
3D `.mol` with hydrogens — ready to paste into a Gaussian, ORCA, xTB, GAMESS or MOPAC input.

Under **3D, other programs** are seven more, and every one of them **writes the cell** when the
structure has one:

| Format | For |
|---|---|
| `.cif` | crystallography, and anything that reads a CIF. `P 1`, fractional coordinates |
| `POSCAR` | VASP. Direct coordinates, atoms grouped by element as the format requires |
| `.gro` | GROMACS. Nanometres, fixed columns, box on the last line |
| `.gjf` | a Gaussian input, with the cell as `TV` lines |
| `coord` | xtb and Turbomole. Bohr, with `$periodic 3` and `$lattice angs` |
| `.pwi` | a Quantum ESPRESSO `pw.x` input: `CELL_PARAMETERS`, `ATOMIC_SPECIES`, `ATOMIC_POSITIONS` in ångström |
| `.abi` | an ABINIT input: `acell`, `rprim`, `xcart` in bohr, `typat` and `znucl` |

They all take the same thing — a list of atoms and, when there is one, three lattice vectors —
so **converting between any two of them is reading one and writing another**. Open a `POSCAR`,
save a `.cif`, open that: the same crystal comes back. There is no matrix of special cases.

Two conventions are handled rather than assumed. GROMACS will not accept a box whose first
vector has a y or z component, and PDB's `CRYST1` line has only six numbers and cannot say
which way the cell points — so for those two the cell is put in the standard setting (a along
x, b in the xy plane) and **the atoms are turned with it**. The fractions are what is
invariant; a cell rotated while its coordinates were not is a different structure.

### SAVE SESSION — everything, as a file

**SAVE ▸ 2DWORM session** — first in the SAVE menu and on its own, above the formats, because
it is not one of them — writes one file, `name.2dworm.zip`, that holds **everything on the page**:
the drawing, the 3D structure, the representation, the background, the camera, the picked
atoms and the kept marks, the dashed lines, the note, the cell, the charges, the file the
structure came from, and a small picture of the view. Drop it back on the page — this one or
any other copy of 2D-WORM — and everything is as you left it. It is the thing to use when a
structure is too large for a link, and it is also the thing to use when you want a copy that
depends on no server at all.

A surface from a `.cube` is saved as a **frozen surface**: the mesh of triangles that was on
screen, at the isovalue it was drawn with, in its colours — a coloured ESP map, an NCI or an
IGM picture included. A frozen surface is a few hundred kilobytes where the cube was thirty
megabytes, and it is what the file carries by default. What it cannot do is be re-sliced at a
different isovalue, and the page says so when such a file opens. If you want that, **SAVE ▸
2DWORM session + cube files** puts the cube files in as well — tens of megabytes, but complete — or
set it once under **OPTIONS ▸ Session file**.

Inside, the file is ordinary: a zip with a `manifest.json`, the `state.json` a shared link
would carry, the drawing as `.ket`, the structure in its own format, the original file, the
surfaces as binary meshes, the cube files when asked for, the note as `notes.md` and a
`thumb.png` — with a checksum for every member. Any zip program opens it, so nothing in it is
held hostage by this page.

---

## Making a 3D structure

Nothing happens on its own: the 3D view changes only when you press one of the three
buttons. That keeps the page responsive even with a large structure.

**MAKE 3D** builds a 3D structure with hydrogens from the drawing. Wedge and hash bonds are
respected, so stereocentres come out as you drew them.

**MINIMIZE** relaxes the structure you are looking at and shows the energy before and
after, together with the force field that did the work.

**BEST CONFORMATION** generates several conformers, minimises each one, and keeps the one
with the lowest energy. It takes longer than MAKE 3D and gives a better geometry.

**CLEAR** empties the 3D view. The drawing in Ketcher is not touched.

### The two force fields

The **Field** menu chooses what MINIMIZE uses.

**MMFF94s+** is accurate for ordinary organic molecules, but it has no parameters for
transition metals and it stops at 999 atoms.

**UFF** — the Universal Force Field — covers **every element from hydrogen to lawrencium**,
transition metals, lanthanides and actinides included, and has no size limit, so it is what
handles a metal complex or a protein. It is a rougher force field: it will give you sensible
bond lengths and hold a coordination geometry, but it knows nothing about ligand-field
effects, so it will not choose square planar over tetrahedral for you, and it does not do
Jahn–Teller distortions. Treat a UFF geometry as a tidy starting point for a real
calculation, never as a result.

UFF does not offer every element in every geometry — nickel, for instance, exists only as
the square-planar `Ni4+2`. When your atom is in some other geometry the status line says
which type was used instead, so you know what shaped the result.

The coordination geometry is read from the coordinates you supply, not guessed from an
oxidation state the file never carried: four ligands with a 180° angle between two of them
are treated as square planar, four at 109° as tetrahedral, six as octahedral. So if you want
a particular geometry, draw it or supply it — the force field will keep it, not invent one.

**Field: auto** (the default) uses MMFF94s+ wherever it applies and falls back to UFF where
it does not, saying in the status line which one ran and why. The two report energies on
completely different scales, so never compare a UFF number with an MMFF one.

A conformer search is a different thing from a force field: it rebuilds the molecule from
a library of torsions, and that library covers ordinary organic chemistry only. So
**BEST CONFORMATION is not available for a structure containing a metal**, for one above
999 atoms, or while UFF is selected — it says so straight away rather than trying and
failing. MINIMIZE still works on all of them.

While any of these runs, its button turns **red and says KILL** — press it to stop
immediately. Nothing else freezes in the meantime, because the calculation runs in the
background.

**A minimisation can be taken back.** MINIMIZE, MINIMIZE SELECTED, BEST CONFORMATION and MIN
pPERIODIC each leave the structure they replaced on the **UNDO** stack in the EXPERT row, and
**RESET ALL** unwinds the whole stack back to the structure as it was opened or made. A job you
killed leaves nothing on the stack, because nothing changed.

If you change the drawing after building a 3D structure, the status line reminds you to
press MAKE 3D again.

### Working on a file you dropped in

A structure dropped into the 3D panel is independent of the drawing. **MINIMIZE** and
**BEST CONFORMATION** then work on *that* structure, and whatever is in Ketcher is left
alone — so you can keep one molecule on the drawing board and refine another in 3D.

An `.xyz` file carries no bonds and a `.pdb` carries no bond orders, so they are worked out
from the distances between the atoms and every bond is treated as single. The status line
says so. For an aromatic or conjugated molecule, open it in the drawing instead and press
MAKE 3D.

Bonds to a metal are found using a proper table of covalent radii, so a complex dropped in
as `.xyz` arrives with its ligands attached — the 3D viewer's own bond perception stops at
the common organic elements and would otherwise leave the metal floating free.

MINIMIZE has no size limit: above 999 atoms it uses UFF, which works straight on the
coordinates. A protein is minimised in place, keeping its residue names, chains and
`CONECT` records. Only BEST CONFORMATION is restricted, as described above.

> The 3D builder is meant for ordinary organic molecules. Metal complexes and unusual
> coordination geometries are outside what a force field of this kind does well — treat
> such structures as a starting point for a real calculation, not as a result.

---

## The 3D view

Drag to rotate, scroll to zoom, drag with the middle button to move. **FIT** re-centres — the
same framing ENTER gives, the structure's extent on screen fitted to the panel, which is also
how a structure opens (a long molecule looked at end-on is not shrunk to fit its length).
**The right mouse button clears the selection** — the one thing you reach for most, without
looking for the button.

You can choose element, number or **charge** labels; the background; whether hydrogens are
shown; and an outline thickness for a cartoon-like look. Atom sizes come from a real
van-der-Waals table, so metals are drawn at their proper size.

**Labels are one size for the whole structure and they do not change as you turn it.** The
size is measured once, at the middle of the structure, and every caption gets it — under the
default perspective camera a nearer atom is drawn larger while its caption is not, which is
the price of a depth cue; the orthographic camera (OPTIONS ▸ 3D camera) draws every atom at
the same scale as its caption. The camera never switches with the label menu — the two
projections do not frame a structure the same way, and a camera that switched made the
picture jump — so one projection, whatever the labels are doing.
Labels still grow and shrink with the zoom, which is what you want. **Labels on the picked
atoms only**, a checkbox in the picked-atoms window (SELECT ▸ picked atoms list…), captions
three atoms of a structure that is too crowded to caption whole. Where two captions would overlap, the one on the atom **nearest the
camera** is kept and the other is dropped: two numbers on top of each other read as a third
number that is not in the structure.

### Charges, when the file has them

Open a Gaussian, ORCA, xTB or MOPAC output — or a formatted checkpoint — and any population
analysis in it is read and offered in a menu beside the label choice. **CM5, Hirshfeld, NPA,
Löwdin, ESP, CHELPG, APT, Mulliken**, each under the name its own program used. The file opens
showing them, because that is usually why the file was opened.

Nothing is averaged and nothing is renamed. Two methods disagreeing by half an electron on the
same atom is a real fact about those methods, not an error to be smoothed over, so you choose
which one you are looking at. The menu opens on the least basis-set-dependent one the file
actually contains. Red is electron-poor, blue is electron-rich, as on any electrostatic
potential map. The footer gives the **sum**, which is the quickest way to notice that the
wrong table was read — it should be the molecular charge.

The charges travel in a shared link, so a figure captioned with CM5 charges can be reproduced
by whoever you send it to.

### The representations

| Representation | What you get |
|---|---|
| **MacMolPlt (ball & stick)** | the default: the look of a MacMolPlt figure, and what most papers use |
| **Ball & stick + surface** | the same, inside a translucent solvent-accessible surface — shape and atoms at once |
| **Tubes** | bonds only, no atom spheres; good for a crowded structure |
| **Wireframe** | lines only; the lightest thing to draw |
| **Space filling** | full van-der-Waals spheres |
| **Cartoon (protein)** | ribbons along the backbone, coloured from one end to the other |
| **Cartoon + ligands** | the ribbon, with everything that is not the backbone drawn as sticks |
| **Surface only** | the surface by itself |

Under **More looks** in the same menu are four ready-made ones: *Publication* (a spectrum
cartoon with the ligands as sticks), *Technical illustration* (white spheres, black bonds and
a heavy outline — an ink drawing), *Neon on black* and *Crystallographic*. Choosing one that
only works against a particular background sets that background too, unless you have already
chosen your own.

**COLOUR / B&W** applies to whichever representation is showing. Black and white is for print:
the elements are told apart by how light or dark they are, since there is no colour left to do
it with, and the bonds are greyed as well as the atoms.

**Chain** appears when a structure has more than one, and shows them one at a time. In a
complex the thing you are looking for is usually behind everything else.

A cartoon needs a protein backbone. Ask for one on a small molecule and you get ball and
stick with a line in the footer saying why — the note goes away as soon as you choose
something that works. The same happens for any representation that cannot be built for a
particular structure: you get a picture and an explanation rather than an empty panel.

A surface is not drawn in FAST, and not for very large structures — it would take longer than
it is worth. In both cases the footer says so.

### HD, MED and FAST

A large structure can be slow to rotate. **FAST** drops the four things that cost the most
— the atom labels (one sprite per atom, redrawn every time you move the camera), the
outline (a second pass over the whole scene), the per-element atom sizes, and the separate
cylinders for double and triple bonds. **MED** is the full picture. **HD** is the full picture
drawn with more facets on every sphere and cylinder — for a close-up, or a figure, and slower
to turn.

Above about 1200 atoms the view opens in FAST by itself and says so; press MED or HD at any
time and it will stop choosing for you. FAST is always shown in red, because it is the one
that withholds something. Labels are never drawn for more than 400 atoms in any mode, because
past that they are unreadable and they make the view unusable.

**An exported image is always drawn at full quality**, whichever mode the screen is in —
FAST exists to keep rotation smooth, not to lower the picture you publish.

**JPG** saves the view at 1× to 4× the size of the panel — 2× of a normal window is around
2800 pixels wide, enough for a figure in a paper.

---

## Selecting atoms

**Click an atom** and it takes a magenta mark — a colour no element uses, so it is obvious
in ball-and-stick, wireframe and space filling alike. Click it again to let it go, press the
**SELECTION ✕** button, or click the background with the **right mouse button**, to clear them
all.

### SELECT — picking by rule

The **Select…** menu, in the 3D panel's own row of controls, picks atoms without clicking them
one by one: **all**,
**invert**, **clear**; **by element**, listing the elements of *this* structure with their
counts; **by number**; **grow** — one bond out, two bonds out, or everything within 3 Å of
what is picked; **whole molecules of the picked**; and **expression…**, which opens a window
for anything the menu cannot say.

The expression is a small language, and the window lists worked examples you can click:

| Expression | Picks |
|---|---|
| `C` | every carbon |
| `Fe _OR_ S` | the irons and the sulfurs |
| `H(<5)` | hydrogens numbered below 5 |
| `O(13-16)` | oxygens 13 to 16 |
| `12,15,20-30` | atoms by number |
| `Fe(<2.4A)` | everything within 2.4 Å of an iron — **not** the iron |
| `SEL(<3A)` | everything within 3 Å of what is picked |
| `SEL(+2)` | two bonds out from what is picked |
| `M(Cl)` | the whole molecule of every chlorine |
| `*(Z>5.6)` | every atom above z = 5.6 Å |
| `HIS _AND_ *(1.6<X<5.6)` | histidine atoms in a slab of x |
| `* _NOT_ H` | everything but hydrogen |
| `RES(12-20)` | residues 12 to 20 |
| `CHAIN(A) _NOT_ HOH` | chain A without its waters |

A subject is an element, `*` or `ALL`, `SEL` (what is picked now), a residue name, `RES`,
`CHAIN`, or a list of numbers. In brackets after it: a number condition (`<5`, `>1`, `3-9`), a
distance in ångström (`<2.4A` — the **A** is what makes it a distance), a number of bonds
(`+2`), or an axis (`X<0`, `1.6<Z<5.6`). `M( )` takes whole molecules. `_AND_`, `_OR_` and
`_NOT_` (also `AND`, `&`, `|`) are applied **left to right**, and brackets group. **Atom
numbers count from 1**, as on the labels and in every program's output; in a PDB the `TER`
records are never counted. A tick appears as you type when the expression is well formed, and
a sentence saying what is wrong when it is not.

**GROW** is a slider under the EXPERT bar, beside the three geometry sliders: with something
picked, it walks the selection out through the bonds, one bond per step, and the readout says
how many atoms that is. It always measures from what you picked, so walking back to zero is
exactly the original selection.

**Picked atoms list…**, at the bottom of the same menu, shows the selection as numbers you can
copy, paste and edit — in the order you clicked or in numeric order, with spaces or commas —
and applies an edited list back as the selection. **REORDER: PICKED FIRST** renumbers the
structure itself so the picked atoms come first, in that order, and the rest follow: it is
how a constraint block or a scan is written for Gaussian and ORCA, and it is one UNDO. The
structure is rewritten as a molfile when it fits one and a PDB when it has residues or is too
large — the footer says which, and since build 26 the residues, chains and atom names come
through the second; marks, schemes and dashed lines follow the atoms to their new numbers.

### Marks — colours, and keeping them

The mark on a picked atom comes in one of four kinds, chosen in the EXPERT row. The outline is
one pass over the whole picture and there is no way to exempt part of it — so when the outline
is on, it draws over a solid mark as well, and on a dark background the mark comes out in the
outline's colour rather than its own. That is why there are four:

| Mark | What it is | When |
|---|---|---|
| **double** | the atom **tinted** in the colour, inside a thin **cage** in the contrast colour — black on a light background, white on a dark one | the default: two things that agree, so the atom cannot be mistaken for an element of the tint's colour, and the outline cannot swallow it |
| **solid** | a translucent ball around the atom | obvious from across the room |
| **cage** | the ball as a wireframe sphere | with the outline on, or in space filling — the one marker the outline pass skips, and it never hides the atom |
| **tint** | no marker at all: the **atoms** take the colour | for a figure — nothing is added to the picture, and it is exactly the size of everything around it |

The **colour** is chosen beside it: magenta, cyan, yellow, orange, green. Magenta and cyan
match no element; the others do — yellow is sulfur's colour — which is exactly why *double* is
the default, and why *tint* on its own is for a structure you know.

**KEEP** turns the picked atoms into a **mark** in that colour and clears the pick, so you can
go on to pick the next set and keep it in another colour — the magenta atoms are the ligand,
the yellow ones the active site. A **legend** appears in the corner of the view naming each
colour, and it is drawn into the exported image, so a figure can be described by colour in its
caption. **MARKS ✕** removes them all. Marks travel in a shared link and in a session file.

Above three thousand marked atoms the double mark falls back to the cage, because two shapes
an atom is more than a phone will draw.

While the **BOND** tool is armed, the first atom you click takes a **blue cage** instead,
whatever the mark colour is. The two mean different things: a coloured mark is an atom you
chose and which travels in a link; the blue cage is a bond half-drawn and goes as soon as you
finish it or press Escape. When the second click lands, the bond **flashes** for a moment so
you see which one changed.

- **two** selected atoms show the **distance** between them
- **three** show the **angle**
- **four** show the **dihedral**

The measurement appears under the 3D view, the word first and then the number, large:

```
DIHEDRAL   -121.4°   C1 – C2 – C3 – C4
```

For a structure that has residues — anything from the Protein Data Bank — the atoms are named
the way the file names them and the residues follow in brackets, three-letter code with number
and chain:

```
DIHEDRAL    -63.5°   N – CA – C – N   (LEU 249 A, VAL 250 A)
```

**MINIMIZE SELECTED** appears as soon as you have picked something. It relaxes those atoms and
holds everything else exactly where it is — a fragment inside its surroundings rather than in
vacuum. It always uses UFF, whatever the field menu says, because that is the only one of the
two that can be told which atoms may move.

**A selection travels inside a shared link and its QR code.** Point at the two atoms you
mean, send the link, and the person opening it sees the same halos and is told how many you
highlighted. A selection survives MINIMIZE, because the atoms are the same ones; loading a
different structure clears it.

---

## EXPERT — moving atoms and changing bonds by hand

**EXPERT** opens two rows under the 3D controls: the tools on the first, what is done with the
picked atoms and the cell on the second. They are tinted, because while they are open the
mouse can mean something different, and that ought to be visible without reading anything.
It starts on **VIEW**, where nothing is armed and the mouse behaves exactly as it always did.
The buttons carry short names — **ANGLE PAN** is angle panning, **DRAG MOL.** drags a
molecule, **DEL** deletes — so that the row is one row in a half-width panel; the full name is
in every tooltip.

These are three **constraints**, not three ways of moving atoms — which is the whole point of
having three, and the reason each has a different modifier.

| Tool | A drag | Holding **ALT** |
|---|---|---|
| **DRAG ATOM** | the one atom you grabbed follows the pointer in the plane of the screen; its bonds stretch | keeps the bond length: the atom moves on the **sphere** around its neighbour, at whatever point of that sphere is under the pointer |
| **ANGLE PAN** | the atom **swings around its pivot**, carrying everything attached to it; the bond length is frozen and only the 3D angle changes | frees the length, so the bond stretches as it swings |
| **DRAG MOL.** | the whole connected fragment follows the pointer | turns the fragment about its own centre instead — 0.6° per pixel, which feels like turning something in the hand |
| **BOND** | click two atoms to make, change or remove the bond between them | — |
| **+H** | click an atom: a hydrogen is added to it at the least crowded position | — |
| **REPLACE** | click a hydrogen (or any terminal atom): it lights up for a moment, then it is replaced by the substituent chosen beside the tools | — |
| **DEL** | click an atom: it lights **red** for a third of a second, then it goes with its hydrogens, and every bond it leaves on a heavy atom is capped with a hydrogen | — |

An atom follows the pointer in the plane of the screen, at whatever zoom and from whatever
angle you are looking — it goes where you point and never toward or away from you.

**What one selected atom is for.** Two rules decide what actually moves when you swing an
atom, and neither is obvious from the picture:

- **the pivot** is a neighbour you picked if there is one, else its only neighbour, else the
  heavy neighbour with the larger branch — so grabbing the small end of a molecule moves the
  small end;
- **what swings** is the branch away from that pivot. If the branch comes back round to the
  pivot the atom is in a **ring**, and a ring cannot be swung open — so the atom moves with
  its exocyclic groups only and the ring stays where it is.

So picking an atom before you drag does something specific: it **names the pivot** for the
next swing, and the bond to keep for ALT + DRAG ATOM. Click an atom once with a tool armed and
it is picked; click it again and it is not. A press that ends where it began is always a pick,
never a drag — if your hand wandered on the way, the structure is put back first.

The status line names what is changing while you drag: the bond lengths at the atom, the angle
at the pivot, and for a fragment, how far it is from the rest and how close the nearest pair
of atoms has come. That last number is the reason to slide one molecule against another by
hand rather than by typing coordinates.

**Dragging the background still rotates the structure**, with a tool armed. Only a drag that
starts on an atom is taken by the tool, so you can turn the molecule round, move something,
and turn it back without switching tools. **Escape** abandons a half-finished bond, and
Escape again puts the mouse back to normal. A press has to land **on the 3D view itself**: a
structure zoomed in past the edge of the canvas has atoms behind the slider rows above it,
and pressing a slider never picks one of those.

**FREEZE** — beside FIT, red while it is on — holds the whole structure still: no rotation and
no translation, by mouse or by touch, while the tools, the picks, the sliders, the wheel and
the pinch go on working. For a figure that is framed, a drag that must not be spoiled by a
slip of the wrist, a tablet where every touch used to turn the molecule. FIT, SPACE and ENTER
wait until it is released; a new structure releases it.

**LABELS**, beside the SELECTION button, is one press for *captions on the picked atoms
only* — the same switch as in the picked-atoms window, here because it is reached for ten
times more often. Captions that are off come on as numbers.

### The atom window — a double-click on an atom

**Double-click** (or double-tap) an atom and a card opens over the view with everything the
page knows about it, and the three things a click cannot set:

- **number** — type another and press Enter: the atom takes that number and the others move
  along to make room, bonds, marks and schemes following; one undo;
- **element** — a menu of the periodic table: the atom becomes that element where it is,
  nothing added and nothing removed (a hydrogen count that no longer fits is yours to fix
  with +H or DEL), a PDB atom name following the symbol; one undo;
- **x, y, z** — typed exactly, in ångström; one undo each.

Below them, read-only: the file's atom name, the residue and chain, the charge from a
population analysis when the file carried one, the **UFF atom type** the force field would
give it, and its bonds with their orders and lengths. **TO NOTE** puts the same line into the
note, beginning with a chip that picks the atom again; **◀ ▶** step to the neighbours by
number; **Escape** or × closes it. The second click of a double-click does not un-pick the
atom — it stays picked, with the window open on it.

**UNDO** steps back through everything these tools did, one change at a time — and through
the changes that replace the whole structure, too: a minimisation, a conformer search, CELL
EXTEND, pPBC, pMODEL, the builder, USE THIS GEOMETRY from RESULTS. **RESET ALL** unwinds the
whole stack in one press and says how many changes it took back. Both sit in the 3D panel's
own row, beside CLEAR, so a minimisation can be taken back without opening EXPERT. Opening a
different structure clears the history, because the atom numbers no longer mean the same
thing.

### The builder — +H, REPLACE, DELETE, and your own substituents

Three tools that change what the structure *is*, ported from the builder of the full D-WORM.

**+H** puts a hydrogen on the atom you click, at the covalent distance, in the direction that
follows the local geometry — tetrahedral or trigonal, opposite the bonds that are there — and,
among the sensible directions, the one farthest from every other atom. It adds a hydrogen
whether or not the valence wants one; that is what makes it useful for a radical or a metal.
When there was no room — the nearest other atom is closer than a bond, 1.6 Å — the footer
prints that distance in **amber with a ⚠**: the hydrogen is there, but crowded, and MINIMIZE
or UNDO is the next thing to press.

**REPLACE** takes a hydrogen, any atom with a single neighbour, **or the first atom of a
group** and puts a substituent in its place. Which atoms leave is decided by looking at the
molecule from the atom you click: each bond to a heavy neighbour that can be cut without
leaving the atom attached splits the molecule in two, and the *smaller* side — the one the
clicked atom is on — is the group. So a methyl carbon takes its three hydrogens with it, the
oxygen of an OH takes its hydrogen, the ring carbon that carries a phenyl takes the ring, and
the central carbon of a *tert*-butyl takes all three methyls. An atom whose every bond is in a
ring, or one that sits between two sides of the same size, is refused with the reason (click
the first atom of the group you mean instead). The substituent is turned onto the bond,
placed at the covalent distance, and then turned about the new bond to the position with the
most room. The atom that makes the new bond **takes the number of the atom it replaced**; when
only a hydrogen left, nothing else is renumbered and the rest of the group is appended, and
when a group left, the survivors close up (the footer says how many atoms there are now).
Marks, per-selection schemes and dashed lines follow the atoms through the renumbering. The
menu beside the tools holds the built-in library — alkyl, aryl, hetero, carbonyl, halogen
groups, from methyl to mesityl to cyclohexyl — and your own.

**DEL** removes the atom you click with its hydrogens, and caps every bond it leaves behind
on a heavy atom with a hydrogen along the old bond, so what remains is a molecule and not a
radical.

Each is one **UNDO**, and each leaves the new atoms picked, so the next tool can start from
them.

**On a protein, the residues stay.** A structure that came with residues, chains and atom
names — a PDB, an mmCIF, a `.gro` — keeps them through +H, REPLACE, DEL and REORDER: an atom
the builder adds goes into the residue of the atom it hangs from, with a name of its own that
no other atom of that residue has (`H12` beside a residue that has `H1`…`H11`), and the
structure is written back as a PDB with `ATOM`/`HETATM` records, element columns and CONECT
lines, so what you save is still the protein it was. A drawn molecule has no residues and is
still rebuilt as a molfile, bond orders and all. (A PDB that arrives *without* element columns
— many are written that way — is read with the element taken from the atom name by the
format's own rule, so the `1H7` of a thymine methyl is a hydrogen and not an element "1".)

**Your own substituents.** **LIBRARY…** opens a window where a group is plain XYZ text — one
block each: the atom count, a comment line with `key=… name="…" group=…`, then `El x y z`
lines. A dummy atom **X** marks where the *parent* atom sits (the atom the group is bonded
to), and the real atom nearest X is the one that attaches; without an X the first atom
attaches. Bonds are perceived from the distances. Type it, paste it, **IMPORT** a file, or
**SAVE PICKED AS SUBSTITUENT** — pick the atoms of a group on screen and the one bonded to the
rest becomes the attachment atom. The library is kept in this browser and can be
**downloaded** as `fragments_user.xyz`; the same file placed beside `index.html` on a server
is read when the page opens, and it is the file the full D-WORM reads too, so a library moves
between the two as a file.

### One look for part of the structure

A figure of a protein with its ligand in space filling is one picture, and the representation
menu at the top can only make it one way at a time. **Picked as…** in the EXPERT bar draws the
atoms you have picked in a scheme of their own — ball & stick, glass, space filling, tubes,
wireframe, ink, neon, or **hidden** — and leaves everything else as it is.

Apply it again over atoms you have already given a scheme and the later one wins, so trying
something is a correction rather than a blend. **SCHEMES ✕** puts the whole structure back
into the global scheme.

These travel inside a shared link. The person you send it to sees the same figure, which is
the point. They belong to the structure they were made for, so building or opening something
else clears them: the list is atom numbers, and atom 7 is a different atom in a different
molecule.

**Glass** is the one to reach for first: ball and stick at half opacity, so a group inside a
cage or a ligand inside a pocket is visible *through* what surrounds it.

### The three sliders — setting a geometry by number

The drag tools put an atom where the mouse is. Under the EXPERT bar are three sliders that put
a bond at 1.47 Å and a torsion at 60°, which is what building a starting geometry actually
needs.

| Slider | Live when you have picked | What the number means |
|---|---|---|
| **BOND** | 2 atoms | a percentage of the distance they had when you picked them |
| **ANGLE** | 3 atoms | degrees from the angle at the middle atom |
| **DIHEDRAL** | 4 atoms | degrees from the torsion about the middle bond |
| **X, Y, Z** | 1 atom | the three rows become the three axes: ±2 Å from where the atom was when you picked it, and each box holds the coordinate itself — type 1.234 and the atom is at x = 1.234 Å exactly |

**UNIFORM / FREEZE A / FREEZE B** decides which side moves, and it matters more than it looks.
Stretching a bond in the middle of a chain with UNIFORM moves both halves of the molecule
apart, which is right for a diatomic and wrong for a group you are placing. FREEZE A holds the
first atom you picked and everything attached to it; FREEZE B holds the last one's side.

Each slider measures **from where the structure was when you picked the atoms**, not from
wherever it is now, so dragging out and back lands exactly where it started and **0** always
means untouched. The little **0** button does the same thing in one press, and UNDO takes back
a whole drag rather than a hundredth of one.

**A number box beside every slider** takes an exact value: type it and press Enter, and it is
that — a slider is for finding a value, a box is for setting one. **SHIFT** while pressing on a
slider narrows its whole travel to a quarter of the range around the current value, for fine
control with a mouse; the range comes back when you let go.

**The fourth row follows the selection.** With two atoms picked it is **TWIST** — turning one
side about the bond, in degrees; with three it is the **A–B** length; with four the **B–C**
length, the middle bond of the torsion — each in ångström, each with its own UNIFORM / FREEZE
A / FREEZE B, and each a delta from the same reference as the row above it.

Below −100 % a bond turns through itself and comes out the other side. That is deliberate: it
is a real thing to want when you are building, and it is why the slider goes to −300.

**Two atoms in the same ring have no sides** — every branch comes back round — so only the two
ends move and the readout says `ends only`. That is the honest answer: what you are asking for
would tear the ring.

### The ENERGY slider — before and after an edit

Every edit has a *before* (what UNDO would restore) and an *after* (what is on screen when it
is done). The sixth row under the EXPERT bar keeps both and lets you **scrub the structure
between them**: at the left end the geometry before the last edit, at the right the geometry
after it, in between the straight-line interpolation, and beside the slider the **UFF energy
of the geometry under it** — what a minimisation gained, what a drag cost, where along the way
the barrier is. It arms itself after any edit: a drag, a slider, an arrow key, a bond, +H or
REPLACE when the atom count did not change, MINIMIZE, BEST CONFORMATION, MIN pPERIODIC,
pMODEL, USE THIS GEOMETRY. The row names the edit, prints the two end energies and the one at
the slider, and the difference. Wherever you leave it, that is the structure — a link or a
file made afterwards carries it — and **AFTER** puts the finished edit back. The slider is a
way of looking rather than an edit of its own, so it pushes no undo step; UNDO still takes the
whole edit back, and clears the row. The energies are single points of the isolated structure
computed in the page (a few hundred atoms take milliseconds; above 12,000 atoms the row scrubs
the geometry without an energy); in a periodic box they are printed in the approximation
brackets, because the images are not in the sum. **The switch at the start of the row** —
**ON** by itself up to 2,000 atoms, **OFF** above that — decides whether the energies are
computed at all: on a large structure a single point takes seconds and would be paid for
every drag, so above 2,000 atoms the slider still scrubs the geometry and the energies wait
until the switch is pressed. A new structure sets the switch by its size again. An edit that changed the atom count — a
DEL, a REPLACE of a group — has no *before* to interpolate to, and the row says so.

### The arrow keys

With atoms picked, the arrow keys do the same three things one press at a time — which is
what you want when the number matters and not the feel of it.

| Picked | ← and → | ↑ and ↓ |
|---|---|---|
| **2 atoms** | turn one side **about that bond** | stretch it, 0.05 Å a press |
| **3 atoms** | open and close the angle | — |
| **4 atoms** | turn the torsion | — |

Five degrees a press, one with **SHIFT** held. Each press is its own UNDO, and the readout
keeps a running total from where you picked — so you can turn a group to exactly 45° and know
that you have.

Turning about a bond is the dihedral's arithmetic with the axis named by two atoms instead of
four, so the bond keeps its length and nothing else in the molecule moves at all.

**With ANGLE PANNING armed the arrows are the tool**, quantised: the last atom you picked
swings about its pivot — the same pivot a drag would use — by five degrees a press (one with
SHIFT), left and right about the screen's vertical axis, up and down about its horizontal one.
Each press is its own UNDO. The arrows used to fall through to the sliders while the tool held
its own reference, and the two reset each other; now the tool owns them.

### Neon, and what it needs

**Neon** is a thin bright filament inside a halo of its own colour, and it only reads as light
because everything around it is dark — so choosing it darkens the background and switches the
outline on, both of which you can then change. It is for a darkened lecture theatre, and it is
worth trying on a selection rather than on everything.

### The dashed line is not a bond

The fourth bond button, `┈`, draws a **dashed line** between two atoms and nothing else. It is
for a hydrogen bond, a contact, a "these two are close" — the things a figure needs and a
molecule does not have. It travels in a shared link, because it is part of the picture, and it
is **not** exported to any file, **not** counted as connectivity, and **never** seen by a force
field. Nothing that leaves this page will claim those two atoms are bonded.

### The drawing in Ketcher is not touched

There is no way back from the 3D view to the drawing, and there is not going to be one: a
three-dimensional arrangement has no single correct two-dimensional drawing, and writing a
guess back would quietly destroy a layout you made by hand. The moment you use one of these
tools the footer says so — the two have parted company, and **pressing MAKE 3D replaces the
edited structure with a fresh one built from the drawing.** Everything else keeps working on
what is on screen: MINIMIZE, MINIMIZE SELECTED, the exports, the image and the shared link all
take the structure as you have left it, and an added or removed bond travels with it.

---

## NOTES — what you meant, beside what you drew

**NOTES** opens a third panel. Whatever you write there **travels inside the shared link**, so
the person who opens it reads what you were thinking as well as seeing what you drew.

**WRITE** and **READ** switch between the text and how it will look. What you can use:

| You write | You get |
|---|---|
| `# Heading` | a heading — one level, on purpose |
| `**bold**`, `*italic*`, `` `mono` `` | bold, italic, monospace |
| `- something` | a bullet |
| `> note:`, `> warn:`, `> ok:` | a coloured block |
| `{big}words{/}`, `{small}words{/}` | bigger or smaller words |
| `{red}words{/}` — also `blue`, `green`, `orange`, `grey` | words in one of five colours |

The toolbar writes all of it, so nothing has to be remembered: **SIZE / COLOUR…** wraps the
words you have selected. **The five colours are a fixed set, not a picker, and that is
deliberate**: a colour you pick by hand is unreadable on at least one of the four
backgrounds — a dark blue chosen on WHITE disappears on BLACK — while five chosen once can be
checked on all four. A name that is not in the set is left as typed. **TEXT 12 … 21** on the
right sets the size of the panel's text on *this* device and changes nothing in the note.

**COORDINATES…** puts the 3D structure into the note as a block, in any format SAVE writes —
`.xyz`, `.pdb`, a 3D `.mol` with its bonds, a Gaussian input, `coord`, a POSCAR, a CIF, a
Quantum ESPRESSO input — so the note carries a structure somebody can copy straight into a
program. A block is shown exactly as typed, in monospace, and nothing inside it can become
markup. Above two thousand atoms the page asks first, and past what the note can hold it says
so and points at SAVE.

**INSERT SELECTION** is the reason to write the note here rather than in an e-mail. Pick some
atoms in the 3D view, press it, and the note gets the atoms and their measurement as a chip:

> The angle that bothers me is [ANGLE 118.7° C1 – C2 – C3]

Clicking that chip **picks those atoms again**, in whoever's browser is reading it. "The bond I
mean is this one" stops being a sentence anybody has to write.

### A note is somebody else's text

When you open a shared link, the note in it was written by somebody else and is being drawn in
*your* browser. So it goes through its own renderer, deliberately smaller than the one that
draws this manual:

- **no HTML**, of any kind;
- **no `[text](url)`** — that syntax lets the visible words say one thing while the link goes
  somewhere else, which is the whole mechanism of a phishing link. A bare `https://…` is shown
  as itself, **with the host it would actually go to**, and it is not clickable: it asks first,
  naming that host;
- **no images**, so a note can never tell a third-party server who is reading it.

A note is capped at 60,000 characters — room for a coordinate block — and the count beside the title turns red as you approach it.

**FULL LINK always carries the note.** A short link may not: whoever runs the server decides,
and the default is not to, because free text on somebody else's domain is how a site ends up
being used as a link shortener. The SHARE window says so plainly when it has left your note
out.

---

## 2DWORM-VR — the same structure in a headset

**MolStar-VR** — the button with the goggles, in the top row beside NOTES — opens
**2DWORM-VR**: the structure you are looking at, drawn by Mol* instead of 3Dmol, on a page that
can enter an immersive session. It is the one part of 2D-WORM that does not work on every
device: an immersive session needs a headset, and a Mol\* scene needs more of a phone than the
3D panel does. It opens **already
showing what you were looking at** — the same angle, the same centre, the same amount of the
molecule in frame — because what is handed over is the *view* rather than one program's camera
settings.

- **LAUNCH VR** appears active only in a browser that has a headset: Meta Quest, PICO, Vision
  Pro or Wolvic. On an ordinary computer the page still works — it is simply a second viewer.
- **RETURN** goes back to 2D-WORM with everything as you left it: the drawing, the 3D
  structure, the camera and the selected atoms.
- **SAVE VIEW** keeps the view you are in and **RECALL** comes back to it; **FIT** does the
  opposite and re-frames on the structure.
- **SAVE STATE** writes everything down, goes back to 2D-WORM and opens the share dialog there
  with this view already in it — so the link is waiting on the screen when you take the headset
  off. A link cannot be read in a headset, and this does not pretend otherwise.
- The backgrounds and the representation menu are the same words as in the 3D panel.
  **Quality** is worth turning down in a headset: everything is drawn twice, once per eye.

**The view follows you both ways, and there is nothing to switch on.** Going out, 2D-WORM's
view is what the headset opens on. Coming back — by RETURN, by the back button, by closing the
tab — 2D-WORM shows what you were looking at in there.

**A `.cube` travels too.** If the structure came with a grid, it is handed over with it and
**IGM** in the headset draws the same surface that was on screen here. A very large grid stays
behind, and the page says so.

### Inside the headset

There are no menus in an immersive session — the browser's own interface is gone, and the
module that would composite an HTML bar over the view is **not implemented by the Quest
browser**, so anything built that way is simply not there. The controls are therefore drawn
**in the scene**, as geometry, and they ride your **left controller** like a phone held in the
palm. Aim at them with the other controller and pull the trigger.

It sits **on top of the controller**, where the thumbstick is, so nothing is between your eyes
and the buttons.

| | | |
|---|---|---|
| **Render** — steps through the representations | **Chain** — element, chain, or secondary structure | **Hide H** |
| **Surface** — off, molecular, solvent accessible | **IGM** — the field that came with the structure | **Residues** — a label on each |
| **Slab** — keeps the inner 70 / 50 / 30 / 15 % | **BCK** — steps through the backgrounds: white, grey, dark grey, dark green, dark blue, black, **horizon** | **Recentre** — re-frames on the structure |
| **Save** — keeps this view | **Recall** — comes back to it | **Clear** — forgets the picked atoms |
| **Help** — the card below, on your hand (the **X** button does the same) | **Picture** — a PNG of the view | |
| **Leave VR** — one wide button across the bottom, so it cannot be pressed by mistake | | |

Every button that **holds** a state lights a bar underneath itself when it is on, so a toggle
in a headset is not a coin flip.

None of these reimplement anything: each one presses the control of the same name on the flat
page, so what you change in the headset is still set when you take it off.

**Surface** offers two, and they are not the same surface under two names. The *molecular*
surface is where a 1.4 Å probe touches the atoms; the *solvent accessible* one is the sheet its
centre traces, the same shape with every radius 1.4 Å larger. Both are drawn **over** the
sticks rather than instead of them.

**Slab** keeps the middle of the structure and cuts the rest away, which is the only way to
look inside a protein in a headset — the outside is in the way and you cannot rotate it out of
the way from in there.

Along the bottom is a plate reading **2D-WORM-VR** and the version. It is a sign, not a
button: a press cannot land on it.

**HORIZON** is the seventh background: a dusk-blue sky and a ground at your feet — a disc
twenty metres across with a **square grid, a line every metre**, drawn in the scene like the
menu and kept level with the room whatever you do to the molecule. The grid is **fixed to the
room**: walk, and the lines stay where the floor is (the disc follows you in whole-metre
jumps a metre grid cannot show, so it never ends and never slides). A fixed floor and a
horizon are what an inner ear wants while a protein turns in front of it; try it before a
long session. **Y** on the left controller turns the floor on and off — on, and back to
whatever background you had. Black is still where a session starts (on a Quest it is also the
passthrough).

**The hand menu stays outside the molecule.** When your hand goes into a structure, the
panel on it used to be inside the atoms, and whatever atoms were nearer your eye hid it — the
menu "disappeared". Now the panel is kept outside the structure's sphere, sliding along the
line from the structure's centre towards your eye until it is clear, and it is back on your
hand the moment the hand is out again.

**Help** puts a card on your hand in place of the buttons — what the triggers, the A, B, X and
Y buttons and the menu do, in the panel's own lettering — and any press on it puts the
buttons back. **Picture** takes a PNG of the view through Mol*'s own screenshot helper (from
the orbit camera, not from either eye); every picture goes to a strip under the view on the
flat page, where a click saves it after the headset comes off, and the download is tried at
once as well, which a desktop browser honours and a headset browser may not. The flat page has
both as buttons — **HELP** in the header, **PICTURE** beside SAVE STATE — and `?` opens the
help there too.

**The BUG theme crosses over.** A generated palette is made from two numbers, a hue and which
side of the lightness it is on; 2D-WORM hands them across, so the headset page opens in the
same look, and BUG pressed *there* rolls a new one that RETURN brings back with you. A link
made with BUG on carries the same two numbers, so whoever opens it sees the palette you saw.

**Picking atoms works in there too.** Point at an atom and pull the trigger. What is under the
controller is named above it, a yellow cube marks each picked atom, and the measurement
appears on a card above the top row of the menu — one atom gives its coordinates, two a distance, three the angle at the middle one, four
the dihedral about the middle bond. A fifth pick starts again. The card sits at your hand
rather than in the scene, where a number between two atoms spends its life inside a side
chain, and **the card is itself the Clear button** — press it and the measurement is gone.

**It only goes one way.** VR is a way of looking at a structure, not of changing one, so
nothing comes back and nothing you do there can damage your work. Editing, minimising, exports
and sharing all stay in 2D-WORM.

If the page says the viewer is not installed, the server is missing the `molstar/` folder —
see the installing section of `README.md`. Everything else on the site works without it.

---

## Sharing what you see

**SHARE** offers two kinds of link.

**SHORT LINK** stores the drawing on the server and puts only a short **ID** in the link,
so the QR code stays easy to scan. The ID is shown under the QR code together with the
size. Stored drawings may be replaced by newer ones, so a short link is for sharing, not
for archiving.

**A QR code here is not permanent**, and the sentence under every QR code says so before
anything is printed: codes are kept while they are in use and removed when they are not, so one
printed on a poster may stop working later. A very popular code is **retired** after a period
of notice, and a retired code does not simply die — whoever scans it is told that it was
retired and where to write. If you need a code to keep working — for a paper, a thesis, a
poster that will be up for a year — write to contact@dworm.org with what it is for, who you
are, how long you need it and roughly how much use you expect; it can be made permanent, and a
permanent link can carry a whole file, a session included.

**FULL LINK** carries the whole drawing inside the link itself. Nothing is stored anywhere,
and the link keeps working forever — but it is long. **SAVE SESSION** is the other thing that
never expires and needs nobody's permission, and for anything large it is the better choice: a
file has no size limit and depends on no server at all.

**A structure that came from a file** may be too large for either link, and a link without
its coordinates would open on an empty 3D panel. So when the structure is what makes the link
too long, the page offers what it can: if the file names itself — a PDB entry, a COD number —
the link carries that identifier and the other side fetches the deposited entry; if not, it
says so, with the size, and points at SAVE SESSION and at the permanent store rather than
making a link that shows nothing. When it is the **drawing** that is too large, the drawing is
kept and the small structure from the file is left out, and the sentence names the file so you
can send it alongside.

Both carry the 3D settings, the background you chose and the camera angle, so the person who
opens it sees exactly your view, can change the structure, and can send you a new link back.
A large structure travels in its own file format, so a protein arrives complete — unless it came
from **FIND**, in which case the link carries its identifier and the other side fetches it (see
*Finding a structure by name*). There are buttons
for WhatsApp, WeChat (which shares by scanning the QR code), e-mail, the phone share sheet,
and for saving the QR code as a picture.

**Opening a shared structure by ID:** type the ID into the small box at the top of the page
and press **GO**. This is the same code that is printed under the QR — so a code on a poster
or a slide is enough, no link needed.

---

## After updating the page on your own server

Upload **all** of `index.html`, `lib/` and `.htaccess` together. If the 3D panel then behaves
like the previous version — a force field you did not choose, or an error naming one you did
not ask for — your browser is holding an old copy of `lib/mol3d-worker.js`. The page says so
when it notices, and a hard reload (Ctrl+Shift+R, or Cmd+Shift+R) clears it. Adding `?something`
to the page address does not help: it is the worker that is stale, and it has its own address.

---

## Privacy

Everything — drawing, 3D building, minimisation, image export — happens inside your
browser. The first visit downloads the drawing engine once; after that it is cached and the
page works offline.

Two things leave the browser only because you asked them to:

- **SHARE ▸ SHORT LINK** stores the drawing on this server so the link can be short. Only
  the drawing and the 3D settings are stored; no address of yours is kept with it. FULL LINK
  stores nothing at all.
- **FIND** sends the words you type, and your network address, to the database you asked —
  the **RCSB PDB**, **PDBe**, the **NCBI** (PubChem, CACTUS), the **COD** and **TCOD**,
  **Wikidata** or **Zenodo** — because your browser asks them directly. That is the only
  request 2D-WORM makes to anyone other than the server this page came from. Structures you
  fetch that way are not copied onto this server: a shared link carries the identifier, and
  whoever opens it fetches the entry themselves — which means their browser, in turn, contacts
  that database. The molecule of the day comes from this server, and only when you press OPEN.

**No drawing you have not shared ever leaves your computer.** One other thing does go back to
this server, and it is worth stating plainly rather than leaving you to find it: a **count of
what was used** — "make3d 3, minimize 1" — sent as one small batch every couple of minutes and
once more when you close the tab. There is no cookie, no session and no identifier of any kind
behind it, nothing about it can be traced to you, and nothing is sent to any other company. It
exists so that one person can see which parts of this page are worth keeping. Whoever runs the
server can switch it off, and **TERMS.md** says exactly what is counted.

Two things are worth knowing before you press SHORT LINK. **A stored drawing is public to
anyone who has its ID**, so do not share anything confidential — use FULL LINK, which stores
nothing, or save the file. And **it is not an archive**: entries are kept while they are being
opened and are deleted when the space is needed.

The full text is in **TERMS.md**, and inside the app under **INFO ▸ TERMS &amp; PRIVACY**. To have
a shared drawing removed, send its ID to <contact@dworm.org>.

---

## Credits

Ketcher and Indigo (EPAM, Apache-2.0) · 3Dmol.js (Rego & Koes, *Bioinformatics* 2015) ·
MacMolPlt for the visual style (Bode & Gordon, *J. Mol. Graphics Mod.* 1998) ·
OpenChemLib (Actelion/Idorsia) · lz-string · qrcode-generator · fflate (MIT) for the session
file · Mol\* for the headset. The space-group table was checked against spglib.
Full details are in the INFO window.

2D-WORM is free software under the GNU Affero General Public License v3.0.
Source: <https://github.com/theogoncalves/2DWORM> · <https://dworm.org>
