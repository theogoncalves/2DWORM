<!--
NOTE TO THE MAINTAINER — read once, then leave this comment in place or delete it.

Before you publish this file:
  1. Replace <YOUR FULL LEGAL NAME> everywhere (2 places) and <JURISDICTION> (1 place).
  2. Confirm with the KAUST technology-transfer office that you own the software; if the
     university has rights, this agreement has to name the correct owner.
  3. Section 1(c) is the clause that keeps commercial licensing possible. Do not remove it.
  4. This document is modelled on the widely used Apache-style Individual CLA. It has not
     been reviewed by a lawyer. Have it reviewed once before you sign your first commercial
     licence, since that is the moment its wording matters.
  5. Contributors employed by a company should also arrange for the Corporate CLA
     (see section 9) — their employer may own their work.
-->

# Contributor License Agreement (Individual)

**Project:** D-WORM — the WORM family of scientific software (2D-WORM, D-WORM, WORM-PC,
3D-WORM and the dworm.org website), together with all of their source code, documentation
and related materials.

**Owner:** &lt;YOUR FULL LEGAL NAME&gt; ("the Owner"), the copyright holder of the Project.

Thank you for contributing. This agreement sets out the rights you give the Owner in the
material you contribute. It **does not take your copyright away** — you keep it, and you
remain free to use your own work however you like. It gives the Owner the permissions needed
to keep the Project available under an open-source licence and, where necessary, under a
commercial licence that funds its development.

By submitting a Contribution to the Project, or by accepting this agreement electronically
(for example by confirming it on a pull request), you agree to the following terms.

---

## 1. Definitions

**"You"** means the individual who submits a Contribution and who accepts this agreement.

**"Contribution"** means any original work of authorship — including source code,
documentation, test files, translations, examples, designs or other material, and any
modification of existing material — that You intentionally submit to the Project by any means,
including pull requests, patches, e-mail, issue attachments or messages. It does not include
material clearly marked in writing as "Not a Contribution".

---

## 2. Grant of copyright licence

Subject to the terms of this agreement, You grant to the Owner, and to recipients of software
distributed by the Owner:

**(a)** a perpetual, worldwide, non-exclusive, royalty-free, irrevocable copyright licence to
reproduce, prepare derivative works of, publicly display, publicly perform, sublicense and
distribute Your Contribution and such derivative works;

**(b)** the right to include Your Contribution in the Project and to distribute it as part of
the Project under the GNU Affero General Public License, version 3 or later, or under any
later open-source licence that the Owner adopts for the Project;

**(c)** the right to license Your Contribution, and any work containing it, **under any terms,
including proprietary or commercial terms**, so that the Owner may offer commercial licences
of the Project to organisations that cannot comply with its open-source licence.

You retain all right, title and interest in and to Your Contribution, and nothing in this
agreement restricts Your own use of it.

---

## 3. Grant of patent licence

You grant to the Owner and to recipients of software distributed by the Owner a perpetual,
worldwide, non-exclusive, royalty-free, irrevocable (except as stated below) patent licence to
make, have made, use, offer to sell, sell, import and otherwise transfer Your Contribution,
where such licence applies only to those patent claims licensable by You that are necessarily
infringed by Your Contribution alone or by combination of Your Contribution with the Project.

If any entity institutes patent litigation alleging that the Project or a Contribution
constitutes patent infringement, any patent licences granted under this agreement to that
entity terminate as of the date such litigation is filed.

---

## 4. You are entitled to grant these rights

You represent that:

**(a)** each Contribution is Your original creation, or You have the right to submit it under
the terms of this agreement;

**(b)** You are legally entitled to grant the above licences. If Your employer, university or
another party has rights to intellectual property that You create — including anything created
during working hours or using their equipment or facilities — You represent that You have
received permission to make the Contribution on their behalf, that they have waived such
rights, or that they have signed a Corporate CLA with the Owner;

**(c)** each Contribution complies with any licence terms of third-party material it contains.

---

## 5. Third-party material

If Your Contribution includes work that is not Your original creation, You will submit it
separately from any Contribution that is, and will identify the source, the author and the
licence of that material, marking it clearly, for example:

> `Third-party material: <name>, <source URL>, licensed under <licence>.`

---

## 6. No obligation and no warranty

The Owner is under no obligation to accept, use, or distribute any Contribution. Unless
required by applicable law or agreed in writing, You provide Your Contribution **"AS IS",
without warranties or conditions of any kind**, either express or implied, including any
warranty of merchantability, fitness for a particular purpose, title or non-infringement.

---

## 7. Attribution

The Owner will make reasonable efforts to credit contributors, for example in the Project's
release notes, an `AUTHORS` file or the software's INFO screen. This agreement does not
require a specific form of credit, and the omission of credit is not a breach of it.

---

## 8. Keeping this agreement accurate

You agree to notify the Owner in writing if You become aware that any statement You made in
this agreement is or has become inaccurate.

---

## 9. Contributions on behalf of an employer

If You are contributing as part of Your employment, or Your employer may own rights in Your
work, a **Corporate Contributor License Agreement** signed by an authorised representative of
that employer is required in addition to this agreement. Please write to
**contact@dworm.org** to arrange it before submitting code.

---

## 10. Acceptance and governing law

You may accept this agreement electronically — for example, by writing the sentence below as a
comment on a pull request, or by using the Project's CLA assistant, if one is in use. Such
acceptance is recorded together with Your account identity and the date, and has the same
effect as a signature.

> I have read the D-WORM Contributor License Agreement and I agree to it.

This agreement is governed by the laws of &lt;JURISDICTION&gt;, without regard to its conflict
of law provisions.

---

### Record of acceptance (only if signing on paper or by e-mail)

| Field | Value |
|---|---|
| Full name | |
| E-mail | |
| GitHub or other account | |
| Country | |
| Date | |
| Signature | |

Send the completed form to **contact@dworm.org**.
