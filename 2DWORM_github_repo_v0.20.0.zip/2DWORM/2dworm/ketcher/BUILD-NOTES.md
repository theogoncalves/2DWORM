# 2D-WORM Ketcher build notes

Self-contained, self-hostable Ketcher (EPAM) sketcher page, meant to be embedded in an
`<iframe>` by a parent page on the same origin. All asset paths are relative (`./assets/...`),
so the folder can live anywhere (e.g. `https://host/anything/2dworm/ketcher/index.html`)
on a plain Apache/Bluehost host over http or https. Verified with `python3 -m http.server`
from a nested path.

## Versions (all pinned exactly)

| Package | Version |
|---|---|
| ketcher-react | 3.18.0 |
| ketcher-standalone | 3.18.0 (Indigo WASM 1.46.0) |
| ketcher-core | 3.18.0 |
| react / react-dom | 18.3.1 |
| vite | 5.4.19 |
| @vitejs/plugin-react | 4.3.4 |
| events (browser polyfill for Node `events`) | 3.3.0 |
| playwright (tests only) | 1.56.1, Chromium 1194 from `/opt/pw-browsers` |
| node | 22.22.2 (ketcher-standalone declares `node >= 24` but builds fine) |

## Build

Source project: `ketcher-build` (`src/`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `test/`, `public/`).
Files in `public/` (`.htaccess`, this `BUILD-NOTES.md`) are copied verbatim into the output on every build; edit them there.

```bash
cd ketcher-build
export PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1
npm ci                      # or npm install
npm run build               # -> 2dworm/ketcher/  (outDir is set in vite.config.js)

# verification (headless Chromium; serves 2dworm on a random port)
PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node test/run-test.mjs
PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node test/subfolder-test.mjs   # nested path via python http.server
```

Build option: `KETCHER_FULL_MONOMERS=1 npm run build` keeps the full macromolecule monomer
library (+4 MB of JS). Not needed: the macromolecules editor is disabled in this build.

## Output (`2dworm/ketcher/`)

```
index.html                                     1.0 KB
.htaccess                                      Apache: AddType application/wasm + long cache for hashed assets
assets/index-<hash>.js                         4.34 MB (1.12 MB gzip)  main bundle: React + ketcher-react + ketcher-core
assets/index.modern-55d8e3ef-<hash>.js         432 KB  (132 KB gzip)   ketcher-react secondary chunk, loaded at start
assets/index-<hash>.css                        183 KB  (29 KB gzip)
assets/indigoWorker-d22340fa-<hash>.js         75 KB   (24 KB gzip)    Indigo web worker (module worker)
assets/indigo-ketcher-1.46.0-<hash>.wasm       11.8 MB (3.8 MB gzip)   Indigo WASM, fetched lazily by the worker
assets/index.modern-<hash>.js                  1.24 MB (337 KB gzip)   macromolecules editor chunk - NEVER requested in this build
```

* Total folder: **18.07 MB** (18 MB on disk).
* Initial download before the editor UI appears: index.html + main JS + secondary chunk + CSS
  = **4.95 MB raw / ~1.28 MB gzipped**. The worker JS + 11.8 MB WASM are fetched afterwards
  by the worker; API calls that need Indigo (SMILES/molfile/CDX/layout/image) queue until it is ready.
* `ready` postMessage arrived ~0.85-1.0 s after navigation on localhost in headless Chromium.

Output is ES modules (`<script type="module">`), not IIFE. IIFE was not practical:
ketcher-standalone spawns a **module** worker (`new Worker(new URL(...), {type:'module'})`) and
ketcher-react uses dynamic `import()` for the macro editor chunk, which Rollup's IIFE format
cannot code-split. ES modules load fine from any subfolder over http/https (verified); they only
fail on `file://`, which is not a target.

## Page behaviour (src/main.jsx)

* Full-window editor (100vw x 100vh, no margins). Ketcher keeps its own (light) theme; the dark
  page background only shows during loading.
* `onInit(ketcher)`:
  * `window.ketcher = ketcher`
  * subscribes `ketcher.editor.subscribe('change', ...)` and posts
    `{type:'2dworm-ketcher-change'}` to `window.parent`, throttled to 300 ms (leading + trailing edge)
  * posts `{type:'2dworm-ketcher-ready'}` to `window.parent` (once)
  * Ketcher errors are posted as `{type:'2dworm-ketcher-error', message}` (and logged).
* Quirk: ketcher-react 3.18 calls `onInit` **twice** with the same Ketcher and editor instance
  (its init effect runs twice). The page guards against it, so `ready` is posted once and the change
  subscription is not duplicated.
* Macromolecules editor disabled (`disableMacromoleculesEditor`), so `getCDX()`/`getCDXml()` never
  throw "not available in macro mode".

Parent-side pattern (same origin):

```js
const iframe = document.getElementById('ketcher');
window.addEventListener('message', (ev) => {
  if (ev.data?.type === '2dworm-ketcher-ready') { /* iframe.contentWindow.ketcher is usable */ }
  if (ev.data?.type === '2dworm-ketcher-change') { /* something changed on the canvas */ }
});
// If the parent attaches its listener late, it can also poll: iframe.contentWindow.ketcher
const ketcher = () => iframe.contentWindow.ketcher;
```

## Build fixes that were required (all in vite.config.js)

1. `import 'ketcher-standalone/dist/binaryWasm'` instead of the package root. The root entry
   (`dist/main.js`, 21 MB) inlines the WASM as base64; `binaryWasm` keeps it as a separate file.
2. `worker.format = 'es'` (module worker). Vite rewrites both `new Worker(new URL(...))` and the
   worker's own `new URL('indigo-ketcher-1.46.0.wasm', import.meta.url)` to hashed relative asset
   URLs, so worker and WASM are found at runtime from any subfolder. `assetsInlineLimit: 0`.
3. `resolve.alias.events -> events` npm package: ketcher-core imports Node's `events`.
4. `define.global = 'globalThis'`: ketcher-react uses `global.currentState`, `global._ui_editor`.
   Without it: `ReferenceError: global is not defined`.
5. Plugin `fix-ketcher-core-raphael-require`: ketcher-core's ESM file `raphael-ext.modern.js`
   contains a bare CommonJS `require('raphael')`; rewritten to an import.
   Without it: `ReferenceError: require is not defined`.
6. Plugin `stub-ketcher-monomers-library`: replaces the embedded 4 MB monomer-library JSON string
   (`ketcher-core/dist/application/editor/data/monomers.modern.js`) with an empty library.
   Only the macromolecules `CoreEditor` reads it, and that editor is never created here.

## Verified API (test/run-test.mjs, 21/21 checks pass, 0 console errors)

All `ketcher.*` methods below return **Promises - always `await` them**, including `setMolecule`,
`layout`, `getKet`, `getSmiles` (the editor does work synchronously, but Indigo conversions run in
the worker).

```js
const k = iframe.contentWindow.ketcher;

await k.setMolecule('c1ccccc1CC(=O)O');      // SMILES, molfile, KET JSON, CDXML, base64-CDX: format auto-detected
await k.setMolecule('');                     // clears the canvas
await k.getSmiles();                         // 'c1c(CC(O)=O)cccc1'
await k.getMolfile('v2000');                 // string with 'V2000'
await k.getMolfile('v3000');                 // string with 'V3000'
await k.getKet();                            // JSON string {ket_version:'2.0.0', root:{nodes,connections,templates}, mol0:{atoms,bonds}}
await k.layout();                            // resolves undefined; canvas re-laid-out (KET changes)
await k.getCDXml();                          // '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE CDXML ...' (multi-line)
await k.getCDX();                            // base64 STRING of the binary CDX (see below)
const png = await k.generateImage(await k.getKet(), { outputFormat: 'png' }); // Blob, type 'image/png'
const svg = await k.generateImage(await k.getKet(), { outputFormat: 'svg' }); // Blob, type 'image/svg+xml'
```

Empty canvas:
* `getKet()` -> `{"ket_version":"2.0.0","root":{"nodes":[],"connections":[],"templates":[]}}` (parseable)
* `getSmiles()` -> `""` (empty string, no error)

### CDX binary handling (the important part)

`getCDX()` returns a **base64 string**. Decoded, it is the raw ChemDraw binary file starting with
the 8-byte magic `VjCD0100`. In ketcher-core this format is literally labelled "Base64 CDX"
(`SupportedFormat.cdx`, extension `.b64cdx`); `binaryCdx`/`.cdx` is the same bytes, decoded.

Save as a binary `.cdx` file (browser):

```js
const b64 = (await ketcher.getCDX()).replace(/\s/g, '');
const bin = atob(b64);
const bytes = new Uint8Array(bin.length);
for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
const blob = new Blob([bytes], { type: 'chemical/x-cdx' });
// e.g. download:
const a = document.createElement('a');
a.href = URL.createObjectURL(blob); a.download = 'structure.cdx'; a.click();
```

Load a binary `.cdx` file back (File/ArrayBuffer -> base64 -> setMolecule). **Do not** pass the
raw binary string; Ketcher/Indigo detect CDX only in base64 form (decoded prefix `VjCD0100`):

```js
async function loadCdxFile(file /* File or Blob */) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  const b64 = btoa(bin);
  await ketcher.setMolecule(b64);        // format auto-detected as CDX
}
```

Alternative through Indigo directly (also verified), e.g. to convert without touching the canvas:

```js
// base64 CDX -> KET / SMILES / CDXML.  IMPORTANT: do NOT pass inputFormat.
const ket   = (await ketcher.indigo.convert(b64, { outputFormat: 'chemical/x-indigo-ket' })).struct;
const smi   = (await ketcher.indigo.convert(b64, { outputFormat: 'chemical/x-daylight-smiles' })).struct;
const cdxml = (await ketcher.indigo.convert(b64, { outputFormat: 'chemical/x-cdxml' })).struct;
// anything -> base64 CDX
const cdxB64 = (await ketcher.indigo.convert('c1ccccc1', { outputFormat: 'chemical/x-cdx' })).struct;
```

Quirks found:
* `ketcher.indigo.convert(b64, { inputFormat: 'chemical/x-cdx', ... })` **fails** in standalone
  (WASM) mode with `RXN loader: bad header ...` - the `input-format` option makes Indigo skip its
  auto-detection and it does not accept base64 there. Omit `inputFormat` and let Indigo auto-detect
  (this is exactly what Ketcher's own `setMolecule` path does: it never passes `input_format`).
* `setMolecule(cdxml)` round-trips fine. A CDXML string with all newlines stripped is
  mis-identified as "SMILES" by ketcher-core's `identifyStructFormat`, but still loads correctly
  because Indigo auto-detects the actual content; if that ever bites, convert first with
  `ketcher.indigo.convert(cdxml, { outputFormat: 'chemical/x-indigo-ket' })` and `setMolecule(ket)`.
* `getCDX()`/`getCDXml()` throw if the editor were in macromolecules mode; that mode is disabled here.
* `generateImage(data, opts)` takes a KET/molfile/SMILES *string*, not a Struct; returns a Blob.
  `opts.backgroundColor` and `bondThickness` are also accepted.
* `layout()` resolves `undefined` (no return value); read the result with `getKet()` afterwards.
* Indigo version reported by `await ketcher.indigo.info()`: `1.46.0.0-...-wasm32-wasm-clang-23.0.0`.

## Test artefacts

`ketcher-build/test/out/`: `results.json`, `screenshot.png`, `phenylacetic.{mol,ket,cdx,cdxml,png,svg}`
(the `.cdx` is the decoded 857-byte binary, magic `VjCD0100`).
`2dworm-test/ketcher-test.html` is the tiny parent page used by the test (iframe + message log).

## Hosting notes

* Serve `.wasm` as `application/wasm` (the shipped `.htaccess` does `AddType application/wasm .wasm`).
  If the MIME type is wrong the worker logs "wasm streaming compile failed" and falls back to
  ArrayBuffer instantiation - it still works, just slower.
* Asset filenames are content-hashed; only `index.html` needs a short cache.
* Everything is same-origin; no CORS/COOP/COEP headers are required (no SharedArrayBuffer use).
