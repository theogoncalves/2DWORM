# ketcher/ — build output, not kept in git

This folder holds the compiled Ketcher 3.18.0 bundle (about 18 MB, including the 12 MB Indigo
WASM). Build artefacts are deliberately not committed, so this folder is empty in a fresh clone
apart from these notes.

Two ways to fill it:

1. **Download the ready-to-upload zip** attached to a
   [release](https://github.com/theogoncalves/2DWORM/releases) — it contains this folder built.
2. **Build it yourself:**

   ```bash
   cd ../ketcher-build
   npm ci
   npm run build          # writes ../ketcher/
   ```

`BUILD-NOTES.md` in this folder records the exact versions, the build fixes that were needed,
and the verified Ketcher API (including how binary `.cdx` files are handled).
