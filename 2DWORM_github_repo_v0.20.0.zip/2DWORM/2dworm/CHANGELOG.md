# Changelog

All notable changes to 2D-WORM. Versions follow [semantic versioning](https://semver.org).

## [0.20.0] — build 28 — 2026-09-13

Dante's second list from the Quest, the tablet and the PC, and pREST.

### Fixed

- **Selecting every atom of a large structure took a minute.** Each picked atom was drawn as
  two shapes and the status line named all of them (a 200,000-character line, laid out and
  then cut to one). Above 400 marked atoms the marks are one bulk tint per colour
  (`markBulk`, one `addStyle` over a predicate per group), the status line names thirty and
  counts the rest, and nothing is measured for more than four. Measured on 8yax (40,738
  atoms): `applyStyle` 65 s → 0.67 s, the status line 305 → 12 ms.
- **A press on a slider row picked the atom behind it.** The tool handler sat on the whole
  panel and `atomAtPoint()` finds an atom wherever it projects, including under the bars when
  the structure is zoomed in past the edge. A press now has to land on the 3D view itself.
- **In VR the hand menu vanished when it touched the molecule.** Not culling (Mol*'s hiZ
  occlusion is off by default and nothing enables it — build 27's notes were wrong about
  that): the panel was inside the atoms and the nearer atoms hid it. The panel is kept outside
  the structure's sphere with a margin of its own size, sliding along the line from the centre
  towards the eye (`keepPanelOutside`), and returns to the hand as soon as the hand is out.
- **The VR floor walked with you** — build 27 re-centred the disc under the head every frame,
  so its rings slid under your feet ("very strange, making me dizzy"). The ground is a square
  grid now, a line every metre on a disc twenty metres across, centred under the head in
  whole-metre jumps a metre grid cannot show: fixed to the room, and endless.
- **The EXPERT bar grew on a pick.** pMODEL and pREST appear with a selection; with CRYSTAL
  beside them the second row was full at 700 px and the hint, insisting on 40 px, wrapped it —
  the canvas moved between the two clicks of a double-click. The hint now takes what is left,
  down to nothing.

### Added

- **The ENERGY switch.** ON by itself up to 2,000 atoms, OFF above; when off the slider still
  scrubs the geometry and the energies wait for the switch — a single point on a protein is
  seconds and was paid for every drag. A new structure sets it by size again.
- **DEL and REPLACE light the atom first** — red for DEL, 0.3 s (`TOOL_FLASH_MS`), the
  acknowledgement the bond tool gives — then take it. A second click during the flash is
  ignored.
- **One picked atom turns the three rows into X, Y, Z**: ±2 Å along each axis from where the
  atom was picked, the number box holding the coordinate itself (typed exactly, beyond the
  slider), the side rule hidden, one undo per drag or typed number.
- **FREEZE**, beside FIT, red while on: the structure neither turns nor moves, by mouse or by
  touch, while picks, tools, sliders, wheel and pinch go on working (3Dmol's mousedown and a
  single-finger touchstart are stopped in the capture phase; two fingers pass, because two
  fingers is the pinch). FIT, SPACE and ENTER wait; a new structure releases it. The VIEW
  tool's pick is done by the page while frozen, since 3Dmol never sees the click.
- **LABELS**, one press beside the SELECTION button: captions on the picked atoms only (the
  picked-atoms window's switch, reachable without the window). Captions that are off come on
  as numbers.
- **The atom window**: a double-click or double-tap on an atom. Editable number (renumbered
  through the REORDER machinery — `reorderAtoms(perm)` — bonds, marks and schemes following,
  one undo), element (the periodic table; nothing added or removed; a PDB name follows the
  symbol; one undo) and x, y, z (exact, one undo each); read-only name, residue and chain,
  charge from any population analysis in the file, the UFF atom type, the bonds with orders
  and lengths; TO NOTE puts the same line into the note behind a chip; ◀ ▶ walk the numbers.
  The double is detected on the second press, on the document in the capture phase, ahead of
  the tools and of 3Dmol, and the atom under the FIRST press is the one meant — a pick can
  move the bars, and the picture, under a hand that has not moved. The second click does not
  un-pick.
- **NOTES: sizes and five colours.** `{big}…{/}`, `{small}…{/}`, `{red|blue|green|orange|grey}…{/}`
  — a fixed set of names, each a class and nothing else (no picker, no style attribute; a
  name outside the set is left as typed), written by the SIZE / COLOUR… menu around the
  selected words. TEXT 12–21 sets the panel's text size on the device and is remembered
  there. Decision C2 ("two sizes, colour from the role") is revised by this at Dante's
  request; the renderer's safety envelope is unchanged.
- **PAUSED! has views.** MODEL / REST / ALL draw the model system, its surroundings, or both,
  for pMODEL, pREST and MIN pPERIODIC (a temporary hide set, `pauseHidden`, honoured by
  `applyStyle`); TAIL H / TAIL CH3 rebuilds a pMODEL or pREST intermediate with the other cap
  on the spot, and CONTINUE runs with what is showing (the job message is composed after the
  pause).
- **Methyl caps** (`lib/pmodel.js`, `cap: 'CH3'`, OPTIONS ▸ pMODEL / pREST caps): the cap
  carbon on the original bond vector at the ONIOM distance for a carbon (a cut C–C keeps its
  length exactly), three hydrogens at 1.07 Å, tetrahedral, staggered against the linker's
  other bonds by a deterministic azimuth scan; all four held. A multiple-bond cut keeps its
  hydrogens whatever the option.
- **The region grows before it is cut** (`growRegion`): an outside hydrogen bonded to a
  region atom joins it (an X–H bond is never cut), and so does any outside atom bonded to
  two or more region atoms — whose two caps would otherwise coincide, which is what made a
  thin pREST shell come back at half a million kcal/mol. The atoms drawn in are counted in
  `describe()`.
- **pREST** (`buildRest`, OPTIONS ▸ pREST shell: 3, 5, 8 Å or all): the mirror of pMODEL —
  the picked atoms are the model and are held, the shell of the rest within the distance is
  free, the far rest is cut away and capped at the boundary; `shell: Infinity` relaxes the
  entire rest without a cut. Same result shape, same `applyModel`, same PAUSED! views. The
  page refuses a region whose every atom sits at a cut (nothing would move); the library
  builds it, for the tests.
- **2DWORM-VR: Y toggles the floor** — HORIZON on, then the background you had before it
  (`toggleFloor`); the picture stays on the menu and on PICTURE. The help card and the flat
  HELP say so.

### Suites

`build28.mjs` (74). `build27.mjs` follows the twenty-metre disc.

## [0.19.1] — build 27 — 2026-09-13

Dante's first test of build 26, on the Quest 3, a tablet and a PC — six things, all in.

### Fixed

- **FIND had no box to type in.** The database menu holds eight providers since build 24,
  each described in a phrase, and a `<select>` is as wide as its widest option: the menu grew
  to the width of the dialog, squeezed the text box to 18 px and pushed SEARCH out of sight —
  "databases appear and no field for a molecule's name", on every device. The menu is capped
  (the dropdown list still shows every phrase in full), the box keeps 140 px at least, and on
  a phone the menu and the button wrap under it. Checked at 1400, 1024 and 430 px.
- **The BUG theme reaches 2DWORM-VR** (it used to arrive as WORM or DUSK). A generated palette
  is a function of two numbers — a hue and which side of the lightness it is on —
  `makeBugPalette(hue, dark)` is deterministic now, the hand-over carries the two numbers, the
  headset page has the same palette arithmetic and a BUG button of its own, and RETURN brings
  the palette chosen there back. A link made with BUG on carries the two numbers too (`st.tp`),
  so it reproduces the look instead of rolling a new one on arrival. (`+null` is `0`: a missing
  hue coerced to red until the check said so.)

### Changed

- **One MolStar-VR button**, in the top row beside NOTES; the copy in the 3D panel's own row
  is gone (Dante: "it is already near NOTES").
- Ketcher's "Ready." no longer overwrites a later message: it reports ready on its own clock,
  and after a return from 2DWORM-VR it arrived a moment after "Back from…" and wiped it.

### Added — 2DWORM-VR

- **HORIZON**, a seventh background: a dusk-blue sky and a ground at floor level — a disc
  twelve metres across with a ring every metre and a spoke every 30°, one fan and a few
  hundred thin quads, built as a dynamic group like the measurement markers and placed every
  frame under the head through the same `inverse(camera.view)` bridge the hand menu uses, so
  turning or scaling the molecule leaves the floor where the floor is. The floor's height comes
  from the headset's `local-floor` reference space when it offers one, from an assumed 1.5 m
  below the eyes when it does not. Black is still the session default.
- **The help card**, ported from Dante's Mol* page: twelve lines in the panel's own lettering
  on the menu's own rectangle, a second primitives group so it is a representation of its
  own; **Help** on the menu or the **X** button shows it in place of the buttons (the lamps go
  dark under it), any press on it puts the buttons back. A **HELP** button and `?` on the flat
  page open an overlay with the flat and headset controls.
- **Pictures**: **Picture** on the menu or the **Y** button — Mol*'s `viewportScreenshot`
  helper, from the orbit camera with the labels turned to face it — into a strip under the
  view (`#vrGallery`, each a download named after the structure and the time) with the
  download tried at once; **PICTURE** on the flat page does the same. Mol* turns the left
  controller's X and Y into `GamepadX` / `GamepadY` key releases; the page listens for the
  session's duration (the snapshot list is emptied when the menu is built, so nothing else
  answers them).
- **The pick cubes are half as big again** (0.33 Å half-size, was 0.22): too small to see
  across a protein.

### Tests

New suite `build27.mjs` (26): FIND at three widths, the palette arithmetic, the link, the
crossing and the return, the fifteen buttons, the card, a picture, the ground's size in
metres, the overlay. `vr.mjs` follows the fifteen buttons.

## [0.19.0] — build 26 — 2026-09-12

The rest of the list, with the decisions Dante took on the four open questions.

### Added — the ENERGY slider (§7)

A sixth row under the EXPERT bar. Every edit — a drag, a slider, an arrow key, a bond, a
minimisation, BEST CONFORMATION, MIN pPERIODIC, pMODEL, USE THIS GEOMETRY — has a before (the
undo record) and an after (what is on screen when it is done); the row keeps both sets of
coordinates and scrubs the structure between them, printing the UFF energy of the geometry
under the slider, the two end energies and the difference. Wherever it is left, that is the
structure; AFTER puts the finished edit back; it pushes no undo of its own (dragging back is
its undo) and UNDO still takes the whole edit back and clears the row. Single points are
computed in the page from `lib/uff.js`; in a periodic box they go into the approximation
brackets because the images are not counted; above 12,000 atoms the row scrubs without an
energy; an edit that changed the atom count has no before and the row says so.

### Added — REPLACE takes a whole group

Click a methyl carbon, the oxygen of an OH, the ring carbon that carries a phenyl, the central
carbon of a *tert*-butyl: the whole group leaves and the substituent takes its place. The rule
is one sentence — each bond to a heavy neighbour that can be cut without leaving the atom
attached splits the molecule, and the smaller side, the one the clicked atom is on, is the
group. An atom whose every bond is in a ring, or one between two sides of the same size, is
refused with the reason. The attachment atom keeps the replaced atom's number; when a group
left the survivors close up and the footer says how many atoms there are now. Marks,
per-selection schemes and dashed lines follow the atoms through a rewrite that removed atoms
(`builderShow` takes the map now; DELETE used to drop them).

### Added — residues through the builder

+H, REPLACE, DEL and REORDER on a structure that came with residues (a PDB, an mmCIF, a
`.gro`) keep the residue names, numbers, chains and atom names: `viewerStruct()` carries them,
`toPDB()` writes `ATOM`/`HETATM` records with element columns, and an atom the builder adds
goes into the residue of the atom it hangs from with a name no other atom of that residue has.
`structText()` chooses the writer once for everything that rebuilds a structure: a PDB when
there are residues, a molfile when it fits, a PDB otherwise. A drawn molecule is still a
molfile. On the way: **a PDB without element columns** was read with the element taken from
the first character of the atom name, so `1H7` became an element "1" — a DNA's formula read
C200H104160… and its methyl hydrogens were heavy atoms to the builder and unknown to UFF.
`pdbWithElements()` fills the columns in by the format's own rule before 3Dmol sees the file.

### Changed

- **The EXPERT bar is two rows by construction** — the tools on the first (VIEW, DRAG ATOM,
  ANGLE PAN, DRAG MOL., BOND, +H, REPLACE, DEL — short names, the long ones in the tooltips
  and the manual), what is done with the picked atoms and the cell on the second. One line
  each in a half-width panel with BOND armed; the substituent menu is the one thing that still
  wraps. The hint has a zero flex basis: with the old 6em basis Chrome gave the row two flex
  lines for an empty or one-letter hint and one for a sentence, and the 3D view moved 18 px
  each time a tool was armed — measured while an arrow key was swinging an atom. The whole
  hint is its tooltip. `lang/*.json`: the two label keys and the three drag tooltips renamed
  in every language, the long translations shortened to match.
- **Perspective is the default camera again**, orthographic the OPTIONS choice (Dante's call).
  Neither switches with the label menu, so B5 holds for both: the suite asserts the invariant
  (one projection with labels on and off) rather than which one. `fitView` keeps 3Dmol's
  sphere fit under perspective and the measured extent under orthographic. The one label
  size is now measured at the **centroid** — 3Dmol's rotation centre — rather than at a
  middle-indexed atom: under perspective an atom's scale depends on its depth and a 90° turn
  changed the captions by 2 %; at the centroid they are the same size at any angle.
- **+H says when there is no room**: the nearest-atom distance turns amber with ⚠ below 1.6 Å.
  `addHydrogenTo` and `substitute` return `closest`.

- **SAVE ▸ 2DWORM session** is the first entry of the SAVE menu, under its own heading and
  above the formats — a session is the whole page as a file, not a format among formats
  (Dante, during the build). The two entries were renamed from "Session".

### Fixed

- GROW's **0** button did nothing: the generic zero-button wiring of the slider rows replaced
  its handler (it ran later). The generic wiring is now limited to the rows' own buttons.
- `REORDER: PICKED FIRST` sets `bondsEdited` (the bonds written are exactly these) and carries
  marks, schemes and dashed lines to their new numbers instead of dropping them.
- **No atom could be picked in 2DWORM-VR** — in the headset or on the flat page. A click on
  one atom gives a Mol* loci whose `indices` is an Interval packed as two int32s in a float64,
  and `atomFromLoci()` did not know the packed form (the menu's `firstGroupId()` did) and
  returned null for every real click; the suite had injected picks directly and never
  exercised the click path. Dante's report. It decodes with `firstGroupId()` now, `vr.mjs`
  clicks real atoms through Mol*'s own projection, and a drawn molecule's atoms are named
  element + number (`C1 – C2`), as 2D-WORM numbers them, instead of `C (MOL 1)`.

### For the reviewers

`2dworm-test/strings.mjs` walks the page the way `i18nCollect()` does and lists every English
string that is not yet a key in the language files — 365 at this build — into
`lang/STRINGS_TO_REVIEW.md` (a table with empty Hindi and Urdu columns) and
`lang/strings_to_review.csv`. The keys are added to the JSON files when translations arrive,
not before, so `lang.mjs`'s "untranslated by accident" check keeps its meaning.

### Tests

New suite `build26.mjs` (56 checks in a browser: the two rows and their heights, group
replacement with a mark that follows the renumbering, the refusals, residues through the four
tools on `DNA.pdb`, the element columns, the ENERGY slider end to end, GROW's 0, the camera,
the reviewer sheet). `fragments.mjs` grows to 98 (groups, refusals, residues on new atoms,
`closest`). `test.mjs` and `build25.mjs` assert the projection invariant; `lang.mjs` follows
the renamed keys.

## [0.18.0] — build 25 — 2026-09-12

The rest of the list: the p-methods and their breakpoint, the builder, and the small things.

### Added — PAUSED!, the breakpoint

A pseudo-periodic or model-system result depends on an intermediate the page builds and throws
away — Dante's point: "the generated structure with frozen environment is not unique". With
**OPTIONS ▸ PAUSED!** on, a procedure stops at that point, draws the intermediate, turns its
job button red with the word PAUSED!, and offers CONTINUE and STOP in a bar under the view; the
status line says *paused*. KILL still works, so a forgotten pause never looks like a hang, and
nothing can be left waiting for ever. MIN pPERIODIC shows its frozen shell as thick grey tubes;
pMODEL shows the capped model with the caps in yellow and the held atoms caged. Built once, as
a contract any long procedure can use (`pausePoint`), not as a feature of one button.

### Added — pPBC

`lib/ppbc.js`: an orthogonal box guessed from the van-der-Waals envelope, the molecule turned to
the smallest box (principal axes, then a bounded refinement whose volumes never increase), the
box made the cell. A gap between images is an OPTIONS choice. The sentence is in the
approximation brackets and says "guess"; one UNDO. It exists so that MIN pPERIODIC has a cell
to work with for a molecule that came without one.

### Added — pMODEL

`lib/pmodel.js`: the picked region cut free, every cut bond capped with as many hydrogens as
its order at the ONIOM-scaled link-atom distance along the old bond (the ideal single-bond
length for a multiple bond, since a measured double bond is shorter than the single bond the
cap stands in for), the region relaxed with UFF while linkers and caps are held, the
coordinates put back under their original numbers. Cut anywhere; a cut that is not a single
bond between light atoms is named in the brackets unless OPTIONS says not to. The notes say
what the charge caveat is and that the result is a model-system guess. One UNDO.

### Added — the builder

`lib/fragments.js`, ported from the builder of Dante's D-WORM (worm4): the fragment table
(38 groups, methyl to mesityl to cyclohexyl, as Z-matrices and Cartesians with the X dummy at
the parent), NeRF placement, the multi-XYZ user-library format, bond perception. Three EXPERT
tools: **+H** (a hydrogen where there is most room, coordination-driven, at the covalent
distance), **REPLACE** (a hydrogen becomes the chosen substituent, turned to the clearest
torsion; the attachment atom takes the hydrogen's number), **DELETE** (an atom with its
hydrogens, every wound capped). **LIBRARY…** edits your own groups as XYZ text, imports a file,
downloads `fragments_user.xyz`, and saves the picked atoms as a group; the library lives in
this browser and in a `fragments_user.xyz` beside `index.html`, the same two places worm4
keeps it. Dante's own file ships as the example.

### Added — the small things

UNDO and RESET ALL in the 3D panel's own row, beside CLEAR. OPTIONS cross to 2DWORM-VR and come
back with RETURN, as a query string. The camera is **orthographic by default** whatever the
labels do — switching projections with the label menu moved the picture by 2 % and 9 px, and no
scale match can make two projections frame an asymmetric structure alike (B5); perspective is
an OPTIONS choice. With ANGLE PANNING armed the arrow keys swing the picked atom about the
tool's own pivot instead of falling through to the sliders (B6). A number box beside every
slider; SHIFT narrows a slider's range by four around its value. A fourth slider row that
follows the selection: TWIST with two atoms, the A–B length with three, the B–C length with
four. COORDINATES… puts the structure into the note as a fenced block in any format SAVE
writes, and the note's cap is 60,000 characters so it fits. A `.mol2` with lone-pair centres
opens without them, renumbered, and says so. BUG replaces DUSK on the theme row: a generated
palette on every press, in fixed lightness bands so it stays readable (DUSK still opens from a
link). A picked-atoms window: the selection as numbers to copy and paste, click or numeric
order, spaces or commas, applied back; REORDER: PICKED FIRST renumbers the structure the way a
constraint block wants; labels on the picked atoms only.

### Fixed

MIN pPERIODIC was not a job button — it never showed KILL and a second press tried to start a
second job; it and pMODEL are in the list now. Picking ties (two atoms within a few pixels)
were broken by the projection scale, which under the orthographic camera is the same for every
atom, so the lower index won; ties are now broken by depth, and a click on an atom's own
centre beats a nearer atom two pixels off. A query string that holds nothing but OPTIONS no
longer stops the return from 2DWORM-VR. The `before` hook of a job button mistook `true` for a
message. **Framing under the orthographic camera** — two things the default camera exposed:
3Dmol's own fit sizes the bounding SPHERE, so a 90-Å helix looked at down its axis opened as a
22-px disc in a 700-px panel (perspective hid it by drawing the near end large); a structure
now opens, and FIT shows it, the way ENTER frames it — the measured extent, fitted to the
panel. And SPACE/ENTER centred to a quarter of the error: `viewer.translate` converts its
pixels at the camera's depth, half a pixel per pixel in orthographic; the first pass now
measures how far the structure actually moved and the rest are scaled by it. Switching to
perspective in OPTIONS on a deep structure could put the camera inside it; the switch now
falls back to a fresh fit when the match leaves atoms in front of the lens. The fit at opening
is capped at 120 px/Å (a molecule seen down its own axis has a two-angstrom extent, and
filling the panel with it is not a picture); SPACE and ENTER, which are asked for, are not.

### Tests

New suites: `fragments.mjs` (83), `pmodel.mjs` (56), `ppbc.mjs` (35), `build25.mjs` (60, the
page in a browser). `edit.mjs` runs with the 3D panel solo — three rows of EXPERT controls in a
half-width panel put two atoms of ethanol four pixels apart, and the drag tests click by
projected position. `test.mjs` and `notes.mjs` follow the new camera and note cap.

## [0.17.0] — build 24 — 2026-09-12

The build after the long list. Everything on it that could be built without a device in hand
is in; what is not is in `BUILD24_NOTES.md`, with the reasons.

### Added — SAVE SESSION: the whole page in one file

`name.2dworm.zip` holds the drawing, the structure, the representation, the background, the
camera, the picked atoms, the marks, the dashed lines, the note, the cell, the charges, the
file the structure came from and a thumbnail — the same state a shared link carries, plus what
a link cannot hold. Drop it on any 2D-WORM and everything is as it was. It is the answer to
"too large for a link", and to "I want a copy that depends on no server".

A cube's surface is saved **frozen**: the mesh that was on screen, at its isovalue, in its
colours — an ESP map, an NCI or IGM picture included — a few hundred kilobytes where the cube
was thirty megabytes. A frozen surface cannot be re-sliced and the page says so when one opens;
dropping the original cube brings the live field back. **Session + cube files** puts the cubes
in too, and OPTIONS remembers which you want. Inside, it is an ordinary zip — `manifest.json`,
`state.json`, `drawing.ket`, the structure, `original/`, `surfaces/*.bin`, `volumes/*.cube`,
`notes.md`, `thumb.png` — with a checksum per member, so any zip program opens it.

### Added — RESULTS: the optimisation and the modes

An output file used to give up its last geometry and nothing else. **RESULTS** now opens a
window on a Gaussian, ORCA, xTB or MOPAC output: the energy against the step (kcal/mol relative
to the lowest; an IRC against its reaction coordinate), any step in a small viewer with its
four convergence tests ticked or crossed, and every vibrational mode — imaginary first, in red
— animated by 3Dmol's own `vibrate()` with a stick IR spectrum drawn high wavenumbers to the
left. **USE THIS GEOMETRY** takes a step into the page, which makes the window a step in a
workflow and not a picture; it is undoable.

### Added — a selection language, a SELECT menu, GROW

`Fe(<2.4A) _OR_ Fe`, `M(Cl)`, `SEL(+2)`, `*(1.6<Z<5.6)`, `CHAIN(A) _NOT_ HOH` — subjects
(elements, `*`, `SEL`, residue names, `RES`, `CHAIN`, numbers), conditions (number, distance
with an `A`, bonds with a `+`, an axis), `M()` for whole molecules, and `_AND_` / `_OR_` /
`_NOT_` left to right. Atom numbers are 1-based, as on the labels, and `TER` records never
count. The window ticks a well-formed expression as it is typed and says what is wrong with a
malformed one; fourteen worked examples are clickable. The **Select…** menu covers the everyday
cases without typing — all, invert, by element with counts, by number, grow, whole molecules —
and **GROW** is a slider that walks the pick out through the bonds and back, measuring from
what was picked so zero is always exactly the original.

### Added — marks in colour, kept, with a legend; the DOUBLE mark

Five mark colours — magenta, cyan, yellow, orange, green. **KEEP** turns the pick into a mark
in that colour and clears it for the next set, so a figure can say "the magenta atoms are the
ligand, the yellow ones the active site"; a legend appears in the corner and is drawn into the
exported image; **MARKS ✕** removes them; marks travel in the link and the session file.

The default mark is now **double**: the atom tinted in the colour inside a thin cage in the
contrast colour (black on a light page, white on a dark one). Two markers that agree — so a
yellow tint can never be read as sulfur, and the outline pass, which draws over a solid ball,
cannot swallow it. Tint recolours only what the atom already draws, adding no primitive, and
above 3,000 marked atoms double falls back to the cage. The half-drawn bond is always a blue
cage, whatever the mark colour, and the finished bond flashes.

### Added — a crystal builder, and CIFs expanded by symmetry

A `.cif` lists its asymmetric unit; the symmetry operators are now applied — the file's own, or
the table's when the file names a group and lists none — so urea's five atoms become the
sixteen of its cell. `lib/crystal.js` carries all 230 space groups, verified against spglib.
**CRYSTAL** builds one from the numbers a paper gives: lattice system (greying what it fixes),
cell parameters, space group, the asymmetric unit in fractional coordinates, a supercell up to
8×8×8, with a preview that counts before BUILD makes anything; **FROM THE 3D VIEW (P1)** goes
the other way.

### Added — readers for twelve more programs, writers for two

NWChem, CASTEP (`.cell` and `.castep`, with the cell), Q-Chem, Molpro, Psi4, Turbomole (`coord`,
`gradient`, `energy`, outputs), Quantum ESPRESSO and ABINIT (inputs and outputs, with the
cell), ADF/AMS and Jaguar — last geometry and, where the program prints one beside it, the last
energy. The classifier is now a table of scored recognisers with the tie recorded, rather than
a chain of `if`s. **SAVE** writes a Quantum ESPRESSO `.pwi` and an ABINIT `.abi`.

Molecular dynamics, in `lib/mdgeom.js`: AMBER `.rst7` / `.inpcrd` / `.restrt` with `.parm7` /
`.prmtop`; NAMD `.coor` (text or binary) with `.psf` and `.xsc`; CHARMM `.crd` with `.psf`;
LAMMPS data files and the last frame of a dump. Files dropped together are paired by what they
are. A coordinate file without its topology still opens, with the elements guessed and the
footer saying so.

### Added — FIND: eight databases, a name table, a progress bar

The providers are **data** (`lib/providers.json`), not code: RCSB PDB, PDBe, PubChem, COD,
TCOD, Wikidata, CACTUS and Zenodo ship switched on — all public domain or free without a credit
line; AlphaFold (CC-BY) is present but off, and when an operator switches it on the credit line
arrives with every structure. Sixty-odd common names are known to the page itself and offered
last. A large fetch shows how much has arrived, with a stop button.

### Added — the molecule of the day, retired codes, permanent files

An empty 3D panel offers one structure from a list the operator keeps in **a database of its
own** (`featured.php`, uploaded from the admin page), with a credit line; nothing is fetched
until OPEN. Short links carry a **notice** under every QR code saying that a code is not
permanent and where to write for one that is; a very popular code is **retired** after
`retire_hits` / `retire_days` and answers HTTP 410 with a sentence and the address rather than a
bare 404. The admin page can upload a file as a permanent link (`f=` payload, never opened by
the server) and lists the fifty most-opened codes.

### Added — CELL EXTEND asks, and everything is undoable

Above 1,500 added atoms CELL EXTEND asks first, with the numbers (a zeolite's 216 become
60,000). MINIMIZE, MINIMIZE SELECTED, BEST CONFORMATION, MIN pPERIODIC, CELL EXTEND and USE
THIS GEOMETRY each leave the structure they replaced on the UNDO stack — the one kind of change
that used to be final — and **RESET ALL** unwinds the whole stack. A killed job leaves nothing
on it.

### Added — OPTIONS, MAX, the manifest, HD

An **OPTIONS** window: the on-screen-keyboard rule (Ketcher's hidden text box raised the
keyboard on every tool on a tablet — *automatic* stops that on touch screens only) and what a
session file carries; each setting is remembered and is a parameter in a link. ⛶ has three
positions — solo, **MAX** with the control bars gone and a way back on screen, and back —
instead of the browser's full-screen mode, which the iPhone does not offer; a web-app manifest
and icons make **Add to Home Screen** the way to lose the browser's bars. **HD** joins MED and
FAST (FAST always red). Right-click clears the selection. The VR button is **MolStar-VR** with
goggles; the headset menu cycles six backgrounds and the session is ended properly on leaving.

### Added — Hindi and Urdu

`lang/hi.json` and `lang/ur.json`; Urdu reads right-to-left like Arabic, and neither mirrors
the layout. The sentences added in this build are still English in every file, pending the
native readers.

### Changed

A grid above 1.5 million points is **thinned** before marching (every second or third point,
header vectors scaled with it), so a 32 MB Gaussian cube opens on a phone; a mapped grid's
colour range is the 90th percentile of its values rather than the extreme. MIN PERIODIC is
**MIN pPERIODIC**, and its energy is printed in brackets in the approximation colour, as any
pseudo-periodic number should be. A cube is no longer stored as the "original" file (it is a
volume, opt-in). Libraries are loaded with the build stamp and must not import one another
statically. The `#editHint` no longer wraps the EXPERT bar and shrinks the canvas.

### Fixed

The charges a file came with are applied before the RESULTS sniff, so an output no longer opens
for a moment without its captions. A whole-structure UNDO record survives `show3d`. The
`kbdObserver` was read before its declaration. The names-table result no longer short-circuits a
FIND search.

### Tests

**2,292 checks in thirty-two suites, all passing.** New: `build24.mjs` (85, the page in a
browser), `sellang.mjs` (45), `mdgeom.mjs` (163), `qcresults.mjs` (83), `session.mjs` (94),
`crystal.mjs` (120), `names.mjs` (33); `qcgeom.mjs` 440, `fetchdb.mjs` 153, `server.mjs` 109,
`admin.mjs` 91, `terms.mjs` 55, `lang.mjs` 68, `edit.mjs` 71. The corpus of real files
(Gaussian, ORCA, cubes, CIFs, an mmCIF, VASP, inputs for six programs) lives in
`2dworm-test/corpus/`; the cubes are not in the repository.

## [0.16.0] — build 23 — 2026-09-11

Two grids at once, and three things off the administrator's list.

### Added — the surface from one grid, the colours from another

An ESP map, an NCI plot and an IGM picture are all the same shape of thing: a surface taken
from one quantity and painted with the values of another. The only reason they need different
software is the quantity, not the drawing — and NCIPLOT, Multiwfn and every ESP workflow hand
them over the same way, as two cubes from one run on the same grid.

So a second `.cube` **on the same grid colours the first** rather than replacing it. A colour
range appears beside the isovalue, built from the second grid's own values; blue is negative
and red positive, as in every such figure in print. **One** surface is drawn, not two — a
coloured surface is single-valued by construction and the sign is what the colour is carrying
now. A cube on a *different* grid is a different calculation, and that one does replace.

"The same grid" is decided on the header's own numbers — counts, origin, the three axis
vectors — rather than with a tolerance, because it is an exact statement and a pair written
by one program in one run agrees to the last digit.

Both grids travel to the headset when they fit. 2DWORM-VR steps between them rather than
painting one with the other; Mol\* can colour a surface from a second volume and this page
does not ask it to yet.

### Added — the store can be closed

`store_on`. There was no way to turn the service off short of deleting the folder, and
"set every limit to zero" does the opposite, because zero means *no limit* in three of them.

Off stops **new** short links and QR codes, and says so in a sentence that points at the FULL
LINK instead. It deliberately does not stop opens: a QR code printed on a poster cannot be
recalled, so everything already stored goes on working — and a full link never reaches the
server in either direction, so people can go on sharing while the store is shut.

### Added — every setting says what it does

A page of fifteen numbers with no explanation is a page nobody dares change anything on,
which comes to the same thing as not being able to change it. Each one now carries a sentence
beside it, kept next to the setting itself in `core.php` so the two cannot drift apart —
`terms.mjs` fails if a setting is added without one.

### Added — Other, on the map

Everything below five and every country with no position is folded into **Other**, and until
now Other appeared only in the table underneath: a map showing four circles could be hiding a
third of the visits and looked complete. It is drawn as a **square in the bottom-left corner**
on the same scale as the circles — a square rather than a circle precisely so that nobody
reads it as a country.

### Added — a total per day

The two bars are links made and links opened; the third column is the **total for that day**,
which is what "how busy was it" actually asks. The summary underneath gives both averages.

### Tests

**1084 checks in twenty-five suites.** `server.mjs` 42 → 46 for closing the store without
breaking what is already out there, `admin.mjs` 54 → 56 for Other on the map, `terms.mjs`
47 → 49, `cube.mjs` 24 → 32 for the second grid.

## [0.15.0] — build 22 — 2026-09-11

Four more readers, one look for part of a structure, and the arrow keys.

### Added — GAMESS-US, Molden, Multiwfn `.mwfn` and NBO `.47`

Geometry only, as with `.cube`, `.fchk` and `.wfn`: the nuclei are near the top of all four,
so only the head of the file is ever read. GAMESS also gives up its Mulliken and Löwdin
charges, and its **last** geometry rather than its first — the ANGS block is written after
every optimiser step and the BOHR block before every energy, so which one is last is not the
same as which one is right.

**Every wavefunction format gives a label and a nuclear charge, and they can disagree in two
opposite ways.** Read the charge and an effective core potential ruins it: chlorine writes 7
and comes out as nitrogen, which is the bug in `Pt(NH3)2Cl2.wfn`. Read the label and a
shouting output ruins it instead: GAMESS capitalises everything, so a carbon labelled `CO`
comes out as cobalt. Neither can be preferred outright. The rule is that **when either
reading of the label agrees with the charge, the agreement settles it** — which is what
tells `CO` with a charge of 6 from `CO` with a charge of 27 — and only when nothing agrees
does the label win, because an ECP is far commoner than a mislabelled atom. Both traps are
in the suite, each with the file that springs it.

`.molden` says its own units on the section header (`[Atoms] AU` or `[Atoms] Angs`), which
is unusually civilised of a format. `.mwfn` and `.47` are always bohr, and the `.47` never
says so anywhere — its second column is a **mass** number, not a charge, which is the one
thing to get wrong there.

### Added — one look for part of the structure

A figure of a protein with its ligand in space filling is one picture, and a single global
representation menu cannot make it. **Picked as…** in EXPERT draws the selected atoms in a
scheme of their own — ball & stick, glass, space filling, tubes, wireframe, ink, neon, or
hidden — over whatever the rest is drawn in. Later exceptions win where two overlap, so
applying again is a correction rather than a blend, and **SCHEMES ✕** puts everything back.

They **travel inside a shared link**, beside the dashed lines, because a figure that arrives
looking unlike the one that was sent is the one thing a link must not do — and they are
filtered against the structure that actually arrived, since a link is text somebody else can
edit. They go with the structure they were made for: an atom index means a different atom in
a different molecule.

### Added — Glass, and a Neon that looks like neon

**Glass** is ball and stick at half opacity: a group inside a cage, or a ligand inside a
pocket, seen *through* its surroundings rather than instead of them. Worth far more applied
to a selection than to everything.

**Neon** was two bright colours, which is not what neon is. A neon tube is a thin bright
filament inside a soft halo of the same colour, and it only reads as light because
everything around it is dark. 3Dmol has no emissive material, so the glow is built rather
than lit: a 0.07 Å filament, a translucent sphere at every atom in the same colour for the
bloom, and the outline pass — now allowed a colour of its own — as a second, wider halo. The
background goes dark with it.

### Added — the arrow keys

With atoms picked in EXPERT: **← and → turn one side about the picked bond**, five degrees a
press and one with SHIFT; **↑ and ↓** stretch it. Three or four atoms picked and the keys
drive the angle or the torsion instead. It is the sliders' own arithmetic with the axis named
by two atoms instead of four — one reference, one undo per press — and the readout keeps a
running total from where you picked.

They do **not** go through the slider. A range input snaps its value to its step, so a length
change expressed as a percentage came back quantised and `↑` then `↓` did not cancel: 0.05 Å
became 0.047 Å and the atom crept. The keys carry their own exact numbers.

### Added — the Ketcher toolbars at 75 % and 50 %

125, 150 and 175 per cent are rules inside Ketcher's own bundle, where changing anything
costs a full rebuild and a 17 MB re-upload. The two smaller ones are injected from the parent
page instead, which is where all of them should have been. `zoom` rather than a transform, so
the toolbar actually takes less room and the drawing gets it.

### Tests

**1068 checks in twenty-five suites.** `reps.mjs` (15) is new. `geo.mjs` grew 18 → 30 for the
arrow keys, `qcgeom.mjs` 72 → 88 for the readers, `test.mjs` 91 → 92.

## [0.14.0] — build 21 — 2026-09-11

The headset menu as it was meant to be, the volume a `.cube` came with, a cell relaxed
inside its own surroundings, and three sliders for setting a geometry by number.

### Added — the hand menu, all thirteen controls

| | | |
|---|---|---|
| Render | Chain | Hide H |
| Surface | IGM | Residues |
| Slab | BCK | Recentre |
| Save | Recall | Clear |
| **Leave VR** — one wide button across the bottom | | |

A three-column grid on the left controller with the name plate underneath, and **the panel
now sits on top of the controller** rather than two centimetres below the grip, where the
controller body was between your eyes and the buttons and the ray from the other hand
clipped it on the way in. Both offsets stay adjustable from the URL (`?menulift=`,
`?menufwd=`) because the right answer is a few centimetres either way depending on the
headset and finding it should not need a rebuild.

**Lamps.** Every button that holds a state — Chain, Hide H, Surface, IGM, Residues, Slab,
and Recall once there is something to recall — lights a bar under itself when it is on. A
toggle you cannot see the state of is a coin flip. They are their own little group of a few
quads, rebuilt on their own rather than by rebuilding the menu, so a press costs nothing you
can feel: the menu is a state-tree reload and the lamps are not.

**Not one button implements anything.** Each presses the flat page's own control — the same
select, the same checkbox — so the headset and the page cannot disagree, what you set in
there is still set when you take the headset off, and every one of them can be tested in a
flat browser, which is the only place any of it *can* be tested. The suite asserts the
buttons against `XR_ACTIONS` both ways, so a button with no action, or an action no button
reaches, fails the build.

### Added — what the new buttons do

- **Chain** — element, chain, or secondary structure.
- **Surface** — off, molecular, or solvent accessible, drawn **over** the sticks rather than
  instead of them: a surface on its own hides where the atoms are. These are two different
  surfaces and not one under two names — the molecular surface is where a 1.4 Å probe
  touches the atoms, the solvent-accessible one is where its centre goes.
- **Residues** — a label on every residue.
- **Slab** — keeps the inner 70, 50, 30 or 15 %. A clip object on each representation,
  discarded in the shader — **not** `cameraClipping`, which is the obvious candidate and
  which works by shrinking the camera radius: in an immersive session the near and far
  planes come from the headset, so it would have done nothing where it is wanted most.
- **IGM** — the volumetric field handed over from 2D-WORM (below), positive lobe blue and
  negative red. Says plainly when no field was handed over rather than cycling a menu with
  one entry in it.
- **Save / Recall** — Save keeps the view and writes it back for 2D-WORM; Recall returns to
  it. **SAVE STATE** on the flat bar writes everything down, goes home and opens the share
  dialog there, so the link is on screen when you take the headset off. A link cannot be
  read in a headset and this does not pretend otherwise.

### Added — the volume a `.cube` came with

A cube file is a molecule and a grid, and until now only the molecule was read. The grid is
drawn: two isosurfaces for signed data — an orbital, an IGM, an NCI plot — and one for a
density, blue and red, over whatever representation is in force. It is a **shape**, the same
category as the selection halo and the periodic box, so it is torn down and rebuilt with
them and cannot go stale on its own.

The isovalues on the menu are built **from the grid's own largest value**, so every entry on
it draws something. A fixed list is what makes somebody type 0.02 into a density in atomic
units and conclude the file is broken.

The grid travels to the headset with the structure, so IGM there is the same surface that is
on screen here. `sessionStorage` is the carrier, deliberately — nothing is written to disk
and nothing is sent anywhere — so a grid over four megabytes stays behind and the page says
so rather than failing the hand-over.

### Added — the camera lock runs both ways, and has no switch

Coming in was already automatic. Going out is too: leaving 2DWORM-VR by **any** route —
RETURN, the back button, the tab closing, the headset's home button — writes the view down,
and 2D-WORM picks it up. Nothing to press. It is the same neutral record in both directions
— where the middle of the view is, how much of the structure is in frame, and the rotation —
so neither engine has to know anything about the other's camera, and the suite asserts a
full round trip rather than one leg of it.

### Added — MIN PERIODIC: the cell relaxed inside its own surroundings

A unit cell minimised as if it were a molecule contracts, and looks plausible doing it: most
of its atoms are at a surface that does not exist, and the force field pulls them in to
satisfy contacts that in the crystal the next cell along satisfies.

MIN PERIODIC builds those neighbours as atoms and freezes them. The 26 images around the
cell; a seed of the cell's own atoms **plus every image atom within 2 Å of the outside of a
face** — a molecule can sit against the wall without being bonded through it, and a shell
grown along bonds alone would leave it out; then everything within **four bonds** of a seed,
walked over (atom, image) pairs. UFF relaxes the cell's atoms against the frozen shell —
pick atoms first and only those move, which is how you relax a defect, an adsorbate or
hydrogens you have just added. Afterwards the shell is thrown away and anything that drifted
out is brought back by a lattice vector, whole molecules at a time, by CELL FIX.

It is not a periodic force field: the shell does not relax back and the lattice parameters
never change. For a structure from a diffraction experiment that is the right question
anyway — the cell is measured, the hydrogen positions are not.

### Added — three sliders: bond, angle, dihedral

Full width, under the EXPERT bar, each live only when the selection has the right number of
atoms in it — and each saying what it is waiting for rather than disappearing. Bond as a
percentage of the length it had when it was picked (past −100 % it turns through itself,
which is a real thing to want when you are building); angle and dihedral in degrees from
where they were. **UNIFORM / FREEZE A / FREEZE B** decides which side moves, which matters
more than it looks: stretching a bond in the middle of a chain with UNIFORM moves both
halves of the molecule apart.

Every slider is a **delta from a reference**, never a step from where we are. The reference
is taken when the selection is made and each move rebuilds from it, so dragging out and back
lands exactly where it started. Increments would look identical for the first second and
then drift — a hundred small rotations do not compose back to the identity, and the molecule
would end subtly turned with the slider reading zero. One undo for the whole drag.

Two atoms in a ring have no sides: every branch comes back round. The two ends move, the
ring stays, and the readout says `ends only` rather than tearing it or doing nothing
without explaining.

### Added — smaller things from the list

- **A protein opens as a ribbon** with its ligands drawn. Five hundred residues in ball and
  stick is a hairball. Choose a scheme yourself and the page stops choosing, like FAST and
  QUALITY and the periodic box.
- **DUSK** — the WORM palette after sunset, for a darkened room and for a headset, where a
  page of cream fills your whole field of view. Ketcher's own canvas stays light, as it does
  in BLACK: it draws its bonds in black and has no theme to switch.
- **Outline v.slim and vv.slim**, for a figure that will be printed, where a line that looks
  right on screen comes out as a black band.
- **Hide the controls in full screen** — one floating button, or `H`. Offered only in full
  screen, where there is nothing else on the page; `ESC` still leaves, so it cannot strand
  anybody.
- **ANGLE PANNING** now sits next to DRAG ATOM, which is the tool it is a variation of.
- **PT is PT-BR**, because it is Brazilian Portuguese and somebody in Lisbon should be told.

### Fixed

- **Hiding a field destroyed it.** `isHidden` is cell state, not a transform parameter;
  going through the state builder's `update()` rewrites the parameters instead, and an
  isosurface whose parameters have been replaced by an empty object never comes back —
  WebGL refuses it as an empty texture. It looked like a working toggle exactly once.
- **An electron density has no negative lobe.** An isosurface at a level the data never
  reaches is a mesh with no triangles, which is a texture with no pixels, which WebGL
  refuses — and the whole field failed to appear. The grid's own statistics now decide
  whether there is a second lobe to draw.
- **The dihedral slider turned the wrong way.** Rodrigues is right-handed about its axis and
  the atan2 dihedral has a convention of its own; the two are independent, and the sign was
  settled by measurement rather than by argument.
- **Mol\* drew the structure in its own proportions.** Its ball-and-stick defaults to spheres
  a quarter of an ångström across with sticks nearly as fat. The MacMolPlt proportions
  2D-WORM draws in — 0.26 × the van der Waals radius, a 0.13 Å stick — now go across with
  the structure, so it does not change shape when it crosses over.

### Tests

Two new suites: **cube** (24) for the grid, drawn here and carried over, and **geo** (18)
for the sliders, which is mostly arithmetic — a frozen side must not move by a thousandth of
an ångström, and out and back must land exactly where it started. **vr** grew from 56 to 81,
**periodic** from 47 to 58.

## [0.13.0] — build 20 — 2026-09-10

Three tools that did not do what their names said, a caption that changed size when you
turned the molecule, everything a file carries besides coordinates, and the headset controls
built the way the hardware actually allows.

### Fixed — the three drag tools, as D-WORM defines them

They are three **constraints**, not three ways of moving atoms, and only one of the three was
right. What shipped as ANGLE PAN was in fact ALT + DRAG MOLECULES; real angle panning had
never been built; and no tool had an ALT behaviour at all. Ported from `js/builder.js` in the
full D-WORM (`danteo.org/NCI2/worm4`), where they have been used enough to have their edges
worn off:

| Tool | Drag | ALT |
|---|---|---|
| **DRAG ATOM** | follows the mouse in the plane of the screen; bonds stretch | keeps the bond length — the atom moves on the sphere around its only, or its picked, neighbour |
| **ANGLE PANNING** | swings around its pivot **with everything attached**; the bond is frozen and only the 3D angle changes | frees the length |
| **DRAG MOLECULES** | the whole connected fragment follows the mouse | turns the fragment about its own centroid |

Two rules decide what actually moves, and neither is obvious. **The pivot** is a neighbour you
picked if there is one, else the only neighbour, else the heavy neighbour with the largest
branch — so the smaller side moves. **The moving set** is the branch away from the pivot;
when that branch comes back round to the pivot the atom is in a ring, so it falls back to the
atom plus its exocyclic groups and the ring stays put. That is what one selected atom is for:
it names the pivot for the next swing, and the bond to keep for ALT + DRAG ATOM.

A press that *ends where it began* is a pick, not a drag, even if the hand wandered on the
way — the structure is put back first.

### Fixed — a frame that was not square, and a quaternion that was not a rotation

Two bugs, both invisible in a picture and both wrong in the hand.

`dragBasis()` returns the model directions the screen axes correspond to, and under a
perspective camera those two are a fraction of a degree out of square. Every sphere
calculation takes a vector apart with dot products, which inverts a basis only when the basis
is orthonormal — so a bond that was supposed to be **frozen** drifted by about 2 × 10⁻⁴ Å
across a drag. Gram-Schmidt, and it is frozen to 10⁻⁹.

`screenRightInModel()` computed `q*·v·q*` where a rotation is `q*·v·q`. For a unit quaternion
that returns `(1, 0, 0)` **whatever the orientation** — so the function silently gave the same
answer for every view, and it went unnoticed because the answer is right in the orientation a
page opens in. This is half of why labels changed size as a structure was turned.

### Fixed — the captions

The other half: the pixels-per-ångström scale was measured **at each atom**, so under a
perspective camera a nearer atom got a bigger label, and rotating changes which atoms are
near. Now there is **one size for the whole structure**, the camera goes **orthographic**
while labels are on, and rotation cannot change either. Overlapping captions are dropped
front-to-back — the atom nearest the camera keeps its label — because two numbers drawn on
top of each other read as a third number that is not in the structure.

### Fixed — `hidden` meant hidden

`.ptitle { display: flex }` outranks the browser's own `[hidden] { display: none }`, so the
EXTENSIONS row was **visible on every visit** though the script had never switched it on, and
so were several other rows and menus. Fixed once, in one rule, rather than by chasing the
dozen places that set the attribute.

### Added — charges, read from the file and shown as captions

Every population analysis a file contains, under the name its own program used: **CM5,
Hirshfeld, NPA, Löwdin, ESP, CHELPG, APT, Mulliken** from Gaussian, ORCA, xTB, MOPAC and
formatted checkpoints. Nothing is averaged and nothing is renamed — two methods disagreeing by
half an electron is a real fact about them. The menu lists what the file actually held and
opens on the least basis-set-dependent one available. Red for electron-poor, blue for
electron-rich, the convention every ESP map in the literature uses. The sum is printed, which
is the fastest way to notice that the wrong table was read.

### Added — the cell, kept, drawn and written back out

A periodic file used to give up only a **phrase** saying a cell was there; the three vectors
were read and thrown away. Now they are kept, and:

- the **box is drawn** in the 3D view, with a, b and c marked at the origin, and a toggle;
- the cell travels in a **shared link**, so a QR code reproduces the crystal rather than a
  cluster of atoms in vacuum;
- readers for VASP OUTCAR and POSCAR/CONTCAR, CP2K (output and input), Gaussian `TV`, CIF,
  `.gro`, PDB `CRYST1`, XSF and Turbomole `$lattice`;
- **writers** for CIF, POSCAR, `.gro`, Gaussian `.gjf` and xtb/Turbomole `coord`, each of
  which writes the cell whenever there is one. GROMACS will not accept a box whose first
  vector has a y or z component, so `.gro` and PDB are written in the standard setting **and
  the atoms are turned with the cell** — fractions are what is invariant.

One reader, one writer, nothing in between that has to know about the pair: that is what makes
the interconversion seamless rather than a matrix of special cases.

### Changed — the headset controls are geometry now, not HTML

The DOM overlay is **gone**. The Quest browser does not implement it: the feature comes back
NOT GRANTED and the bar is simply not there. Tested on the device. In its place, ported from
the D-WORM Mol* viewer:

- an **in-world menu on the left controller**, held like a phone in the palm — Render, BCK,
  Recentre, Save, Clear, Leave VR — aimed at with the other controller by intersecting its ray
  with the button rectangles directly, because Mol*'s own picking projects onto a plane at the
  molecule's depth and the panel is a metre nearer;
- a **name plate** at the bottom reading **2D-WORM-VR** and the version, which carries no
  action and is not in the list the ray is tested against: it is a sign, not a control;
- **atom selection in VR**, with the distance, angle or dihedral on a card above the top row.
  The card is itself the Clear button;
- labels drawn as **flat quads in a five-by-seven font** rather than Mol* text, which turns
  with the head in a session and cannot be resized by a transform.

### Added — Spanish, Polish, German and Italian

Eight languages now: English, Arabic, Chinese, Portuguese, **Spanish**, **Polish**, **German**
and **Italian**. Every string in every file, and a `//same` line where a word legitimately
comes out identical in a language ("Error" in Spanish) rather than by oversight.

### Tests

`periodic.mjs` is new (27 checks): round trips through every writer, the box, the charge menu,
and what a link is allowed to carry. `edit.mjs` was rewritten for the real drag semantics (64,
was 42) and `vr.mjs` for the in-world menu (56, was 46). **891 checks in 21 suites.**

## [0.12.0] — build 19 — 2026-09-10

The NOTES panel, and the controls that make an immersive session usable.

### Added — NOTES, a third panel

What you meant, travelling with what you drew. A heading, bold, italic, monospace, bullets,
and three blocks — **note**, **warn**, **ok** — whose colour comes from what the text *is*
rather than from a picker, because a colour chosen by hand is unreadable on at least one of
the four themes. The toolbar writes every piece of syntax, so nothing has to be remembered.

**INSERT SELECTION** is the reason to write it here rather than in an e-mail: it drops the
atoms you picked and their measurement in as a chip, and clicking that chip **picks those
atoms again** in whoever's browser is reading it. "The bond I mean is this one" stops being a
sentence anybody has to write.

### Added — a second renderer, and everything it deliberately cannot do

A note is the only text in this program written by one person and drawn in another person's
browser. So it does not go through the renderer that draws the manual — it has its own,
smaller one, and what it leaves out is the point:

- **no raw HTML.** Every character is escaped first; the only tags that appear are ones the
  function wrote itself.
- **no `[text](url)`.** That syntax lets the visible words say one thing while the link goes
  somewhere else, which is the entire mechanism of a phishing link. A bare `https://…` is
  shown as itself **with the host it would really go to**, is not a link, and asks before it
  opens, naming that host. Only `http` and `https` are recognised at all — an allow-list of
  two, not a block-list of the schemes somebody thought of.
- **no images**, so a note can never tell a third-party server who is reading it — and the
  sentence in `TERMS.md` about loading nothing from anywhere else stays true.

`notes.mjs` puts sixteen real techniques through it — a broken tag a parser might repair, an
attribute break-out inside a chip, a `<base>`, a meta refresh — and checks the **DOM that
results**, not the HTML string: `&lt;script&gt;` in a string is reassuring and proves nothing.

A note is capped at 4,000 characters. It travels in a FULL LINK always; whether a *stored*
drawing may carry one is the operator's decision and the default is no, because free text on
somebody else's domain is how a site ends up being used as a link shortener. The SHARE window
says plainly when it has left your note out.

### Added — the in-headset controls for 2DWORM-VR

An immersive session takes over rendering, so the page's own controls are not composited into
the headset — which is why VR was a menu-less room. The WebXR **DOM Overlay** is the way
round it, and the five buttons Dante asked for are on it: **BACKGROUND · RENDER · SAVE VIEW ·
CLEAR · LEAVE VR**. Each one presses the flat page's own control rather than repeating its
logic, so the two cannot disagree and what you set in the headset is still set when you take
it off. Picking two, three or four atoms gives a distance, an angle or a signed dihedral, read
out above the bar.

Four things had to be held down for the length of a session, every one of them learned in the
NCI2 viewer rather than reasoned out here, and all four are now tested:

- **the head rotation is forced to zero**, or Mol\*'s labels come out edge-on and spin as you
  turn your head — its XR path rotates the text quads by the inverse head orientation read in
  the raw reference space, which only agrees with the scene when the camera has no rotation;
- **the camera stops re-fitting itself**, or the molecule jumps back to where it started every
  time a button changes the representation;
- **the button that loses the molecule is disarmed** — the controller's X/A is bound to
  dragFocus, which re-focuses on whatever the ray points at, usually nothing;
- **so is the click that re-fits the camera on empty space.**

All four are put back on the way out. And the structure is now **placed** before the session:
otherwise whatever the flat page happened to be zoomed to is where the molecule turns up —
inside your head, or three metres behind you.

**Still not built:** the menu on the left controller. This is the same five buttons on a
flat overlay rather than following your hand; the in-world version is geometry and its own
text rendering, and it is the remaining piece of the VR spec.

### Tests

`notes.mjs` — 41 checks, most of them hostile input. `vr.mjs` grew from 28 to 46, and `terms.mjs` from 41 to 47.
Suites now total **818**.

## [0.11.0] — build 18 — 2026-09-10

Every limit and every wait is now settable from the admin page, and reading a shared drawing
has a ceiling of its own.

### Added — a Settings section on the admin page

Thirteen settings: the three size limits, the two row limits, the total, the retention period,
the two write rate limits, the two waits, the new read ceiling and read wait, and the counter
switch. Each row shows the shipped default and **where the value in force actually comes
from** — this page, `config.php`, or the default.

**They live in the database, not in `config.php`.** A web page that can rewrite an executable
PHP file turns "somebody got into the admin page" into "somebody runs code on the server". The
consequence you will meet in practice is documented on the page itself: a value saved here
wins over `config.php`, so editing that file afterwards appears to do nothing until the box is
cleared. Saving a value that already equals what `config.php` says stores nothing, so the file
is not silently taken out of the loop for settings nobody changed.

**Five settings are deliberately not there** — `admin_hash`, `db_path`, `geo_csv`, `page_url`
and `short_base`. Anyone who got in could otherwise change the password, point the service at
another database, read a file of their choosing, or send every link anybody shares to a site of
their own. Posting them anyway writes nothing: the form is not the list of what may be changed.

### Added — a ceiling on opens, and a wait that ships off

`read_per_hour` (600) limits how many stored drawings one address may open in an hour, using
the same salted hourly hash the write limiter uses, so no address is stored. `read_wait`
exists and is **0**.

That asymmetry is the point. A wait before *storing* is paid by whoever is filling the
database. A wait before *opening* would be paid by the colleague who was sent the link and by
whoever is scanning a poster with a phone — while the thing it is meant to stop, somebody
walking the key space to copy the store, is not inconvenienced by seconds at all, only by a
ceiling. If it is ever turned on it uses the same signed ticket a large upload does: a
`sleep()` occupies a PHP worker for its whole duration, so a handful of requests would take the
service down more cheaply than the abuse being prevented.

### Added — PRUNE NOW says what it will remove first

Saving a smaller limit changes what is accepted from then on and touches nothing already
stored — a mistyped figure in a number field must not delete somebody's work. PRUNE NOW is the
separate, deliberate press, and it now reports how many entries and how many megabytes it would
drop before it drops them, and the same figures afterwards.

### Added — the page tells you when TERMS.md has stopped being true

Making these settable is exactly the change that lets a privacy policy go stale unnoticed. So
the numbers the policy states are written down in `core.php` as well, and three things are
locked together: the build fails if that table stops matching `TERMS.md`, the build fails if it
stops matching the shipped defaults, and **the admin page warns, naming the sentence, when the
live settings no longer match it**. The first two are checks on us; the third is a warning
rather than a refusal, because it is the operator's service and his policy to edit — but he is
told, in the place where he changed the thing that made it untrue.

### Tests

`settings.mjs` is new — 37 checks. Most of them are about what the page must *not* be able to
do.

## [0.10.0] — build 17 — 2026-09-10

**2DWORM-VR** — the structure you are looking at, in a headset.

### Added — a second page, and a hand-over rather than a rebuild

`2dworm-vr.html` draws the same structure with **Mol\* 5.11.0**, which carries a full WebXR
manager of its own. It is a separate page because Mol\* is 5 MB: putting that behind a button
most visitors never press would be paid for by everybody. It is served from your own server —
never a CDN — so the privacy policy's "the page loads nothing from any host but this one" stays
true; leave the `molstar/` folder out and the page says so instead of showing an empty box.

**VR** in the 3D panel hands the structure over and **RETURN** comes back with 2D-WORM exactly
as it was left — the drawing, the 3D structure, the camera and the selection. One way, by
decision: VR is a way of looking at a structure, not of changing one.

### Added — the camera lock, which is the part with arithmetic in it

The two engines describe a view in completely different terms — 3Dmol keeps a model rotation
quaternion and a camera z, Mol\* a position, a target and an up vector — so nothing is copied
across. What travels is **the view itself, in units both can express**: where the middle of it
is in the structure's own coordinates, how much is visible in ångström, and the rotation. Each
side converts that to its own arithmetic. This is the neutral record the JSmol/3Dmol lock in
the NCI2 viewer settles on, and for the same reason: matching the rotation alone leaves a
sideways offset that swings around as you turn, because each engine picks its own centre and
neither tells the other.

`vr.mjs` asserts it as physical quantities rather than as a screenshot — same axis, same centre
to 10⁻⁵ Å, same framing, same way up — **with the structure rotated as well as square-on**,
because a rotation convention that is wrong is only wrong when there is a rotation.

### Notes for whoever reads this next

Three things cost an hour each and are written down in the build notes: Mol\*'s `Vec3` is a
plain array, and an `{x, y, z}` passed to `camera.setState` is *silently ignored* — a lock that
reports success and did not happen; Mol\* frames the camera on what was just added **on a later
frame**, so the camera has to be set after the plugin says it is idle; and `managers.camera
.reset()` returns to the camera's last committed snapshot, which on this page is the view that
was handed over, so FIT appeared to do nothing until it was made to frame the visible sphere.

The in-headset menu, controller picking and in-world measurements are **not** in this build —
that is the next piece of work, and the NCI2 viewer already has all three to port from.
Suites now total **716**.

## [0.9.0] — build 16 — 2026-09-10

**EXTENSIONS** — the 3D view can now be edited by hand.

### Added — four tools and an undo

A second row under the 3D controls, tinted so that "the mouse means something different now"
is visible without reading anything. It opens on **VIEW**, where nothing is armed.

- **DRAG ATOM** moves the atom you grabbed. **DRAG MOLECULE** moves everything bonded to it —
  the molecule, not the structure, so a solvent molecule can be pushed aside without dragging
  the solute with it. **ANGLE PAN** turns that molecule about its own centre.
- **BOND** — click two atoms for single, double, triple, or to remove the bond between them.
- **UNDO**, forty steps, cleared when a different structure is opened because the atom
  numbers stop meaning the same thing.

Two things that are easy to get wrong and are now tested rather than trusted. **A drag goes
where the pointer goes**, at any zoom and from any angle: the projection is measured through
`modelToScreen` rather than derived from the camera, and the movement applied is the
minimum-norm solution of the 2×3 Jacobian, which is by construction the movement in the plane
of the screen with nothing toward or away from you. **The vertical sign is asserted in pixels**
— drag down 70 px, the atom must end up 70 px lower — because a sign error there looks
perfectly normal in a picture and is unusable in the hand.

**Dragging the background still rotates the structure** with a tool armed: the handlers sit on
the panel in the capture phase and only stop the event when the gesture actually started on an
atom. Escape drops a half-finished bond, Escape again drops the tool.

### Added — the dashed line, which is not a bond

The fourth bond button draws a dashed line and nothing else — a hydrogen bond, a contact, a
"these two are close". It travels in a shared link because it is part of the picture, and it is
**not** exported to any file, **not** counted as connectivity and **never** seen by a force
field. The suite checks all four of those, not just that a line appears.

### Fixed — a removed bond no longer comes back

Bond perception fills in bonds around any atom left with none, and around every metal — which
is exactly the bond somebody is most likely to have wanted gone. An explicit edit now switches
perception off for that structure, so a deleted bond stays deleted.

### Notes

The drawing in Ketcher is never written to, and there is no SEND TO KETCHER. A
three-dimensional arrangement has no single correct two-dimensional drawing, and writing a
guess back would destroy a layout made by hand. The footer says so the first time a tool is
used, and MAKE 3D still replaces the edited structure with a fresh one from the drawing.
An edited structure travels in a shared link as a molfile, with its bonds.

`edit.mjs` is new — 42 checks, every one of them driven through real pointer events at real
screen positions, because the arithmetic that could be wrong is the arithmetic between a pixel
and an ångström. Suites now total **688**. The new interface strings are in all four languages.

## [0.8.1] — build 15 — 2026-09-10

The administrator's page, so that "what is worth keeping" stops being a guess. Nothing in the
application itself changed.

### Added — a map that is actually a map

The circles on **Where the visits come from** used to float on an empty grid. They now sit on
a real coastline: **Natural Earth 1:110m land**, which is *public domain* — no attribution and
no licence to inherit, which is exactly why it is that dataset and not a prettier one. It is
65 rings and about 3 300 points, generated by `2dworm-test/make-coastlines.mjs` into
`QRsharing/lib/coastlines.php`, and no country borders are drawn at all.

Two things that went wrong on the way are now tested rather than remembered. Douglas–Peucker
collapsed every closed ring to two points, because a closed ring's base line is degenerate —
so the thinning is radial. And a landmass that crosses 180° arrives as one ring whose longitude
jumps from +179 to −179, which an equirectangular projection draws as a bar clean across the
Arctic — so the rings are cut at the seam and walked out to the edge. `admin.mjs` now checks
the geometry directly: no single step wider than half the map, four inland places that must
fall on land and three stretches of ocean that must not.

### Added — feature counters, and three new sections that read them

- **What is used** — which parts of the page are actually pressed, all time, as a share of the
  total, and this month beside it. This is the table that answers *what is worth keeping*.
- **Devices and headsets** — the platform, and the headset for anyone who really entered an
  immersive session. A Quest is Android and appears in both; they must never be added together.
- **Per year**, beside the day and month charts, for the question those two cannot answer.
- **How busy can it get before the hosting has to grow?** — which deliberately refuses to print
  a number, and says why: no address and no session is stored, so there is nobody to count, and
  a first visit is 17 MB of static files that never reach PHP at all.

The counting is a batch the page posts every couple of minutes and once more when the tab
closes — never a request per action. `count_usage => false` switches all of it off, and the
endpoint then says `counting: false` and stores nothing.

### Changed — the privacy policy, because the counters changed it

`TERMS.md` said *no analytics*. That is no longer the whole truth, so it has been rewritten
rather than left to rot: what each counter records, that the page batches for two minutes, that
the user-agent string never reaches the database, that the counts are kept rather than pruned,
and — the part that matters — **that the tallies cannot be joined**. There is a count of visits
from a country today, a count of Windows machines today and a count of MAKE 3D presses today,
and nothing relates them; a single row naming all three would be one identifiable person.

`terms.mjs` now pins every one of those sentences to the line of code it describes, so the
policy fails the build before it can go stale. `ADMIN.md` gained the four new sections and
`config.example.php` the settings that had drifted (`small_wait`, and `large_wait` is 60, not
20).

### Tests

`counts.mjs` is new — 25 checks, most of them about what must **not** reach the database. It
reads the tables directly rather than believing the endpoint's reply. Suites now total **645**.

## [0.8.0] — build 14 — 2026-09-10

The list that came back from testing build 13 on a desktop, a tablet and an Android phone,
plus two things that list turned up on the way.

### Fixed — PINK never reached Ketcher, and no theme ever reached its toolbars

Both halves of that report were exactly right, and the cause was the same: the rules that
paint the drawing panel lived in `ketcher-build/src/app.css`, which is **bundled into the built
Ketcher asset**. There was a rule for WORM and one for BLACK, none for PINK, and none for the
toolbars in any theme — so PINK left the canvas white, and WORM changed the paper but not the
tools.

They have been moved out of the bundle and into `index.html`, injected into the frame at run
time. The frame is same-origin, so this was always possible, and it matters beyond the bug: a
colour change used to cost a full rebuild and a re-upload of a **17 MB** bundle, and now costs
one small file. All four themes now paint the canvas, the toolbars, the element palette and
the template strip together — the check counts light-coloured panels left behind in the frame
and fails if there is even one.

### Added — the things that were in the way

- **FAST turns amber while it is actually leaving something out** — a surface, the labels, the
  outline — and goes back to plain when it is not. The footer had been saying so all along and
  it was missed; a control that silently withholds what you asked for should look different
  from one that does not. Amber rather than red: FAST is a compromise, not a danger.
- **"One moment…" with a STOP**, for fetching a structure and for storing a large share. The
  STOP really aborts the request rather than hiding the box, which is the difference between a
  cancel button and a decoration. The footer runs red while it waits and green when it lands —
  and says so in words too, because a red-green pair alone is invisible to a colour-blind
  reader.
- **A full-screen button on each panel.** Not the Fullscreen API — an iPhone allows that only
  for a video — but the header, the footer and the other panel taken out of the way, which
  behaves identically on every device. Escape puts it back.
- **A chain menu for structures that have more than one.** In a complex the thing you are
  looking for is usually behind everything else, and hiding the rest is quicker than rotating
  past it. Offered only when there really is more than one chain: a dropdown with a single
  entry is furniture, not a control.
- **The measurement names residues.** A deposited file names its atoms far better than we can
  — `CA` says something, `C312` says nothing — so the readout now uses the file's own atom
  names and puts the residues in brackets, three-letter, with number and chain:
  `DIHEDRAL −63.5° N – CA – C – N (LEU 249 A, VAL 250 A)`. A drawing has no residues and gets
  no empty brackets.
- **MINIMIZE asks first above 5000 atoms.** It is not refused — UFF has finished 58,870 — but
  it can take minutes, so it is a question rather than a surprise.
- **The QR card names the structure**: title, reference and file, under the code. A fetched
  entry arrives called `1CRN` or a PubChem number, which says nothing once the card has been
  photographed and sent on.
- **Storing takes a moment, and says so.** Ten seconds for an ordinary drawing, a minute for a
  large one, counted down in bold. The wait is enforced by the **server**, with a signed
  ticket, not by the page — the point of it is that one script cannot fill the database faster
  than a person could ever draw. And the share window now says plainly that **a stored link
  expires with demand**: the ones nobody opens are the first to go.

### Added — more ways to draw a structure, and black and white

- **Four ready-made looks** under *More looks* in the same menu as the plain representations —
  publication, technical illustration, neon on black, crystallographic. One menu chooses what
  the panel draws; two could disagree with each other. Choosing one that only works against a
  particular background sets that background with it, unless you have already chosen your own.
- **Black and white, for every representation**, with colour still the default. 3Dmol has no
  greyscale scheme and none of its built-in ones is one, so this is a colouring given outright
  — a map from element to grey chosen by **lightness**, because with the hue gone, value is
  the only thing left to tell oxygen from nitrogen. It colours the **bonds** as well: with
  only the spheres greyed, a C–O stick came out half red, which is the one thing a black and
  white figure must not do.
- The looks that were suggested for this did not run as written, and it is worth recording
  why: `ChainHetatm` for `chainHetatm` (scheme names are case-sensitive, so it silently
  coloured nothing), a `bonded` selector that does not exist in this version, a `white`
  colourscheme that does not exist at all, and `cartoonQuality: 10` — which is already the
  default and changes nothing. The looks here are the same ideas written against the API that
  is actually present.

### Added — partial optimisation, and three more readers

- **MINIMIZE SELECTED** relaxes the atoms you have picked and holds the rest where they are.
  The frozen atoms stay in the terms and in the pair list, so they still push and pull on the
  ones that move — the difference between relaxing a group inside its surroundings and
  relaxing it in vacuum. It is always UFF, whatever the field menu says, because OpenChemLib
  is handed a molfile and has no way to be told which atoms may move. The check asserts the
  frozen atoms do not move by so much as a rounding error.
- **`.cube` / `.cub`, `.fchk` and `.wfn` are read for their geometry**, and for nothing else. A
  cube carries a volume and the other two carry a wavefunction; turning either into something
  to look at is a calculation, and belongs in D-WORM. All three name their nuclei near the
  **top**, so only the first few megabytes are ever fetched — 3Dmol's own cube reader pulled
  the whole volume into memory to reach the same dozen lines. All three are in **bohr**, and a
  cube says which by the **sign** of its voxel count.

## [0.7.4] — build 13 — 2026-09-09

Everything here comes from one session of using build 12 on a desktop, a tablet and an
Android phone. Nothing in it is new capability for its own sake; it is the list of things
that were in the way.

### Fixed — the interface stays where it is

- **Arabic no longer moves the page.** Build 12 turned the whole layout right-to-left, which
  put KETCHER and 3DMOL on opposite sides from where they had just been: every button a
  person had learned jumped somewhere else the moment the language changed, and changing back
  moved them again. Now only the *text* changes. The layout is left-to-right in all four
  languages, Arabic runs right-to-left inside each button, label and paragraph (`unicode-bidi:
  plaintext`, which lets the browser decide per line), and paragraphs of Arabic prose are
  right-aligned. Measured rather than assumed: the two panels are at the same pixel offsets
  before and after the switch.
- This is a deliberate departure from the usual right-to-left convention, and it is the right
  one here. The page is an instrument with two panels and a row of controls, not a document —
  what matters is that the drawing area does not move under your hand.

### Changed — the top row, in the order the work happens

- **KETCHER · 3DMOL · FIND**, then the four languages in the middle, then the background
  colours, then the ID box, then **OPEN · SAVE · SHARE**, and **INFO** by itself at the end.
  FIND sits next to 3DMOL because what it fetches lands there.
- **A fourth background, pink**, alongside white, black and cream.
- **`3DMOL(MACMOLPLT)` is now just `3DMOL`.** MacMolPlt describes the first representation,
  not the panel, so that is where its name now is: *MacMolPlt (ball & stick)* at the top of
  the representation list. Two panels named after two programs was one name too many.
- **CLEAN UP moved to the left of the Tools size box**, and **CLEAR** and **INFO** were given
  room around them. On a phone these sit a few millimetres from buttons that throw work away;
  the space is the safeguard.
- **The QR code's ID is underneath it**, not beside it — that is where a person reads it
  from, and where it stays when the card is photographed.

### Added — four more ways to draw a structure

- **Cartoon**, **cartoon + ligands**, **ball & stick with a solvent-accessible surface**, and
  **surface only** join tubes, wireframe and space filling.
- A cartoon needs a protein backbone. Asked for one on a small molecule the page **draws ball
  and stick and says why**, rather than showing an empty panel: 3Dmol builds its meshes inside
  `render()`, so a representation it cannot construct throws *later* than where it was chosen,
  and an unexplained blank panel was the old result. Any other representation that fails to
  build falls back the same way, and the explanation is **taken back** when a scheme that
  works is chosen.
- A surface is skipped in FAST and above 4000 atoms — with a line saying so — because a
  solvent-accessible surface of a whole protein takes tens of seconds and cannot be
  interrupted.

### Fixed — reading the screen

- **Selected atoms are glass, not paint.** The marker used to be a larger opaque sphere in a
  different colour, so a selected carbon could be mistaken for an element that is not in the
  molecule. Now you see the atom and its own colour straight through the marker, and it is the
  *size* of the marker rather than its colour that says *this one*.
  Making it translucent was not enough on its own, and the reason is worth recording: the halo
  was a second `sphere` **style** on the atom, and 3Dmol merges styles by key — so the second
  sphere did not sit on top of the first, it **replaced** it. The atom vanished inside the
  marker, which is precisely the confusion the marker exists to prevent. The halo is now a
  *shape*, drawn independently of the atom, so the atom keeps its own radius and colour and
  the marker is glass around it. The test now checks both halves: that a marker appeared, and
  that the atom underneath is untouched.
- **Distances, angles and dihedrals read as a measurement**: the word first, then the number
  large and bold, then which atoms it was taken between — `DIHEDRAL  −121.4°  C1 – C2 – C3 – C4`.
  The number is what you write down, so it is the part you can read across a room.
- **Atom labels are 5 % smaller.**
- **On Android, pressing KETCHER or 3DMOL no longer opens the keyboard.** The panel buttons
  now let go of the focus, immediately and again a quarter of a second later, so the browser
  has nothing to bring a keyboard up for. Drawing continues where it left off.

### Fixed — labelling a structure was fifty times slower than it needed to be

- 3Dmol redraws the entire scene for **every label added**, unless the fourth argument of
  `addLabel` says not to. Labelling 300 atoms therefore meant 300 full renders: **113 seconds**
  on a machine without a GPU, a clear stall on a machine with one — and it happened again on
  every zoom, which is what made a labelled structure feel like treacle. The labels are now
  built and the scene drawn once: **113 s → 0.5 s** for the same 300 atoms.
- The test that guards it **counts the redraws**, not the seconds — a stopwatch threshold
  would only fail at random on a slower machine. The same treatment fixed the flakiest check
  in the suite: FAST versus QUALITY is now asserted by what each one actually does (one
  `setStyle` for the whole structure against one per element, and no outline pass) rather
  than by which of two software-rendered timings happened to come out lower.

### Added — the administrator's map has continents

- The world map was circles on an empty rectangle, which is hard to read unless you already
  know where the countries are. Coarse land outlines are now drawn behind them. They are
  deliberately rough — a dozen simplified polygons carried in the file itself, no boundary
  data and no licence to inherit — and no country is coloured in, for the reason the map was
  built this way in the first place: area is what the eye compares, and a large country with
  two visits must not shout louder than a small one with two hundred.

## [0.7.3] — build 12 — 2026-09-09

### Added
- **`QRsharing/set-password.php`** — because there is no default administrator password and
  the first thing a new installation does is refuse to let you in, correctly, with *"No
  administrator password is configured"*. Run `php set-password.php` once in that folder: it
  asks for a password, writes `config.php` with the bcrypt hash, and stops.
  It exists because of a specific trap. **A bcrypt hash is full of `$` characters**, and pasted
  into a double-quoted PHP string they are read as variable names — the hash silently becomes
  rubbish and the login then refuses a password that is correct, with nothing to say why. (That
  is not hypothetical: it cost an afternoon in the test suite.) The helper writes single quotes,
  so it cannot happen.
  It **refuses to run from a browser** — a page that sets the administrator password must not be
  reachable over the web, and the check is on PHP's own SAPI name, which a request cannot
  influence. It refuses to replace an existing password without `--force`, and it keeps every
  other setting already in `config.php`. Delete it afterwards, like `setup-check.php`.
- `ADMIN.md` now says plainly that **you set the password, there isn't one**, and gives the
  by-hand route with the single-quote warning in bold.

## [0.7.2] — build 11 — 2026-09-09

### Added — English, العربية, 中文
- **The interface speaks three languages**, with Arabic turning the whole page right-to-left,
  panels and all. Ketcher's own drawing toolbars stay English — they are a separate program.
- **The dictionary is keyed by the English sentence itself**, not by invented identifiers. That
  one decision is what makes the rest work: a missing translation is never a broken placeholder,
  it is simply English, so a half-finished language is safe to ship from its first line; the
  file a translator receives reads as a list of sentences rather than of key names; and
  `index.html` needs no translation markup at all, which keeps the page small. `lang/en.json` is
  the template; `lang/ar.json` and `lang/zh.json` are first drafts for a native speaker to
  correct and send back — no code is involved.
- Which strings stay in English on purpose — brands, file formats, program names — is **written
  down** in each file rather than left to be guessed at, and the journal citations in the INFO
  window are deliberately never translated, as citations should not be.
- Chemical formulas, element symbols and bond lengths are forced left-to-right, so a formula
  reads the same in Arabic as in English.
- An English visitor downloads no language file at all.

### Added — the administrator's page
- **A world map of where the visits come from**: one circle per country at its real position,
  with the **area** proportional to the count, because area is what the eye compares. A
  proportional-symbol map rather than a coloured-in one, deliberately: filling country shapes
  needs boundary data, every free set of which carries its own licence, and a large country with
  two visits would shout louder than a small one with two hundred. The table underneath gives
  every country with a **count and a percentage**, and is the exact read.
- **Written per day**, split into links *made* (each costs a row) and links *opened* (costs
  nothing), with the average new rows per day and — at that rate — roughly when the small store
  would begin dropping its oldest entries.
- **Each store shows how full it is** as a percentage of its own limit.
- **Add an entry by hand**: paste a full link, give it a name — `toluene`, `lecture` — and it is
  stored permanently under that name. That is how a teaching example gets an ID that still works
  in two years. One row per drawing always, because a takedown blocks by content and two rows
  would mean blocking only one of them.
- The page follows a dark browser, and **`ADMIN.md`** is a full guide: every control, adding and
  removing entries, backups, the kill switch, and a section on keeping unwanted people out with
  the things left to the operator listed in the order they matter.

### Fixed
- **MAKE 3D failed on caffeine — and on anything else Indigo cannot kekulise.** Aromatic bonds
  are handed to Indigo to be given explicit orders before OpenChemLib sees them, and Indigo
  *quietly fails* on caffeine's fused imidazole: it returns the molfile unchanged, type-4 bonds
  intact, raising no error. OpenChemLib's reader cannot use those, so the conformer generator
  died with "Conformer generation failed for fragment 1" — a message pointing nowhere near the
  cause. The result of the call is now checked rather than the call trusted, and it falls back
  to SMILES, which OpenChemLib handles itself. Caffeine is one of the most-used test molecules
  in chemistry and is in the paper's own Table 4.
- **A crystal could be minimised as if it were a molecule, and the result looked fine.** A
  VASP `POSCAR`, `CONTCAR` or `OUTCAR`, a GROMACS box, a crystallographic CIF or a periodic
  CP2K run all describe a *repeating cell*: the atoms at a face are bonded to their own
  periodic images. Neither MMFF94s+ nor UFF implements periodic boundary conditions, so
  minimising one relaxed every surface atom inwards against vacuum and returned a tidy,
  confident, physically meaningless structure — the dangerous kind of wrong, because nothing
  about it looks wrong. MINIMIZE and BEST CONFORMATION now refuse, say exactly why, and point
  to the honest alternative (save as `.xyz` and reopen it, if you really did mean an isolated
  cluster). The status line says so as soon as the file is opened, and the flag travels in a
  shared link so the recipient cannot do what the sender could not.
  What is deliberately **not** blocked: a deposited protein. A `.pdb` carries a `CRYST1`
  record and an mmCIF carries a cell, but those coordinates are whole molecules — 1CRN, 4HHB
  and 1AON minimise exactly as before. A CIF is told apart from an mmCIF by its PDBx tags,
  not by its file name, because FIND fetches large PDB entries as `.cif`.

### Added
- **`2dworm-bench.html`** — the benchmark page. It reproduces the performance tables on
  whatever device you are holding, including a phone, and prints them as markdown ready to
  paste into a manuscript. It **drives the real application** in an iframe through
  `window.dworm2d` rather than re-implementing the conformer generator, the force fields,
  bond perception or the renderer: a benchmark that reimplements what it measures ends up
  measuring the reimplementation. It gives the 3D panel the whole frame (render cost scales
  with the canvas), reports the median of a stated number of runs, separates the worker's
  cold start, and measures **frames per second while rotating** — which is what "still usable
  on a phone" actually means.

## [0.7.1] — build 10 — 2026-09-09

### Added
- **Terms of Use and a Privacy Policy** (`TERMS.md`), reachable from **INFO ▸ TERMS &
  PRIVACY**, from the SHARE window and from the FIND window. Written from the server code
  rather than from memory, so it describes what is actually stored:
  - the row a shared drawing occupies, field by field, and that **nothing in it says who
    stored it** — no name, no address, no session, no fingerprint;
  - how long it lasts: while it is opened, two years since it was last opened, and sooner
    when a store fills — **sharing is not archiving**;
  - that **a stored drawing is public to anyone with the ID**, said plainly, because chemists
    will otherwise paste unpublished work into it;
  - the rate limiter, honestly: it keeps a **one-way hash of the address**, salted with a
    per-installation secret and the current hour, for at most two hours. That is not "no
    address is stored anywhere", which is what the earlier wording would have implied, so it
    is written out instead;
  - the usage counter (day, country, action, count — the address exists only inside the
    request and is discarded; countries under five actions fold into "Other");
  - the two `localStorage` keys, and that no cookie is set for ordinary visitors;
  - **FIND's two outside services**, linked to their own policies;
  - and the hosting company's access log, which is outside the program and does normally hold
    addresses — said rather than glossed over.
- **A takedown route**: send the ID to contact@dworm.org. Removal blocks the **content hash**,
  so re-uploading the same drawing does not bring it back.
- A plain warning that MINIMIZE and BEST CONFORMATION are **empirical force fields, not
  quantum chemistry** — do not cite a 2D-WORM geometry as a result.

### Changed
- **INFO ▸ MORE** is now **INFO ▸ MANUAL**, beside the new TERMS & PRIVACY button; both use one
  document window, and neither file is downloaded until it is asked for.
- `.md` files are served as `text/plain` and compressed, so opening TERMS.md directly shows it
  instead of downloading it.

### Fixed
- **The manual's tables were being shown as paragraphs full of vertical bars.** The little
  markdown renderer had no idea what a table was, so the three tables in MANUAL.md — the file
  formats, the FIND databases, the calculation outputs — arrived as `|---|---|` and rows of
  pipes. They are tables now, and a wide one scrolls inside the window rather than stretching
  it. The same renderer also gained **italics** (`*like this*` was showing its asterisks) and
  **autolinks** (`<https://…>` and `<someone@example.org>` were showing their angle brackets
  and were not clickable) — which is what made the new privacy policy's links to the RCSB and
  NCBI pages dead text until it was fixed.

## [0.7.0] — build 9 — 2026-09-09

### Fixed
- **Every `.pdb` opened in 2D-WORM was silently losing its hydrogens.** 3Dmol's PDB reader
  discards them unless it is asked not to, and a structure without hydrogens looks perfectly
  ordinary — so nothing announced it. MINIMIZE was therefore relaxing the wrong molecule and
  the exported `.xyz` was missing atoms. Every model is now loaded with `keepH`. This turned
  up while investigating why `.pdbqt` files lost their hydrogens; it was never about PDBQT.
- **A texture leak that made the page slow after a few structures.** 3Dmol's
  `removeAllLabels()` takes label sprites out of the scene but never disposes them — only
  `removeLabel()`, one at a time, frees the canvas texture behind each. Labels are rebuilt
  whenever the zoom changes so they keep their size relative to the atoms, so **with labels
  switched on, rotating a structure abandoned one GPU texture per atom per frame**: seconds
  of dragging a 300-atom molecule leaked tens of thousands of them. No JavaScript heap
  profiler shows this, because a texture is not in the JavaScript heap. Labels are now
  disposed before being let go, and they are only rebuilt when the zoom has changed by more
  than 4 % — rotating alone no longer rebuilds anything.
  (The measured JavaScript heap, for the record, was already flat: twelve 2000-atom
  structures dropped one after another moved it by 0.0 MB.)

### Added
- **Click an atom to select it.** Selected atoms get a magenta halo over whatever style is
  in force, so they stand out in ball-and-stick, wireframe and space filling alike. Click
  again to let one go. Two selected atoms show the **distance**, three the **angle**, four
  the **torsion**. **The selection travels inside a shared link and QR code**, so "this one,
  and this one" survives being sent to somebody else — they see the same halos and are told
  how many you highlighted.
- **Every format 3Dmol can read is now wired to OPEN**: CIF and mmCIF, `.mol2`, `.pqr`,
  `.pdbqt`, Gaussian `.cube` (its atoms), `.lammpstrj`, Amber `.prmtop`, ChemDoodle JSON,
  and the binary MMTF and BinaryCIF. A PDBQT has AutoDock atom types where the element
  belongs, so those columns are stripped first. A binary file is re-expressed as PDB after
  loading, because it cannot travel inside a link. A `.prmtop` with no coordinates says so
  instead of showing an empty panel.

- **FIND: search a public database by name and bring the structure in.** The **RCSB PDB** for
  proteins, DNA and RNA; **PubChem** for small molecules. Type *aspirin* or *haemoglobin* and
  click a result; a PDB identifier (`1CRN`) or a CID (`2244`) on its own goes straight to that
  entry. A small molecule arrives in the drawing as well as in the 3D view, and if PubChem has
  no computed conformer for it, only the drawing is filled in and MAKE 3D does the rest. An
  entry published only as mmCIF is fetched as mmCIF. Both databases answer the browser
  directly, so nothing passes through dworm.org.
  Only these two sources are offered, and deliberately so: the contents of both are in the
  public domain, so there is no attribution or redistribution condition to carry.
- **A fetched structure is shared by identifier, never by copying it.** The link — and the
  server's row behind a SHORT LINK — carries `rcsb:1CRN`, and whoever opens it fetches the
  entry themselves. A whole protein therefore costs about twelve characters instead of
  hundreds of kilobytes, no third party's data is ever written into the sharing database, and
  the recipient sees the current revision rather than a copy frozen on the day the link was
  made. They must be online, and if the database cannot be reached the page says exactly that
  instead of showing an empty panel. **The identifier is dropped the instant the structure
  changes** — MINIMIZE, a conformer search, MAKE 3D, another file — because a changed
  structure is the user's own work; from then on the coordinates travel in the link as before.
  This is enforced in one place: `show3d()` clears the provenance unless it is handed one.
- **What a search sends, said where it can be seen**: the FIND window, the manual, the INFO
  window and `NOTICE` all now state that a search sends the words typed and the visitor's
  network address to the RCSB PDB or the NCBI, and that this is the only request 2D-WORM makes
  to any host other than the one serving the page. The manual previously promised, without
  qualification, that nothing left the browser.

### The sharing service, rebuilt
- **Three stores.** Small (≤ 20 kB, 100 000 entries), large (to 500 kB, 2 000 entries) and a
  **permanent** one that is never pruned. An entry is promoted to permanent from the admin
  page; nothing lands there by itself.
- **The wait on a large drawing is enforced by the server, not the browser.** The first
  attempt is answered with a ticket signed over the drawing's fingerprint and the time; only
  a ticket old enough, and belonging to that exact drawing, is accepted. Nothing is stored
  while you wait, and no PHP process is held open for twenty seconds.
- **Pictures are re-encoded before sharing**, in the browser. A pasted photograph is what
  turns a 3 kB share into a 3 MB one. The copy in Ketcher is untouched — only the copy
  inside the link is smaller, and the dialog says how much was saved. The server never
  decodes a payload, so it still has no idea what a drawing contains.
- **Admin page behind two locks.** It answers 404 unless `.admin-enabled` exists next to it,
  so for most of the year the door is not locked, it is not there. The password is verified
  server-side against a bcrypt hash in `config.php`, never appears in the page, and failed
  attempts shut the door for the hour. Every action carries a CSRF token. Drawings are
  opened in the app in a new tab, never rendered inside the page that holds the session.
- **Blocking, not just deleting**: a takedown remembers the drawing's fingerprint, so
  uploading the same thing again does not bring it back.
- **Usage counters and a map by country.** The address is turned into a country in memory
  and discarded in the same breath; what is written is one row per day, country and action
  with a count. Nothing below five, and nothing unrecognised, is ever displayed separately.
  The country table is built from a CSV you supply — see `QRsharing/geo/README.md` for a
  free one and what its licence asks.
- **Backup** (a consistent snapshot through `VACUUM INTO`, not a copy that misses the
  write-ahead log), a **kill switch** with a reason the page shows, and an **announcement
  banner**.

## [0.6.0] — build 8 — 2026-09-09

### Added
- **Opening a finished calculation.** Drop an output on the page and the structure appears:
  **ORCA**, **Gaussian**, **CP2K**, **MOPAC**, **xTB** and **VASP** outputs, their input
  files, plus **GROMACS `.gro`** and **VASP `POSCAR`/`CONTCAR`** (both read by 3Dmol itself).
  **Geometry only — the last one in the file.** No energies, no optimisation trajectory, no
  frequencies, no orbitals; those stay in the full D-WORM, and they are what makes an output
  reader grow without limit.
  - The program is detected from the **content**, not the extension: `.out` and `.log` are
    used by half of computational chemistry.
  - **Units are converted.** xTB and Turbomole `coord` files are in bohr; read as angstrom
    they would give a molecule half its true size and look entirely plausible. ORCA's
    `CARTESIAN COORDINATES (A.U.)` block is skipped for the same reason, and CP2K's
    `UNIT bohr` is honoured.
  - Gaussian's atomic numbers become symbols, and ghost centres (Z = 0) are dropped. VASP's
    elements are rebuilt from the `POTCAR` lines and `ions per type`; if they are missing the
    status line says every atom is being shown as carbon rather than pretending.
  - A **Gaussian Z-matrix is refused, not misread** — a cartesian reader would take the bond
    length and angle as y and z and produce a plausible, completely wrong structure. (The
    test suite caught exactly that.)
  - A CP2K optimisation says where the optimised geometry really is (`-pos-1.xyz` or the
    `.restart` file), rather than quietly handing back the starting structure.
  - `lib/qcgeom.js` is **fetched only when such a file is opened**, so a first visit is
    unchanged. A very large output is read from the end first.

## [0.5.1] — build 7 — 2026-09-09

### Fixed
- **A new page could run an old worker, and it looked exactly like a bug in the new build.**
  `.htaccess` cached every `.js` for seven days while `index.html` was never cached, so after
  an upload the browser paired build 6's page with build 5's `lib/mol3d-worker.js`. Choosing
  UFF then still ran MMFF94s+ — which reported *"Class$S184: Couldn't assign an atom type to
  atom 1 (Ni)"* under a label saying UFF. Three changes so it cannot recur:
  - **Only `ketcher/assets/` is cached hard.** Those file names carry a content hash, so a
    new build never reuses one. Everything else — `index.html`, `lib/*.js`, `*.json` — now
    revalidates. A 304 is one small round trip and it is always right.
  - **The worker URL carries the build**: `lib/mol3d-worker.js?v=0.5.1.7`, and the worker
    passes the same stamp to its own import of `uff.js`. This works even where a host
    ignores `.htaccess`. (Note a query on `index.html` does *not* help — it is the worker
    that goes stale, and it has its own URL.)
  - **The worker announces its build on startup** and the page says so plainly if the two
    disagree, instead of failing in a way that looks chemical.
- **A failed minimisation now names the force field that actually ran**, not the one that was
  asked for. After an `auto` fallback those differ, and the wrong label sent a real bug report
  in the wrong direction.

### Added
- When UFF has no type for an atom's actual coordination, the status line says which one it
  used instead — for example *"Ni: 2-coordinate, but UFF only offers Ni4+2 (90 deg)"*. UFF has
  one nickel type and it is square planar; you should know that shaped your coordinates.

## [0.5.0] — build 6 — 2026-09-09

### Added
- **UFF, the Universal Force Field** (`lib/uff.js`) — the complete Table 1 of the paper:
  **127 atom types covering all 103 elements, hydrogen through lawrencium**, and every
  energy term (bond, angle, torsion, inversion, van der Waals) with analytic gradients and
  an L-BFGS minimiser. It works straight on coordinates, so MINIMIZE now handles
  **transition-metal complexes, lanthanides and actinides** and has **no 999-atom limit**:
  a protein is relaxed in place, keeping its residue names, chains and `CONECT` records.
  Written from Rappé *et al.*, *J. Am. Chem. Soc.* **1992**, *114*, 10024, and licensed
  AGPL-3.0 with the rest of the project. No code or parameter file was taken from Open
  Babel, whose UFF is GPL-2-**only** and therefore incompatible with AGPL-3.0.
- **UFF is cross-validated against an independent implementation.** `2dworm-test/uff-cross.mjs`
  compares energies and minimised bond lengths against RDKit's UFF (BSD-3) for every element
  RDKit can type; the reference numbers were measured, not copied. Bond lengths agree on
  85 of 86 systems and energies on 73 of 86, with all thirteen differences documented and
  explained in the test — they are chemically impossible test geometries (six ligands on a
  halogen) or places where our typing reads the coordinates and RDKit's does not.
  The cross-check found three real errors, since fixed: the effective charge of **Bi, Po
  and At**, and a minimiser that could step two bonded atoms straight through each other.
- **Force-field menu**: `auto` (default) uses MMFF94s+ where it applies and falls back to
  UFF where it does not, saying which one ran and why; MMFF94s+ and UFF can also be chosen
  by hand. Energies from the two are never compared — they are on different scales.
- **BEST CONFORMATION explains itself** instead of failing. A conformer search rebuilds the
  molecule from a torsion library that covers ordinary organic chemistry only, so it now
  refuses immediately — naming the element, the size, or UFF as the reason — and points at
  MINIMIZE. It no longer runs ten conformers before giving up.
- **FAST / QUALITY toggle** for the 3D view. FAST drops the four measurable costs: atom
  labels (one sprite per atom, redrawn on every camera movement — by far the worst), the
  outline (a second render pass), the per-element style calls, and the extra cylinders for
  double and triple bonds. Above 1200 atoms the view opens in FAST by itself and says so.
  Labels are capped at 400 atoms in both modes. **Exported images are always full quality.**
- **CLEAR button** on the 3D panel: empties the 3D view and leaves the drawing alone.
- **Bonds to metals are found properly**, using published covalent radii (Cordero *et al.*,
  *Dalton Trans.* 2008). 3Dmol's own perception stops at the common organic elements, so a
  complex dropped in as `.xyz` used to arrive with its metal floating free of its ligands —
  and a force field then had nothing to hold the geometry together.
- OpenChemLib's internal class names (`Class$S66: …`) no longer leak into the status line.

## [0.4.1] — build 5 — 2026-09-09

### Fixed
- **A structure dropped into the 3D panel disappeared when MINIMIZE was pressed.** The 3D
  structure was always converted to a molfile V2000 first, and that format cannot hold more
  than 999 atoms: its count fields are three characters wide. Anything larger produced a file
  whose header was silently wrong, and the minimiser then read a fragment of it. Structures
  are now kept in the format they arrived in — a dropped PDB stays a PDB — and a V2000 copy
  is made only when one is possible.
- **A shared link or QR code of a large structure opened empty on the other device**, for the
  same reason: the broken molfile was what the link carried. Links now carry the structure in
  its own format. A 1200-atom protein compresses to about 13 kB, well inside the short-link
  limit. Older links keep working.
- **MINIMIZE and BEST CONFORMATION refuse politely** when a structure is too large for the
  force field, or unreadable, instead of clearing the view. The structure stays on screen and
  the status line says what happened.
- **The remembered background was only half applied on loading.** The page painted itself
  black or cream, while the buttons and the 3D view stayed on white.
- **A drawing containing a pasted picture or a query atom put a red "Convert error" across
  the page** every time it changed: the check for "has the drawing changed" asked Ketcher for
  a SMILES, which cannot describe either. It now uses a fingerprint that always works.
- A missing `ketcher/` folder now explains itself instead of showing the web server's own
  "404 Not Found" inside the drawing panel.

### Added
- **MINIMIZE and BEST CONFORMATION work on a structure dropped into the 3D panel**, leaving
  the drawing in Ketcher untouched — two different structures at once. Where bond orders had
  to be guessed from the geometry (`.xyz`, `.pdb`), the status line says so.
- `.xyz` and `.pdb` are written from what the viewer holds, so structures of any size can be
  exported.
- A shared link carries the sender's background as well, so the recipient sees the same view.
- A short link that would be too large is stored without the 3D coordinates rather than
  refused; the drawing is complete and MAKE 3D rebuilds the rest.

## [0.4.0] — build 4 — 2026-09-08

### Added
- **BEST CONFORMATION**: generates several conformers, minimises each and keeps the one with
  the lowest energy.
- **KILL**: while a 3D calculation runs its button turns red and stops the work immediately.
- **WORM theme**: a third background, desert cream, next to WHITE and BLACK. One switch now
  sets the page, the Ketcher canvas and the 3D view together.
- **Sticky RMB / ALT / CTRL / SHIFT buttons** so tablets and phones can reach the Ketcher
  tools that need a keyboard or a right click.
- **Toolbar size selector** (100–175 %) for large tablets; a larger size is chosen
  automatically on touch screens.
- **ID field with GO** in the header: open a shared structure by typing the code printed
  under its QR image.
- Share dialog shows the structure **ID** and the **size** under the QR code, with a
  **2D-WORM** heading above it, and has a **WeChat** button.
- `MANUAL.md`, shown by INFO ▸ MORE, replacing the developer README.
- Repository files: `LICENSE` (AGPL-3.0), `NOTICE`, `SECURITY.md`, `CHANGELOG.md`,
  `CITATION.cff`, `.gitignore`.

### Changed
- **The 3D view no longer updates by itself.** Building a structure is always an explicit
  MAKE 3D, and the calculation runs in a Web Worker, so a big molecule can never freeze the
  page. The `auto` checkbox is gone.
- INFO now lists the licence, the GitHub repository, the Ketcher manual and the papers to
  cite for 3Dmol.js and MacMolPlt.
- The share dialog no longer mentions how much the server keeps; it says stored drawings may
  be replaced by newer ones.
- Ketcher is frozen at 3.18.0 (Indigo 1.46.0) and the version is stated in INFO.

### Fixed
- The BLACK theme now inverts the drawing canvas properly: black paper, white bonds,
  element colours preserved.

## [0.3.0] — build 3 — 2026-09-07

### Added
- `QRsharing`: optional PHP + SQLite service giving short links and small QR codes.
- INFO window with version, contact and acknowledgements.
- Atom labels scale with the zoom; own van-der-Waals table so metals are drawn at their
  real size.

### Changed
- 3D panel renamed 3DMOL(MACMOLPLT).

## [0.2.0] — build 2 — 2026-09-07

### Added
- WHITE / BLACK page background.
- Outline thickness selector for the 3D view.

### Changed
- Ketcher's ring and template tools moved to a vertical column on the right.
- Links are shorter (deflate + base64url) and survive being wrapped by e-mail programs.

### Fixed
- The 3D view no longer stops following the drawing after a shared link is opened.

## [0.1.0] — build 1 — 2026-09-06

First working version: Ketcher drawing, 3D structure generation and viewing, ChemDraw
import and export, publication images, self-contained share links and QR codes.
