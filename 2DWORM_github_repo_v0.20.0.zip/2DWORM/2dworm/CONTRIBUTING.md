# Contributing to D-WORM

Thank you for wanting to help. D-WORM (2D-WORM, D-WORM, WORM-PC, 3D-WORM) is built so that
people **without a licence for commercial chemistry software** can still draw, view and prepare
structures. Anything that makes it work better for them is welcome.

**Contact:** contact@dworm.org · **Website:** https://dworm.org

---

## The most useful things you can send

You do not need to write code to help. In rough order of usefulness:

1. **Bug reports** — especially anything that breaks with a real file.
2. **Test files** — Gaussian, ORCA, MOPAC, xTB outputs, PDB/mmCIF/CDX files that do not open
   correctly, or that open but look wrong. Files from unusual programs and versions are gold.
3. **Feature requests** grounded in a real task ("I need X because I do Y every week").
4. **Documentation fixes** — wrong or unclear wording, missing steps.
5. **Code** — see the section below first.

---

## Reporting a bug

Please include:

- **What you did**, step by step, and what you expected instead.
- **The version**: open **INFO** in the program and copy the version and build number.
- **Your browser and system**: e.g. "Chrome 141 on Windows 11", "Safari on iPad".
- **The file**, if one is involved. If it is confidential, a small anonymised example that
  still shows the problem is just as good.
- For the web pages: anything red in the browser console (F12 → Console) helps a lot.

Report it as a GitHub issue if you have an account, or by e-mail to contact@dworm.org.

**Do not report security or privacy problems publicly.** Send them straight to
contact@dworm.org and give me a reasonable time to fix them before disclosure.

---

## Contributing code

**Current policy: code contributions are accepted by prior arrangement.** Please write to
contact@dworm.org (or open an issue) describing what you would like to change *before* you
start work. This saves you from writing something that does not fit, and lets us settle the
paperwork below in advance.

### The CLA

Anyone contributing code, documentation or other material must accept the
**[Contributor License Agreement](CLA.md)** once.

In plain words: **you keep the copyright in your work**, and you stay free to use it however
you like. You give this project permission to distribute it — including the permission to
offer a commercial licence to companies. That last point is what pays for continued
development, so it is not optional. It is the same arrangement used by many
open-source projects that are funded this way.

If you are employed, or your work was done using an employer's or university's equipment or
time, your employer may legally own it. In that case a **Corporate CLA** is also needed — write
to contact@dworm.org and we will sort it out.

Accepting the CLA is a single comment on your pull request:

> I have read the D-WORM Contributor License Agreement and I agree to it.

### Licence of contributions

Contributions are distributed as part of the project under the **GNU Affero General Public
License v3.0 or later**. Add nothing under a licence that conflicts with this.

---

## Technical ground rules

These keep the project small, self-contained and legally clean.

- **No external CDNs or online services at runtime.** Every page must work from a plain folder
  on a plain web server, with no network calls except to the project's own optional PHP
  service. Vendor new libraries into `lib/` with their licence file.
- **Dependencies must be permissive** — MIT, BSD or Apache-2.0. **Never** paste GPL-licensed
  code into the web pages or into the project's own source files; call GPL programs as separate
  processes instead. If you are unsure about a library's licence, ask before adding it.
- **Identify third-party material.** If a piece of your contribution comes from somewhere else,
  say so, name the source and the licence, and keep it in its own file.
- **Keep it small.** The pages are meant to load quickly on a modest connection. A new feature
  that adds megabytes needs a good reason, or must load on demand.
- **Do not remove or hide the INFO screen, the copyright notices or the acknowledgements.**
  Besides being unfair to the people credited there, they are required by the AGPL.
- **Privacy:** the software does not collect personal data, and must not start. No analytics,
  no third-party trackers, no IP addresses in logs beyond what the web server does by itself.
- **Tests:** the Playwright suite in `2dworm-test/` must pass before and after your change. Add
  a check for whatever you fixed or added — it is the only way a bug stays fixed.
- **Style:** match the file you are editing. Comments explain *why*, not *what*.

---

## The name

The code is free to copy and modify under the AGPL, but **"D-WORM", "DESERT WORM", "2D-WORM"
and the WORM logo are trademarks of the project owner**. A modified version distributed to
others must use a different name and must not suggest endorsement. See `TRADEMARK.md`.
This restriction applies to the name only, never to the code.

---

## Credit and authorship

Everyone who helps is credited. The only question is where, and this section says so in
advance, so that nobody has to guess and nobody is surprised. If you would rather not be
named anywhere, say so and you will not be.

There are three levels. They are about the **kind** of involvement, not about how clever or
welcome the help was.

### 1. Authors — cited whenever the software is cited

Listed in `CITATION.cff`, on the software paper, and in the program's INFO screen.

You are an author if your involvement is **sustained** and you carry **responsibility for a
part of the software**: you wrote a substantial component, or you shaped its design over time,
you keep it working, and you could explain and defend that part to a reviewer.

Volume of code is a weak signal. Someone who persuaded the project to change how a whole tool
behaves has contributed more than someone who fixed forty typos.

### 2. Contributors — listed in `AUTHORS` and in the release notes

Real, identifiable work that is nevertheless bounded: a file-format reader, a feature, a
translation, a documentation chapter, a set of tests, or sustained testing that changed how
something was built.

### 3. Acknowledgements — listed in the README and in the paper's acknowledgements

A bug report, a few test files, a good suggestion, help with wording — together with
institutions and funders.

### How the levels are recorded

`AUTHORS` names people with their roles, using the wording of the
[CRediT taxonomy](https://credit.niso.org) where it fits (Conceptualization, Software,
Validation, Data curation, Writing, Supervision, Funding acquisition). Roles describe what
someone did rather than ranking them:

```
Theo P. Goncalves  — conceptualization, software, design, maintenance
<Name>             — software (ORCA and MOPAC parsers), validation
<Name>             — validation, data curation (test files), documentation review
```

Two practical notes:

- **The `AUTHORS` file and the paper's author list do not have to match, and usually do not.**
  The repository can be generous, because listing someone there takes nothing away from anyone.
  A journal asks for *significant* contributions to the software; smaller help belongs in the
  acknowledgements.
- **Small contributions are recognised often rather than formally.** Every release note names
  the people who reported or fixed something in that release. For most people that is worth
  more than a line in a file they will never open.

### If you are unsure which level applies to you

Ask. Before you start, ideally. The level will be agreed with you openly, and where the paper
is concerned, so will the author order — normally the lead author first and the rest by
contribution. Being told early is what keeps this comfortable for everybody.

---

## Citing D-WORM

If the software was useful in work you publish, please cite it — see `CITATION.cff` or the
"How to cite" entry in the INFO screen. Citations are what keep this project alive and funded.
