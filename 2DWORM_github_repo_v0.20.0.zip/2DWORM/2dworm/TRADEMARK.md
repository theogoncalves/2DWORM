# Trademark policy

The software in this repository is free to use, copy and modify under the GNU Affero
General Public License v3.0. **The names and the logo are not covered by that licence.**

"2D-WORM", "D-WORM", "DESERT WORM", "3D-WORM" and the WORM logo are trademarks of
Theo P. Goncalves.

## What you may do without asking

- Use the software, privately or publicly, under the terms of the AGPL.
- Say truthfully that your work uses, is based on, or is compatible with 2D-WORM.
- Cite the software, quote its name in papers, talks, teaching material and documentation.
- Keep the names in place when you distribute the software unchanged.

## What needs permission

- Distributing a **modified** version under the name 2D-WORM or D-WORM. Please rename it,
  so that users know whose work they are running and where to send bug reports.
- Using the names or the logo in the name of your own product, service or company, in your
  own logo, or in any way that suggests this project endorses you.
- Registering a domain, an account or a package name that could be mistaken for an official one.

Permission is usually easy to get: write to **contact@dworm.org**.

This restriction applies to the names only, never to the code. Renaming your fork satisfies it.
