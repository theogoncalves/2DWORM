// Replaces ketcher-core/dist/application/editor/data/monomers.modern.js (a ~4 MB embedded JSON string
// holding the macromolecule monomer library). The macromolecules editor is disabled in this build
// (disableMacromoleculesEditor), so an empty library is sufficient and saves ~4 MB of JS.
// Build with KETCHER_FULL_MONOMERS=1 to keep the original library.
const monomersDataRaw = '{"root":{"nodes":[],"connections":[],"templates":[]}}';
export default monomersDataRaw;
