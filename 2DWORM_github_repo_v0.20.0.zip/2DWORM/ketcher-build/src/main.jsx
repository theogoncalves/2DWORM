import React from 'react';
import { createRoot } from 'react-dom/client';
import { Editor } from 'ketcher-react';
import { StandaloneStructServiceProvider } from 'ketcher-standalone/dist/binaryWasm';
import 'ketcher-react/dist/index.css';
import './app.css';
import { setModifier } from './sticky-modifiers';

// StandaloneStructServiceProvider = Indigo compiled to WASM, running in a Web Worker.
// The 'binaryWasm' entry keeps the .wasm as a separate file (the default entry inlines it as base64).
const structServiceProvider = new StandaloneStructServiceProvider();

const CHANGE_THROTTLE_MS = 300;

function postToParent(msg) {
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage(msg, '*');
    }
  } catch (e) {
    console.warn('[2dworm-ketcher] postMessage failed', e);
  }
}

// Throttled (leading + trailing edge) notifier for editor changes.
function makeChangeNotifier() {
  let lastSent = 0;
  let timer = null;
  const send = () => {
    lastSent = Date.now();
    timer = null;
    postToParent({ type: '2dworm-ketcher-change' });
  };
  return () => {
    const elapsed = Date.now() - lastSent;
    if (elapsed >= CHANGE_THROTTLE_MS) {
      send();
    } else if (!timer) {
      timer = setTimeout(send, CHANGE_THROTTLE_MS - elapsed);
    }
  };
}

const state = { ketcher: null, editor: null, subscriber: null, readySent: false };

/* The parent page drives the look and the sticky modifier keys from outside the iframe. */
window.addEventListener('message', (ev) => {
  const d = ev.data;
  if (!d || typeof d !== 'object') return;
  if (d.type === '2dworm-set-theme') {
    const t = String(d.theme || 'white');
    if (t === 'white') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', t);
  } else if (d.type === '2dworm-set-uiscale') {
    const s = String(d.scale || '100');
    if (s === '100') document.documentElement.removeAttribute('data-uiscale');
    else document.documentElement.setAttribute('data-uiscale', s);
  } else if (d.type === '2dworm-set-modifier') {
    setModifier(d.name, d.on);
  }
});

// NOTE: ketcher-react 3.18 calls onInit twice for the same Ketcher/editor instance
// (its init effect runs twice). Keep this idempotent: subscribe once per editor, post 'ready' once.
function onInit(ketcher) {
  window.ketcher = ketcher;
  state.ketcher = ketcher;

  const loading = document.getElementById('loading');
  if (loading) loading.remove();

  const editor = ketcher.editor;
  if (state.editor !== editor) {
    if (state.editor && state.subscriber) {
      // editor.unsubscribe() takes the subscriber object returned by subscribe(), not the handler.
      try { state.editor.unsubscribe('change', state.subscriber); } catch (e) { /* ignore */ }
    }
    state.editor = editor;
    state.subscriber = editor.subscribe('change', makeChangeNotifier());
  }

  if (!state.readySent) {
    state.readySent = true;
    postToParent({ type: '2dworm-ketcher-ready' });
  }
}

function App() {
  return (
    <Editor
      staticResourcesUrl="./"
      structServiceProvider={structServiceProvider}
      errorHandler={(message) => {
        console.error('[2dworm-ketcher] error:', message);
        postToParent({ type: '2dworm-ketcher-error', message: String(message) });
      }}
      onInit={onInit}
      disableMacromoleculesEditor={true}
    />
  );
}

createRoot(document.getElementById('root')).render(<App />);
