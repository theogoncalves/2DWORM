/**
 * 2D-WORM — sticky modifier keys for touch devices (build 4).
 *
 * A tablet or a phone has no ALT, CTRL, SHIFT or right mouse button, but several
 * Ketcher tools need them. The parent page shows four buttons; when one is on, this
 * module makes every event inside the editor *look* as if that key were held down.
 *
 * It works by wrapping the property getters on the event prototypes rather than by
 * re-dispatching synthetic events, so Ketcher's own listeners see the modified value
 * with no change to event ordering, and nothing has to be simulated.
 *
 * PointerEvent inherits from MouseEvent, so patching MouseEvent covers pen and touch too.
 */

const sticky = { ctrl: false, alt: false, shift: false, rmb: false };

function patch(proto, prop, override) {
  let desc = null;
  for (let p = proto; p && !desc; p = Object.getPrototypeOf(p)) {
    desc = Object.getOwnPropertyDescriptor(p, prop);
  }
  if (!desc || typeof desc.get !== 'function') return;
  const original = desc.get;
  Object.defineProperty(proto, prop, {
    configurable: true,
    enumerable: desc.enumerable,
    get() { return override(original.call(this), this); },
  });
}

function install() {
  for (const [prop, key] of [['ctrlKey', 'ctrl'], ['altKey', 'alt'], ['shiftKey', 'shift']]) {
    patch(MouseEvent.prototype, prop, (real) => real || sticky[key]);
    patch(KeyboardEvent.prototype, prop, (real) => real || sticky[key]);
    if (typeof WheelEvent !== 'undefined') patch(WheelEvent.prototype, prop, (real) => real || sticky[key]);
  }
  // Right mouse button: report button 2 / buttons bit 2 while RMB is armed.
  patch(MouseEvent.prototype, 'button', (real) => (sticky.rmb && real === 0 ? 2 : real));
  patch(MouseEvent.prototype, 'buttons', (real) => (sticky.rmb && real === 1 ? 2 : real));

  // RMB is one-shot: it releases itself after the click it was armed for, because a
  // permanently held right button would make ordinary drawing impossible.
  window.addEventListener('pointerup', () => {
    if (sticky.rmb) { sticky.rmb = false; report(); }
  }, true);

  // Keep the browser's own context menu out of the way while RMB is armed.
  window.addEventListener('contextmenu', (e) => { if (sticky.rmb) e.preventDefault(); }, true);
}

function report() {
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: '2dworm-modifiers', state: { ...sticky } }, '*');
    }
  } catch (e) { /* ignore */ }
}

/** Called by the parent page: set one modifier, or clear them all. */
export function setModifier(name, on) {
  if (name === 'clear') {
    sticky.ctrl = sticky.alt = sticky.shift = sticky.rmb = false;
  } else if (name in sticky) {
    sticky[name] = !!on;
  }
  report();
}

export function getModifiers() {
  return { ...sticky };
}

install();
window.dworm2dModifiers = { set: setModifier, get: getModifiers };
