import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Set KETCHER_FULL_MONOMERS=1 to keep the full (~4 MB) macromolecule monomer library in the bundle.
const keepFullMonomers = process.env.KETCHER_FULL_MONOMERS === '1';

// Replace ketcher-core's embedded ~4 MB monomer library (only used by the macromolecules editor,
// which this build disables) with an empty library. Saves ~4 MB of JS on first load.
function stubMonomersLibrary() {
  const stub = path.resolve(__dirname, 'src/empty-monomers-library.js');
  return {
    name: 'stub-ketcher-monomers-library',
    enforce: 'pre',
    resolveId(source, importer) {
      if (keepFullMonomers) return null;
      if (importer && importer.includes('ketcher-core') && /data\/monomers(\.modern)?\.js$/.test(source)) {
        return stub;
      }
      return null;
    },
  };
}

// ketcher-core's ESM build contains a bare CommonJS `require('raphael')` (raphael-ext.modern.js),
// which Rollup leaves as-is and which then fails in the browser ("require is not defined").
// Rewrite it into a real ESM import so the UMD raphael package gets bundled.
function fixKetcherCoreRaphaelRequire() {
  return {
    name: 'fix-ketcher-core-raphael-require',
    enforce: 'pre',
    transform(code, id) {
      if (id.includes('ketcher-core') && code.includes("require('raphael')")) {
        return {
          code: "import __raphaelCjs from 'raphael';\n" +
            code.replace("typeof window !== 'undefined' ? require('raphael') : undefined", '__raphaelCjs'),
          map: null,
        };
      }
      return null;
    },
  };
}

// Build a self-contained Ketcher page that works from any subfolder over http.
export default defineConfig({
  plugins: [stubMonomersLibrary(), fixKetcherCoreRaphaelRequire(), react()],
  base: './',
  define: {
    // ketcher-react/ketcher-core reference the Node-style `global` object (global.currentState etc).
    global: 'globalThis',
  },
  resolve: {
    alias: {
      // ketcher-core imports the Node 'events' module; map it to the browser polyfill package.
      events: 'events',
    },
  },
  build: {
    outDir: '../2dworm/ketcher',
    emptyOutDir: true,
    target: 'es2020',
    sourcemap: false,
    // Keep the ~12 MB Indigo WASM (and everything else non-trivial) as separate files.
    assetsInlineLimit: 0,
    chunkSizeWarningLimit: 5000,
    rollupOptions: {
      output: {
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]',
      },
    },
  },
  worker: {
    // ketcher-standalone creates a module worker: new Worker(new URL('indigoWorker...js', import.meta.url), {type:'module'})
    format: 'es',
    rollupOptions: {
      output: {
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]',
      },
    },
  },
  optimizeDeps: {
    exclude: ['ketcher-standalone'],
  },
});
