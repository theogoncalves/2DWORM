// Playwright verification of the built Ketcher page embedded in an iframe.
// Usage: node test/run-test.mjs   (serves ../2dworm over http on a free port)
import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('../../2dworm/', import.meta.url));
const OUT = fileURLToPath(new URL('./out', import.meta.url));
fs.mkdirSync(OUT, { recursive: true });

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.wasm': 'application/wasm', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const requested = [];
const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = path.join(ROOT, urlPath === '/' ? 'index.html' : urlPath);
  requested.push(urlPath);
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('not found'); return; }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;
console.log('serving', ROOT, 'at', base);

const results = [];
function ok(name, detail) { results.push({ name, ok: true, detail }); console.log('PASS', name, detail ?? ''); }
function fail(name, detail) { results.push({ name, ok: false, detail }); console.log('FAIL', name, detail ?? ''); }

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const consoleErrors = [];
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') consoleErrors.push(`[${m.type()}] ${m.text()}`); });
page.on('pageerror', (e) => consoleErrors.push('[pageerror] ' + e.message));

const t0 = Date.now();
await page.goto(`${base}/ketcher-test.html`);
try {
  await page.waitForFunction(() => window.__ready === true, null, { timeout: 90000 });
  ok('ready message received', `${Date.now() - t0} ms after navigation`);
} catch (e) {
  fail('ready message received', e.message);
  console.log('console:', consoleErrors);
  await page.screenshot({ path: path.join(OUT, 'fail.png') });
  await browser.close(); server.close(); process.exit(1);
}

const frame = page.frame({ url: /ketcher\/index\.html/ }) || page.frames()[1];

// Helper: run code in the iframe with access to `ketcher`.
async function inFrame(fn, arg) { return frame.evaluate(fn, arg); }

// ---- empty canvas ----
try {
  const r = await inFrame(async () => {
    const ket = await ketcher.getKet();
    const smiles = await ketcher.getSmiles();
    let parsed = null; try { parsed = JSON.parse(ket); } catch (e) {}
    return { ket, smiles, parsedKeys: parsed ? Object.keys(parsed) : null, smilesType: typeof smiles };
  });
  if (r.parsedKeys) ok('empty canvas getKet() parseable', JSON.stringify(r.ket)); else fail('empty canvas getKet() parseable', r.ket);
  ok('empty canvas getSmiles()', `type=${r.smilesType} value=${JSON.stringify(r.smiles)}`);
} catch (e) { fail('empty canvas', e.message); }

// ---- setMolecule SMILES + exports ----
let ketOfBenzene = null;
try {
  const r = await inFrame(async () => {
    await ketcher.setMolecule('c1ccccc1CC(=O)O');
    const smiles = await ketcher.getSmiles();
    const mol2 = await ketcher.getMolfile('v2000');
    const mol3 = await ketcher.getMolfile('v3000');
    const ket = await ketcher.getKet();
    return { smiles, mol2, mol3, ket };
  });
  ketOfBenzene = r.ket;
  ok('setMolecule(SMILES) + getSmiles()', r.smiles);
  ok('getMolfile(v2000)', `${r.mol2.length} chars, has V2000: ${r.mol2.includes('V2000')}`);
  ok('getMolfile(v3000)', `${r.mol3.length} chars, has V3000: ${r.mol3.includes('V3000')}`);
  const k = JSON.parse(r.ket);
  ok('getKet()', `${r.ket.length} chars, root keys: ${Object.keys(k).join(',')}, atoms in mol0: ${k.mol0?.atoms?.length}`);
  fs.writeFileSync(path.join(OUT, 'phenylacetic.mol'), r.mol2);
  fs.writeFileSync(path.join(OUT, 'phenylacetic.ket'), r.ket);
  await page.waitForTimeout(500);
  const changes = await page.evaluate(() => window.__changeCount);
  if (changes > 0) ok('change postMessage fired after setMolecule', `count=${changes}`); else fail('change postMessage fired after setMolecule', 'count=0');
} catch (e) { fail('setMolecule/exports', e.message); }

// ---- CDXML / CDX ----
let cdxml = null, cdxB64 = null;
try {
  const r = await inFrame(async () => {
    const cdxml = await ketcher.getCDXml();
    const cdx = await ketcher.getCDX();
    let decoded = null, decodeErr = null;
    try { decoded = atob(cdx.replace(/\s/g, '')); } catch (e) { decodeErr = e.message; }
    return {
      cdxml, cdx,
      cdxType: typeof cdx, cdxLen: cdx.length,
      cdxHead: cdx.slice(0, 40),
      isBase64: /^[A-Za-z0-9+/=\s]+$/.test(cdx),
      decodedHead: decoded ? decoded.slice(0, 8) : null,
      decodedLen: decoded ? decoded.length : null,
      decodeErr,
      cdxmlHasNewline: cdxml.includes('\n'),
    };
  });
  cdxml = r.cdxml; cdxB64 = r.cdx;
  ok('getCDXml()', `${r.cdxml.length} chars, starts: ${JSON.stringify(r.cdxml.slice(0, 60))}, has newlines: ${r.cdxmlHasNewline}`);
  ok('getCDX()', `type=${r.cdxType} len=${r.cdxLen} base64=${r.isBase64} head=${JSON.stringify(r.cdxHead)} decoded header=${JSON.stringify(r.decodedHead)} decodedLen=${r.decodedLen} err=${r.decodeErr}`);
  // Write binary .cdx to disk (Node side)
  const buf = Buffer.from(r.cdx.replace(/\s/g, ''), 'base64');
  fs.writeFileSync(path.join(OUT, 'phenylacetic.cdx'), buf);
  fs.writeFileSync(path.join(OUT, 'phenylacetic.cdxml'), r.cdxml);
  ok('binary .cdx written', `${buf.length} bytes, magic=${JSON.stringify(buf.subarray(0, 8).toString('latin1'))}`);
} catch (e) { fail('getCDXml/getCDX', e.message); }

// ---- CDXML round trip ----
try {
  const r = await inFrame(async (cdxml) => {
    await ketcher.setMolecule('');
    const before = await ketcher.getSmiles();
    await ketcher.setMolecule(cdxml);
    const after = await ketcher.getSmiles();
    return { before, after };
  }, cdxml);
  if (r.after && r.after.length > 5) ok('setMolecule(cdxml) round trip', `before=${JSON.stringify(r.before)} after=${r.after}`); else fail('setMolecule(cdxml) round trip', JSON.stringify(r));
} catch (e) { fail('setMolecule(cdxml)', e.message); }

// ---- CDX (base64) round trip via setMolecule ----
try {
  const r = await inFrame(async (b64) => {
    await ketcher.setMolecule('');
    await ketcher.setMolecule(b64);
    return await ketcher.getSmiles();
  }, cdxB64);
  if (r && r.length > 5) ok('setMolecule(base64 cdx) round trip', r); else fail('setMolecule(base64 cdx) round trip', JSON.stringify(r));
} catch (e) { fail('setMolecule(base64 cdx)', e.message); }

// ---- binary .cdx file -> base64 -> setMolecule (simulating file upload) ----
try {
  const bin = fs.readFileSync(path.join(OUT, 'phenylacetic.cdx'));
  const r = await inFrame(async (bytesArr) => {
    // Simulate reading a binary .cdx File: bytes -> base64 string
    const bytes = new Uint8Array(bytesArr);
    let binStr = '';
    for (let i = 0; i < bytes.length; i += 0x8000) binStr += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    const b64 = btoa(binStr);
    await ketcher.setMolecule('');
    await ketcher.setMolecule(b64);
    return await ketcher.getSmiles();
  }, Array.from(bin));
  if (r && r.length > 5) ok('binary .cdx bytes -> btoa -> setMolecule', r); else fail('binary .cdx bytes -> btoa -> setMolecule', JSON.stringify(r));
} catch (e) { fail('binary .cdx -> setMolecule', e.message); }

// ---- indigo.convert with explicit input format ----
try {
  const r = await inFrame(async (b64) => {
    const out = {};
    try {
      const res = await ketcher.indigo.convert(b64, { inputFormat: 'chemical/x-cdx', outputFormat: 'chemical/x-daylight-smiles' });
      out.cdxToSmiles = res;
    } catch (e) { out.cdxToSmilesErr = e.message || String(e); }
    try {
      const res = await ketcher.indigo.convert('c1ccccc1', { outputFormat: 'chemical/x-cdx' });
      out.smilesToCdx = { format: res.format, structHead: res.struct.slice(0, 30), len: res.struct.length, decodedHead: atob(res.struct.slice(0, 40)).slice(0, 8) };
    } catch (e) { out.smilesToCdxErr = e.message || String(e); }
    try {
      const res = await ketcher.indigo.convert(b64, { inputFormat: 'chemical/x-cdx', outputFormat: 'chemical/x-indigo-ket' });
      out.cdxToKetWithInputFormat = res.struct.length;
    } catch (e) { out.cdxToKetWithInputFormatErr = (e.message || String(e)).slice(0, 80) + '...'; }
    try {
      // NO inputFormat: Indigo auto-detects base64 CDX
      const res = await ketcher.indigo.convert(b64, { outputFormat: 'chemical/x-indigo-ket' });
      out.cdxToKetAutoDetect = { format: res.format, ketAtoms: JSON.parse(res.struct).mol0?.atoms?.length };
      const res2 = await ketcher.indigo.convert(b64, { outputFormat: 'chemical/x-daylight-smiles' });
      out.cdxToSmilesAutoDetect = res2.struct;
      const res3 = await ketcher.indigo.convert(b64, { outputFormat: 'chemical/x-cdxml' });
      out.cdxToCdxmlAutoDetect = res3.struct.slice(0, 40);
    } catch (e) { out.autoDetectErr = e.message || String(e); }
    return out;
  }, cdxB64);
  if (r.cdxToKetAutoDetect && r.cdxToKetAutoDetect.ketAtoms === 10) ok('ketcher.indigo.convert(base64cdx) auto-detect', JSON.stringify(r)); else fail('ketcher.indigo.convert()', JSON.stringify(r));
} catch (e) { fail('ketcher.indigo.convert', e.message); }

// ---- one-line CDXML quirk (identifyStructFormat treats newline-free strings as SMILES) ----
try {
  const oneLine = cdxml.replace(/\r?\n/g, '');
  const r = await inFrame(async (oneLine) => {
    const out = {};
    try { await ketcher.setMolecule(''); await ketcher.setMolecule(oneLine); out.direct = await ketcher.getSmiles(); } catch (e) { out.directErr = (e.message || String(e)).slice(0, 120); }
    try {
      const res = await ketcher.indigo.convert(oneLine, { outputFormat: 'chemical/x-indigo-ket' });
      await ketcher.setMolecule(''); await ketcher.setMolecule(res.struct); out.viaConvert = await ketcher.getSmiles();
    } catch (e) { out.viaConvertErr = (e.message || String(e)).slice(0, 120); }
    return out;
  }, oneLine);
  ok('one-line CDXML handling', JSON.stringify(r));
} catch (e) { fail('ketcher.indigo.convert', e.message); }

// ---- generateImage ----
try {
  const r = await inFrame(async (ket) => {
    const png = await ketcher.generateImage(ket, { outputFormat: 'png' });
    const svg = await ketcher.generateImage(ket, { outputFormat: 'svg' });
    const pngBuf = new Uint8Array(await png.arrayBuffer());
    const svgText = await svg.text();
    return {
      pngIsBlob: png instanceof Blob, pngType: png.type, pngSize: png.size, pngMagic: Array.from(pngBuf.slice(0, 4)),
      svgIsBlob: svg instanceof Blob, svgType: svg.type, svgSize: svg.size, svgHead: svgText.slice(0, 60),
      pngB64: btoa(String.fromCharCode.apply(null, pngBuf)), svgText,
    };
  }, ketOfBenzene);
  if (r.pngIsBlob && r.pngMagic[1] === 0x50) ok('generateImage png', `Blob type=${r.pngType} size=${r.pngSize}`); else fail('generateImage png', JSON.stringify(r).slice(0, 200));
  if (r.svgIsBlob && r.svgHead.includes('svg')) ok('generateImage svg', `Blob type=${r.svgType} size=${r.svgSize} head=${JSON.stringify(r.svgHead)}`); else fail('generateImage svg', JSON.stringify(r).slice(0, 200));
  fs.writeFileSync(path.join(OUT, 'phenylacetic.png'), Buffer.from(r.pngB64, 'base64'));
  fs.writeFileSync(path.join(OUT, 'phenylacetic.svg'), r.svgText);
} catch (e) { fail('generateImage', e.message); }

// ---- layout ----
try {
  const r = await inFrame(async () => {
    await ketcher.setMolecule('CC(C)C(=O)N1CCCC1C(=O)O');
    const ketBefore = await ketcher.getKet();
    const res = await ketcher.layout();
    const ketAfter = await ketcher.getKet();
    return { res: String(res), changed: ketBefore !== ketAfter, smiles: await ketcher.getSmiles() };
  });
  ok('layout()', `returned=${r.res} ketChanged=${r.changed} smiles=${r.smiles}`);
} catch (e) { fail('layout', e.message); }

// ---- change event on user-like edit via editor API ----
try {
  const before = await page.evaluate(() => window.__changeCount);
  await inFrame(async () => { await ketcher.setMolecule('CCO'); });
  await page.waitForTimeout(600);
  const after = await page.evaluate(() => window.__changeCount);
  if (after > before) ok('editor change -> postMessage', `count ${before} -> ${after}`); else fail('editor change -> postMessage', `count ${before} -> ${after}`);
} catch (e) { fail('change event', e.message); }

// ---- misc API notes ----
try {
  const r = await inFrame(async () => {
    const info = await ketcher.indigo.info();
    return { indigoVersion: info.indigoVersion || JSON.stringify(info), ketcherKeys: Object.getOwnPropertyNames(Object.getPrototypeOf(ketcher)).filter(k => k !== 'constructor').join(' ') };
  });
  ok('indigo info', r.indigoVersion);
  console.log('Ketcher prototype methods:', r.ketcherKeys);
} catch (e) { fail('indigo info', e.message); }

await page.screenshot({ path: path.join(OUT, 'screenshot.png') });
console.log('\nRequested resources:', requested.filter(p => p.includes('ketcher/')).join('\n  '));
console.log('\nConsole errors/warnings (' + consoleErrors.length + '):');
for (const c of consoleErrors.slice(0, 15)) console.log('  ' + c.slice(0, 300));

const failed = results.filter(r => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify(results, null, 2));
await browser.close();
server.close();
process.exit(failed.length ? 1 : 0);
