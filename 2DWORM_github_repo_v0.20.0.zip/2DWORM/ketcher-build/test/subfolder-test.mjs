// Serve the folder above the repository so the page lives at a nested path, /2dworm/ketcher-test.html.
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const port = 8765;
const srv = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1', '--directory', fileURLToPath(new URL('../../..', import.meta.url))], { stdio: 'ignore' });
await new Promise(r => setTimeout(r, 1200));
const browser = await chromium.launch(); const page = await browser.newPage();
const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
const failed = []; page.on('requestfailed', r => failed.push(r.url())); page.on('response', r => { if (r.status() >= 400) failed.push(r.status() + ' ' + r.url()); });
await page.goto(`http://127.0.0.1:${port}/2dworm/ketcher-test.html`);
await page.waitForFunction(() => window.__ready === true, null, { timeout: 60000 });
const frame = page.frames()[1];
const smiles = await frame.evaluate(async () => { await ketcher.setMolecule('c1ccccc1'); return ketcher.getSmiles(); });
console.log('nested path OK, smiles =', smiles, '| errors:', errs, '| failed requests:', failed);
await browser.close(); srv.kill();
